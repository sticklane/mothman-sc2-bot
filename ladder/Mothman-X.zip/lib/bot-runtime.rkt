#lang racket/base

(require racket/match
         racket/list
         racket/set
         racket/math
         racket/flonum
         racket/string
         racket/performance-hint
         "../compiler/syntax.rkt"
         (only-in "sc2-types.rkt" normalize-race normalize-known-race resolve-matchup-symbol)
         (except-in "sc2-common.rkt" unit-type-sym)
         "sc2-bayesian.rkt"
         "sc2-game-constants.rkt"
         (prefix-in geo: (except-in "sc2-geometry.rkt" aabb-overlaps?))
         (prefix-in pathing: "sc2-pathing.rkt")
         (prefix-in placement: "sc2-placement.rkt")
         (prefix-in combat: "sc2-combat-eval.rkt")
         (only-in "build-orders.rkt" lookup-build-order-for-matchup)
         "sc2-logging.rkt"
         "perception-grid.rkt"
         "econ-ledger.rkt"
         "tactics-sim.rkt"
         "human-cortex.rkt"
         "mirror-mind-predictor.rkt"
         "priority-macro-brain.rkt"
         (only-in "situational-counter-planner.rkt"
                  evaluate-situational-counter-plan
                  select-situational-upgrades
                  situational-counter-plan-primary-situation
                  situational-counter-plan-active-situations
                  situational-counter-plan-recommended-upgrades
                  situational-counter-plan-ability-actions))

(provide
 WORKER-AND-NONCOMBAT-SYMS
 PRO-CHRONO-11-STRUCTURES
 (struct-out live-bot-runtime)
 (struct-out random-stealth-harass-plan)
 (struct-out sc2-tech-node)
 (struct-out plan-goal-node)
 (struct-out dynamic-macro-plan)
 (struct-out macro-world-state)
 (struct-out macro-brain-decision)
 SC2-TECH-GRAPH
 lookup-sc2-tech-node
 find-all-broken-tech-dependencies
 translate-goal-to-next-action
 synthesize-dynamic-macro-plan
 macro-brain-decision-dynamic-plan
 make-macro-world-state
 obs-hash->macro-world-state
 step-priority-macro-brain
 macro-brain-can-spend?
 make-live-bot-runtime
 evaluate-random-stealth-harass-plan
 step-layer1-perception!
 step-layer1b-mastermind!
 step-layer1c-mirror-mind!
 step-layer2-economy!
 step-layer3-and-4-tactics!
 step-layer5-human-cortex!
 step-pro-human-camera-and-apm-governor!
 step-live-bot-runtime!
 parse-frame-state-sexp
 runtime-step-sexp!
 sanitize-stale-target-actions
 filter-rush-threat-enemies
 select-target-enemy-for-unit
 compute-next-posture
 DEC-GOAL-STREAMS
 (struct-out race-bank-target)
 (struct-out stream-budget-slice)
 (struct-out decoupled-bank-allocation)
 (struct-out max-supply-plan)
 compute-bank-targets
 allocate-decoupled-goal-streams
 decoupled-stream-can-spend?
 evaluate-max-supply-manager
 NON-COMBAT-AND-SCOUT-ENEMY-SYMS
 combat-unit-record?
 rt-role-leases
 rt-bistable-states
 rt-scout-state
 rt-spotter-lings
 rt-tumor-state
 rt-door-state
 rt-splash-state
 rt-wall-state
 rt-disruptor-tracker
 rt-spell-claims
 rt-unit-mode-tracker
 rt-transport-tracker
 reset-wave3-tactical-state!
 bayesian-posterior-from-likelihoods
 compute-bayesian-pad-camped-posterior
 worker-carrying-minerals-or-gas?
 select-far-mineral-patch-non-carrying-worker)

(define-inline (unit-type-sym u)
  (cond
    [(hash? u)
     (define raw (hash-ref u 'type 'unknown))
     (cond
       [(symbol? raw) raw]
       [(string? raw) (string->symbol (string-downcase raw))]
       [else 'unknown])]
    [(symbol? u) u]
    [(string? u) (string->symbol (string-downcase u))]
    [else 'unknown]))

;; Per-runtime weak map caching last-known `(cons x y)` coordinates for enemy UnitTags
;; so stale/dead/snapshot target tags (`ActionResult=207 Error_CantTargetThatUnit`) downgrade
;; cleanly to `(attack-pos uid last-x last-y)` instead of failing in SC2!
;; Per-runtime weak-hash state accessors preserving `(struct live-bot-runtime ...)`
;; positional arity while lazily initializing each per-instance container.
(define-syntax-rule (define-rt-weak-state accessor-name init-expr)
  (define accessor-name
    (let ([tbl (make-weak-hasheq)])
      (lambda (rt)
        (hash-ref! tbl rt (lambda () init-expr))))))

(define (make-resettable-rt-weak-state init-fn)
  (define tbl (make-weak-hasheq))
  (values (lambda (rt) (hash-ref! tbl rt init-fn))
          (lambda (rt) (hash-set! tbl rt (init-fn)))))

(define-rt-weak-state rt-enemy-pos-cache (make-hasheqv))

(define-rt-weak-state rt-role-leases        (make-hasheqv))
(define-rt-weak-state rt-bistable-states    (make-hash))
(define-rt-weak-state rt-scout-state        (make-hasheq))
(define-rt-weak-state rt-spotter-lings      (make-hasheq))
(define-rt-weak-state rt-tumor-state        (make-hasheqv))
(define-rt-weak-state rt-door-state         (make-hasheq))
(define-rt-weak-state rt-splash-state       (make-hash))
(define-rt-weak-state rt-wall-aabbs-box     (box '()))
(define-rt-weak-state rt-enemy-race-box     (box 'Unknown))
(define-rt-weak-state rt-initial-enemy-race-box (box #f))
(define-rt-weak-state rt-experiment-box     (box #f))
(define-rt-weak-state rt-creep-tracker      (make-creep-spread-tracker))
(define-rt-weak-state rt-burrow-tracker     (make-burrow-dodge-tracker))
(define-rt-weak-state rt-bayes-cache        (make-vector 30 #f))
(define-rt-weak-state rt-map-elem-tracker   (make-map-element-tracker))
(define-rt-weak-state rt-simcity-cache      (make-hash))
(define-rt-weak-state rt-sit-plan-cache     (box #f))
(define-rt-weak-state rt-wall-state         (make-hasheq))
(define-rt-weak-state rt-rush-defense-state (make-hasheqv))
(define-rt-weak-state rt-wave3-frame-box    (box -1))
(define-rt-weak-state rt-l2-scratch         (make-hasheq))
(define-rt-weak-state rt-macro-bundle-cache (box #f))
(define-rt-weak-state rt-l34-scratch        (make-hasheq))
(define-rt-weak-state rt-l5-scratch         (make-hasheq))
(define-rt-weak-state rt-l1b-cache          (box #f))

(define (pooled-hasheq! scratch key)
  (let ([ht (hash-ref scratch key #f)])
    (if (hash? ht)
        (begin (hash-clear! ht) ht)
        (let ([nht (make-hasheq)])
          (hash-set! scratch key nht)
          nht))))

(define (pooled-hasheqv! scratch key)
  (let ([ht (hash-ref scratch key #f)])
    (if (hash? ht)
        (begin (hash-clear! ht) ht)
        (let ([nht (make-hasheqv)])
          (hash-set! scratch key nht)
          nht))))

(define (pooled-mutable-set! scratch key)
  (let ([s (hash-ref scratch key #f)])
    (if s
        (begin (set-clear! s) s)
        (let ([ns (mutable-set)])
          (hash-set! scratch key ns)
          ns))))

(define (pooled-mutable-seteqv! scratch key)
  (let ([s (hash-ref scratch key #f)])
    (if s
        (begin (set-clear! s) s)
        (let ([ns (mutable-seteqv)])
          (hash-set! scratch key ns)
          ns))))

(define (pooled-mutable-seteq! scratch key)
  (let ([s (hash-ref scratch key #f)])
    (if s
        (begin (set-clear! s) s)
        (let ([ns (mutable-seteq)])
          (hash-set! scratch key ns)
          ns))))

(define (mutable-hasheq-matches-immut? mht immut)
  (and (hash? immut)
       (= (hash-count mht) (hash-count immut))
       (for/and ([(k v) (in-hash mht)])
         (equal? (hash-ref immut k RUNTIME-MISSING) v))))

(define (reuse-or-freeze-hasheq! scratch key mht)
  (define cached (hash-ref scratch key #f))
  (if (mutable-hasheq-matches-immut? mht cached)
      cached
      (let ([frozen (for/hasheq ([(k v) (in-hash mht)]) (values k v))])
        (hash-set! scratch key frozen)
        frozen)))

(define-values (rt-disruptor-tracker reset-rt-disruptor-tracker!)
  (make-resettable-rt-weak-state make-disruptor-tactical-tracker))
(define-values (rt-spell-claims reset-rt-spell-claims!)
  (make-resettable-rt-weak-state make-spell-claims))
(define-values (rt-unit-mode-tracker reset-rt-unit-mode-tracker!)
  (make-resettable-rt-weak-state make-unit-mode-tracker))
(define-values (rt-transport-tracker reset-rt-transport-tracker!)
  (make-resettable-rt-weak-state make-transport-tracker))

(define (reset-wave3-tactical-state! rt)
  (reset-rt-disruptor-tracker! rt)
  (reset-rt-spell-claims! rt)
  (reset-rt-unit-mode-tracker! rt)
  (reset-rt-transport-tracker! rt)
  (set-box! (rt-wave3-frame-box rt) -1)
  (set-box! (rt-macro-bundle-cache rt) #f)
  (set-box! (rt-l1b-cache rt) #f)
  (let ([s (rt-l2-scratch rt)]) (when (hash? s) (hash-clear! s)))
  (let ([s (rt-l34-scratch rt)]) (when (hash? s) (hash-clear! s)))
  (let ([s (rt-l5-scratch rt)]) (when (hash? s) (hash-clear! s)))
  (let ([st (rt-splash-state rt)])
    (when (hash? st)
      (for ([k (in-list (hash-keys st))])
        (when (or (pair? k)
                  (memq k '(disruptor-directive-frame
                            disruptor-directive-set
                            wave3-preserved-frame
                            wave3-preserved-set
                            wm-disarmed-ht
                            mode-dwell-ht
                            wm-dwell-ht
                            lib-dwell-ht
                            vik-dwell-ht
                            thor-dwell-ht
                            bc-jump-ready-ht
                            bc-yamato-ready-ht
                            tank-dwell-ht)))
          (hash-remove! st k)))))
  (void))

(define ORDER-PROT-CACHE (make-hasheqv))
(define CAN-ATK-AIR-CACHE (make-hasheq))
(define CAN-ATK-GND-CACHE (make-hasheq))
(define UNIT-FLYING-SYM-CACHE (make-hasheq))
(define UNIT-DETECTOR-SYM-CACHE (make-hasheq))
(define CANON-STRUCT-CACHE (make-hasheq))
(define CANON-UNIT-CACHE (make-hasheq))
(define UNIT-COMBAT-STATS-CACHE (make-hasheq))
(define RES-COST-50-CACHE (make-hasheq))
(define RES-COST-100-CACHE (make-hasheq))
(define ENEMY-SYM-FLAGS-CACHE (make-hasheq))
(define HEAVY-SIEGE-CACHE (make-hasheq))
(define EQUIV-SYMS-NO-ADDONS-CACHE (make-hasheq))
(define EQUIV-SYMS-ADDONS-CACHE (make-hasheq))
(define REQ-PYLON-POWER-CACHE (make-hasheq))
(define BUILD-ISSUE-LOCK-KEY-CACHE (make-hasheq))
(define SAVE-CANCEL-REBUILD-KEY-CACHE (make-hasheq))

(define PRESERVED-ECON-HEAD-SET
  (hasheq 'pull-workers-attack #t
          'mineral-walk #t
          'rebalance-gas-to-minerals #t
          'terran-addon-swap #t
          'land-building #t
          'lift #t
          'cancel-building #t
          'inject-larva #t
          'worker-scout #t
          'overlord-scout #t
          'mineral-harass #t
          'periodic-scout #t
          'cast-deception-and-scout-spells #t))

(define PRESERVED-ECON-CAST-SET
  (hasheq 'inject-larva #t
          'battery-overcharge #t
          'lift #t
          'spawn-creep-tumor #t
          'spread-creep-tumor #t
          'morph-supply-depot-raise #t
          'morph-supply-depot-lower #t))

(define PRESERVED-TACTIC-HEAD-SET
  (hasheq 'snipe-enemy-changeling #t
          'cast-deception-and-scout-spells #t
          'cast-protective-buff-aura #t
          'position-in-buff-aura-with-splash-spread #t
          'pre-split-wings #t
          'form-concave-arc #t
          'high-ground-tactics #t
          'execute-spatial-maneuver #t
          'burrow-down #t
          'burrow-up #t
          'burrow-block #t
          'patrol-block-expansion #t
          'harass-workers #t
          'periodic-scout #t
          'roach-tunnel-move #t
          'infestor-burrow-move #t
          'infestor-burrow-cast #t
          'blind-skillshot-shimmer #t
          'emergency-detector-response #t))

(define PRESERVED-TACTIC-CAST-SET
  (hasheq 'purification-nova #t
          'blink #t
          'morph-thor-high-impact #t
          'morph-thor-high-impact-mode #t
          'morph-thor-explosive #t
          'morph-thor-explosive-mode #t
          'morph-viking-fighter #t
          'morph-viking-assault #t))

(define TERRAN-ADDON-BLDG-SET
  (hasheq 'barracks-techlab #t 'barracks-tech-lab #t 'barracks-reactor #t
          'factory-techlab #t 'factory-tech-lab #t 'factory-reactor #t
          'starport-techlab #t 'starport-tech-lab #t 'starport-reactor #t
          'tech-lab #t 'techlab #t 'reactor #t))

(define ZERG-SHALLOW-BURROW-SET
  (hasheq 'roach-burrowed #t 'infestor-burrowed #t 'lurker-burrowed #t 'lurker-mp-burrowed #t
          'zergling-burrowed #t 'baneling-burrowed #t 'drone-burrowed #t 'queen-burrowed #t
          'widow-mine-burrowed #t))

(define (fast-structure-equivalent-syms bldg-sym [include-free-addons? #f])
  (define tbl (if include-free-addons? EQUIV-SYMS-ADDONS-CACHE EQUIV-SYMS-NO-ADDONS-CACHE))
  (or (hash-ref tbl bldg-sym #f)
      (let ([v (remove-duplicates (sc2-structure-equivalent-syms bldg-sym include-free-addons?) eq?)])
        (hash-set! tbl bldg-sym v)
        v)))

(define (fast-requires-pylon-power? sym)
  (let ([v (hash-ref REQ-PYLON-POWER-CACHE sym 'miss)])
    (if (eq? v 'miss)
        (let ([r (sc2-structure-requires-pylon-power? sym)])
          (hash-set! REQ-PYLON-POWER-CACHE sym r)
          r)
        v)))

(define (fast-build-issue-lock-key cs)
  (or (hash-ref BUILD-ISSUE-LOCK-KEY-CACHE cs #f)
      (let ([k (list 'build-issue-lock cs)])
        (hash-set! BUILD-ISSUE-LOCK-KEY-CACHE cs k)
        k)))

(define (fast-save-cancel-rebuild-key cs)
  (or (hash-ref SAVE-CANCEL-REBUILD-KEY-CACHE cs #f)
      (let ([k (string->symbol (format "save-cancel-rebuild-~a" cs))])
        (hash-set! SAVE-CANCEL-REBUILD-KEY-CACHE cs k)
        k)))

(define RUNTIME-MISSING (string->uninterned-symbol "runtime-missing"))

(define (fast-enemy-sym-flags sym)
  (or (hash-ref ENEMY-SYM-FLAGS-CACHE sym #f)
      (let ([flags (+ (if (hash-ref RUNTIME-UNTARGETABLE-SET sym #f) 1 0)
                      (if (hash-ref RUNTIME-CHANGELING-SET sym #f) 2 0)
                      (if (hash-ref RUNTIME-MOBILE-DET-SET sym #f) 4 0)
                      (if (hash-ref RUNTIME-STATIC-DET-SET sym #f) 8 0)
                      (if (hash-ref RUNTIME-PASSIVE-DECOY-SET sym #f) 16 0)
                      (if (hash-ref RUNTIME-STRUCT-SYM-SET sym #f) 32 0)
                      (if (hash-ref RUNTIME-LIGHT-BIO-SET sym #f) 64 0)
                      (if (hash-ref RUNTIME-ARMORED-SET sym #f) 128 0)
                      (if (fast-unit-is-flying-sym? sym) 256 0))])
        (hash-set! ENEMY-SYM-FLAGS-CACHE sym flags)
        flags)))

(define (fast-finite-real v default)
  (if (and (real? v) (= (- v v) 0))
      v
      default))

(define (fast-res-cost-50 sym)
  (or (hash-ref RES-COST-50-CACHE sym #f)
      (let ([c (+ (sc2-min-cost sym 50) (sc2-gas-cost sym 0))])
        (hash-set! RES-COST-50-CACHE sym c)
        c)))

(define (fast-res-cost-100 sym)
  (or (hash-ref RES-COST-100-CACHE sym #f)
      (let ([c (+ (sc2-min-cost sym 100) (sc2-gas-cost sym 0))])
        (hash-set! RES-COST-100-CACHE sym c)
        c)))

(define (fast-order-protection-class ab-id)
  (if (or (not (exact-integer? ab-id)) (<= ab-id 0))
      'idle
      (let ([v (hash-ref ORDER-PROT-CACHE ab-id #f)])
        (or v
            (let ([c (sc2-order-protection-class ab-id)])
              (hash-set! ORDER-PROT-CACHE ab-id c)
              c)))))

(define (fast-can-attack-air? sym)
  (let ([v (hash-ref CAN-ATK-AIR-CACHE sym 'miss)])
    (if (eq? v 'miss)
        (let ([c (sc2-unit-can-attack-air? sym)])
          (hash-set! CAN-ATK-AIR-CACHE sym c)
          c)
        v)))

(define (fast-can-attack-ground? sym)
  (let ([v (hash-ref CAN-ATK-GND-CACHE sym 'miss)])
    (if (eq? v 'miss)
        (let ([c (sc2-unit-can-attack-ground? sym)])
          (hash-set! CAN-ATK-GND-CACHE sym c)
          c)
        v)))

(define (fast-unit-is-flying-sym? sym)
  (let ([v (hash-ref UNIT-FLYING-SYM-CACHE sym 'miss)])
    (if (eq? v 'miss)
        (let ([c (sc2-unit-is-flying-sym? sym)])
          (hash-set! UNIT-FLYING-SYM-CACHE sym c)
          c)
        v)))

(define (fast-unit-is-detector-sym? sym)
  (let ([v (hash-ref UNIT-DETECTOR-SYM-CACHE sym 'miss)])
    (if (eq? v 'miss)
        (let ([c (sc2-unit-is-detector-sym? sym)])
          (hash-set! UNIT-DETECTOR-SYM-CACHE sym c)
          c)
        v)))

(define (fast-canonical-structure-sym sym)
  (if (symbol? sym)
      (let ([v (hash-ref CANON-STRUCT-CACHE sym #f)])
        (or v
            (let ([c (sc2-canonical-structure-sym sym)])
              (hash-set! CANON-STRUCT-CACHE sym c)
              c)))
      'unknown))

(define (fast-canonical-unit-sym sym)
  (if (symbol? sym)
      (let ([v (hash-ref CANON-UNIT-CACHE sym #f)])
        (or v
            (let ([c (sc2-canonical-unit-sym sym)])
              (hash-set! CANON-UNIT-CACHE sym c)
              c)))
      'unknown))

(define (fast-unit-combat-stats sym)
  (let ([v (hash-ref UNIT-COMBAT-STATS-CACHE sym #f)])
    (or v
        (let ([c (sc2-unit-combat-stats sym)])
          (hash-set! UNIT-COMBAT-STATS-CACHE sym c)
          c))))

(define (unit-total-hp-and-shield u [default-hp SC2-DRONE-MAX-HP])
  (if (not (eq? (hash-ref u 'hull-hp RUNTIME-MISSING) RUNTIME-MISSING))
      (hash-ref u 'hp default-hp)
      (+ (hash-ref u 'hp default-hp)
         (hash-ref u 'shield 0))))

(define RUNTIME-STRUCT-SYM-SET
  (for/hasheq ([s (in-list SC2-ALL-STRUCTURE-SYMS)]) (values s #t)))
(define RUNTIME-TOWNHALL-SYM-SET
  (for/hasheq ([s (in-list SC2-TOWNHALL-STRUCTURE-SYMS)]) (values s #t)))
(define RUNTIME-UNTARGETABLE-SET
  (for/hasheq ([s (in-list SC2-UNTARGETABLE-OR-DECOY-UNIT-SYMS)]) (values s #t)))
(define RUNTIME-CHANGELING-SET
  (for/hasheq ([s (in-list SC2-CHANGELING-UNIT-SYMS)]) (values s #t)))
(define RUNTIME-MOBILE-DET-SET
  (for/hasheq ([s (in-list SC2-MOBILE-DETECTOR-SYMS)]) (values s #t)))
(define RUNTIME-STATIC-DET-SET
  (for/hasheq ([s (in-list SC2-STATIC-DETECTOR-SYMS)]) (values s #t)))
(define RUNTIME-PASSIVE-DECOY-SET
  (for/hasheq ([s (in-list SC2-PASSIVE-SCOUT-OR-DECOY-UNIT-SYMS)]) (values s #t)))
(define RUNTIME-STEALTH-SET
  (for/hasheq ([s (in-list SC2-CLOAKED-OR-BURROW-STEALTH-SYMS)]) (values s #t)))
(define RUNTIME-LIGHT-BIO-SET
  (hasheq 'marine #t 'zergling #t 'zealot #t 'adept #t 'hydralisk #t
          'probe #t 'scv #t 'drone #t 'reaper #t 'hellion #t 'sentry #t
          'high-templar #t 'ghost #t))
(define RUNTIME-ARMORED-SET
  (hasheq 'marauder #t 'roach #t 'stalker #t 'immortal #t 'siege-tank #t
          'siege-tank-sieged #t 'thor #t 'ultralisk #t 'colossus #t))
(define RUNTIME-SPELLCASTER-SET
  (hasheq 'ghost #t 'raven #t 'battlecruiser #t 'high-templar #t 'sentry #t
          'oracle #t 'queen #t 'ravager #t 'infestor #t 'viper #t))
(define RUNTIME-UNIT-MODE-SET
  (hasheq 'thor #t 'thor-ap #t 'hellion #t 'hellbat #t 'viking #t
          'viking-fighter #t 'viking-assault #t 'cyclone #t))
(define RUNTIME-STATIC-DEFENSE-SET
  (hasheq 'spine-crawler #t 'photon-cannon #t 'bunker #t 'planetary-fortress #t))
(define RUNTIME-SHORT-BIO-SET
  (hasheq 'marine #t 'marauder #t 'zergling #t 'roach #t 'hydralisk #t
          'zealot #t 'stalker #t 'adept #t))
(define RUNTIME-WORKER-SET
  (hasheq 'drone #t 'probe #t 'scv #t))
(define RUNTIME-SPOTTER-SET
  (hasheq 'overseer #t 'observer #t 'phoenix #t 'oracle #t 'void-ray #t 'voidray #t
          'viking #t 'viking-fighter #t 'medivac #t 'liberator #t 'liberator-ag #t
          'raven #t 'banshee #t 'mutalisk #t 'corruptor #t 'viper #t 'warp-prism #t))
(define RUNTIME-IMMOBILE-BILE-SET
  (hasheq 'siege-tank-sieged #t 'widow-mine-burrowed #t 'liberator-ag #t
          'planetary-fortress #t 'bunker #t 'photon-cannon #t 'spine-crawler #t))
(define RUNTIME-MASSIVE-AC-SET
  (hasheq 'brood-lord #t 'broodlord #t 'tempest #t 'carrier #t 'battlecruiser #t
          'colossus #t 'mothership #t 'liberator #t 'liberator-ag #t
          'void-ray #t 'voidray #t 'corruptor #t))
(define RUNTIME-SIEGE-BREAKER-SET
  (hasheq 'viper #t 'brood-lord #t 'tempest #t 'liberator #t 'liberator-ag #t 'disruptor #t))
(define RUNTIME-HEAVY-SB-SET
  (hasheq 'ravager #t 'lurker #t 'lurker-burrowed #t 'ultralisk #t
          'siege-tank #t 'siege-tank-sieged #t 'colossus #t))
(define RUNTIME-SIEGE-SUPP-SET
  (hasheq 'siege-tank #t 'siege-tank-sieged #t 'liberator #t 'liberator-ag #t
          'brood-lord #t 'tempest #t 'ravager #t 'lurker #t 'lurker-burrowed #t))
(define RUNTIME-STATIC-DEFVAL-SET
  (hasheq 'planetary-fortress #t 'bunker #t 'photon-cannon #t 'spine-crawler #t))
(define RUNTIME-RT-CHANGELING-SET
  (hasheq 'changeling #t 'changeling-zealot #t 'changeling-marine #t
          'changeling-marine-shield #t 'changeling-zergling #t
          'changeling-zergling-wings #t))
(define RUNTIME-ZERG-BRUISED-BURROW-SET
  (hasheq 'roach #t 'zergling #t 'hydralisk #t 'baneling #t
          'ravager #t 'lurker #t 'lurker-mp #t 'infestor #t))
(define RUNTIME-ZERG-ALREADY-BURROWED-SET
  (hasheq 'roach-burrowed #t 'zergling-burrowed #t 'hydralisk-burrowed #t
          'baneling-burrowed #t 'ravager-burrowed #t 'lurker-burrowed #t
          'lurker-mp-burrowed #t 'infestor-burrowed #t))
(define RUNTIME-SWARM-HOST-LOCUST-SET
  (hasheq 'swarm-host #t 'swarm-host-burrowed #t 'locust #t 'locust-flying #t))
(define RUNTIME-ENEMY-BURROW-COUNTER-SET
  (hasheq 'swarm-host #t 'swarm-host-burrowed #t 'locust #t 'locust-flying #t
          'lurker-burrowed #t 'lurker-mp-burrowed #t 'roach-burrowed #t
          'zergling-burrowed #t 'infestor-burrowed #t 'baneling-burrowed #t
          'widow-mine-burrowed #t))
(define RUNTIME-ENEMY-STATIC-DET-SET
  (hasheq 'photon-cannon #t 'missile-turret #t 'spore-crawler #t))
(define RUNTIME-TUMOR-SET
  (hasheq 'creep-tumor #t 'creep-tumor-burrowed #t 'creep-tumor-queen #t))
(define RUNTIME-ALLY-HARASS-SET
  (hasheq 'baneling #t 'baneling-burrowed #t 'adept #t 'widow-mine #t
          'widow-mine-burrowed #t 'medivac #t 'oracle #t 'raven #t
          'viking-fighter #t 'viking-assault #t 'zergling #t 'hellion #t
          'reaper #t 'zealot #t))
(define RUNTIME-ENEMY-HARASS-SET
  (hasheq 'baneling #t 'baneling-burrowed #t 'adept #t 'widow-mine #t
          'widow-mine-burrowed #t 'medivac #t 'warp-prism #t 'oracle #t 'raven #t
          'mutalisk #t 'banshee #t 'liberator #t 'zergling #t 'hellion #t 'reaper #t))
(define RUNTIME-STATIC-DEF-AND-NYDUS-SET
  (hasheq 'photon-cannon #t 'shield-battery #t 'bunker #t 'missile-turret #t
          'planetary-fortress #t 'nydus-network #t 'nydus-canal #t 'nydus-worm #t
          'spine-crawler #t 'spine-crawler-uprooted #t 'spore-crawler #t
          'spore-crawler-uprooted #t 'swarm-host #t 'swarm-host-burrowed #t))
(define RUNTIME-ALLY-MAP-ELEM-RECALL-SET
  (hasheq 'warp-prism #t 'warp-prism-phasing #t 'nexus #t 'mothership #t
          'medivac #t 'overlord-transport #t 'dropperlord #t))
(define RUNTIME-ENEMY-MAP-ELEM-RECALL-SET
  (hasheq 'warp-prism #t 'warp-prism-phasing #t 'mothership #t))
(define RUNTIME-ALLY-UNWALLED-PUNISH-SET
  (hasheq 'zergling #t 'adept #t 'hellion #t 'hellion-tank #t 'reaper #t))
(define RUNTIME-WALL-BLOCK-BLDG-SET
  (hasheq 'engineering-bay #t 'pylon #t 'hatchery #t 'refinery #t 'assimilator #t 'extractor #t))
(define RUNTIME-NON-COMBAT-HARASS-SKIP-SET
  (hasheq 'drone #t 'scv #t 'probe #t 'drone-burrowed #t
          'larva #t 'egg #t 'cocoon #t 'overlord #t 'overlord-cocoon #t
          'mule #t 'creep-tumor #t 'creep-tumor-burrowed #t 'creep-tumor-queen #t))

(define (fast-enemy-unit-targetable? e)
  (cond
    [(hash? e)
     (define ty (hash-ref e 'type 'unknown))
     (and (not (hash-ref RUNTIME-UNTARGETABLE-SET ty #f))
          (not (eq? (hash-ref e 'hallucination #f) #t)))]
    [(symbol? e) (not (hash-ref RUNTIME-UNTARGETABLE-SET e #f))]
    [else #t]))

(define (fast-attacker-can-hit-enemy? attacker-sym e)
  (define et (hash-ref e 'type 'marine))
  (define eflying?
    (or (eq? (hash-ref e 'flying #f) #t)
        (eq? (hash-ref e 'flying? #f) #t)
        (eq? (hash-ref e 'is-flying #f) #t)
        (fast-unit-is-flying-sym? et)))
  (and (fast-enemy-unit-targetable? e)
       (if eflying?
           (fast-can-attack-air? attacker-sym)
           (fast-can-attack-ground? attacker-sym))))

;; Pure racket/base 1-to-1 macro energy dispatcher eliminating Typed/Untyped higher-order hash copies.
(define (fast-dispatch-macro-energy! casters candidates frame claimed-targets-set
                                      #:min-energy min-energy
                                      #:valid-caster? [valid-caster? #f]
                                      #:valid-pair? valid-pair?
                                      #:score-pair score-pair
                                      #:emit-cast! emit-cast!)
  (define local-claimed-casters (make-hash))
  (define local-claimed-targets (make-hash))
  (define (entity-key x)
    (if (hash? x) (or (hash-ref x 'id #f) (hash-ref x 'tag #f) x) x))
  (define (target-claimed? tkey raw-cand)
    (or (hash-ref local-claimed-targets tkey #f)
        (cond
          [(set-mutable? claimed-targets-set)
           (or (set-member? claimed-targets-set tkey)
               (set-member? claimed-targets-set raw-cand))]
          [(set? claimed-targets-set)
           (or (set-member? claimed-targets-set tkey)
               (set-member? claimed-targets-set raw-cand))]
          [(hash? claimed-targets-set)
           (or (not (eq? (hash-ref claimed-targets-set tkey RUNTIME-MISSING) RUNTIME-MISSING))
               (not (eq? (hash-ref claimed-targets-set raw-cand RUNTIME-MISSING) RUNTIME-MISSING)))]
          [else #f])))
  (define (claim-target! tkey)
    (hash-set! local-claimed-targets tkey #t)
    (cond
      [(set-mutable? claimed-targets-set) (set-add! claimed-targets-set tkey)]
      [(and (hash? claimed-targets-set) (not (immutable? claimed-targets-set)))
       (hash-set! claimed-targets-set tkey frame)]
      [else (void)]))
  (define eligible-casters
    (for/list ([c (in-list casters)]
               #:when (and (or (not (hash? c))
                               (let ([en (hash-ref c 'energy 0.0)])
                                 (and (real? en) (>= en min-energy))))
                           (or (not valid-caster?) (valid-caster? c))))
      c))
  (define scored-pairs
    (for*/fold ([acc '()])
               ([c (in-list eligible-casters)]
                [cand (in-list candidates)])
      (define tkey (entity-key cand))
      (if (and (not (target-claimed? tkey cand))
               (valid-pair? c cand))
          (let ([sc (score-pair c cand)])
            (if (and (real? sc) (not (nan? sc)) (not (infinite? sc)))
                (cons (vector (exact->inexact sc) c cand (entity-key c) tkey) acc)
                acc))
          acc)))
  (define sorted-pairs (sort scored-pairs (lambda (a b) (> (vector-ref a 0) (vector-ref b 0)))))
  (define emitted '())
  (for ([v (in-list sorted-pairs)])
    (define c (vector-ref v 1))
    (define cand (vector-ref v 2))
    (define ckey (vector-ref v 3))
    (define tkey (vector-ref v 4))
    (unless (or (hash-ref local-claimed-casters ckey #f)
                (target-claimed? tkey cand))
      (hash-set! local-claimed-casters ckey #t)
      (claim-target! tkey)
      (define res (emit-cast! c cand))
      (when (and res (not (void? res)))
        (set! emitted (cons res emitted)))))
  (reverse emitted))

(define (worker-has-engine-build-order? w)
  (and (hash? w)
       (or (eq? (hash-ref w 'has-build-order? #f) #t)
           (memq (hash-ref w 'order-kind #f) '(build expand))
           (let ([ab-id (hash-ref w 'order-ability-id 0)])
             (and (exact-integer? ab-id)
                  (> ab-id 0)
                  (eq? (fast-order-protection-class ab-id) 'build-structure))))
       #t))

(define CARRYING-BUFF-SYMS
  (set 271 272 273 274 275 276
       'carry-mineral-field-minerals
       'carry-high-yield-mineral-field-minerals
       'carry-harvestable-vespene-geyser-gas
       'carry-vespene-geyser-gas
       'carry-vespene-geyser-gas-protoss
       'carry-vespene-geyser-gas-zerg
       'carry-rich-vespene-geyser-gas
       'carry-protoss-vespene-geyser-gas
       'carry-zerg-vespene-geyser-gas))

(define CARRYING-GAS-BUFF-SYMS
  (set 273 274 275 276
       'carry-harvestable-vespene-geyser-gas
       'carry-vespene-geyser-gas
       'carry-vespene-geyser-gas-protoss
       'carry-vespene-geyser-gas-zerg
       'carry-rich-vespene-geyser-gas
       'carry-protoss-vespene-geyser-gas
       'carry-zerg-vespene-geyser-gas))

;; Checks all SC2 HARVEST_RETURN ability IDs (167 MULE, 296 SCV, 299 Probe, 1184 Drone, 3667 generic);
;; note 295/298/1183/3666 are HARVEST_GATHER so empty-handed miners walking to patches stay non-carrying.
(define HARVEST-RETURN-ABILITY-IDS '(167 296 299 1184 3667))
(define HARVEST-RETURN-ABILITY-SYMS
  '(harvest-return harvest-return-drone harvest-return-scv harvest-return-probe))
(define GAS-TARGET-TYPE-SYMS
  '(vespene-geyser rich-vespene-geyser space-platform-geyser protoss-vespene-geyser
    purifiers-vespene-geyser shakuras-vespene-geyser extractor assimilator refinery))

(define (worker-list-has-set-member? xs st)
  (and (list? xs)
       (for/or ([x (in-list xs)])
         (set-member? st x))))

(define (worker-carrying-minerals-or-gas? w)
  (and (hash? w)
       (or (eq? (hash-ref w 'carrying-minerals? #f) #t)
           (eq? (hash-ref w 'carrying-resource? #f) #t)
           (eq? (hash-ref w 'carrying? #f) #t)
           (eq? (hash-ref w 'carrying-cargo? #f) #t)
           (eq? (hash-ref w 'has-cargo? #f) #t)
           (let ([ab-id (hash-ref w 'order-ability-id 0)])
             (and (exact-integer? ab-id)
                  (memv ab-id HARVEST-RETURN-ABILITY-IDS)
                  #t))
           (let ([ab-sym (hash-ref w 'order-ability-sym #f)])
             (and ab-sym (memq ab-sym HARVEST-RETURN-ABILITY-SYMS) #t))
           (let ([ab-sym2 (hash-ref w 'order-ability #f)])
             (and ab-sym2 (memq ab-sym2 HARVEST-RETURN-ABILITY-SYMS) #t))
           (worker-list-has-set-member? (hash-ref w 'buffs #f) CARRYING-BUFF-SYMS)
           (worker-list-has-set-member? (hash-ref w 'buff-ids #f) CARRYING-BUFF-SYMS)
           (let ([ords (hash-ref w 'orders #f)])
             (and (pair? ords)
                  (hash? (car ords))
                  (let* ([o0 (car ords)]
                         [oid (or (hash-ref o0 'ability_id #f)
                                  (hash-ref o0 'ability-id 0))]
                         [osym (or (hash-ref o0 'ability-sym #f)
                                   (hash-ref o0 'ability #f))])
                    (or (and (exact-integer? oid) (memv oid HARVEST-RETURN-ABILITY-IDS))
                        (and osym (memq osym HARVEST-RETURN-ABILITY-SYMS)))))))))

(define (worker-harvesting-gas? w)
  (and (hash? w)
       (or (eq? (hash-ref w 'on-gas? #f) #t)
           (eq? (hash-ref w 'harvesting-gas? #f) #t)
           (eq? (hash-ref w 'resource-kind #f) 'gas)
           (and (memq (hash-ref w 'role #f) '(gas geyser extractor assimilator refinery gas-harvester)) #t)
           (and (memq (hash-ref w 'order-target-type #f) GAS-TARGET-TYPE-SYMS) #t)
           (worker-list-has-set-member? (hash-ref w 'buffs #f) CARRYING-GAS-BUFF-SYMS)
           (worker-list-has-set-member? (hash-ref w 'buff-ids #f) CARRYING-GAS-BUFF-SYMS))))

(define (select-far-mineral-patch-non-carrying-worker workers base-x base-y [mineral-patches '()])
  (cond
    [(or (not (list? workers)) (null? workers)) #f]
    [(null? (cdr workers)) (car workers)]
    [else
     (define fbx (if (flonum? base-x) base-x (exact->inexact base-x)))
     (define fby (if (flonum? base-y) base-y (exact->inexact base-y)))
     (define non-carrying
       (for/list ([w (in-list workers)]
                  #:when (and (hash? w) (not (worker-carrying-minerals-or-gas? w))))
         w))
     (define pool0 (if (pair? non-carrying) non-carrying workers))
     (define non-gas
       (for/list ([w (in-list pool0)]
                  #:when (and (hash? w) (not (worker-harvesting-gas? w))))
         w))
     (define cands (if (pair? non-gas) non-gas pool0))
     (define near-patches
       (if (or (not (list? mineral-patches)) (null? mineral-patches))
           '()
           (for/list ([mp (in-list mineral-patches)]
                      #:when (and (hash? mp)
                                  (real? (hash-ref mp 'x #f))
                                  (real? (hash-ref mp 'y #f)))
                      #:when (let* ([mx0 (hash-ref mp 'x 0.0)]
                                    [my0 (hash-ref mp 'y 0.0)]
                                    [mx (if (flonum? mx0) mx0 (exact->inexact mx0))]
                                    [my (if (flonum? my0) my0 (exact->inexact my0))]
                                    [dx (fl- mx fbx)]
                                    [dy (fl- my fby)]
                                    [d2 (fl+ (fl* dx dx) (fl* dy dy))])
                               (fl<= d2 156.25)))
             (define mx0 (hash-ref mp 'x 0.0))
             (define my0 (hash-ref mp 'y 0.0))
             (define mx (if (flonum? mx0) mx0 (exact->inexact mx0)))
             (define my (if (flonum? my0) my0 (exact->inexact my0)))
             (define dx (fl- mx fbx))
             (define dy (fl- my fby))
             (define d (flsqrt (fl+ (fl* dx dx) (fl* dy dy))))
             (define pid (or (hash-ref mp 'id #f) (hash-ref mp 'tag 0)))
             (vector mx my d (if (exact-integer? pid) pid 0)))))
     (define far-patches
       (cond
         [(null? near-patches) '()]
         [else
          (define ge71
            (for/list ([p (in-list near-patches)]
                       #:when (fl>= (vector-ref p 2) 7.1))
              p))
          (if (pair? ge71)
              ge71
              (let* ([sorted (sort near-patches fl> #:key (lambda (p) (vector-ref p 2)))]
                     [half-k (max 1 (quotient (add1 (length sorted)) 2))])
                (take sorted half-k)))]))
     (define-values (best-w _best-score)
       (for/fold ([bw #f] [bsc -inf.0]) ([w (in-list cands)] #:when (hash? w))
         (define wx0 (hash-ref w 'x fbx))
         (define wy0 (hash-ref w 'y fby))
         (define wx (if (flonum? wx0) wx0 (exact->inexact wx0)))
         (define wy (if (flonum? wy0) wy0 (exact->inexact wy0)))
         (define bdx (fl- wx fbx))
         (define bdy (fl- wy fby))
         (define db (flsqrt (fl+ (fl* bdx bdx) (fl* bdy bdy))))
         (define within-135? (fl<= db 13.5))
         (define sc
           (if (null? far-patches)
               (if within-135? (fl+ 1000.0 db) (fl- db))
               (let* ([otgt (or (hash-ref w 'order-target-id #f)
                                (hash-ref w 'order-target-tag 0))]
                      [otgt-int (if (exact-integer? otgt) otgt 0)])
                 (define-values (min-fd on-far-tgt?)
                   (for/fold ([md +inf.0] [tgt? #f]) ([fp (in-list far-patches)])
                     (define fdx (fl- wx (vector-ref fp 0)))
                     (define fdy (fl- wy (vector-ref fp 1)))
                     (define fd (flsqrt (fl+ (fl* fdx fdx) (fl* fdy fdy))))
                     (define pid (vector-ref fp 3))
                     (values (flmin md fd)
                             (or tgt? (and (> pid 0) (= otgt-int pid))))))
                 (fl+ (fl+ (if (fl<= min-fd 2.2) 1000.0 0.0)
                           (if on-far-tgt? 200.0 0.0))
                      (fl+ (if within-135? (fl+ 50.0 db) -50.0)
                           (fl- (fl* 20.0 min-fd)))))))
         (if (or (not bw) (fl> sc bsc))
             (values w sc)
             (values bw bsc))))
     (or best-w (car cands))]))

(define (populate-valid-enemy-tags-and-pos! sanitized-obs [pos-cache #f])
  (define raw-eu (hash-ref sanitized-obs 'enemy-units '()))
  (define raw-eb (hash-ref sanitized-obs 'enemy-buildings '()))
  (define valid-enemy-tags (make-hasheqv))
  (define pos-tbl (if (hash? pos-cache) pos-cache (make-hasheqv)))
  (define (record-enemy-list! xs)
    (when (list? xs)
      (for ([e (in-list xs)] #:when (hash? e))
        (define eid (hash-ref e 'id 0))
        (when (and (exact-integer? eid) (> eid 0))
          (define ex (hash-ref e 'x #f))
          (define ey (hash-ref e 'y #f))
          (when (and (real? ex) (real? ey))
            (define fx (if (flonum? ex) ex (exact->inexact ex)))
            (define fy (if (flonum? ey) ey (exact->inexact ey)))
            (define prev (hash-ref pos-tbl eid #f))
            (unless (and (pair? prev) (fl= (car prev) fx) (fl= (cdr prev) fy))
              (hash-set! pos-tbl eid (cons fx fy))))
          (define disp-type (hash-ref e 'display-type 1))
          (define snapshot? (eq? (hash-ref e 'snapshot? #f) #t))
          (define ehp (hash-ref e 'hp 1))
          (when (and (real? ehp) (> ehp 0) (not snapshot?) (= disp-type 1))
            (hash-set! valid-enemy-tags eid #t))))))
  (record-enemy-list! raw-eu)
  (record-enemy-list! raw-eb)
  (values valid-enemy-tags pos-tbl))

(define (sanitize-stale-target-actions actions obs
                                       #:pos-cache [pos-cache #f]
                                       #:precomputed-valid-tags [given-valid #f])
  (define sanitized-obs (if (hash? obs) obs (hash)))
  (define fallback-ex (exact->inexact (hash-ref sanitized-obs 'enemy-x 140.0)))
  (define fallback-ey (exact->inexact (hash-ref sanitized-obs 'enemy-y 140.0)))
  (define-values (valid-enemy-tags pos-tbl)
    (if given-valid
        (values given-valid (if (hash? pos-cache) pos-cache (make-hasheqv)))
        (populate-valid-enemy-tags-and-pos! sanitized-obs pos-cache)))
  (define (resolve-last-known-pos tid [def-x fallback-ex] [def-y fallback-ey])
    (define pt (hash-ref pos-tbl tid #f))
    (if (pair? pt)
        (values (car pt) (cdr pt))
        (values def-x def-y)))
  (for/list ([act (in-list (if (list? actions) actions '()))])
    (if (not (pair? act))
        act
        (case (car act)
          [(attack attack-unit)
           (let ([r1 (cdr act)])
             (if (and (pair? r1) (pair? (cdr r1)) (null? (cddr r1))
                      (exact-integer? (cadr r1)))
                 (let ([tid (cadr r1)])
                   (if (hash-ref valid-enemy-tags tid #f)
                       act
                       (let-values ([(lx ly) (resolve-last-known-pos tid)])
                         (list 'attack-pos (car r1) lx ly))))
                 act))]
          [(focus-fire)
           (let ([r1 (cdr act)])
             (if (and (pair? r1) (pair? (cdr r1)) (exact-integer? (cadr r1))
                      (list? (cddr r1)))
                 (let ([tid (cadr r1)]
                       [rest (cddr r1)])
                   (if (hash-ref valid-enemy-tags tid #f)
                       act
                       (let-values ([(lx ly)
                                     (if (and (pair? rest) (pair? (cdr rest))
                                              (real? (car rest)) (real? (cadr rest)))
                                         (resolve-last-known-pos tid
                                                                 (exact->inexact (car rest))
                                                                 (exact->inexact (cadr rest)))
                                         (resolve-last-known-pos tid))])
                         (list 'attack-pos (car r1) lx ly))))
                 act))]
          [(clear-gas-steal)
           (let ([r1 (cdr act)])
             (if (and (pair? r1) (pair? (cdr r1)) (pair? (cddr r1)) (null? (cdddr r1))
                      (exact-integer? (car r1)) (real? (cadr r1)) (real? (caddr r1)))
                 (if (hash-ref valid-enemy-tags (car r1) #f)
                     act
                     (list 'clear-gas-steal 0 (exact->inexact (cadr r1)) (exact->inexact (caddr r1))))
                 act))]
          [(pull-workers-attack)
           (let ([r1 (cdr act)])
             (if (and (pair? r1) (pair? (cdr r1)) (pair? (cddr r1)) (pair? (cdddr r1))
                      (null? (cddddr r1))
                      (exact-integer? (cadr r1)) (real? (caddr r1)) (real? (cadddr r1)))
                 (let ([tid (cadr r1)])
                   (if (or (<= tid 0) (hash-ref valid-enemy-tags tid #f))
                       act
                       (list 'pull-workers-attack (car r1) 0 (exact->inexact (caddr r1)) (exact->inexact (cadddr r1)))))
                 act))]
          [else act]))))

(define WORKER-AND-NONCOMBAT-SYMS
  '(drone probe scv overlord overseer queen larva egg cocoon mule observer
    overlord-cocoon transport-overlord-cocoon baneling-cocoon ravager-cocoon
    brood-lord-cocoon lurker-egg lurker-mp-egg
    creep-tumor creep-tumor-burrowed creep-tumor-queen
    warp-prism warp-prism-phasing observer-siege-mode overseer-siege-mode
    medivac overlord-transport
    interceptor auto-turret point-defense-drone raven-repair-drone
    adept-phase-shift disruptor-phased))

(define WORKER-AND-NONCOMBAT-SYM-SET
  (list->seteq WORKER-AND-NONCOMBAT-SYMS))

(define PRO-CHRONO-11-STRUCTURES
  '(robotics-facility
    stargate
    forge
    twilight-council
    templar-archive
    templar-archives
    cybernetics-core
    robotics-support-bay
    robotics-bay
    fleet-beacon
    dark-shrine
    gateway
    warp-gate
    nexus))

(struct live-bot-runtime
  (bot-name
   configured-race
   actual-race
   posture
   posture-history
   perception
   mastermind
   mirror-mind
   doctrine
   ledger
   cast-limiter
   cortex
   used-creep-tumors
   cooldown-tracker
   bookmarks-initialized?
   step-count
   last-telemetry
   order-ledger
   tactical-brain)
  #:mutable
  #:transparent)

(define (default-posture-for-race race)
  (case race
    [(Zerg zerg)       'Macro12Hatch]
    [(Protoss protoss) 'ForgeFastExpand]
    [(Terran terran)   'OneRaxFE]
    [(Random random)   'RandomRollOpening]
    [else              'Macro12Hatch]))

(define (default-personality-for-race race)
  (case race
    [(Zerg zerg)       SCARLETT-CREEP-SWARM-PERSONALITY]
    [(Protoss protoss) MARV-MACRO-OPEN-PERSONALITY]
    [(Terran terran)   CLEM-TEMPO-MULTITASK-PERSONALITY]
    [else              CLEM-TEMPO-MULTITASK-PERSONALITY]))

(define normalize-race-sym normalize-race)

(define (make-live-bot-runtime #:bot-name [bot-name 'mothman-bot]
                               #:race [race 'Zerg]
                               #:personality [personality #f]
                               #:build-order [_build-order #f]
                               #:cortex-profile [cortex-profile 'Serral]
                               #:postures [_postures '()]
                               #:squads [_squads '()]
                               #:state-machine [_sm #f]
                               #:doctrine [doctrine #f]
                               #:epm-cap [epm-cap 360]
                               #:initial-posture [init-posture #f])
  (define norm-race (normalize-race-sym race))
  (define eff-race (if (eq? norm-race 'Random) 'Zerg norm-race))
  (define pers (or personality (default-personality-for-race norm-race)))
  (define post (or init-posture (default-posture-for-race norm-race)))
  (define prof-sym
    (cond
      [(symbol? cortex-profile) cortex-profile]
      [else 'Serral]))
  (live-bot-runtime
   bot-name
   norm-race
   eff-race
   post
   (list post)
   (make-perception-grid)
   (make-mastermind-state eff-race pers)
   (make-mirror-mind-state #:our-race eff-race)
   doctrine
   (make-symbiotic-ledger SC2-STARTING-MINERALS SC2-STARTING-GAS SC2-STARTING-WORKERS)
   (make-ability-cast-limiter #:max-per-frame 2 #:refractory-frames 16)
   (make-human-cortex #:profile prof-sym
                      #:cam-x SC2-DEFAULT-HOME-BASE-X
                      #:cam-y SC2-DEFAULT-HOME-BASE-Y
                      #:epm-cap epm-cap
                      #:max-tokens 32)
   (mutable-set)
   (make-refractory-cooldown-tracker)
   #f
   0
   (hash)
   (make-order-ledger)
   (make-tactical-mirror-brain)))

(struct random-stealth-harass-plan
  (active?
   rolled-race
   doctrine-name
   stealth-phase
   deny-scout-choke?
   perimeter-flight-path?
   fake-normal-front?
   priority-tech-building
   priority-harass-units
   early-push-threshold)
  #:transparent)

(define (evaluate-random-stealth-harass-plan configured-race actual-race frame-num)
  (define is-random? (member configured-race '(Random random "Random" "random")))
  (define r-sym (normalize-race-sym actual-race))
  (define fn (safe-nonneg-int frame-num 0))
  (cond
    [(not is-random?)
     (random-stealth-harass-plan #f r-sym 'standard-known-race 'none #f #f #f #f '() 28)]
    [(eq? r-sym 'Zerg)
     ;; Doctrine 1: Lambo / Serral 5-Roach + 1-Ravager Pressure (19-Drone Fake-Macro Natural)
     ;; Holds Overlord-1 off the direct center flight lane until 1:35 (loop 2128), shows standard
     ;; Hatchery-first at natural while hiding Roach Warren in back main mineral pocket.
     (random-stealth-harass-plan
      #t
      'Zerg
      'lambo-stealth-5-roach-ravager-pressure
      (if (< fn 2128) 'conceal-overlord-and-back-warren 'roach-ravager-wall-breaker)
      #t
      #t
      #t
      'roach-warren
      '(roach ravager zergling)
      14)]
    [(eq? r-sym 'Terran)
     ;; Doctrine 2: Maru / Clem Marine-First Ramp Denial -> 1-1-1 Widow Mine Drop / Cloaked Banshee
     ;; Skips Reaper (which reveals race at 1:25) in favor of 1st Marine on high-ground ramp to snipe
     ;; incoming Probe/SCV/Overlord scout before it sees the back-corner Factory + Starport.
     (random-stealth-harass-plan
      #t
      'Terran
      'maru-marine-first-scout-denial-111-harass
      (if (< fn 2464) 'ramp-marine-scout-denial 'widow-mine-banshee-harass)
      #t
      #t
      #t
      'factory
      '(marine marauder widow-mine medivac banshee)
      16)]
    [(eq? r-sym 'Protoss)
     ;; Doctrine 3: MaxPax / herO Fake-Normal Ramp Core -> Perimeter Stargate Oracle + Double-Adept Shade
     ;; Shows normal 14-Pylon + 16-Gateway + 20-Nexus + 20-CyberCore at main ramp, hides 2nd Pylon + Stargate
     ;; in back-corner of main, routes Oracle along map-edge dead-air + shades 2 Adepts into natural.
     (random-stealth-harass-plan
      #t
      'Protoss
      'maxpax-fake-normal-core-perimeter-oracle-adept
      (if (< fn 2464) 'fake-normal-ramp-hide-stargate 'perimeter-oracle-double-adept-pincer)
      #t
      #t
      #t
      'stargate
      '(adept stalker oracle)
      14)]
    [else
     (random-stealth-harass-plan #f r-sym 'standard-known-race 'none #f #f #f #f '() 28)]))


;; =============================================================================
;; Total Numeric, Coordinate, and Observation Sanitizers
;; (Shared helpers imported from `sc2-common.rkt`.)
;; =============================================================================

(define safe-coord safe-tile-coord)

(define NON-COMBAT-AND-SCOUT-ENEMY-SYMS
  '(overlord overseer observer overlord-transport overseer-siege-mode observer-siege-mode
    warp-prism-phasing
    changeling changeling-zealot changeling-marine changeling-marine-shield
    changeling-zergling changeling-zergling-wings
    larva egg cocoon overlord-cocoon transport-overlord-cocoon baneling-cocoon ravager-cocoon
    brood-lord-cocoon lurker-egg lurker-mp-egg mule
    interceptor auto-turret point-defense-drone raven-repair-drone
    adept-phase-shift disruptor-phased kd8-charge parasitic-bomb-dummy
    oracle-stasis-trap stasis-ward force-field broodling-escort))

(define NON-COMBAT-AND-SCOUT-ENEMY-SYM-SET
  (list->seteq NON-COMBAT-AND-SCOUT-ENEMY-SYMS))

(define NON-COMBAT-AND-SCOUT-ENEMY-HT
  (for/hasheq ([s (in-list NON-COMBAT-AND-SCOUT-ENEMY-SYMS)])
    (values s #t)))

(define NON-WORKER-PULL-ENEMY-UNIT-SYMS
  (append NON-COMBAT-AND-SCOUT-ENEMY-SYMS
          '(mutalisk corruptor brood-lord broodlord viper
            phoenix oracle void-ray voidray carrier tempest mothership mothership-core
            warp-prism warp-prism-phasing interceptor
            viking viking-fighter medivac liberator liberator-ag banshee raven
            battlecruiser point-defense-drone)))

(define NON-WORKER-PULL-ENEMY-UNIT-SYM-SET
  (list->seteq NON-WORKER-PULL-ENEMY-UNIT-SYMS))

(define NON-WORKER-PULL-ENEMY-UNIT-HT
  (for/hasheq ([s (in-list NON-WORKER-PULL-ENEMY-UNIT-SYMS)])
    (values s #t)))

(define EXCLUDED-MACRO-UNIT-COUNT-HT
  (for/hasheq ([s (in-list '(larva egg cocoon lurker-egg lurker-mp-egg transport-overlord-cocoon
                              warp-prism-phasing observer-siege-mode overseer-siege-mode
                              interceptor auto-turret point-defense-drone raven-repair-drone
                              adept-phase-shift disruptor-phased mule kd8-charge parasitic-bomb-dummy
                              changeling changeling-zealot changeling-marine changeling-marine-shield
                              changeling-zergling changeling-zergling-wings
                              creep-tumor creep-tumor-burrowed creep-tumor-queen
                              broodling broodling-escort locust locust-flying
                              oracle-stasis-trap stasis-ward force-field))])
    (values s #t)))

(define ZERG-MACRO-BLDG-SYMS
  '(hatchery lair hive spawning-pool extractor roach-warren baneling-nest
    evolution-chamber hydralisk-den spire greater-spire lurker-den lurker-den-mp
    infestation-pit ultralisk-cavern spine-crawler spore-crawler nydus-network))

(define PROTOSS-MACRO-BLDG-SYMS
  '(nexus pylon assimilator gateway warp-gate warpgate cybernetics-core
    robotics-facility robotics-bay robotics-support-bay twilight-council forge stargate
    templar-archive templar-archives dark-shrine fleet-beacon photon-cannon shield-battery))

(define TERRAN-MACRO-BLDG-SYMS
  '(command-center orbital-command planetary-fortress supply-depot
    refinery barracks barracks-techlab barracks-tech-lab barracks-reactor
    factory factory-techlab factory-tech-lab factory-reactor
    starport starport-techlab starport-tech-lab starport-reactor
    tech-lab reactor
    engineering-bay armory ghost-academy fusion-core bunker missile-turret sensor-tower))

(define ALL-MACRO-BLDG-SYMS
  (append ZERG-MACRO-BLDG-SYMS PROTOSS-MACRO-BLDG-SYMS TERRAN-MACRO-BLDG-SYMS))

(define ZERG-MACRO-UNIT-SYMS
  '(drone overlord overseer queen zergling baneling roach ravager hydralisk lurker mutalisk corruptor brood-lord ultralisk infestor viper swarm-host))

(define PROTOSS-MACRO-UNIT-SYMS
  '(probe zealot stalker sentry adept high-templar dark-templar archon immortal observer warp-prism colossus disruptor phoenix void-ray oracle carrier tempest mothership))

(define TERRAN-MACRO-UNIT-SYMS
  '(scv marine marauder reaper ghost hellion hellbat widow-mine siege-tank cyclone thor medivac viking liberator raven banshee battlecruiser))

(define ALL-MACRO-UNIT-SYMS
  (append ZERG-MACRO-UNIT-SYMS PROTOSS-MACRO-UNIT-SYMS TERRAN-MACRO-UNIT-SYMS))

(define CRISIS-DEFERRED-TECH-BLDG-SYMS
  '(lair hive infestation-pit spire greater-spire ultralisk-cavern lurker-den lurker-den-mp
    baneling-nest evolution-chamber
    templar-archive templar-archives dark-shrine stargate fleet-beacon robotics-bay
    twilight-council forge
    fusion-core ghost-academy))

(define VIKING-TETHER-TARGET-SYMS
  '(tempest colossus carrier void-ray voidray brood-lord broodlord))

(define VIKING-SCREEN-AA-SYMS
  '(stalker hydralisk marine archon queen photon-cannon missile-turret spore-crawler))

(define THOR-CAPITAL-AIR-SYMS
  '(tempest carrier battlecruiser brood-lord broodlord))

(define RUNTIME-NONCOMBAT-SYM-CACHE (make-hasheq))
(define (fast-noncombat-or-summon-sym? t)
  (let ([v (hash-ref RUNTIME-NONCOMBAT-SYM-CACHE t 'miss)])
    (if (eq? v 'miss)
        (let ([c (sc2-non-combat-or-summon-sym? t)])
          (hash-set! RUNTIME-NONCOMBAT-SYM-CACHE t c)
          c)
        v)))

(define COMBAT-UNIT-EXCLUDED-SYM-CACHE
  (let ([ht (make-hasheq)])
    (for ([s (in-list WORKER-AND-NONCOMBAT-SYMS)]) (hash-set! ht s #t))
    (for ([s (in-list NON-COMBAT-AND-SCOUT-ENEMY-SYMS)]) (hash-set! ht s #t))
    ht))

(define (combat-unit-excluded-sym? t)
  (let ([v (hash-ref COMBAT-UNIT-EXCLUDED-SYM-CACHE t 'miss)])
    (if (eq? v 'miss)
        (let ([c (sc2-non-combat-or-summon-sym? t)])
          (hash-set! COMBAT-UNIT-EXCLUDED-SYM-CACHE t c)
          c)
        v)))

(define SCOUT-OR-DUMMY-ENEMY-SYM-CACHE
  (let ([ht (make-hasheq)])
    (for ([s (in-list NON-COMBAT-AND-SCOUT-ENEMY-SYMS)]) (hash-set! ht s #t))
    ht))

(define (fast-scout-or-noncombat-enemy-sym? t)
  (let ([v (hash-ref SCOUT-OR-DUMMY-ENEMY-SYM-CACHE t 'miss)])
    (if (eq? v 'miss)
        (let ([c (sc2-non-combat-or-summon-sym? t)])
          (hash-set! SCOUT-OR-DUMMY-ENEMY-SYM-CACHE t c)
          c)
        v)))

(define (fast-dist2d x1 y1 x2 y2)
  (if (and (real? x1) (= (- x1 x1) 0)
           (real? y1) (= (- y1 y1) 0)
           (real? x2) (= (- x2 x2) 0)
           (real? y2) (= (- y2 y2) 0))
      (let ([dx (- (exact->inexact x2) (exact->inexact x1))]
            [dy (- (exact->inexact y2) (exact->inexact y1))])
        (sqrt (+ (* dx dx) (* dy dy))))
      (dist2d x1 y1 x2 y2)))

(define (combat-unit-record? u)
  (and (hash? u)
       (let ([t (unit-type-sym u)])
         (and (not (combat-unit-excluded-sym? t))
              (not (eq? (hash-ref u 'is-hallucination #f) #t))
              (not (eq? (hash-ref u 'hallucination #f) #t))
              (not (eq? (hash-ref u 'hallucination? #f) #t))))))

;; Private sentinel distinguishing an absent optional hash key from an explicit #f value.
(define SANITIZE-MISSING (string->uninterned-symbol "sanitize-missing"))

(define (sanitized-pos-int? v)
  (and (exact-integer? v) (>= v 1)))

(define (sanitized-nonneg-int? v)
  (and (exact-integer? v) (>= v 0)))

(define (sanitized-nonneg-inexact? v)
  (and (real? v)
       (inexact? v)
       (>= v 0.0)
       (< v +inf.0)))

(define (sanitized-unit-interval? v)
  (and (real? v)
       (inexact? v)
       (>= v 0.0)
       (<= v 1.0)))

(define (sanitized-tile-coord? v)
  (if (exact-integer? v)
      (and (>= v 0) (<= v 256))
      (and (flonum? v)
           (fl>= v 0.0)
           (fl<= v 256.0)
           (fl= v (fl* (flround (fl* v 2.0)) 0.5)))))

(define (sanitized-opt-key? h k pred?)
  (define v (hash-ref h k SANITIZE-MISSING))
  (or (eq? v SANITIZE-MISSING) (pred? v)))

;; Fast-path check: returns #t when immutable unit hash `u` already satisfies all sanitized invariants.
(define (already-sanitized-unit-record? u)
  (and (hash? u)
       (immutable? u)
       (sanitized-nonneg-int? (hash-ref u 'id #f))
       (symbol? (hash-ref u 'type #f))
       (sanitized-tile-coord? (hash-ref u 'x #f))
       (sanitized-tile-coord? (hash-ref u 'y #f))
       (sanitized-pos-int? (hash-ref u 'hp #f))
       (sanitized-opt-key? u 'max-hp sanitized-pos-int?)
       (sanitized-opt-key? u 'hp-pct sanitized-unit-interval?)
       (sanitized-opt-key? u 'shield sanitized-nonneg-int?)
       (sanitized-opt-key? u 'energy sanitized-nonneg-int?)
       (sanitized-opt-key? u 'dps sanitized-nonneg-int?)
       (sanitized-opt-key? u 'z exact-integer?)
       (sanitized-opt-key? u 'speed sanitized-nonneg-inexact?)
       (sanitized-opt-key? u 'atk-upg sanitized-nonneg-int?)
       (sanitized-opt-key? u 'arm-upg sanitized-nonneg-int?)
       (sanitized-opt-key? u 'shd-upg sanitized-nonneg-int?)
       (sanitized-opt-key? u 'damage-rate-ratio sanitized-nonneg-inexact?)
       (sanitized-opt-key? u 'damage-taken-multiplier sanitized-nonneg-inexact?)))

;; Fast-path check: returns #t when immutable building hash `b` already satisfies unit + building invariants.
(define (already-sanitized-bldg-record? b)
  (and (already-sanitized-unit-record? b)
       (sanitized-pos-int? (hash-ref b 'max-hp #f))
       (sanitized-unit-interval? (hash-ref b 'hp-pct #f))
       (sanitized-unit-interval? (hash-ref b 'build-progress #f))
       (sanitized-opt-key? b 'ideal-harvesters sanitized-nonneg-int?)
       (sanitized-opt-key? b 'assigned-harvesters sanitized-nonneg-int?)))

(define (sanitize-opt-nonneg-0 v) (safe-nonneg-int v 0))
(define (sanitize-opt-nonneg-12 v) (safe-nonneg-int v 12))
(define (sanitize-opt-nonneg-16 v) (safe-nonneg-int v 16))
(define (sanitize-opt-exact-10 v) (safe-exact-int v 10))
(define (sanitize-opt-unit-interval-1 v) (max 0.0 (min 1.0 (safe-finite-real v 1.0))))
(define (sanitize-opt-nonneg-real-1 v) (max 0.0 (safe-finite-real v 1.0)))
(define (sanitize-opt-nonneg-real-3 v) (max 0.0 (safe-finite-real v 3.0)))

(define UNIT-OPT-SANITIZERS
  (list (cons 'hp-pct sanitize-opt-unit-interval-1)
        (cons 'shield sanitize-opt-nonneg-0)
        (cons 'energy sanitize-opt-nonneg-0)
        (cons 'dps sanitize-opt-nonneg-12)
        (cons 'z sanitize-opt-exact-10)
        (cons 'speed sanitize-opt-nonneg-real-3)
        (cons 'atk-upg sanitize-opt-nonneg-0)
        (cons 'arm-upg sanitize-opt-nonneg-0)
        (cons 'shd-upg sanitize-opt-nonneg-0)
        (cons 'damage-rate-ratio sanitize-opt-nonneg-real-1)
        (cons 'damage-taken-multiplier sanitize-opt-nonneg-real-1)))

(define UNIT-OPT-SANITIZER-DISPATCH
  (hasheq 'hp-pct (cons sanitized-unit-interval? sanitize-opt-unit-interval-1)
          'shield (cons sanitized-nonneg-int? sanitize-opt-nonneg-0)
          'energy (cons sanitized-nonneg-int? sanitize-opt-nonneg-0)
          'dps (cons sanitized-nonneg-int? sanitize-opt-nonneg-12)
          'z (cons exact-integer? sanitize-opt-exact-10)
          'speed (cons sanitized-nonneg-inexact? sanitize-opt-nonneg-real-3)
          'atk-upg (cons sanitized-nonneg-int? sanitize-opt-nonneg-0)
          'arm-upg (cons sanitized-nonneg-int? sanitize-opt-nonneg-0)
          'shd-upg (cons sanitized-nonneg-int? sanitize-opt-nonneg-0)
          'damage-rate-ratio (cons sanitized-nonneg-inexact? sanitize-opt-nonneg-real-1)
          'damage-taken-multiplier (cons sanitized-nonneg-inexact? sanitize-opt-nonneg-real-1)))

(define (refractory-ready? tracker key frame cooldown-frames)
  (or (not (refractory-cooldown-tracker? tracker))
      (let* ([tbl (refractory-cooldown-tracker-table tracker)]
             [last-f (hash-ref tbl key #f)])
        (or (not last-f)
            (let ([f (if (exact-integer? frame) frame (inexact->exact (truncate (if (real? frame) frame 0))))]
                  [cd (if (exact-integer? cooldown-frames)
                          (max 0 cooldown-frames)
                          (max 0 (inexact->exact (truncate (if (real? cooldown-frames) cooldown-frames 0)))))])
              (>= (- f last-f) cd))))))

;; Updates optional key `k` in `h` only when present and changed after running `sanitizer`.
(define (sanitize-optional-key h k sanitizer)
  (define old-v (hash-ref h k SANITIZE-MISSING))
  (if (eq? old-v SANITIZE-MISSING)
      h
      (let ([new-v (sanitizer old-v)])
        (if (equal? new-v old-v)
            h
            (hash-set h k new-v)))))

(define-syntax-rule (sanitize-opt-key-inline h k pred? sanitizer)
  (let ([v (hash-ref h k SANITIZE-MISSING)])
    (if (or (eq? v SANITIZE-MISSING) (pred? v))
        h
        (let ([nv (sanitizer v)])
          (if (equal? nv v) h (hash-set h k nv))))))

(define (tel-set ht k v)
  (define cur (hash-ref ht k RUNTIME-MISSING))
  (if (or (eq? cur v)
          (and (not (eq? cur RUNTIME-MISSING))
               (equal? cur v)))
      ht
      (hash-set ht k v)))

(define ENEMY-RACE-BY-CANON-HT
  (let ([ht (make-hasheq)])
    (for ([s (in-list '(drone overlord overseer zergling baneling roach ravager hydralisk
                        lurker mutalisk corruptor brood-lord ultralisk infestor viper queen
                        hatchery lair hive spawning-pool extractor roach-warren baneling-nest
                        spine-crawler spore-crawler))])
      (hash-set! ht s 'Zerg))
    (for ([s (in-list '(scv marine marauder reaper ghost hellion hellbat widow-mine siege-tank
                        cyclone thor medivac viking liberator raven banshee battlecruiser
                        command-center orbital-command planetary-fortress supply-depot refinery
                        barracks factory starport bunker missile-turret))])
      (hash-set! ht s 'Terran))
    (for ([s (in-list '(probe zealot stalker adept sentry high-templar dark-templar archon
                        immortal observer warp-prism colossus disruptor phoenix void-ray oracle
                        carrier tempest mothership nexus pylon assimilator gateway warp-gate
                        forge cybernetics-core photon-cannon shield-battery robotics-facility stargate))])
      (hash-set! ht s 'Protoss))
    ht))

(define ALLY-SYM-FLAGS-CACHE (make-hasheq))
(define (fast-ally-sym-flags ut)
  (define cached (hash-ref ALLY-SYM-FLAGS-CACHE ut -1))
  (if (>= cached 0)
      cached
      (let ([f (bitwise-ior
                (if (fast-unit-is-detector-sym? ut) 1 0)
                (if (or (eq? ut 'disruptor) (eq? ut 'disruptor-phased)) 2 0)
                (if (eq? ut 'sentry) 4 0)
                (if (eq? ut 'overseer) 8 0)
                (if (or (eq? ut 'infestor) (eq? ut 'infestor-burrowed)) 16 0)
                (if (hash-ref RUNTIME-SPOTTER-SET ut #f) 32 0)
                (if (hash-ref RUNTIME-SPELLCASTER-SET ut #f) 64 0)
                (if (hash-ref RUNTIME-UNIT-MODE-SET ut #f) 128 0)
                (if (or (eq? ut 'roach) (eq? ut 'roach-burrowed)) 256 0)
                (if (eq? ut 'ravager) 512 0)
                (if (hash-ref RUNTIME-ZERG-ALREADY-BURROWED-SET ut #f) 1024 0)
                (if (hash-ref RUNTIME-ZERG-BRUISED-BURROW-SET ut #f) 2048 0)
                (if (hash-ref RUNTIME-SWARM-HOST-LOCUST-SET ut #f) 4096 0)
                (if (or (eq? ut 'zergling) (eq? ut 'zergling-burrowed)) 8192 0)
                (if (eq? ut 'queen) 16384 0)
                (if (hash-ref RUNTIME-TUMOR-SET ut #f) 32768 0)
                (if (or (eq? ut 'overseer)
                        (eq? ut 'overseer-siege-mode)
                        (hash-ref RUNTIME-RT-CHANGELING-SET ut #f))
                    65536
                    0)
                (if (or (eq? ut 'overlord-transport) (eq? ut 'dropperlord) (eq? ut 'overlord-ventral))
                    131072
                    0)
                (if (hash-ref RUNTIME-ALLY-UNWALLED-PUNISH-SET ut #f) 262144 0)
                (if (hash-ref RUNTIME-ALLY-HARASS-SET ut #f) 524288 0)
                (if (hash-ref RUNTIME-STATIC-DEF-AND-NYDUS-SET ut #f) 1048576 0)
                (if (hash-ref RUNTIME-ALLY-MAP-ELEM-RECALL-SET ut #f) 2097152 0)
                (if (or (eq? ut 'creep-tumor)
                        (eq? ut 'creep-tumor-burrowed)
                        (eq? ut 'creep-tumor-queen))
                    4194304
                    0))])
        (hash-set! ALLY-SYM-FLAGS-CACHE ut f)
        f)))

(define ALLY-BLDG-FLAGS-CACHE (make-hasheq))
(define (fast-ally-bldg-flags bt)
  (define cached (hash-ref ALLY-BLDG-FLAGS-CACHE bt -1))
  (if (>= cached 0)
      cached
      (let ([f (bitwise-ior
                (if (fast-unit-is-detector-sym? bt) 1 0)
                (if (eq? bt 'armory) 2 0)
                (if (memq bt '(hatchery lair hive nexus command-center orbital-command planetary-fortress)) 4 0)
                (if (hash-ref RUNTIME-TUMOR-SET bt #f) 8 0)
                (if (hash-ref RUNTIME-WALL-BLOCK-BLDG-SET bt #f) 16 0)
                (if (eq? bt 'supply-depot-lowered) 32 0)
                (if (or (hash-ref RUNTIME-STATIC-DEF-AND-NYDUS-SET bt #f)
                        (hash-ref RUNTIME-STATIC-DEF-AND-NYDUS-SET (fast-canonical-structure-sym bt) #f))
                    64
                    0)
                (if (hash-ref RUNTIME-ALLY-MAP-ELEM-RECALL-SET bt #f) 128 0))])
        (hash-set! ALLY-BLDG-FLAGS-CACHE bt f)
        f)))

(define ENEMY-U-INFO-CACHE (make-hasheq))
(define (fast-enemy-u-info et)
  (or (hash-ref ENEMY-U-INFO-CACHE et #f)
      (let* ([flags
              (bitwise-ior
               (if (or (eq? et 'disruptor) (eq? et 'disruptor-phased)) 1 0)
               (if (or (eq? et 'widow-mine) (eq? et 'widow-mine-burrowed)) 2 0)
               (if (eq? et 'baneling) 4 0)
               (if (or (eq? et 'hellion) (eq? et 'lurker-burrowed)) 8 0)
               (if (eq? et 'lurker) 16 0)
               (if (or (eq? et 'siege-tank-sieged) (eq? et 'lurker-burrowed) (eq? et 'lurker-mp-burrowed)) 32 0)
               (if (eq? et 'siege-tank) 64 0)
               (if (eq? et 'lurker-mp) 128 0)
               (if (or (eq? et 'oracle-stasis-trap) (eq? et 'stasis-ward)) 256 0)
               (if (hash-ref RUNTIME-IMMOBILE-BILE-SET et #f) 512 0)
               (if (eq? et 'siege-tank-sieged) 1024 0)
               (if (or (eq? et 'colossus) (fast-unit-is-flying-sym? et)) 2048 0)
               (if (hash-ref RUNTIME-MASSIVE-AC-SET et #f) 4096 0)
               (if (eq? et 'mutalisk) 8192 0)
               (if (hash-ref RUNTIME-RT-CHANGELING-SET et #f) 16384 0)
               (if (hash-ref RUNTIME-ENEMY-STATIC-DET-SET et #f) 32768 0)
               (if (hash-ref RUNTIME-SWARM-HOST-LOCUST-SET et #f) 65536 0)
               (if (hash-ref RUNTIME-TUMOR-SET et #f) 131072 0)
               (if (or (eq? et 'overlord-transport) (eq? et 'dropperlord)) 262144 0)
               (if (or (eq? et 'overseer) (eq? et 'overseer-siege-mode)) 524288 0)
               (if (hash-ref RUNTIME-ENEMY-HARASS-SET et #f) 1048576 0)
               (if (hash-ref RUNTIME-STATIC-DEF-AND-NYDUS-SET et #f) 2097152 0)
               (if (hash-ref RUNTIME-ENEMY-MAP-ELEM-RECALL-SET et #f) 4194304 0)
               (if (combat-unit-excluded-sym? et) 0 8388608)
               (if (hash-ref RUNTIME-ENEMY-BURROW-COUNTER-SET et #f) 16777216 0)
               (if (memq et '(larva egg probe scv drone)) 0 33554432))]
             [v (vector flags (unit-supply-cost et) (fast-res-cost-50 et))])
        (hash-set! ENEMY-U-INFO-CACHE et v)
        v)))

(define ENEMY-B-INFO-CACHE (make-hasheq))
(define (fast-enemy-b-info bt)
  (or (hash-ref ENEMY-B-INFO-CACHE bt #f)
      (let* ([sdef? (hash-ref RUNTIME-STATIC-DEFVAL-SET bt #f)]
             [v (vector
                 (bitwise-ior
                  (if (hash-ref RUNTIME-ENEMY-STATIC-DET-SET bt #f) 1 0)
                  (if (hash-ref RUNTIME-TUMOR-SET bt #f) 2 0)
                  (if (or (hash-ref RUNTIME-STATIC-DEF-AND-NYDUS-SET bt #f)
                          (hash-ref RUNTIME-STATIC-DEF-AND-NYDUS-SET (fast-canonical-structure-sym bt) #f))
                      4
                      0)
                  (if (or (eq? bt 'oracle-stasis-trap) (eq? bt 'stasis-ward)) 8 0)
                  (if (hash-ref RUNTIME-IMMOBILE-BILE-SET bt #f) 16 0)
                  (if (eq? bt 'planetary-fortress) 32 0)
                  (if sdef? 64 0))
                 (if sdef?
                     (+ (fast-res-cost-100 bt)
                        (case bt [(planetary-fortress) 400] [(bunker) 200] [else 0]))
                     0))])
        (hash-set! ENEMY-B-INFO-CACHE bt v)
        v)))

(define BAYES-EB-FLAGS-CACHE (make-hasheq))
(define (fast-bayes-eb-flags bt)
  (define cached (hash-ref BAYES-EB-FLAGS-CACHE bt -1))
  (if (>= cached 0)
      cached
      (let ([f (bitwise-ior
                (if (memq bt '(supply-depot supply-depot-lowered barracks gateway cybernetics-core forge pylon)) 1 0)
                (if (memq bt '(gateway warp-gate barracks factory starport spawning-pool roach-warren)) 2 0)
                (if (hash-ref RUNTIME-TOWNHALL-SYM-SET bt #f) 4 0)
                (if (memq bt '(gateway warp-gate barracks factory starport spawning-pool photon-cannon bunker pylon hatchery)) 8 0)
                (if (eq? bt 'supply-depot-lowered) 16 0)
                (if (memq bt '(photon-cannon shield-battery bunker missile-turret spine-crawler spore-crawler)) 32 0)
                (if (memq bt '(assimilator assimilator-rich refinery refinery-rich extractor extractor-rich)) 64 0))])
        (hash-set! BAYES-EB-FLAGS-CACHE bt f)
        f)))

(define BAYES-EU-FLAGS-HT
  (let ([ht (make-hasheq)])
    (for ([s (in-list '(oracle phoenix mutalisk banshee medivac warp-prism liberator void-ray))])
      (hash-set! ht s 1))
    (for ([s (in-list '(drone probe scv larva egg mule))])
      (hash-set! ht s (bitwise-ior (hash-ref ht s 0) 2)))
    ht))

(define (sanitize-record-list raw fn def-x def-y)
  (if (list? raw)
      (let loop ([rem raw] [acc-rev '()] [idx 0] [same? #t])
        (cond
          [(null? rem)
           (if same? raw (reverse acc-rev))]
          [else
           (define item (car rem))
           (define nitem (fn item def-x def-y))
           (cond
             [(and same? (eq? nitem item))
              (loop (cdr rem) '() (add1 idx) #t)]
             [same?
              (define prefix-rev
                (let copy ([p raw] [n idx] [acc '()])
                  (if (zero? n) acc (copy (cdr p) (sub1 n) (cons (car p) acc)))))
              (loop (cdr rem) (cons nitem prefix-rev) (add1 idx) #f)]
             [else
              (loop (cdr rem) (cons nitem acc-rev) (add1 idx) #f)])]))
      '()))

(define (apply-hash-chgs h chgs)
  (let loop ([rem chgs] [acc h])
    (if (null? rem)
        acc
        (loop (cddr rem) (hash-set acc (car rem) (cadr rem))))))

(define (sanitize-unit-record u [default-x 32.5] [default-y 32.5])
  (cond
    [(hash? u)
     (define base-h (if (immutable? u) u (for/hash ([(k v) (in-hash u)]) (values k v))))
     (let loop ([pos (hash-iterate-first base-h)]
                [seen 0]
                [hp-val 45]
                [bad-mhp? #f]
                [raw-mhp #f]
                [chgs '()])
       (if pos
           (let-values ([(k v) (hash-iterate-key+value base-h pos)])
             (define npos (hash-iterate-next base-h pos))
             (case k
               [(id)
                (define nseen (bitwise-ior seen 1))
                (if (sanitized-nonneg-int? v)
                    (loop npos nseen hp-val bad-mhp? raw-mhp chgs)
                    (let ([nv (safe-nonneg-int v 101)])
                      (loop npos nseen hp-val bad-mhp? raw-mhp
                            (if (eq? nv v) chgs (cons 'id (cons nv chgs))))))]
               [(type)
                (define nseen (bitwise-ior seen 2))
                (if (symbol? v)
                    (loop npos nseen hp-val bad-mhp? raw-mhp chgs)
                    (let ([nv (unit-type-sym base-h)])
                      (loop npos nseen hp-val bad-mhp? raw-mhp
                            (if (eq? nv v) chgs (cons 'type (cons nv chgs))))))]
               [(x)
                (define nseen (bitwise-ior seen 4))
                (cond
                  [(and (flonum? v) (fl>= v 0.0) (fl<= v 256.0))
                   (define r (fl* (flround (fl* v 2.0)) 0.5))
                   (loop npos nseen hp-val bad-mhp? raw-mhp
                         (if (fl= v r) chgs (cons 'x (cons r chgs))))]
                  [(and (exact-integer? v) (>= v 0) (<= v 256))
                   (loop npos nseen hp-val bad-mhp? raw-mhp chgs)]
                  [else
                   (define nv (safe-coord v default-x))
                   (loop npos nseen hp-val bad-mhp? raw-mhp
                         (if (equal? nv v) chgs (cons 'x (cons nv chgs))))])]
               [(y)
                (define nseen (bitwise-ior seen 8))
                (cond
                  [(and (flonum? v) (fl>= v 0.0) (fl<= v 256.0))
                   (define r (fl* (flround (fl* v 2.0)) 0.5))
                   (loop npos nseen hp-val bad-mhp? raw-mhp
                         (if (fl= v r) chgs (cons 'y (cons r chgs))))]
                  [(and (exact-integer? v) (>= v 0) (<= v 256))
                   (loop npos nseen hp-val bad-mhp? raw-mhp chgs)]
                  [else
                   (define nv (safe-coord v default-y))
                   (loop npos nseen hp-val bad-mhp? raw-mhp
                         (if (equal? nv v) chgs (cons 'y (cons nv chgs))))])]
               [(hp)
                (define nseen (bitwise-ior seen 16))
                (if (sanitized-pos-int? v)
                    (loop npos nseen v bad-mhp? raw-mhp chgs)
                    (let ([nv (max 1 (safe-nonneg-int v 45))])
                      (loop npos nseen nv bad-mhp? raw-mhp
                            (if (eq? nv v) chgs (cons 'hp (cons nv chgs))))))]
               [(max-hp)
                (if (sanitized-pos-int? v)
                    (loop npos seen hp-val bad-mhp? raw-mhp chgs)
                    (loop npos seen hp-val #t v chgs))]
               [(hp-pct)
                (if (sanitized-unit-interval? v)
                    (loop npos seen hp-val bad-mhp? raw-mhp chgs)
                    (let ([nv (sanitize-opt-unit-interval-1 v)])
                      (loop npos seen hp-val bad-mhp? raw-mhp
                            (if (equal? nv v) chgs (cons 'hp-pct (cons nv chgs))))))]
               [(shield energy atk-upg arm-upg shd-upg)
                (if (sanitized-nonneg-int? v)
                    (loop npos seen hp-val bad-mhp? raw-mhp chgs)
                    (let ([nv (sanitize-opt-nonneg-0 v)])
                      (loop npos seen hp-val bad-mhp? raw-mhp
                            (if (equal? nv v) chgs (cons k (cons nv chgs))))))]
               [(dps)
                (if (sanitized-nonneg-int? v)
                    (loop npos seen hp-val bad-mhp? raw-mhp chgs)
                    (let ([nv (sanitize-opt-nonneg-12 v)])
                      (loop npos seen hp-val bad-mhp? raw-mhp
                            (if (equal? nv v) chgs (cons 'dps (cons nv chgs))))))]
               [(z)
                (if (exact-integer? v)
                    (loop npos seen hp-val bad-mhp? raw-mhp chgs)
                    (let ([nv (sanitize-opt-exact-10 v)])
                      (loop npos seen hp-val bad-mhp? raw-mhp
                            (if (equal? nv v) chgs (cons 'z (cons nv chgs))))))]
               [(speed)
                (if (sanitized-nonneg-inexact? v)
                    (loop npos seen hp-val bad-mhp? raw-mhp chgs)
                    (let ([nv (sanitize-opt-nonneg-real-3 v)])
                      (loop npos seen hp-val bad-mhp? raw-mhp
                            (if (equal? nv v) chgs (cons 'speed (cons nv chgs))))))]
               [(damage-rate-ratio damage-taken-multiplier)
                (if (sanitized-nonneg-inexact? v)
                    (loop npos seen hp-val bad-mhp? raw-mhp chgs)
                    (let ([nv (sanitize-opt-nonneg-real-1 v)])
                      (loop npos seen hp-val bad-mhp? raw-mhp
                            (if (equal? nv v) chgs (cons k (cons nv chgs))))))]
               [else
                (loop npos seen hp-val bad-mhp? raw-mhp chgs)]))
           (let* ([c1 (if (= seen 31)
                          chgs
                          (let* ([a (if (zero? (bitwise-and seen 1)) (cons 'id (cons 101 chgs)) chgs)]
                                 [b (if (zero? (bitwise-and seen 2)) (cons 'type (cons (unit-type-sym base-h) a)) a)]
                                 [c (if (zero? (bitwise-and seen 4)) (cons 'x (cons (safe-coord default-x default-x) b)) b)]
                                 [d (if (zero? (bitwise-and seen 8)) (cons 'y (cons (safe-coord default-y default-y) c)) c)])
                            (if (zero? (bitwise-and seen 16)) (cons 'hp (cons 45 d)) d)))]
                  [c2 (if bad-mhp?
                          (let ([nv (max 1 (safe-nonneg-int raw-mhp hp-val))])
                            (if (equal? nv raw-mhp) c1 (cons 'max-hp (cons nv c1))))
                          c1)])
             (if (null? c2) base-h (apply-hash-chgs base-h c2)))))]
    [else
     (hash 'id 101 'type 'zergling 'x default-x 'y default-y 'hp 35)]))

(define (sanitize-bldg-record b [default-x 32.5] [default-y 32.5])
  (cond
    [(hash? b)
     (define base-h (if (immutable? b) b (for/hash ([(k v) (in-hash b)]) (values k v))))
     (let loop ([pos (hash-iterate-first base-h)]
                [seen 0]
                [hp-val 45]
                [mhp-val 500]
                [bad-mhp? #f]
                [raw-mhp #f]
                [bad-hp-pct? #f]
                [raw-hp-pct #f]
                [chgs '()])
       (if pos
           (let-values ([(k v) (hash-iterate-key+value base-h pos)])
             (define npos (hash-iterate-next base-h pos))
             (case k
               [(id)
                (define nseen (bitwise-ior seen 1))
                (if (sanitized-nonneg-int? v)
                    (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (safe-nonneg-int v 101)])
                      (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (eq? nv v) chgs (cons 'id (cons nv chgs))))))]
               [(type)
                (define nseen (bitwise-ior seen 2))
                (if (symbol? v)
                    (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (unit-type-sym base-h)])
                      (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (eq? nv v) chgs (cons 'type (cons nv chgs))))))]
               [(x)
                (define nseen (bitwise-ior seen 4))
                (cond
                  [(and (flonum? v) (fl>= v 0.0) (fl<= v 256.0))
                   (define r (fl* (flround (fl* v 2.0)) 0.5))
                   (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                         (if (fl= v r) chgs (cons 'x (cons r chgs))))]
                  [(and (exact-integer? v) (>= v 0) (<= v 256))
                   (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)]
                  [else
                   (define nv (safe-coord v default-x))
                   (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                         (if (equal? nv v) chgs (cons 'x (cons nv chgs))))])]
               [(y)
                (define nseen (bitwise-ior seen 8))
                (cond
                  [(and (flonum? v) (fl>= v 0.0) (fl<= v 256.0))
                   (define r (fl* (flround (fl* v 2.0)) 0.5))
                   (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                         (if (fl= v r) chgs (cons 'y (cons r chgs))))]
                  [(and (exact-integer? v) (>= v 0) (<= v 256))
                   (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)]
                  [else
                   (define nv (safe-coord v default-y))
                   (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                         (if (equal? nv v) chgs (cons 'y (cons nv chgs))))])]
               [(hp)
                (define nseen (bitwise-ior seen 16))
                (if (sanitized-pos-int? v)
                    (loop npos nseen v mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (max 1 (safe-nonneg-int v 45))])
                      (loop npos nseen nv mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (eq? nv v) chgs (cons 'hp (cons nv chgs))))))]
               [(max-hp)
                (define nseen (bitwise-ior seen 32))
                (if (sanitized-pos-int? v)
                    (loop npos nseen hp-val v bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (loop npos nseen hp-val mhp-val #t v bad-hp-pct? raw-hp-pct chgs))]
               [(hp-pct)
                (define nseen (bitwise-ior seen 64))
                (if (sanitized-unit-interval? v)
                    (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp #t v chgs))]
               [(build-progress)
                (define nseen (bitwise-ior seen 128))
                (if (sanitized-unit-interval? v)
                    (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (flmax 0.0 (flmin 1.0 (safe-finite-real v 1.0)))])
                      (loop npos nseen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (equal? nv v) chgs (cons 'build-progress (cons nv chgs))))))]
               [(shield energy atk-upg arm-upg shd-upg)
                (if (sanitized-nonneg-int? v)
                    (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (sanitize-opt-nonneg-0 v)])
                      (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (equal? nv v) chgs (cons k (cons nv chgs))))))]
               [(dps)
                (if (sanitized-nonneg-int? v)
                    (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (sanitize-opt-nonneg-12 v)])
                      (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (equal? nv v) chgs (cons 'dps (cons nv chgs))))))]
               [(ideal-harvesters assigned-harvesters)
                (if (sanitized-nonneg-int? v)
                    (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (sanitize-opt-nonneg-16 v)])
                      (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (equal? nv v) chgs (cons k (cons nv chgs))))))]
               [(z)
                (if (exact-integer? v)
                    (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (sanitize-opt-exact-10 v)])
                      (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (equal? nv v) chgs (cons 'z (cons nv chgs))))))]
               [(speed)
                (if (sanitized-nonneg-inexact? v)
                    (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (sanitize-opt-nonneg-real-3 v)])
                      (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (equal? nv v) chgs (cons 'speed (cons nv chgs))))))]
               [(damage-rate-ratio damage-taken-multiplier)
                (if (sanitized-nonneg-inexact? v)
                    (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)
                    (let ([nv (sanitize-opt-nonneg-real-1 v)])
                      (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct
                            (if (equal? nv v) chgs (cons k (cons nv chgs))))))]
               [else
                (loop npos seen hp-val mhp-val bad-mhp? raw-mhp bad-hp-pct? raw-hp-pct chgs)]))
           (let* ([c1 (if (= (bitwise-and seen 31) 31)
                          chgs
                          (let* ([a (if (zero? (bitwise-and seen 1)) (cons 'id (cons 101 chgs)) chgs)]
                                 [b1 (if (zero? (bitwise-and seen 2)) (cons 'type (cons (unit-type-sym base-h) a)) a)]
                                 [c (if (zero? (bitwise-and seen 4)) (cons 'x (cons (safe-coord default-x default-x) b1)) b1)]
                                 [d (if (zero? (bitwise-and seen 8)) (cons 'y (cons (safe-coord default-y default-y) c)) c)])
                            (if (zero? (bitwise-and seen 16)) (cons 'hp (cons 45 d)) d)))]
                  [max-hp-and-c2
                   (cond
                     [(zero? (bitwise-and seen 32))
                      (let ([m (max 500 hp-val)])
                        (cons m (cons 'max-hp (cons m c1))))]
                     [bad-mhp?
                      (let ([m (max 1 (safe-nonneg-int raw-mhp hp-val))])
                        (cons m (if (equal? m raw-mhp) c1 (cons 'max-hp (cons m c1)))))]
                     [else (cons mhp-val c1)])]
                  [max-hp (car max-hp-and-c2)]
                  [c2 (cdr max-hp-and-c2)]
                  [c3 (cond
                        [(zero? (bitwise-and seen 64))
                         (define pct (flmax 0.0 (flmin 1.0 (fl/ (->fl hp-val) (->fl max-hp)))))
                         (cons 'hp-pct (cons pct c2))]
                        [bad-hp-pct?
                         (define pct (flmax 0.0 (flmin 1.0 (safe-finite-real raw-hp-pct 1.0))))
                         (if (equal? pct raw-hp-pct) c2 (cons 'hp-pct (cons pct c2)))]
                        [else c2])]
                  [c4 (if (zero? (bitwise-and seen 128))
                          (cons 'build-progress (cons (if (hash-ref base-h 'under-construction #f) 0.5 1.0) c3))
                          c3)])
             (if (null? c4) base-h (apply-hash-chgs base-h c4)))))]
    [else
     (hash 'id 201 'type 'hatchery 'x default-x 'y default-y 'hp 1500 'max-hp 1500 'hp-pct 1.0 'build-progress 1.0)]))

(define (sanitize-effect-record eff)
  (cond
    [(hash? eff)
     (define raw-t (hash-ref eff 'type 'none))
     (define t (if (symbol? raw-t) raw-t 'none))
     (hash 'type t
           'x (safe-coord (hash-ref eff 'x 0.0) 0.0)
           'y (safe-coord (hash-ref eff 'y 0.0) 0.0))]
    [(and (list? eff) (= (length eff) 3))
     (hash 'type (if (symbol? (first eff)) (first eff) 'none)
           'x (safe-coord (second eff) 0.0)
           'y (safe-coord (third eff) 0.0))]
    [else
     (hash 'type 'none 'x 0.0 'y 0.0)]))

(define (sanitize-obs-hash obs)
  (cond
    [(not (hash? obs)) (sanitize-obs-hash (hash))]
    [(and (immutable? obs) (eq? (hash-ref obs '__sanitized? #f) #t)) obs]
    [else
     (define base-h (if (immutable? obs) obs (for/hash ([(k v) (in-hash obs)]) (values k v))))
     (define frame (safe-nonneg-int (hash-ref base-h 'frame 0) 0))
     (define minerals (safe-nonneg-int (hash-ref base-h 'minerals 200) 0))
     (define gas (safe-nonneg-int (hash-ref base-h 'gas 0) 0))
     (define supply-used (safe-nonneg-int (hash-ref base-h 'supply-used 12) 12))
     (define supply-cap (min 200 (safe-nonneg-int (hash-ref base-h 'supply-cap 15) 15)))
     (define supply-left
       (max 0 (safe-exact-int (hash-ref base-h 'supply-left (- supply-cap supply-used))
                              (max 0 (- supply-cap supply-used)))))
     (define pending-supply (safe-nonneg-int (hash-ref base-h 'pending-supply 0) 0))
     (define pending-workers (safe-nonneg-int (hash-ref base-h 'pending-workers 0) 0))
     (define depleting-bases
       (safe-nonneg-int (hash-ref base-h 'depleting-bases
                                  (if (or (eq? (hash-ref base-h 'mined-out #f) #t)
                                          (eq? (hash-ref base-h 'mined-out? #f) #t))
                                      1
                                      0))
                        0))
     (define busy-facilities (safe-nonneg-int (hash-ref base-h 'busy-facilities 0) 0))
     (define busy-townhalls (safe-nonneg-int (hash-ref base-h 'busy-townhalls 0) 0))
     (define enemy-workers-killed (safe-nonneg-int (hash-ref base-h 'enemy-workers-killed 0) 0))
     (define mineral-patch-id (safe-nonneg-int (hash-ref base-h 'mineral-patch-id 504) 504))
     (define base-x (safe-coord (hash-ref base-h 'base-x 32.5) 32.5))
     (define base-y (safe-coord (hash-ref base-h 'base-y 32.5) 32.5))
     (define enemy-x (safe-coord (hash-ref base-h 'enemy-x 160.5) 160.5))
     (define enemy-y (safe-coord (hash-ref base-h 'enemy-y 160.5) 160.5))
     (define dir-computed? #f)
     (define cached-ux 0.0)
     (define cached-uy 0.0)
     (define (ensure-dir!)
       (unless dir-computed?
         (let* ([dx (exact->inexact (- enemy-x base-x))]
                [dy (exact->inexact (- enemy-y base-y))]
                [d  (max 1.0 (sqrt (+ (* dx dx) (* dy dy))))])
           (set! cached-ux (/ dx d))
           (set! cached-uy (/ dy d))
           (set! dir-computed? #t))))
     (define raw-nat-x (hash-ref base-h 'natural-x SANITIZE-MISSING))
     (define raw-nat-y (hash-ref base-h 'natural-y SANITIZE-MISSING))
     (define nat-x
       (if (sanitized-tile-coord? raw-nat-x)
           raw-nat-x
           (let ()
             (ensure-dir!)
             (define def-nx (safe-coord (+ base-x (* 18.0 cached-ux)) 45.0))
             (safe-coord (if (eq? raw-nat-x SANITIZE-MISSING) def-nx raw-nat-x) def-nx))))
     (define nat-y
       (if (sanitized-tile-coord? raw-nat-y)
           raw-nat-y
           (let ()
             (ensure-dir!)
             (define def-ny (safe-coord (+ base-y (* 18.0 cached-uy)) 45.0))
             (safe-coord (if (eq? raw-nat-y SANITIZE-MISSING) def-ny raw-nat-y) def-ny))))
     (define raw-au (hash-ref base-h 'ally-units '()))
     (define raw-ab (hash-ref base-h 'ally-buildings '()))
     (define raw-eu (hash-ref base-h 'enemy-units '()))
     (define raw-eb (hash-ref base-h 'enemy-buildings '()))
     (define raw-eff (hash-ref base-h 'effects '()))
     (define ally-units
       (sanitize-record-list raw-au sanitize-unit-record base-x base-y))
     (define ally-buildings
       (sanitize-record-list raw-ab sanitize-bldg-record base-x base-y))
     (define third-x-raw (hash-ref base-h 'third-x #f))
     (define third-y-raw (hash-ref base-h 'third-y #f))
     (define has-explicit-third?
       (and (finite-real? third-x-raw)
            (finite-real? third-y-raw)))
     (define owned-third-th
       (and (not has-explicit-third?)
            (let ([fbx (exact->inexact base-x)]
                  [fby (exact->inexact base-y)]
                  [fnx (exact->inexact nat-x)]
                  [fny (exact->inexact nat-y)])
              (for/first ([b (in-list ally-buildings)]
                          #:when (and (hash? b)
                                      (memq (fast-canonical-structure-sym (hash-ref b 'type 'none))
                                            '(hatchery lair hive nexus command-center orbital-command planetary-fortress))
                                      (let* ([bx (exact->inexact (hash-ref b 'x base-x))]
                                             [by (exact->inexact (hash-ref b 'y base-y))]
                                             [dx1 (fl- bx fbx)]
                                             [dy1 (fl- by fby)]
                                             [dx2 (fl- bx fnx)]
                                             [dy2 (fl- by fny)])
                                        (and (fl> (fl+ (fl* dx1 dx1) (fl* dy1 dy1)) 49.0)
                                             (fl> (fl+ (fl* dx2 dx2) (fl* dy2 dy2)) 49.0)))))
                b))))
     (define third-x
       (if has-explicit-third?
           (safe-coord third-x-raw 60.5)
           (if owned-third-th
               (safe-coord (hash-ref owned-third-th 'x 60.5) 60.5)
               (begin
                 (ensure-dir!)
                 (safe-coord (+ base-x (* 24.25 cached-ux) (* -14.0 cached-uy)) 60.5)))))
     (define third-y
       (if has-explicit-third?
           (safe-coord third-y-raw 40.5)
           (if owned-third-th
               (safe-coord (hash-ref owned-third-th 'y 40.5) 40.5)
               (begin
                 (ensure-dir!)
                 (safe-coord (+ base-y (* 24.25 cached-uy) (* 14.0 cached-ux)) 40.5)))))
     (define raw-eexp-x
       (let ([v (hash-ref base-h 'enemy-expand-x SANITIZE-MISSING)])
         (if (eq? v SANITIZE-MISSING) (hash-ref base-h 'enemy-exp-x SANITIZE-MISSING) v)))
     (define enemy-exp-x
       (if (sanitized-tile-coord? raw-eexp-x)
           raw-eexp-x
           (let ()
             (ensure-dir!)
             (define def-eex (safe-coord (- enemy-x (* 18.0 cached-ux)) 148.0))
             (safe-coord (if (eq? raw-eexp-x SANITIZE-MISSING) def-eex raw-eexp-x) def-eex))))
     (define raw-eexp-y
       (let ([v (hash-ref base-h 'enemy-expand-y SANITIZE-MISSING)])
         (if (eq? v SANITIZE-MISSING) (hash-ref base-h 'enemy-exp-y SANITIZE-MISSING) v)))
     (define enemy-exp-y
       (if (sanitized-tile-coord? raw-eexp-y)
           raw-eexp-y
           (let ()
             (ensure-dir!)
             (define def-eey (safe-coord (- enemy-y (* 18.0 cached-uy)) 148.0))
             (safe-coord (if (eq? raw-eexp-y SANITIZE-MISSING) def-eey raw-eexp-y) def-eey))))
     (define enemy-units
       (sanitize-record-list raw-eu sanitize-unit-record nat-x nat-y))
     (define enemy-buildings
       (sanitize-record-list raw-eb sanitize-bldg-record enemy-x enemy-y))
     (define effects
       (if (and (list? raw-eff) (pair? raw-eff))
           (for/list ([e (in-list raw-eff)]) (sanitize-effect-record e))
           '()))
     (define vis-secs
       (let ([vs (hash-ref base-h 'visible-sectors '(0 1 2 3))])
         (cond
           [(not (list? vs)) '(0 1 2 3)]
           [(for/and ([v (in-list vs)]) (and (exact-integer? v) (>= v 0) (< v 64))) vs]
           [else
            (for/list ([raw (in-list vs)]
                       #:when (let ([idx (if (exact-integer? raw) raw (safe-exact-int raw -1))])
                                (and (>= idx 0) (< idx 64))))
              (if (exact-integer? raw) raw (safe-exact-int raw -1)))])))
     (define res-upgs
       (let ([ru (hash-ref base-h 'researched-upgrades '())])
         (cond
           [(or (not (list? ru)) (null? ru)) '()]
           [(for/and ([u (in-list ru)]) (symbol? u)) ru]
           [else (for/list ([u (in-list ru)] #:when (symbol? u)) u)])))
     (define pend-upgs
       (let ([pu (hash-ref base-h 'pending-upgrades '())])
         (cond
           [(or (not (list? pu)) (null? pu)) '()]
           [(for/and ([u (in-list pu)]) (symbol? u)) pu]
           [else (for/list ([u (in-list pu)] #:when (symbol? u)) u)])))
     (define nuke-alert
       (let ([na (hash-ref base-h 'nuke-alert #f)])
         (cond
           [(not na) #f]
           [(pair? na) (cons (safe-coord (car na) nat-x) (safe-coord (cdr na) nat-y))]
           [else (cons nat-x nat-y)])))
     (define out-h
       (if (eq? (hash-ref base-h '__sanitized? #f) #t)
           base-h
           (hash-set base-h '__sanitized? #t)))
     (define-syntax-rule (push-obs-eq k v)
       (unless (eq? (hash-ref base-h k SANITIZE-MISSING) v)
         (set! out-h (hash-set out-h k v))))
     (define-syntax-rule (push-obs-eqv k v)
       (unless (equal? (hash-ref base-h k SANITIZE-MISSING) v)
         (set! out-h (hash-set out-h k v))))
     (define-syntax-rule (push-opt-key k pred? sanitizer)
       (let ([ov (hash-ref base-h k SANITIZE-MISSING)])
         (unless (or (eq? ov SANITIZE-MISSING) (pred? ov))
           (let ([nv (sanitizer ov)])
             (unless (equal? nv ov)
               (set! out-h (hash-set out-h k nv)))))))
     (push-obs-eq 'frame frame)
     (push-obs-eq 'minerals minerals)
     (push-obs-eq 'gas gas)
     (push-obs-eq 'supply-used supply-used)
     (push-obs-eq 'supply-cap supply-cap)
     (push-obs-eq 'supply-left supply-left)
     (push-obs-eq 'pending-supply pending-supply)
     (push-obs-eq 'pending-workers pending-workers)
     (push-obs-eq 'depleting-bases depleting-bases)
     (push-obs-eq 'busy-facilities busy-facilities)
     (push-obs-eq 'busy-townhalls busy-townhalls)
     (push-obs-eq 'enemy-workers-killed enemy-workers-killed)
     (push-obs-eq 'mineral-patch-id mineral-patch-id)
     (push-obs-eqv 'base-x base-x)
     (push-obs-eqv 'base-y base-y)
     (push-obs-eqv 'natural-x nat-x)
     (push-obs-eqv 'natural-y nat-y)
     (push-obs-eqv 'third-x third-x)
     (push-obs-eqv 'third-y third-y)
     (push-obs-eqv 'enemy-x enemy-x)
     (push-obs-eqv 'enemy-y enemy-y)
     (push-obs-eqv 'enemy-expand-x enemy-exp-x)
     (push-obs-eqv 'enemy-exp-x enemy-exp-x)
     (push-obs-eqv 'enemy-expand-y enemy-exp-y)
     (push-obs-eqv 'enemy-exp-y enemy-exp-y)
     (push-obs-eq 'ally-units ally-units)
     (push-obs-eq 'ally-buildings ally-buildings)
     (push-obs-eq 'enemy-units enemy-units)
     (push-obs-eq 'enemy-buildings enemy-buildings)
     (push-obs-eq 'effects effects)
     (push-obs-eq 'visible-sectors vis-secs)
     (push-obs-eq 'researched-upgrades res-upgs)
     (push-obs-eq 'pending-upgrades pend-upgs)
     (push-obs-eqv 'nuke-alert nuke-alert)
     (push-opt-key 'gas-workers sanitized-nonneg-int? sanitize-opt-nonneg-0)
     (push-opt-key 'our-terrain-z exact-integer? sanitize-opt-exact-10)
     (push-opt-key 'enemy-terrain-z exact-integer? sanitize-opt-exact-10)
     (push-opt-key 'mineral-harvesters sanitized-nonneg-int? sanitize-opt-nonneg-0)
     (push-opt-key 'ideal-mineral-harvesters sanitized-nonneg-int? sanitize-opt-nonneg-0)
     (push-opt-key 'gas-harvesters sanitized-nonneg-int? sanitize-opt-nonneg-0)
     (push-opt-key 'ideal-gas-harvesters sanitized-nonneg-int? sanitize-opt-nonneg-0)
     (push-opt-key 'army-supply sanitized-nonneg-int? sanitize-opt-nonneg-0)
     out-h]))

(define (detect-actual-race-from-obs obs fallback-race)
  (define obs-race (hash-ref obs 'actual-race (hash-ref obs 'race #f)))
  (cond
    [(and obs-race (not (memq obs-race '(Random random "Random" "random"))))
     (normalize-race-sym obs-race)]
    [else
     (define all-types
       (append (map (lambda (u) (fast-canonical-unit-sym (unit-type-sym u)))
                    (hash-ref obs 'ally-units '()))
               (map (lambda (b) (fast-canonical-structure-sym (unit-type-sym b)))
                    (hash-ref obs 'ally-buildings '()))))
     (cond
       [(ormap (lambda (t) (memq t '(drone overlord overseer hatchery lair hive spawning-pool zergling roach queen))) all-types)
        'Zerg]
       [(ormap (lambda (t) (memq t '(probe nexus pylon gateway warp-gate forge cybernetics-core zealot stalker adept sentry))) all-types)
        'Protoss]
       [(ormap (lambda (t) (memq t '(scv command-center orbital-command planetary-fortress supply-depot barracks factory starport marine marauder siege-tank))) all-types)
        'Terran]
       [else fallback-race])]))

;; =============================================================================
;; Layer 1: Spatial Perception & Frame-0 Random Race Resolution
;; =============================================================================

(define (step-layer1-perception! rt raw-obs #:sanitized? [sanitized? #f])
  (define obs (if sanitized? raw-obs (sanitize-obs-hash raw-obs)))
  (define frame (hash-ref obs 'frame 0))
  (define resolved-race (detect-actual-race-from-obs obs (live-bot-runtime-actual-race rt)))
  (set-live-bot-runtime-actual-race! rt resolved-race)
  (set-mastermind-state-race! (live-bot-runtime-mastermind rt) resolved-race)
  (set-mirror-mind-state-our-race! (live-bot-runtime-mirror-mind rt) resolved-race)
  (when (and (eq? (live-bot-runtime-configured-race rt) 'Random)
             (not (eq? resolved-race 'Random))
             (not (live-bot-runtime-doctrine rt)))
    (define cur-pers (mastermind-state-personality (live-bot-runtime-mastermind rt)))
    (define target-pers (default-personality-for-race resolved-race))
    (when (and (bot-personality? cur-pers)
               (bot-personality? target-pers)
               (memq (bot-personality-name cur-pers)
                     '(SCARLETT-CREEP-SWARM-PERSONALITY
                       MARV-MACRO-OPEN-PERSONALITY
                       CLEM-TEMPO-MULTITASK-PERSONALITY))
               (not (eq? (bot-personality-name cur-pers)
                         (bot-personality-name target-pers))))
      (set-mastermind-state-personality! (live-bot-runtime-mastermind rt) target-pers)))
  (define (finite-nonneg-coord? v)
    (if (flonum? v)
        (and (fl>= v 0.0) (fl= (fl- v v) 0.0))
        (and (real? v) (>= v 0) (= (- v v) 0))))
  (define ally-units
    (let ([raw (hash-ref obs 'ally-units '())])
      (let loop ([rem raw])
        (cond
          [(null? rem) raw]
          [(let ([u (car rem)])
             (and (hash? u)
                  (not (and (finite-nonneg-coord? (hash-ref u 'x #f))
                            (finite-nonneg-coord? (hash-ref u 'y #f))))))
           (map (lambda (u)
                  (if (hash? u)
                      (let ([ux (hash-ref u 'x #f)]
                            [uy (hash-ref u 'y #f)])
                        (if (and (finite-nonneg-coord? ux) (finite-nonneg-coord? uy))
                            u
                            (let ([nx (safe-nonneg-int ux 32)]
                                  [ny (safe-nonneg-int uy 32)])
                              (if (and (eqv? ux nx) (eqv? uy ny))
                                  u
                                  (hash-set (hash-set u 'x nx) 'y ny)))))
                      u))
                raw)]
          [else (loop (cdr rem))]))))
  (define enemy-units
    (let ([raw (hash-ref obs 'enemy-units '())])
      (let loop ([rem raw])
        (cond
          [(null? rem) raw]
          [(let ([u (car rem)])
             (and (hash? u)
                  (not (and (finite-nonneg-coord? (hash-ref u 'x #f))
                            (finite-nonneg-coord? (hash-ref u 'y #f))))))
           (map (lambda (u)
                  (if (hash? u)
                      (let ([ux (hash-ref u 'x #f)]
                            [uy (hash-ref u 'y #f)])
                        (if (and (finite-nonneg-coord? ux) (finite-nonneg-coord? uy))
                            u
                            (let ([nx (safe-nonneg-int ux 160)]
                                  [ny (safe-nonneg-int uy 160)])
                              (if (and (eqv? ux nx) (eqv? uy ny))
                                  u
                                  (hash-set (hash-set u 'x nx) 'y ny)))))
                      u))
                raw)]
          [else (loop (cdr rem))]))))
  (define visible-sectors (hash-ref obs 'visible-sectors '(0 1 2 3)))
  (perception-grid-ingest-frame!
   (live-bot-runtime-perception rt)
   frame
   ally-units
   enemy-units
   visible-sectors))

;; =============================================================================
;; Layer 1b: ZeroSpace Mastermind & Posture State Machine
;; =============================================================================

(define filter-rush-threat-cache-cell (make-thread-cell #f))

(define (filter-rush-threat-enemies enemy-units [base-x 32.5] [base-y 32.5] [nat-x 45.0] [nat-y 45.0])
  (define bx (if (flonum? base-x) base-x (exact->inexact base-x)))
  (define by (if (flonum? base-y) base-y (exact->inexact base-y)))
  (define nx (if (flonum? nat-x) nat-x (exact->inexact nat-x)))
  (define ny (if (flonum? nat-y) nat-y (exact->inexact nat-y)))
  (define cached (thread-cell-ref filter-rush-threat-cache-cell))
  (if (and cached
           (eq? (vector-ref cached 0) enemy-units)
           (fl= (vector-ref cached 1) bx)
           (fl= (vector-ref cached 2) by)
           (fl= (vector-ref cached 3) nx)
           (fl= (vector-ref cached 4) ny))
      (vector-ref cached 5)
      (let ([res
             (for/list ([e (in-list (if (list? enemy-units) enemy-units '()))]
                        #:when (and (hash? e)
                                    (let ([t (unit-type-sym e)])
                                      (and (not (fast-scout-or-noncombat-enemy-sym? t))
                                           (not (eq? (hash-ref e 'changeling? #f) #t))
                                           (not (eq? (hash-ref e 'is-hallucination #f) #t))
                                           (not (eq? (hash-ref e 'hallucination? #f) #t))
                                           (not (eq? (hash-ref e 'hallucination #f) #t))
                                           (or (not (or (eq? t 'drone) (eq? t 'probe) (eq? t 'scv)))
                                               (let ([ex-raw (safe-coord (hash-ref e 'x nx) nx)]
                                                     [ey-raw (safe-coord (hash-ref e 'y ny) ny)])
                                                 (define ex (if (flonum? ex-raw) ex-raw (exact->inexact ex-raw)))
                                                 (define ey (if (flonum? ey-raw) ey-raw (exact->inexact ey-raw)))
                                                 (define dx1 (fl- bx ex))
                                                 (define dy1 (fl- by ey))
                                                 (define dx2 (fl- nx ex))
                                                 (define dy2 (fl- ny ey))
                                                 (or (fl<= (fl+ (fl* dx1 dx1) (fl* dy1 dy1)) 2025.0)
                                                     (fl<= (fl+ (fl* dx2 dx2) (fl* dy2 dy2)) 2025.0))))))))
               e)])
        (when (and (list? enemy-units)
                   (or (null? enemy-units)
                       (and (hash? (car enemy-units)) (immutable? (car enemy-units)))))
          (thread-cell-set! filter-rush-threat-cache-cell (vector enemy-units bx by nx ny res)))
        res)))

(define (compute-next-posture rt raw-obs [raw-fap-score 0]
                              #:rush-enemies [pre-rush-enemies #f]
                              #:ally-unit-types [pre-ally-unit-types #f]
                              #:ally-bldgs [pre-ally-bldgs #f])
  (define obs (sanitize-obs-hash raw-obs))
  (define fap-score (safe-finite-real (hash-ref obs 'fap-score raw-fap-score) 0.0))
  (define frame (hash-ref obs 'frame 0))
  (define cfg-race (live-bot-runtime-configured-race rt))
  (define act-race (live-bot-runtime-actual-race rt))
  (define cur (live-bot-runtime-posture rt))
  (define base-x (hash-ref obs 'base-x 32.5))
  (define base-y (hash-ref obs 'base-y 32.5))
  (define nat-x (hash-ref obs 'natural-x 45.0))
  (define nat-y (hash-ref obs 'natural-y 45.0))
  (define enemy-units (hash-ref obs 'enemy-units '()))
  (define rush-enemies
    (or pre-rush-enemies
        (filter-rush-threat-enemies enemy-units base-x base-y nat-x nat-y)))
  (define ally-unit-types
    (or pre-ally-unit-types
        (map unit-type-sym (hash-ref obs 'ally-units '()))))
  (define ally-bldgs
    (or pre-ally-bldgs
        (map unit-type-sym (hash-ref obs 'ally-buildings '()))))

  (define in-crisis?
    (not (not (memq cur '(EarlyScoutCrisis CrisisZealotRush CrisisZerglingFlood CrisisEarlyBust)))))
  (define in-victory?
    (not (not (memq cur '(MothmanApexVictory SwarmVictory ProtossArmadaVictory
                          TerranDominionVictory ChameleonSupremeVictory)))))
  (define in-midgame-recovery-or-contain?
    (not (not (memq cur '(StalkerImmortalColossus MacroHydraLurker BioTankMedivac
                          MidGameBioTankContain DragoonReaverVanguard MutaLurkerContain
                          VesselGhostPush TriRaceVanguardContain)))))

  ;; Hysteresis band [-8, -2] (±3 around -5) for crisis entry/exit
  (define rush-fap-threat?
    (if in-crisis?
        (<= fap-score -2.0)
        (< fap-score -8.0)))

  (define rush-threat?
    (and (< frame 2500)
         (>= (length rush-enemies) 3)
         rush-fap-threat?))

  ;; Hysteresis deadband: enter >= +13.0 (or no rush & >= +8.0), exit <= -5.0, catastrophic < -15.0
  (define catastrophic-deficit? (< fap-score -15.0))
  (define victory-fap-ok?
    (cond
      [catastrophic-deficit? #f]
      [in-victory?           (> fap-score -5.0)]
      [else
       (or (>= fap-score 13.0)
           (and (null? rush-enemies) (>= fap-score 8.0)))]))

  (cond
    [(and (eq? cfg-race 'Random)
          (or (eq? act-race 'Random)
              (not (hash-has-key? raw-obs 'mineral-harvesters))))
     (define victory-ready?
       (or (>= frame 3500)
           (memq 'ghost ally-unit-types)
           (memq 'colossus ally-unit-types)
           (memq 'corruptor ally-unit-types)
           in-victory?))
     (cond
       [rush-threat? 'EarlyScoutCrisis]
       [(and victory-ready? victory-fap-ok?)
        'MothmanApexVictory]
       [(and victory-ready? catastrophic-deficit?)
        'MidGameBioTankContain]
       [(and victory-ready? (eq? cur 'MidGameBioTankContain))
        'MidGameBioTankContain]
       [(or (>= frame 1800)
            (memq 'starport ally-bldgs)
            (memq 'spire ally-bldgs)
            (memq 'robotics-facility ally-bldgs))
        'TriRaceVanguardContain]
       [(>= frame 350) 'AdaptiveCounterRecovery]
       [else 'RandomRollOpening])]
    [(eq? act-race 'Zerg)
     (define victory-ready?
       (or (>= frame 3200)
           (memq 'hive ally-bldgs)
           (memq 'corruptor ally-unit-types)
           in-victory?))
     (cond
       [rush-threat? 'CrisisZealotRush]
       [(and victory-ready? victory-fap-ok?)
        'SwarmVictory]
       [(and victory-ready? catastrophic-deficit?)
        'MacroHydraLurker]
       [(and victory-ready? (eq? cur 'MacroHydraLurker))
        'MacroHydraLurker]
       [(or (memq 'lair ally-bldgs) (memq 'spire ally-bldgs) (>= frame 1800))
        'MutaLurkerContain]
       [(or (>= frame 300) (memq 'spawning-pool ally-bldgs))
        'SunkenLairRecovery]
       [else 'Macro12Hatch])]
    [(eq? act-race 'Protoss)
     (define victory-ready?
       (or (>= frame 2600)
           (memq 'stalker ally-unit-types)
           (memq 'colossus ally-unit-types)
           in-victory?))
     (cond
       [rush-threat? 'CrisisZerglingFlood]
       [(and victory-ready? victory-fap-ok?)
        'ProtossArmadaVictory]
       [(and victory-ready? catastrophic-deficit?)
        'StalkerImmortalColossus]
       [(and victory-ready? (eq? cur 'StalkerImmortalColossus))
        'StalkerImmortalColossus]
       [(or (memq 'cybernetics-core ally-bldgs) (memq 'robotics-facility ally-bldgs) (>= frame 1800))
        'DragoonReaverVanguard]
       [(or (>= frame 300) (memq 'gateway ally-bldgs) (memq 'warp-gate ally-bldgs) (memq 'forge ally-bldgs))
        'CannonWallRecovery]
       [else 'ForgeFastExpand])]
    [else ;; Terran
     (define victory-ready?
       (or (>= frame 3200)
           (memq 'ghost ally-unit-types)
           in-victory?))
     (cond
       [rush-threat? 'CrisisEarlyBust]
       [(and victory-ready? victory-fap-ok?)
        'MothmanApexVictory]
       [(and victory-ready? catastrophic-deficit?)
        'BioTankMedivac]
       [(and victory-ready? (eq? cur 'BioTankMedivac))
        'BioTankMedivac]
       [(or (memq 'starport ally-bldgs) (memq 'siege-tank ally-unit-types) (>= frame 1800))
        'VesselGhostPush]
       [(or (>= frame 300) (memq 'barracks ally-bldgs))
        'BunkerSiegeRecovery]
       [else 'OneRaxFE])]))

(define (step-layer1b-mastermind! rt raw-obs #:sanitized? [sanitized? #f])
  (define obs (if sanitized? raw-obs (sanitize-obs-hash raw-obs)))
  (define ally-units (hash-ref obs 'ally-units '()))
  (define enemy-units (hash-ref obs 'enemy-units '()))
  (define base-x (hash-ref obs 'base-x 32.5))
  (define base-y (hash-ref obs 'base-y 32.5))
  (define nat-x (hash-ref obs 'natural-x 45.0))
  (define nat-y (hash-ref obs 'natural-y 45.0))
  (define ally-combat-rev '())
  (define ally-unit-types-rev '())
  (define worker-cnt 0)
  (for ([u (in-list ally-units)])
    (define t (unit-type-sym u))
    (set! ally-unit-types-rev (cons t ally-unit-types-rev))
    (when (hash? u)
      (when (memq t '(drone probe scv))
        (set! worker-cnt (add1 worker-cnt)))
      (when (and (not (combat-unit-excluded-sym? t))
                 (not (eq? (hash-ref u 'is-hallucination #f) #t))
                 (not (eq? (hash-ref u 'hallucination #f) #t))
                 (not (eq? (hash-ref u 'hallucination? #f) #t)))
        (set! ally-combat-rev (cons u ally-combat-rev)))))
  (define ally-combat (reverse ally-combat-rev))
  (define ally-unit-types (reverse ally-unit-types-rev))
  (define enemy-combat (filter-rush-threat-enemies enemy-units base-x base-y nat-x nat-y))
  (define fap-score
    (let ([ov (hash-ref obs 'fap-score #f)])
      (if (finite-real? ov)
          (safe-finite-real ov 0.0)
          (fap-evaluate-engagement ally-combat enemy-combat))))
  (define ally-bldgs (map unit-type-sym (hash-ref obs 'ally-buildings '())))
  (define mstate (live-bot-runtime-mastermind rt))
  (step-double-reaction! mstate
                         #:fap-score fap-score
                         #:enemy-units enemy-units
                         #:ally-buildings ally-bldgs
                         #:self-workers (max 12 worker-cnt)
                         #:enemy-workers 14
                         #:self-army (* 50 (length ally-combat))
                         #:enemy-army (* 50 (length enemy-combat)))
  (when (live-bot-runtime-doctrine rt)
    (define new-p (step-doctrine-loadout! (live-bot-runtime-doctrine rt)
                                          #:fap-score fap-score
                                          #:under-rush? (< fap-score -20)))
    (set-mastermind-state-personality! mstate new-p))
  (define next-posture
    (compute-next-posture rt obs fap-score
                          #:rush-enemies enemy-combat
                          #:ally-unit-types ally-unit-types
                          #:ally-bldgs ally-bldgs))
  (define old-posture (live-bot-runtime-posture rt))
  (define posture-actions
    (if (not (eq? next-posture old-posture))
        (let* ([new-hist (append (live-bot-runtime-posture-history rt) (list next-posture))]
               [capped-hist (if (> (length new-hist) 32)
                                (drop new-hist (- (length new-hist) 32))
                                new-hist)])
          (set-live-bot-runtime-posture! rt next-posture)
          (set-live-bot-runtime-posture-history! rt capped-hist)
          (list (list 'posture-transition next-posture)))
        '()))
  (values posture-actions fap-score))

;; =============================================================================
;; Layer 1c: Adaptive Mirror-Mind Opponent Prediction Layer
;; =============================================================================

(define (step-layer1c-mirror-mind! rt obs)
  (define mmstate (live-bot-runtime-mirror-mind rt))
  (step-mirror-mind-predictor! mmstate obs))

;; =============================================================================
;; Layer 2: Economy, Zero-Supply-Block Macro, Pro Mechanics & Anti-Cheese
;; =============================================================================

(define UNIT-SUPPLY-COST-CACHE (make-hasheq))
(define (unit-supply-cost unit-sym)
  (hash-ref! UNIT-SUPPLY-COST-CACHE unit-sym (lambda () (sc2-supply-cost unit-sym 2))))

;; Pooled mutable context & top-level phases for step-layer2-economy!
(struct l2-ctx
  (minerals
   gas
   pending-supply
   supply-left
   effective-free-supply
   actions
   bldg-types
   morphing-bldg-types
   pending-upgs
   unit-counts
   bo-reserved-min
   bo-reserved-gas
   worker-pull-emitted-1ab?
   cur-rush-fighting-wids
   cur-rush-disengaging-wids
   uncontested-zerg-hatch-cache
   pad-camped-cache
   pad-last-px
   pad-last-py
   pad-last-r
   pad-last-val
   ally-canon-bldg-counts-ht
   rt
   raw-obs
   orig-raw-obs
   race
   SIMCITY-EXCLUDED-BLDG-SYMS
   active-assimilators
   active-bases
   active-escrow-sym
   active-extractors
   active-intel-method
   active-refineries
   active-worker-count
   addon-swap-acts
   allow-exact-wall-slot?
   ally-bldgs
   ally-combat-supply-early
   ally-combat-units
   ally-units
   bank-target
   barracks-list
   base-x
   base-y
   basic-combat-min-floor
   bldg-actively-damaged?
   blocked-nat-expanded-early?
   bo-active-goal
   bo-eval
   bo-goal-sym
   bypass-wall-depot1?
   bypass-wall-pylon?
   ccs
   cd-tracker
   cg4-cap
   cg5-cap
   cg6-cap
   cg7-cap
   cheese-dist-thresh
   claimed-addon-fac-ids
   colossus-goal-cap
   corridor-mid-x
   corridor-mid-y
   cortex
   creep-self-sustaining?
   crisis-freeze-expand-or-gas?
   crisis-freeze-workers?
   crisis-tech-upgrade-deferral?
   cur-escrow-age-frames
   cur-escrow-peak-min
   cur-escrow-start-frame
   cur-exp-streak-start
   cur-peak-supply
   cur-th-total-cnt
   depleting-bases
   desired-bases
   dyn-plan
   early-enemy-nat-x
   early-enemy-nat-y
   early-enemy-third-x
   early-enemy-third-y
   early-race-th-sym
   early-survival-crisis?
   eff-pending-supply
   eff-phase-supply
   effective-enemy-race
   endgame-corner-hunt?
   enemy-air-raiders?
   enemy-bldgs
   enemy-capital-air?
   enemy-cloaked-or-air?
   enemy-exp-x
   enemy-exp-y
   enemy-heavy-ground-siege?
   enemy-muta-cnt-p
   enemy-rush-workers
   enemy-u-counts
   enemy-units
   enemy-x
   enemy-y
   escrow-suppressed-active?
   escrow-suppressed-goal
   escrow-suppressed-until-frame
   escrow-timed-out-now?
   exp-goal-sym-this-step
   expansion-pads
   factories-list
   fbx
   fby
   first-ready-pylon
   fnx
   fny
   forward-proxy-detected?
   forward-proxy-structures
   frame
   ftx
   fty
   gas-bkt25
   gateways
   goal-stream-alloc
   ground-enemy-units-for-cheese
   hard-supply-lockout-reserve-min
   hard-supply-lockout?
   has-gas-harvesters?
   has-nat?
   has-third?
   has-unpowered-bldg?
   hatcheries
   in-base-proxy-completed-cannon?
   in-base-proxy-completed-cannons
   in-base-proxy-detected?
   in-base-proxy-structures
   initial-enemy-race
   intel-confidence
   intel-coverage
   intel-deficit
   intel-freshness
   intel-priority-sector
   intel-staleness-frames
   intel-target-goal
   l2-sc
   larva-slot-cnt
   last-enemy-seen-frame
   last-seen-army-frame
   last-seen-main-frame
   last-seen-natural-frame
   last-seen-third-frame
   leases
   live-army-supply
   live-enemy-threat-supply
   live-game-obs?
   live-game?
   live-gas-harvesters
   live-obs-harvesters?
   live-open-combat-slots
   macro-decision
   macro-plan
   map-grids
   max-escrow-timeout-frames
   mc-cv
   min-bkt25
   mmstate-rush-post
   nat-block-thresh2
   nat-x
   nat-y
   natural-blocked?
   need-supply?
   next-exp-timeout-cnt
   nexuses
   non-builder-defense-workers
   non-building-workers
   obs
   obs-minerals
   oledger
   oledger-early
   open-prod-slots
   open-prod-slots-snapshot
   orphaned-prereqs
   owned-base-coords
   pending-cc-count
   pending-workers
   plan-next-actions-ht
   power-placement-failed?
   pressure-metrics
   prev-exp-last-f
   prev-rush-fighting-wids
   prev-tel-early
   prev-telemetry-ht
   prio-log-line
   prio-saving-for-sym
   prio-scheduled-actions
   prio-summary
   prod-facilities
   protoss-aa-needed?
   protoss-emergency-pylon?
   protoss-matchup-wall
   protoss-pending-robo-gas-reserve
   protoss-pylon-count
   protoss-saving-for-expand?
   proxy-or-cheese-enemies
   proxy-structure-threat-supply
   race-th-sym
   raw-enemy-bldgs-early
   ready-bldg-counts
   ready-bldg-types
   ready-bldgs
   ready-hatch-count
   real-depot-count
   real-pylon-count
   recalled-groups
   remembered-enemy-threat-frame
   remembered-enemy-threat-supply
   repaired-prereqs
   researched-upgs
   reserve-supply-floor?
   reserved-expansion-minerals
   rush-def-st
   rush-threat-enemies
   rush-worker-swarm?
   scout-rush-aborted-latch?
   scout-st
   scout-worker
   scout-worker-id
   severe-intel-blindness?
   step-geysers
   step-mineral-patches
   step-neutral-units
   step-wall-aabbs
   stream-spendable-ht
   sup-left-key
   supply-at-risk?
   supply-cap
   supply-provider-sym
   supply-threshold
   supply-used
   target-workers
   tech-obs
   terran-addon-ox
   terran-addon-oy
   terran-addon-xs
   terran-addon-ys
   terran-cannon-breakout-mode?
   terran-emergency-depot?
   terran-ideal-worker-cap
   terran-ramp-wall
   terran-rax-reactor-bldgs
   terran-rax-techlab-bldgs
   terran-saving-for-expand?
   terran-saving-for-orbital?
   third-x
   third-y
   total-bldg-counts
   total-workers
   townhalls
   uncamped-pad-cache
   under-base-attack?
   under-early-cheese?
   unit-types
   unpowered-protoss-bldg
   urgent-combat-or-intel-need?
   wall-slot-3
   wall-st
   wall-supply-attempts
   worker-rush-active?
   workers
   zerg-fog-army-floor-ok?
   zerg-hold-overlord-min?
   zerg-holding-for-aa-corruptor?
   zerg-holding-for-aa-spire?
   zerg-larva-mineral-surplus-ok?
   zerg-real-anti-air-threat?
   zerg-saving-for-expand?
   zerg-spire-res-gas
   zerg-spire-res-min
   zerg-vs-tp-or-fog-floor)
  #:mutable)

(define (make-l2-ctx)
  (l2-ctx #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f))

(define-rt-weak-state rt-l2-ctx (make-l2-ctx))

(define (l2-clear-ctx-refs! ctx)
  (set-l2-ctx-actions! ctx #f)
  (set-l2-ctx-bldg-types! ctx #f)
  (set-l2-ctx-morphing-bldg-types! ctx #f)
  (set-l2-ctx-pending-upgs! ctx #f)
  (set-l2-ctx-cur-rush-fighting-wids! ctx #f)
  (set-l2-ctx-cur-rush-disengaging-wids! ctx #f)
  (set-l2-ctx-uncontested-zerg-hatch-cache! ctx #f)
  (set-l2-ctx-pad-camped-cache! ctx #f)
  (set-l2-ctx-rt! ctx #f)
  (set-l2-ctx-raw-obs! ctx #f)
  (set-l2-ctx-orig-raw-obs! ctx #f)
  (set-l2-ctx-race! ctx #f)
  (set-l2-ctx-SIMCITY-EXCLUDED-BLDG-SYMS! ctx #f)
  (set-l2-ctx-active-assimilators! ctx #f)
  (set-l2-ctx-active-bases! ctx #f)
  (set-l2-ctx-active-escrow-sym! ctx #f)
  (set-l2-ctx-active-extractors! ctx #f)
  (set-l2-ctx-active-refineries! ctx #f)
  (set-l2-ctx-addon-swap-acts! ctx #f)
  (set-l2-ctx-ally-bldgs! ctx #f)
  (set-l2-ctx-ally-combat-units! ctx #f)
  (set-l2-ctx-ally-units! ctx #f)
  (set-l2-ctx-bank-target! ctx #f)
  (set-l2-ctx-barracks-list! ctx #f)
  (set-l2-ctx-bo-eval! ctx #f)
  (set-l2-ctx-ccs! ctx #f)
  (set-l2-ctx-cd-tracker! ctx #f)
  (set-l2-ctx-cheese-dist-thresh! ctx #f)
  (set-l2-ctx-claimed-addon-fac-ids! ctx #f)
  (set-l2-ctx-cortex! ctx #f)
  (set-l2-ctx-depleting-bases! ctx #f)
  (set-l2-ctx-desired-bases! ctx #f)
  (set-l2-ctx-dyn-plan! ctx #f)
  (set-l2-ctx-early-race-th-sym! ctx #f)
  (set-l2-ctx-effective-enemy-race! ctx #f)
  (set-l2-ctx-enemy-bldgs! ctx #f)
  (set-l2-ctx-enemy-rush-workers! ctx #f)
  (set-l2-ctx-enemy-units! ctx #f)
  (set-l2-ctx-expansion-pads! ctx #f)
  (set-l2-ctx-factories-list! ctx #f)
  (set-l2-ctx-fbx! ctx #f)
  (set-l2-ctx-fby! ctx #f)
  (set-l2-ctx-first-ready-pylon! ctx #f)
  (set-l2-ctx-fnx! ctx #f)
  (set-l2-ctx-fny! ctx #f)
  (set-l2-ctx-forward-proxy-structures! ctx #f)
  (set-l2-ctx-ftx! ctx #f)
  (set-l2-ctx-fty! ctx #f)
  (set-l2-ctx-gateways! ctx #f)
  (set-l2-ctx-ground-enemy-units-for-cheese! ctx #f)
  (set-l2-ctx-hatcheries! ctx #f)
  (set-l2-ctx-in-base-proxy-completed-cannons! ctx #f)
  (set-l2-ctx-in-base-proxy-structures! ctx #f)
  (set-l2-ctx-initial-enemy-race! ctx #f)
  (set-l2-ctx-intel-priority-sector! ctx #f)
  (set-l2-ctx-l2-sc! ctx #f)
  (set-l2-ctx-leases! ctx #f)
  (set-l2-ctx-live-open-combat-slots! ctx #f)
  (set-l2-ctx-macro-decision! ctx #f)
  (set-l2-ctx-macro-plan! ctx #f)
  (set-l2-ctx-map-grids! ctx #f)
  (set-l2-ctx-mc-cv! ctx #f)
  (set-l2-ctx-min-bkt25! ctx #f)
  (set-l2-ctx-mmstate-rush-post! ctx #f)
  (set-l2-ctx-nat-block-thresh2! ctx #f)
  (set-l2-ctx-nexuses! ctx #f)
  (set-l2-ctx-non-builder-defense-workers! ctx #f)
  (set-l2-ctx-non-building-workers! ctx #f)
  (set-l2-ctx-obs! ctx #f)
  (set-l2-ctx-oledger! ctx #f)
  (set-l2-ctx-oledger-early! ctx #f)
  (set-l2-ctx-open-prod-slots! ctx #f)
  (set-l2-ctx-open-prod-slots-snapshot! ctx #f)
  (set-l2-ctx-orphaned-prereqs! ctx #f)
  (set-l2-ctx-owned-base-coords! ctx #f)
  (set-l2-ctx-pending-workers! ctx #f)
  (set-l2-ctx-plan-next-actions-ht! ctx #f)
  (set-l2-ctx-pressure-metrics! ctx #f)
  (set-l2-ctx-prev-rush-fighting-wids! ctx #f)
  (set-l2-ctx-prev-tel-early! ctx #f)
  (set-l2-ctx-prev-telemetry-ht! ctx #f)
  (set-l2-ctx-prio-log-line! ctx #f)
  (set-l2-ctx-prio-saving-for-sym! ctx #f)
  (set-l2-ctx-prio-scheduled-actions! ctx #f)
  (set-l2-ctx-prio-summary! ctx #f)
  (set-l2-ctx-prod-facilities! ctx #f)
  (set-l2-ctx-protoss-matchup-wall! ctx #f)
  (set-l2-ctx-proxy-or-cheese-enemies! ctx #f)
  (set-l2-ctx-race-th-sym! ctx #f)
  (set-l2-ctx-raw-enemy-bldgs-early! ctx #f)
  (set-l2-ctx-ready-bldg-types! ctx #f)
  (set-l2-ctx-ready-bldgs! ctx #f)
  (set-l2-ctx-recalled-groups! ctx #f)
  (set-l2-ctx-repaired-prereqs! ctx #f)
  (set-l2-ctx-researched-upgs! ctx #f)
  (set-l2-ctx-rush-def-st! ctx #f)
  (set-l2-ctx-rush-threat-enemies! ctx #f)
  (set-l2-ctx-scout-st! ctx #f)
  (set-l2-ctx-scout-worker! ctx #f)
  (set-l2-ctx-scout-worker-id! ctx #f)
  (set-l2-ctx-step-geysers! ctx #f)
  (set-l2-ctx-step-mineral-patches! ctx #f)
  (set-l2-ctx-step-neutral-units! ctx #f)
  (set-l2-ctx-step-wall-aabbs! ctx #f)
  (set-l2-ctx-stream-spendable-ht! ctx #f)
  (set-l2-ctx-sup-left-key! ctx #f)
  (set-l2-ctx-target-workers! ctx #f)
  (set-l2-ctx-tech-obs! ctx #f)
  (set-l2-ctx-terran-addon-ox! ctx #f)
  (set-l2-ctx-terran-addon-oy! ctx #f)
  (set-l2-ctx-terran-addon-xs! ctx #f)
  (set-l2-ctx-terran-addon-ys! ctx #f)
  (set-l2-ctx-terran-ramp-wall! ctx #f)
  (set-l2-ctx-terran-rax-reactor-bldgs! ctx #f)
  (set-l2-ctx-terran-rax-techlab-bldgs! ctx #f)
  (set-l2-ctx-total-workers! ctx #f)
  (set-l2-ctx-townhalls! ctx #f)
  (set-l2-ctx-uncamped-pad-cache! ctx #f)
  (set-l2-ctx-unit-types! ctx #f)
  (set-l2-ctx-unpowered-protoss-bldg! ctx #f)
  (set-l2-ctx-wall-slot-3! ctx #f)
  (set-l2-ctx-wall-st! ctx #f)
  (set-l2-ctx-workers! ctx #f))


(define (l2-emit! ctx act)
    (set-l2-ctx-actions! ctx (cons act (l2-ctx-actions ctx))))

(define (l2-building-grounded-and-powered? ctx b)
    (if (hash? b)
        (let* ([raw-sym (unit-type-sym b)]
               [canon-sym (fast-canonical-structure-sym raw-sym)])
          (and (not (eq? (hash-ref b 'flying? #f) #t))
               (not (memq raw-sym
                          '(barracks-flying factory-flying starport-flying
                            command-center-flying orbital-command-flying
                            spine-crawler-uprooted spore-crawler-uprooted)))
               (or (not (sc2-structure-requires-pylon-power? canon-sym))
                   (not (eq? (hash-ref b 'powered? #t) #f)))))
        #t))

(define (l2-unit-stasis-frozen? ctx u)
    (define b (hash-ref u 'buffs '()))
    (and (list? b)
         (or (memq 'oracle-stasis-trap-target b)
             (memq 'stasis-ward-target b))))

(define (l2-compute-race-ideal-worker-cap ctx bases)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define step-neutral-units (l2-ctx-step-neutral-units ctx))
    (define n-bases (length bases))
    (define fallback-cap (min 70 (* SC2-IDEAL-WORKERS-PER-BASE (max 1 n-bases))))
    (cond
      [(or (null? bases)
           (null? step-neutral-units))
       fallback-cap]
      [else
       (define raw-cap
         (for/sum ([th (in-list bases)])
           (define thx (hash-ref th 'x base-x))
           (define thy (hash-ref th 'y base-y))
           (define thid (hash-ref th 'id 0))
           (define prof
             (compute-base-optimal-worker-allocation
              thx thy step-neutral-units ally-bldgs thid))
           (define pcnt (BaseResourceProfile-patch-count prof))
           (define gcnt (+ (BaseResourceProfile-gold-patch-count prof)
                           (BaseResourceProfile-rich-geyser-count prof)))
           (define vcnt (BaseResourceProfile-geyser-count prof))
           (cond
             [(and (< pcnt 4)
                   (= gcnt 0)
                   (not (and (>= n-bases 3) (>= vcnt 1))))
              SC2-IDEAL-WORKERS-PER-BASE]
             [else
              (max 0 (BaseResourceProfile-optimal-total-workers prof))])))
       (min 70 (max (if (<= n-bases 1) SC2-IDEAL-WORKERS-PER-BASE 0) raw-cap))]))

(define (l2-offset-defense-anchor ctx anchor-x anchor-y [min-dist 5.5])
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define third-x (l2-ctx-third-x ctx))
  (define third-y (l2-ctx-third-y ctx))
    (geo:offset-defense-anchor anchor-x anchor-y enemy-x enemy-y min-dist
                               (list (cons nat-x nat-y) (cons third-x third-y))))

(define (l2-enemy-hostile-near-point? ctx px py [radius 16.0])
  (define enemy-units (l2-ctx-enemy-units ctx))
    (or (ormap (lambda (e)
                 (and (combat-unit-record? e)
                      (sc2-enemy-unit-targetable? (unit-type-sym e))
                      (<= (dist2d px py (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) radius)))
               enemy-units)
        (>= (count (lambda (e)
                     (and (memq (unit-type-sym e) '(probe scv drone))
                          (not (eq? (hash-ref e 'hallucination? #f) #t))
                          (not (eq? (hash-ref e 'hallucination #f) #t))
                          (<= (dist2d px py (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) radius)))
                   enemy-units)
            SC2-WORKER-RUSH-MIN-ENEMY-WORKERS)))

(define (l2-find-uncontested-zerg-hatchery ctx)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
    (if (eq? (l2-ctx-uncontested-zerg-hatch-cache ctx) 'uninit)
        (let ([res (and (l2-enemy-hostile-near-point? ctx base-x base-y 16.0)
                        (for/first ([b (in-list ally-bldgs)]
                                    #:when (and (memq (fast-canonical-structure-sym (unit-type-sym b))
                                                      '(hatchery lair hive))
                                                (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                                                (let ([hx (hash-ref b 'x base-x)]
                                                      [hy (hash-ref b 'y base-y)])
                                                  (and (> (dist2d base-x base-y hx hy) 8.0)
                                                       (not (l2-enemy-hostile-near-point? ctx hx hy 16.0))))))
                          b))])
          (set-l2-ctx-uncontested-zerg-hatch-cache! ctx res)
          res)
        (l2-ctx-uncontested-zerg-hatch-cache ctx)))

(define (l2-safe-zerg-build-anchor ctx default-x default-y)
    (define safe-h (l2-find-uncontested-zerg-hatchery ctx))
    (if safe-h
        (values (safe-coord (+ (hash-ref safe-h 'x default-x) 3.0))
                (safe-coord (+ (hash-ref safe-h 'y default-y) 3.0)))
        (values default-x default-y)))

(define (l2-save-cancel-rebuild-ready? ctx bldg-sym [cooldown-frames 60])
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define frame (l2-ctx-frame ctx))
  (define race (l2-ctx-race ctx))
    (define cs (fast-canonical-structure-sym bldg-sym))
    (define cancel-cd-key (fast-save-cancel-rebuild-key cs))
    (define last-cancel-f
      (and (refractory-cooldown-tracker? cd-tracker)
           (hash? (refractory-cooldown-tracker-table cd-tracker))
           (hash-ref (refractory-cooldown-tracker-table cd-tracker) cancel-cd-key #f)))
    (if (not (exact-integer? last-cancel-f))
        #t
        (let ([elapsed (- frame last-cancel-f)])
          (if (not (eq? race 'Zerg))
              (>= elapsed cooldown-frames)
              (cond
                [(>= elapsed (max 16 cooldown-frames)) #t]
                [(< elapsed (min 16 cooldown-frames)) #f]
                [else
                 (>= elapsed (if (l2-find-uncontested-zerg-hatchery ctx) 16 cooldown-frames))])))))

(define (l2-enemy-bldg-is-proxy? ctx eb)
  (define early-enemy-nat-x (l2-ctx-early-enemy-nat-x ctx))
  (define early-enemy-nat-y (l2-ctx-early-enemy-nat-y ctx))
  (define early-enemy-third-x (l2-ctx-early-enemy-third-x ctx))
  (define early-enemy-third-y (l2-ctx-early-enemy-third-y ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define frame (l2-ctx-frame ctx))
    (cond
      [(and (hash? eb) (hash-has-key? eb 'is-proxy?))
       (eq? (hash-ref eb 'is-proxy? #f) #t)]
      [(not (and (hash? eb) (hash-has-key? eb 'x) (hash-has-key? eb 'y)))
       #f]
      [else
       (define canon (fast-canonical-structure-sym (unit-type-sym eb)))
       (define ebx (exact->inexact (hash-ref eb 'x 9999.0)))
       (define eby (exact->inexact (hash-ref eb 'y 9999.0)))
       (define dx-e (- ebx enemy-x))
       (define dy-e (- eby enemy-y))
       (define dx-n (- ebx early-enemy-nat-x))
       (define dy-n (- eby early-enemy-nat-y))
       (define dx-3 (- ebx early-enemy-third-x))
       (define dy-3 (- eby early-enemy-third-y))
       (and (not (memq canon '(creep-tumor creep-tumor-burrowed creep-tumor-queen
                               oracle-stasis-trap stasis-ward auto-turret)))
            (not (and (>= frame 3360)
                      (memq canon '(hatchery lair hive nexus command-center orbital-command planetary-fortress))))
            (> (+ (* dx-e dx-e) (* dy-e dy-e)) 784.0)
            (> (+ (* dx-n dx-n) (* dy-n dy-n)) 784.0)
            (> (+ (* dx-3 dx-3) (* dy-3 dy-3)) 784.0))]))

(define (l2-raw-eb-explicit-build-progress? ctx eb)
  (define raw-enemy-bldgs-early (l2-ctx-raw-enemy-bldgs-early ctx))
    (define eid (hash-ref eb 'id #f))
    (define raw-match
      (and eid
           (findf (lambda (rb)
                    (and (hash? rb)
                         (equal? (hash-ref rb 'id #f) eid)))
                  raw-enemy-bldgs-early)))
    (and raw-match (hash-has-key? raw-match 'build-progress)))

(define (l2-pad-camped-posterior ctx px py [radius 11.5])
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define live-obs-harvesters? (l2-ctx-live-obs-harvesters? ctx))
  (define mmstate-rush-post (l2-ctx-mmstate-rush-post ctx))
    (cond
      [(and (l2-ctx-pad-last-px ctx) (equal? px (l2-ctx-pad-last-px ctx)) (equal? py (l2-ctx-pad-last-py ctx)) (equal? radius (l2-ctx-pad-last-r ctx)))
       (l2-ctx-pad-last-val ctx)]
      [(and (l2-ctx-pad-camped-cache ctx) (hash-ref (l2-ctx-pad-camped-cache ctx) (cons px (cons py radius)) #f))
       => values]
      [else
       (define fpx (if (flonum? px) px (exact->inexact px)))
       (define fpy (if (flonum? py) py (exact->inexact py)))
       (define r (if (flonum? radius) radius (exact->inexact radius)))
       (define r2 (fl* r r))
       (define camp-bldg?
         (for/or ([eb (in-list enemy-bldgs)])
           (let ([canon (fast-canonical-structure-sym (unit-type-sym eb))])
             (and (or (memq canon '(photon-cannon bunker planetary-fortress spine-crawler
                                                  hatchery lair hive nexus command-center orbital-command))
                      (memq canon SC2-TOWNHALL-STRUCTURE-SYMS))
                  (let ([dx (fl- fpx (exact->inexact (hash-ref eb 'x 9999.0)))]
                        [dy (fl- fpy (exact->inexact (hash-ref eb 'y 9999.0)))])
                    (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2))))))
       (define camp-combat-cnt
         (for/sum ([e (in-list enemy-units)])
           (if (combat-unit-record? e)
               (let ([dx (fl- fpx (exact->inexact (hash-ref e 'x 9999.0)))]
                     [dy (fl- fpy (exact->inexact (hash-ref e 'y 9999.0)))])
                 (if (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2) 1 0))
               0)))
       (define ally-near-cnt
         (for/sum ([a (in-list ally-combat-units)])
           (let ([dx (fl- fpx (exact->inexact (hash-ref a 'x base-x)))]
                 [dy (fl- fpy (exact->inexact (hash-ref a 'y base-y)))])
             (if (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 196.0) 1 0))))
       (define res
         (compute-bayesian-pad-camped-posterior
          #:camp-building-observed? camp-bldg?
          #:enemy-combat-count camp-combat-cnt
          #:ally-defender-count ally-near-cnt
          #:total-ally-combat-count (length ally-combat-units)
          #:live-obs? live-obs-harvesters?
          #:dist-to-our-base (fast-dist2d px py base-x base-y)
          #:dist-to-enemy-base (fast-dist2d px py enemy-x enemy-y)
          #:rush-posterior mmstate-rush-post))
       (if (not (l2-ctx-pad-last-px ctx))
           (begin
             (set-l2-ctx-pad-last-px! ctx px)
             (set-l2-ctx-pad-last-py! ctx py)
             (set-l2-ctx-pad-last-r! ctx radius)
             (set-l2-ctx-pad-last-val! ctx res))
           (begin
             (unless (l2-ctx-pad-camped-cache ctx) (set-l2-ctx-pad-camped-cache! ctx (make-hash)))
             (hash-set! (l2-ctx-pad-camped-cache ctx) (cons px (cons py radius)) res)))
       res]))

(define (l2-pad-camped-by-enemy? ctx px py [radius 11.5])
    (>= (l2-pad-camped-posterior ctx px py radius) 0.55))

(define (l2-any-natural-blocker? ctx)
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define nat-block-thresh2 (l2-ctx-nat-block-thresh2 ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
    (define nx (exact->inexact nat-x))
    (define ny (exact->inexact nat-y))
    (define-syntax-rule (blocker-in-list? lst)
      (for/or ([e (in-list lst)])
        (define dx (fl- nx (exact->inexact (hash-ref e 'x 9999))))
        (define dy (fl- ny (exact->inexact (hash-ref e 'y 9999))))
        (fl<= (fl+ (fl* dx dx) (fl* dy dy)) nat-block-thresh2)))
    (or (blocker-in-list? enemy-units)
        (blocker-in-list? enemy-bldgs)))

(define (l2-pad-hash-list-xy-sum ctx xs acc)
    (for/fold ([s acc]) ([u (in-list xs)])
      (if (hash? u)
          (let ([ux (hash-ref u 'x 0.0)]
                [uy (hash-ref u 'y 0.0)])
            (fl+ s (fl+ (if (real? ux) (exact->inexact ux) 0.0)
                        (if (real? uy) (exact->inexact uy) 0.0))))
          s)))

(define (l2-pad-cands-xy-sum ctx pads acc)
    (for/fold ([s acc]) ([p (in-list pads)])
      (cond
        [(pair? p)
         (cond
           [(and (real? (car p)) (real? (cdr p)))
            (fl+ s (fl+ (exact->inexact (car p)) (exact->inexact (cdr p))))]
           [(and (real? (car p)) (pair? (cdr p)) (real? (cadr p)))
            (fl+ s (fl+ (exact->inexact (car p)) (exact->inexact (cadr p))))]
           [else s])]
        [(hash? p)
         (let ([px (hash-ref p 'x 0.0)]
               [py (hash-ref p 'y 0.0)])
           (fl+ s (fl+ (if (real? px) (exact->inexact px) 0.0)
                       (if (real? py) (exact->inexact py) 0.0))))]
        [else s])))

(define (l2-select-uncamped-expansion-pad ctx [prefer-natural? #f])
  (define active-bases (l2-ctx-active-bases ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define expansion-pads (l2-ctx-expansion-pads ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-obs-harvesters? (l2-ctx-live-obs-harvesters? ctx))
  (define mmstate-rush-post (l2-ctx-mmstate-rush-post ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define natural-blocked? (l2-ctx-natural-blocked? ctx))
  (define rt (l2-ctx-rt ctx))
  (define third-x (l2-ctx-third-x ctx))
  (define third-y (l2-ctx-third-y ctx))
  (define townhalls (l2-ctx-townhalls ctx))
  (define uncamped-pad-cache (l2-ctx-uncamped-pad-cache ctx))
    (define key (and prefer-natural? #t))
    (define step-cached (hash-ref uncamped-pad-cache key #f))
    (cond
      [step-cached
       (values (car step-cached) (cdr step-cached))]
      [else
       (define door-st (rt-door-state rt))
       (define persist-tbl
         (and live-obs-harvesters?
              (hash-ref! door-st 'uncamped-pad-persist make-hasheq)))
       (define pentry (and persist-tbl (hash-ref persist-tbl key #f)))
       (define ttl-limit (if (= (modulo frame 16) 8) 12 8))
       (define nat-blk? (and natural-blocked? #t))
       (define post-2500? (>= frame 2500))
       (define n-th (if persist-tbl (length townhalls) 0))
       (define n-eu (if persist-tbl (length enemy-units) 0))
       (define n-eb (if persist-tbl (length enemy-bldgs) 0))
       (define n-ac (if persist-tbl (length ally-combat-units) 0))
       (define n-ep (if persist-tbl (length expansion-pads) 0))
       (define xy-csum-box #f)
       (define (get-xy-csum)
         (or xy-csum-box
             (let ([s (l2-pad-cands-xy-sum ctx
                       expansion-pads
                       (l2-pad-hash-list-xy-sum ctx
                        ally-combat-units
                        (l2-pad-hash-list-xy-sum ctx
                         enemy-bldgs
                         (l2-pad-hash-list-xy-sum ctx
                          enemy-units
                          (l2-pad-hash-list-xy-sum ctx townhalls 0.0)))))])
               (set! xy-csum-box s)
               s)))
       (cond
         [(and (vector? pentry)
               (>= frame (vector-ref pentry 0))
               (< (- frame (vector-ref pentry 0)) ttl-limit)
               (eq? nat-blk? (vector-ref pentry 1))
               (eq? post-2500? (vector-ref pentry 2))
               (= active-bases (vector-ref pentry 3))
               (= base-x (vector-ref pentry 10))
               (= base-y (vector-ref pentry 11))
               (= nat-x (vector-ref pentry 12))
               (= nat-y (vector-ref pentry 13))
               (= third-x (vector-ref pentry 14))
               (= third-y (vector-ref pentry 15))
               (= enemy-x (vector-ref pentry 16))
               (= enemy-y (vector-ref pentry 17))
               (= n-th (vector-ref pentry 4))
               (= n-eu (vector-ref pentry 5))
               (= n-eb (vector-ref pentry 6))
               (= n-ac (vector-ref pentry 7))
               (= n-ep (vector-ref pentry 8))
               (equal? mmstate-rush-post (vector-ref pentry 9))
               (fl= (get-xy-csum) (vector-ref pentry 18)))
          (define px (vector-ref pentry 19))
          (define py (vector-ref pentry 20))
          (hash-set! uncamped-pad-cache key (cons px py))
          (values px py)]
         [else
          (let-values ([(px py)
                        (placement:select-uncamped-expansion-pad
                         expansion-pads
                         prefer-natural?
                         #:base-x base-x
                         #:base-y base-y
                         #:nat-x nat-x
                         #:nat-y nat-y
                         #:third-x third-x
                         #:third-y third-y
                         #:enemy-x enemy-x
                         #:enemy-y enemy-y
                         #:townhalls townhalls
                         #:enemy-units enemy-units
                         #:enemy-bldgs enemy-bldgs
                         #:ally-combat-units ally-combat-units
                         #:natural-blocked? natural-blocked?
                         #:live-obs? live-obs-harvesters?
                         #:active-bases active-bases
                         #:frame frame
                         #:rush-posterior mmstate-rush-post)])
            (hash-set! uncamped-pad-cache key (cons px py))
            (when persist-tbl
              (hash-set! persist-tbl
                         key
                         (vector frame nat-blk? post-2500? active-bases
                                 n-th n-eu n-eb n-ac n-ep mmstate-rush-post
                                 base-x base-y nat-x nat-y third-x third-y
                                 enemy-x enemy-y (get-xy-csum) px py)))
            (values px py))])]))

(define (l2-scout-encounters-early-worker-rush? ctx sw)
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define scout-rush-aborted-latch? (l2-ctx-scout-rush-aborted-latch? ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
    (and sw
         (< frame 3360)
         (let ([swx (hash-ref sw 'x base-x)]
               [swy (hash-ref sw 'y base-y)])
           (and (> (dist2d swx swy base-x base-y) 8.0)
                (or worker-rush-active?
                    scout-rush-aborted-latch?
                    (>= (count (lambda (e)
                                 (define ex0 (hash-ref e 'x 9999.0))
                                 (define ey0 (hash-ref e 'y 9999.0))
                                 (and (memq (unit-type-sym e) '(probe scv drone))
                                      (<= (dist2d swx swy ex0 ey0) 14.0)
                                      (> (dist2d ex0 ey0 enemy-x enemy-y) 16.0)))
                               enemy-units)
                        3)
                    (>= (count (lambda (e)
                                 (and (memq (unit-type-sym e) '(probe scv drone))
                                      (<= (dist2d swx swy
                                                  (hash-ref e 'x 9999.0)
                                                  (hash-ref e 'y 9999.0))
                                          5.5)))
                               enemy-units)
                        3))))))

(define (l2-recall-building-group! ctx g)
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define cg4-cap (l2-ctx-cg4-cap ctx))
  (define cg5-cap (l2-ctx-cg5-cap ctx))
  (define cg6-cap (l2-ctx-cg6-cap ctx))
  (define cg7-cap (l2-ctx-cg7-cap ctx))
  (define cortex (l2-ctx-cortex ctx))
  (define recalled-groups (l2-ctx-recalled-groups ctx))
    (when (and (not (set-member? recalled-groups g))
               (not (null? (hash-ref (case g
                                       [(4) cg4-cap]
                                       [(5) cg5-cap]
                                       [(6) cg6-cap]
                                       [(7) cg7-cap]
                                       [else (hash)])
                                     'ready-tags '())))
               (not (in-camera-viewport? (human-cortex-cam-x cortex)
                                         (human-cortex-cam-y cortex)
                                         base-x base-y)))
      (set-add! recalled-groups g)
      (l2-emit! ctx (list 'control-group-recall g))))

(define (l2-min-dist2-to-owned-base ctx ex ey)
  (define fbx (l2-ctx-fbx ctx))
  (define fby (l2-ctx-fby ctx))
  (define fnx (l2-ctx-fnx ctx))
  (define fny (l2-ctx-fny ctx))
  (define ftx (l2-ctx-ftx ctx))
  (define fty (l2-ctx-fty ctx))
  (define has-nat? (l2-ctx-has-nat? ctx))
  (define has-third? (l2-ctx-has-third? ctx))
    (define fex (exact->inexact ex))
    (define fey (exact->inexact ey))
    (define dx1 (- fex fbx))
    (define dy1 (- fey fby))
    (define d2-1 (+ (* dx1 dx1) (* dy1 dy1)))
    (define d2-2 (if has-nat?
                     (let ([dx (- fex fnx)] [dy (- fey fny)]) (+ (* dx dx) (* dy dy)))
                     +inf.0))
    (define d2-3 (if has-third?
                     (let ([dx (- fex ftx)] [dy (- fey fty)]) (+ (* dx dx) (* dy dy)))
                     +inf.0))
    (min d2-1 d2-2 d2-3))

(define (l2-min-dist-to-owned-base ctx ex ey)
    (sqrt (l2-min-dist2-to-owned-base ctx ex ey)))

(define (l2-ally-has-vision-of? ctx sx sy)
  (define ally-units (l2-ctx-ally-units ctx))
    (define fsx (exact->inexact sx))
    (define fsy (exact->inexact sy))
    (for/or ([u (in-list ally-units)])
      (define ux (hash-ref u 'x SANITIZE-MISSING))
      (define uy (hash-ref u 'y SANITIZE-MISSING))
      (and (not (eq? ux SANITIZE-MISSING))
           (not (eq? uy SANITIZE-MISSING))
           (let ([dx (fl- (exact->inexact ux) fsx)]
                 [dy (fl- (exact->inexact uy) fsy)])
             (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 225.0)))))

(define (l2-enemy-seen-near? ctx sx sy radius)
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
    (define fsx (exact->inexact sx))
    (define fsy (exact->inexact sy))
    (define r (exact->inexact radius))
    (define r2 (fl* r r))
    (or (for/or ([e (in-list enemy-units)])
          (define ex (hash-ref e 'x SANITIZE-MISSING))
          (define ey (hash-ref e 'y SANITIZE-MISSING))
          (and (not (eq? ex SANITIZE-MISSING))
               (not (eq? ey SANITIZE-MISSING))
               (let ([dx (fl- (exact->inexact ex) fsx)]
                     [dy (fl- (exact->inexact ey) fsy)])
                 (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2))))
        (for/or ([e (in-list enemy-bldgs)])
          (define ex (hash-ref e 'x SANITIZE-MISSING))
          (define ey (hash-ref e 'y SANITIZE-MISSING))
          (and (not (eq? ex SANITIZE-MISSING))
               (not (eq? ey SANITIZE-MISSING))
               (let ([dx (fl- (exact->inexact ex) fsx)]
                     [dy (fl- (exact->inexact ey) fsy)])
                 (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2))))))

(define (l2-crisis-tech-bldg-deferred? ctx bldg-sym)
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
    (and crisis-tech-upgrade-deferral?
         (not (not (memq (sc2-canonical-structure-sym bldg-sym)
                         CRISIS-DEFERRED-TECH-BLDG-SYMS)))))

(define (l2-emergency-inmain-supply-anchor ctx retry-idx)
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define obs (l2-ctx-obs ctx))
    (define main-mps
      (filter (lambda (mp)
                (and (hash? mp)
                     (<= (dist2d base-x base-y
                                 (hash-ref mp 'x base-x)
                                 (hash-ref mp 'y base-y))
                         13.0)))
              (let ([mps (hash-ref obs 'mineral-patches '())])
                (if (list? mps) mps '()))))
    (define-values (ux uy)
      (cond
        [(not (null? main-mps))
         (define cnt (length main-mps))
         (define mcx (/ (for/sum ([m (in-list main-mps)]) (exact->inexact (hash-ref m 'x base-x))) cnt))
         (define mcy (/ (for/sum ([m (in-list main-mps)]) (exact->inexact (hash-ref m 'y base-y))) cnt))
         (define dx (- (exact->inexact base-x) mcx))
         (define dy (- (exact->inexact base-y) mcy))
         (define d (max 0.5 (sqrt (+ (* dx dx) (* dy dy)))))
         (values (/ dx d) (/ dy d))]
        [else
         (define dx (- (exact->inexact nat-x) (exact->inexact base-x)))
         (define dy (- (exact->inexact nat-y) (exact->inexact base-y)))
         (define d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
         (values (/ dx d) (/ dy d))]))
    (define angle-offsets '#(0.0 0.55 -0.55 1.10 -1.10 1.65 -1.65))
    (define ang (vector-ref angle-offsets (modulo (max 0 retry-idx) (vector-length angle-offsets))))
    (define ca (cos ang))
    (define sa (sin ang))
    (define rx (- (* ux ca) (* uy sa)))
    (define ry (+ (* ux sa) (* uy ca)))
    (define rad (+ 5.5 (* 0.5 (quotient (max 0 retry-idx) (vector-length angle-offsets)))))
    (values (safe-coord (+ base-x (* rad rx)) (+ base-x 4.5))
            (safe-coord (+ base-y (* rad ry)) (+ base-y 4.5))))

(define (l2-wall-aabbs-for-build ctx exact-wall-slot?)
  (define step-wall-aabbs (l2-ctx-step-wall-aabbs ctx))
    (if exact-wall-slot?
        (filter (lambda (r)
                  (not (memq (reserved-aabb-kind r)
                             '(wall-slot doorway-corridor terran-addon-pad))))
                step-wall-aabbs)
        step-wall-aabbs))

(define (l2-can-spend-supply? ctx cost)
  (define reserve-supply-floor? (l2-ctx-reserve-supply-floor? ctx))
  (define zerg-hold-overlord-min? (l2-ctx-zerg-hold-overlord-min? ctx))
    (and (not reserve-supply-floor?)
         (not zerg-hold-overlord-min?)
         (>= (l2-ctx-effective-free-supply ctx) cost)
         (> (l2-ctx-supply-left ctx) 0)))

(define (l2-spend-resources-and-supply! ctx m-cost g-cost s-cost)
    (set-l2-ctx-minerals! ctx (max 0 (- (l2-ctx-minerals ctx) m-cost)))
    (set-l2-ctx-gas! ctx (max 0 (- (l2-ctx-gas ctx) g-cost)))
    (when (> s-cost 0)
      (set-l2-ctx-supply-left! ctx (max 0 (- (l2-ctx-supply-left ctx) s-cost)))
      (set-l2-ctx-effective-free-supply! ctx (max 0 (- (l2-ctx-effective-free-supply ctx) s-cost)))))

(define (l2-upgrade-needed? ctx upg-sym)
  (define frame (l2-ctx-frame ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define researched-upgs (l2-ctx-researched-upgs ctx))
    (and (not (memq upg-sym researched-upgs))
         (not (memq upg-sym (l2-ctx-pending-upgs ctx)))
         (= (order-ledger-pending-count-for-type oledger upg-sym frame) 0)))

(define (l2-cur-ally-canon-bldg-count ctx bldg-sym)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
    (unless (l2-ctx-ally-canon-bldg-counts-ht ctx)
      (define ht (make-hasheq))
      (for ([b (in-list ally-bldgs)]
            #:when (hash? b))
        (define cs (fast-canonical-structure-sym (unit-type-sym b)))
        (hash-set! ht cs (add1 (hash-ref ht cs 0))))
      (set-l2-ctx-ally-canon-bldg-counts-ht! ctx ht))
    (hash-ref (l2-ctx-ally-canon-bldg-counts-ht ctx) (fast-canonical-structure-sym bldg-sym) 0))

(define (l2-record-build-issue-lock! ctx bldg-sym)
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-game-obs? (l2-ctx-live-game-obs? ctx))
    (when (and live-game-obs?
               (refractory-cooldown-tracker? cd-tracker)
               (hash? (refractory-cooldown-tracker-table cd-tracker)))
      (define cs (fast-canonical-structure-sym bldg-sym))
      (hash-set! (refractory-cooldown-tracker-table cd-tracker)
                 (fast-build-issue-lock-key cs)
                 (list frame (l2-cur-ally-canon-bldg-count ctx cs)))))

(define (l2-build-issue-blocked? ctx bldg-sym [cd-frames #f])
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-game-obs? (l2-ctx-live-game-obs? ctx))
    (define cs (fast-canonical-structure-sym bldg-sym))
    (define tbl (and live-game-obs?
                     (refractory-cooldown-tracker? cd-tracker)
                     (refractory-cooldown-tracker-table cd-tracker)))
    (define lock-entry (and (hash? tbl) (hash-ref tbl (fast-build-issue-lock-key cs) #f)))
    (and (pair? lock-entry)
         (let ([eff-cd (if (exact-integer? cd-frames) cd-frames 56)]
               [last-issue-f (car lock-entry)]
               [last-issue-cnt (cadr lock-entry)])
           (and (<= 0 (- frame last-issue-f))
                (< (- frame last-issue-f) eff-cd)
                (= (l2-cur-ally-canon-bldg-count ctx cs) last-issue-cnt)
                (let ([last-cancel-f (hash-ref tbl (fast-save-cancel-rebuild-key cs) #f)])
                  (not (and (exact-integer? last-cancel-f)
                            (>= last-cancel-f last-issue-f)
                            (l2-save-cancel-rebuild-ready? ctx cs 60))))))))

(define (l2-building-present-or-pending? ctx bldg-sym [include-free-addons? #f])
  (define frame (l2-ctx-frame ctx))
  (define oledger (l2-ctx-oledger ctx))
    (define eq-syms (fast-structure-equivalent-syms bldg-sym include-free-addons?))
    (for/or ([s (in-list eq-syms)])
      (define cs (fast-canonical-structure-sym s))
      (or (memq s (l2-ctx-bldg-types ctx))
          (memq cs (l2-ctx-bldg-types ctx))
          (memq s (l2-ctx-morphing-bldg-types ctx))
          (memq cs (l2-ctx-morphing-bldg-types ctx))
          (> (order-ledger-pending-count-for-type oledger s frame) 0)
          (and (not (eq? cs s))
               (> (order-ledger-pending-count-for-type oledger cs frame) 0))
          (l2-build-issue-blocked? ctx cs))))

(define (l2-emit-build-verified! ctx bldg-sym raw-x raw-y
                                [clearance SC2-BUILD-SITE-MIN-CLEARANCE]
                                #:exact-wall-slot? [exact-wall-slot? #f])
  (define SIMCITY-EXCLUDED-BLDG-SYMS (l2-ctx-SIMCITY-EXCLUDED-BLDG-SYMS ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define expansion-pads (l2-ctx-expansion-pads ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-game-obs? (l2-ctx-live-game-obs? ctx))
  (define map-grids (l2-ctx-map-grids ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define race (l2-ctx-race ctx))
  (define rt (l2-ctx-rt ctx))
  (define step-geysers (l2-ctx-step-geysers ctx))
  (define step-mineral-patches (l2-ctx-step-mineral-patches ctx))
    (define canon-sym (fast-canonical-structure-sym bldg-sym))
    (unless (or (l2-build-issue-blocked? ctx canon-sym)
                (l2-crisis-tech-bldg-deferred? ctx canon-sym))
      (define use-simcity?
        (and (not exact-wall-slot?)
             (not (memq canon-sym SIMCITY-EXCLUDED-BLDG-SYMS))
             (or live-game-obs?
                 (pair? step-mineral-patches)
                 (pair? step-geysers)
                 map-grids)
             (let ([d-base (fast-dist2d raw-x raw-y base-x base-y)]
                   [d-nat (fast-dist2d raw-x raw-y nat-x nat-y)])
               (and (<= d-base 25.0)
                    (or (<= d-base d-nat)
                        (<= (fast-dist2d base-x base-y nat-x nat-y) 1.0))))))
      (define-values (target-x target-y)
        (if use-simcity?
            (let* ([sc-cache (rt-simcity-cache rt)]
                   [sc-key (list canon-sym
                                 (inexact->exact (round base-x))
                                 (inexact->exact (round base-y))
                                 (length (l2-ctx-bldg-types ctx)))]
                   [cached (hash-ref sc-cache sc-key #f)])
              (if cached
                  (values (car cached) (cdr cached))
                  (let ([rsites
                         (for/list ([rs (in-list (in-progress-order-ledger-reserved-sites oledger))]
                                    #:when (<= frame (reserved-build-site-expires-frame rs)))
                           (hasheq 'x (reserved-build-site-x rs)
                                   'y (reserved-build-site-y rs)
                                   'bldg-sym (reserved-build-site-bldg-sym rs)
                                   'builder-id (reserved-build-site-builder-id rs)
                                   'expires-frame (reserved-build-site-expires-frame rs)))]
                        [wall-bbs (l2-wall-aabbs-for-build ctx #f)])
                    (define-values (sx sy)
                      (placement:solve-pro-simcity-layout-placement
                       canon-sym race base-x base-y nat-x nat-y
                       #:enemy-x enemy-x
                       #:enemy-y enemy-y
                       #:ally-bldgs ally-bldgs
                       #:mineral-patches step-mineral-patches
                       #:geysers step-geysers
                       #:reserved-sites rsites
                       #:reserved-aabbs wall-bbs
                       #:expansion-pads expansion-pads
                       #:map-grids map-grids
                       #:frame frame))
                    (hash-set! sc-cache sc-key (cons sx sy))
                    (values sx sy))))
            (values raw-x raw-y)))
      (define-values (bx by)
        (order-ledger-resolve-build-coords!
         oledger bldg-sym target-x target-y ally-bldgs frame clearance
         #:expansion-pads expansion-pads
         #:exact-wall-slot? exact-wall-slot?
         #:reserved-aabbs (l2-wall-aabbs-for-build ctx exact-wall-slot?)))
      (define sx (safe-coord bx raw-x))
      (define sy (safe-coord by raw-y))
      (l2-emit! ctx (list 'build bldg-sym sx sy))
      (l2-record-build-issue-lock! ctx canon-sym)
      (when (and exact-wall-slot?
                 live-game-obs?
                 (refractory-cooldown-tracker? cd-tracker)
                 (hash? (refractory-cooldown-tracker-table cd-tracker)))
        (hash-set! (refractory-cooldown-tracker-table cd-tracker)
                   (list 'build-issue-exact-wall canon-sym)
                   frame))
      (order-ledger-record-issued! oledger (+ 820000 (modulo frame 10000) (length (l2-ctx-actions ctx)))
                                   'build bldg-sym sx sy frame)
      (set-l2-ctx-bldg-types! ctx (cons canon-sym (l2-ctx-bldg-types ctx)))
      (l2-spend-resources-and-supply! ctx (sc2-min-cost bldg-sym) (sc2-gas-cost bldg-sym) 0)))

(define (l2-emit-gas-build-verified! ctx gas-sym raw-x raw-y [cost-sym gas-sym])
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define oledger (l2-ctx-oledger ctx))
    (define canon-sym (fast-canonical-structure-sym gas-sym))
    (unless (l2-build-issue-blocked? ctx canon-sym)
      (define sx (safe-coord raw-x (+ base-x 4.0)))
      (define sy (safe-coord raw-y (+ base-y 4.0)))
      (l2-emit! ctx (list 'build gas-sym sx sy))
      (l2-record-build-issue-lock! ctx canon-sym)
      (order-ledger-record-issued! oledger (+ 815000 (modulo frame 10000) (length (l2-ctx-actions ctx)))
                                   'build gas-sym sx sy frame)
      (set-l2-ctx-bldg-types! ctx (cons canon-sym (l2-ctx-bldg-types ctx)))
      (l2-spend-resources-and-supply! ctx (sc2-min-cost cost-sym) 0 0)))

(define (l2-unit-count ctx sym)
    (hash-ref (l2-ctx-unit-counts ctx) (sc2-canonical-unit-sym sym) 0))

(define (l2-normalize-facility-slot-sym ctx sym)
    (define csym (sc2-canonical-structure-sym sym))
    (case csym
      [(gateway warp-gate) 'gateway]
      [(hatchery lair hive nexus command-center orbital-command planetary-fortress) 'townhall]
      [else csym]))

(define (l2-barracks-addon-kind ctx b)
  (define terran-rax-reactor-bldgs (l2-ctx-terran-rax-reactor-bldgs ctx))
  (define terran-rax-techlab-bldgs (l2-ctx-terran-rax-techlab-bldgs ctx))
    (define explicit (hash-ref b 'addon #f))
    (define atag (hash-ref b 'add-on-tag 0))
    (cond
      [(eq? explicit 'techlab) 'techlab]
      [(eq? explicit 'reactor) 'reactor]
      [(and (> atag 0)
            (for/or ([ab (in-list terran-rax-techlab-bldgs)]) (equal? (hash-ref ab 'id -1) atag)))
       'techlab]
      [(and (> atag 0)
            (for/or ([ab (in-list terran-rax-reactor-bldgs)]) (equal? (hash-ref ab 'id -1) atag)))
       'reactor]
      [else
       (define bx (exact->inexact (hash-ref b 'x -999.0)))
       (define by (exact->inexact (hash-ref b 'y -999.0)))
       (define ax (fl+ bx (exact->inexact SC2-TERRAN-ADDON-OFFSET-X)))
       (define ay (fl+ by (exact->inexact SC2-TERRAN-ADDON-OFFSET-Y)))
       (cond
         [(for/or ([ab (in-list terran-rax-techlab-bldgs)])
            (define dx (fl- ax (exact->inexact (hash-ref ab 'x -9999.0))))
            (define dy (fl- ay (exact->inexact (hash-ref ab 'y -9999.0))))
            (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 3.0625))
          'techlab]
         [(for/or ([ab (in-list terran-rax-reactor-bldgs)])
            (define dx (fl- ax (exact->inexact (hash-ref ab 'x -9999.0))))
            (define dy (fl- ay (exact->inexact (hash-ref ab 'y -9999.0))))
            (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 3.0625))
          'reactor]
         [else #f])]))

(define (l2-upgrade-researcher-slot ctx upg-sym)
    (define node (lookup-sc2-tech-node upg-sym))
    (define raw-slot
      (cond
        [node (sc2-tech-node-producer-slot node)]
        [else
         (case upg-sym
           [(infantry-weapons-1 infantry-armor-1
             terran-infantry-weapons-1 terran-infantry-weapons-2 terran-infantry-weapons-3
             terran-infantry-armor-1 terran-infantry-armor-2 terran-infantry-armor-3
             hi-sec-auto-tracking)
            'engineering-bay]
           [(vehicle-weapons-1 terran-vehicle-weapons-1 terran-vehicle-weapons-2
             terran-vehicle-and-ship-plating-1 terran-ship-weapons-1
             terran-ship-weapons-2 terran-ship-weapons-3)
            'armory]
           [(stimpack combat-shield concussive-shells) 'barracks-techlab]
           [(drilling-claws infernal-pre-igniter smart-servos cyclone-lock-on-damage) 'factory-techlab]
           [(banshee-cloak hyperflight-rotors) 'starport-techlab]
           [(personal-cloaking) 'ghost-academy]
           [(weapon-refit) 'fusion-core]
           [(ground-weapons-1 ground-armor-1
             protoss-ground-weapons-1 protoss-ground-weapons-2 protoss-ground-weapons-3
             protoss-ground-armor-1 protoss-ground-armor-2 protoss-ground-armor-3
             protoss-shields-1 protoss-shields-2)
            'forge]
           [(warpgate warpgate-research warp-gate warp-gate-research protoss-air-weapons-1 protoss-air-armor-1)
            'cybernetics-core]
           [(charge blink resonating-glaives) 'twilight-council]
           [(extended-thermal-lance gravitic-booster gravitic-drive) 'robotics-bay]
           [(psi-storm psionic-storm) 'templar-archive]
           [(shadow-stride) 'dark-shrine]
           [(flux-vanes anion-pulse-crystals) 'fleet-beacon]
           [(missile-attacks-1 ground-carapace-1
             zerg-missile-weapons-1 zerg-missile-weapons-2 zerg-missile-weapons-3
             zerg-ground-armor-1 zerg-ground-armor-2 zerg-ground-armor-3
             zerg-melee-weapons-1 zerg-melee-weapons-2 zerg-melee-weapons-3)
            'evolution-chamber]
           [(zergling-movementspeed metabolic-boost zergling-attackspeed adrenal-glands) 'spawning-pool]
           [(overlord-speed pneumatized-carapace burrow) 'townhall]
           [(glial-reconstitution tunneling-claws) 'roach-warren]
           [(centrifical-hooks) 'baneling-nest]
           [(grooved-spines muscular-augments) 'hydralisk-den]
           [(lurker-range seismic-spines adaptive-talons) 'lurker-den]
           [(neural-parasite pathogen-glands) 'infestation-pit]
           [(chitinous-plating anabolic-synthesis) 'ultralisk-cavern]
           [(zerg-flyer-weapons-1 zerg-flyer-armor-1) 'spire]
           [else #f])]))
    (and raw-slot (l2-normalize-facility-slot-sym ctx raw-slot)))

(define (l2-emit-research-verified! ctx upg-sym)
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define rt (l2-ctx-rt ctx))
    (define r-slot (l2-upgrade-researcher-slot ctx upg-sym))
    (when (and (not crisis-tech-upgrade-deferral?)
               (l2-upgrade-needed? ctx upg-sym)
               (or (not live-game?)
                   (not r-slot)
                   (> (hash-ref open-prod-slots r-slot 0) 0))
               (>= (l2-ctx-minerals ctx) (sc2-min-cost upg-sym))
               (>= (l2-ctx-gas ctx) (sc2-gas-cost upg-sym))
               (or (not live-game?)
                   (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                              (list 'research-upg upg-sym)
                                              frame
                                              28)))
      (l2-recall-building-group! ctx 7)
      (l2-emit! ctx (list 'research upg-sym))
      (set-l2-ctx-pending-upgs! ctx (cons upg-sym (l2-ctx-pending-upgs ctx)))
      (when (and live-game? r-slot)
        (hash-set! open-prod-slots r-slot (max 0 (sub1 (hash-ref open-prod-slots r-slot 0)))))
      (order-ledger-record-issued! oledger (+ 850000 (modulo frame 10000) (length (l2-ctx-actions ctx)))
                                   'research upg-sym base-x base-y frame)
      (l2-spend-resources-and-supply! ctx (sc2-min-cost upg-sym) (sc2-gas-cost upg-sym) 0)))

(define (l2-plan-wants-now? ctx sym)
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define macro-decision (l2-ctx-macro-decision ctx))
  (define plan-next-actions-ht (l2-ctx-plan-next-actions-ht ctx))
    (define csym (sc2-canonical-structure-sym sym))
    (or (eq? bo-goal-sym sym)
        (eq? bo-goal-sym csym)
        (hash-has-key? plan-next-actions-ht sym)
        (hash-has-key? plan-next-actions-ht csym)
        (not (not (memq sym (macro-brain-decision-scheduled-ids macro-decision))))
        (not (not (memq csym (macro-brain-decision-scheduled-ids macro-decision))))))

(define (l2-core-progression-exempt-from-surcharge? ctx target-sym)
  (define active-escrow-sym (l2-ctx-active-escrow-sym ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define total-bldg-counts (l2-ctx-total-bldg-counts ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
    (and target-sym
         (or (and (eq? target-sym 'robotics-facility)
                  (= (sc2-count-equivalent-structures total-bldg-counts 'robotics-facility #f) 0)
                  (>= supply-used 30))
             (and (not under-base-attack?)
                  (or (memq target-sym
                            '(spawning-pool cybernetics-core forge
                              orbital-command barracks-techlab factory starport engineering-bay
                              robotics-facility twilight-council))
                      (and (<= live-enemy-threat-supply 0)
                           (or (eq? target-sym bo-goal-sym)
                               (eq? target-sym active-escrow-sym)
                               (memq target-sym
                                     '(roach-warren queen
                                       hatchery nexus command-center
                                       warp-gate-research metabolic-boost stimpack lair)))))))))

(define (l2-non-combat-min-ok? ctx cost [target-sym #f])
  (define basic-combat-min-floor (l2-ctx-basic-combat-min-floor ctx))
  (define hard-supply-lockout-reserve-min (l2-ctx-hard-supply-lockout-reserve-min ctx))
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
  (define zerg-hold-overlord-min? (l2-ctx-zerg-hold-overlord-min? ctx))
    (define supply-lock-floor
      (cond
        [(memq target-sym '(pylon supply-depot overlord)) 0]
        [zerg-hold-overlord-min?
         (max hard-supply-lockout-reserve-min (sc2-min-cost 'overlord))]
        [else hard-supply-lockout-reserve-min]))
    (and (>= (- (l2-ctx-minerals ctx) cost) supply-lock-floor)
         (>= (- (l2-ctx-minerals ctx) cost)
             (cond
               [(not urgent-combat-or-intel-need?) 0]
               [(l2-core-progression-exempt-from-surcharge? ctx target-sym) basic-combat-min-floor]
               [else 125]))))

(define (l2-non-combat-gas-ok? ctx cost [target-sym #f])
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
    (or (<= cost 0)
        (>= (- (l2-ctx-gas ctx) cost)
            (if (and urgent-combat-or-intel-need?
                     (not (l2-core-progression-exempt-from-surcharge? ctx target-sym)))
                50
                0))))

(define (l2-worker-army-curve-satisfied? ctx)
  (define active-bases (l2-ctx-active-bases ctx))
  (define larva-slot-cnt (l2-ctx-larva-slot-cnt ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define live-open-combat-slots (l2-ctx-live-open-combat-slots ctx))
  (define race (l2-ctx-race ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define zerg-fog-army-floor-ok? (l2-ctx-zerg-fog-army-floor-ok? ctx))
    (and zerg-fog-army-floor-ok?
         (or (not live-game?)
             (< total-workers 24)
             (and (eq? race 'Zerg)
                  (not under-base-attack?)
                  (>= active-bases 3)
                  (< total-workers 55)
                  (>= live-army-supply 4.0))
             (and (not under-base-attack?)
                  (<= live-enemy-threat-supply 0)
                  (or (and (< total-workers (min 66 (* 20 active-bases))) (>= (l2-ctx-minerals ctx) 150))
                      (and (>= (l2-ctx-minerals ctx) 350)
                           (<= (if (exact-integer? live-open-combat-slots)
                                   (+ live-open-combat-slots larva-slot-cnt)
                                   99)
                               1))))
             (>= live-army-supply
                 (required-army-supply-for-worker-growth total-workers live-enemy-threat-supply)))))

(define (l2-can-spend-by-priority? ctx id-sym [cat-sym 'combat-unit])
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define escrow-suppressed-active? (l2-ctx-escrow-suppressed-active? ctx))
  (define goal-stream-alloc (l2-ctx-goal-stream-alloc ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define macro-decision (l2-ctx-macro-decision ctx))
  (define protoss-pending-robo-gas-reserve (l2-ctx-protoss-pending-robo-gas-reserve ctx))
  (define severe-intel-blindness? (l2-ctx-severe-intel-blindness? ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
    (define m-cost (sc2-min-cost id-sym))
    (define g-cost (sc2-gas-cost id-sym))
    (define alt-sym
      (case id-sym
        [(viking) 'viking-fighter]
        [(viking-fighter viking-assault) 'viking]
        [(templar-archive) 'templar-archives]
        [(templar-archives) 'templar-archive]
        [(lurker-den) 'lurker-den-mp]
        [(lurker-den-mp) 'lurker-den]
        [else #f]))
    (or (not live-game?)
        (and escrow-suppressed-active?
             (>= (l2-ctx-minerals ctx) m-cost)
             (>= (l2-ctx-gas ctx) g-cost))
        (and (eq? cat-sym 'combat-unit)
             (>= (- (l2-ctx-gas ctx) g-cost) (if (> g-cost 0) protoss-pending-robo-gas-reserve 0))
             (or under-base-attack?
                 (> live-enemy-threat-supply 0)
                 escrow-suppressed-active?
                 (and severe-intel-blindness? (null? ally-combat-units))))
        (macro-brain-can-spend? macro-decision id-sym (l2-ctx-minerals ctx) (l2-ctx-gas ctx) cat-sym)
        (and alt-sym
             (macro-brain-can-spend? macro-decision alt-sym (l2-ctx-minerals ctx) (l2-ctx-gas ctx) cat-sym))
        (and (not under-base-attack?)
             (<= live-enemy-threat-supply 0)
             (case cat-sym
               [(expansion) (decoupled-stream-can-spend? goal-stream-alloc 'expansion m-cost g-cost)]
               [(production-scaling)
                (and (>= (l2-ctx-minerals ctx) 550)
                     (decoupled-stream-can-spend? goal-stream-alloc 'production-facilities m-cost g-cost))]
               [else #f]))))

(define (l2-try-train-unit! ctx unit-sym producer-key [recall-group #f] #:respect-bo-reserve? [respect-bo? #f])
  (define active-bases (l2-ctx-active-bases ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define macro-decision (l2-ctx-macro-decision ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
    (define m-cost (sc2-min-cost unit-sym))
    (define g-cost (sc2-gas-cost unit-sym))
    (define s-cost (sc2-supply-cost unit-sym))
    (define alt-u-sym (if (eq? unit-sym 'viking) 'viking-fighter #f))
    (define is-bo-head?
      (or (eq? bo-goal-sym unit-sym)
          (and alt-u-sym (eq? bo-goal-sym alt-u-sym))
          (and live-game?
               (or (not (not (memq unit-sym (macro-brain-decision-scheduled-ids macro-decision))))
                   (and alt-u-sym
                        (not (not (memq alt-u-sym (macro-brain-decision-scheduled-ids macro-decision)))))))))
    (define max-batch
      (cond
        [(not live-game?) 1]
        [(and (memq unit-sym '(drone probe scv))
              (>= active-bases 2)
              (< total-workers (min 70 (* 22 active-bases)))
              (not under-base-attack?)
              (<= live-enemy-threat-supply 0))
         (min 3 active-bases)]
        [(memq unit-sym '(drone probe scv queen overlord observer sentry raven)) 1]
        [else 4]))
    (let loop ([trained 0])
      (define avail-slots (hash-ref open-prod-slots producer-key 0))
      (define eff-min (if (and respect-bo? (not (and is-bo-head? (= trained 0)))) (- (l2-ctx-minerals ctx) (l2-ctx-bo-reserved-min ctx)) (l2-ctx-minerals ctx)))
      (define eff-gas (if (and respect-bo? (not (and is-bo-head? (= trained 0)))) (- (l2-ctx-gas ctx) (l2-ctx-bo-reserved-gas ctx)) (l2-ctx-gas ctx)))
      (cond
        [(and (< trained max-batch)
              (> avail-slots 0)
              (l2-can-spend-supply? ctx s-cost)
              (or (<= m-cost 0) (>= eff-min m-cost))
              (or (<= g-cost 0) (>= eff-gas g-cost)))
         (hash-set! open-prod-slots producer-key (sub1 avail-slots))
         (when (and recall-group (= trained 0))
           (l2-recall-building-group! ctx recall-group))
         (l2-emit! ctx (list 'train unit-sym))
         (order-ledger-record-issued! oledger (+ 860000 (modulo frame 10000) (length (l2-ctx-actions ctx)))
                                      'train unit-sym base-x base-y frame)
         (set-l2-ctx-unit-counts! ctx (hash-update (l2-ctx-unit-counts ctx) (sc2-canonical-unit-sym unit-sym) add1 0))
         (l2-spend-resources-and-supply! ctx m-cost g-cost s-cost)
         (loop (add1 trained))]
        [else (> trained 0)])))

(define (l2-emit-building-morph-verified! ctx target-sym source-syms [recall-group 4])
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define ready-bldgs (l2-ctx-ready-bldgs ctx))
    (define m-cost (sc2-min-cost target-sym))
    (define g-cost (sc2-gas-cost target-sym))
    (define src-bldg
      (findf (lambda (b)
               (and (hash? b)
                    (memq (fast-canonical-structure-sym (unit-type-sym b)) source-syms)
                    (<= (hash-ref b 'order-count 0) 0)
                    (= (hash-ref b 'order-ability-id 0) 0)
                    (not (order-ledger-facility-busy? oledger b frame))))
             ready-bldgs))
    (cond
      [(and (not (l2-crisis-tech-bldg-deferred? ctx target-sym))
            (not (l2-building-present-or-pending? ctx target-sym))
            (>= (l2-ctx-minerals ctx) m-cost)
            (>= (l2-ctx-gas ctx) g-cost)
            (or src-bldg
                (and (not live-game?)
                     (ormap (lambda (s) (memq s ready-bldg-types)) source-syms))))
       (when recall-group
         (l2-recall-building-group! ctx recall-group))
       (l2-emit! ctx (list 'morph target-sym))
       (define rec-id
         (if (hash? src-bldg)
             (hash-ref src-bldg 'id (+ 821000 (modulo frame 10000) (length (l2-ctx-actions ctx))))
             (+ 821000 (modulo frame 10000) (length (l2-ctx-actions ctx)))))
       (order-ledger-record-issued! oledger rec-id 'morph target-sym base-x base-y frame)
       (set-l2-ctx-bldg-types! ctx (cons (sc2-canonical-structure-sym target-sym) (l2-ctx-bldg-types ctx)))
       (set-l2-ctx-morphing-bldg-types! ctx (cons (sc2-canonical-structure-sym target-sym) (l2-ctx-morphing-bldg-types ctx)))
       (when (and live-game? (ormap (lambda (s) (memq s '(hatchery lair command-center))) source-syms))
         (hash-set! open-prod-slots 'townhall
                    (max 0 (sub1 (hash-ref open-prod-slots 'townhall 0)))))
       (l2-spend-resources-and-supply! ctx m-cost g-cost 0)
       #t]
      [else #f]))

(define (l2-emit-unit-morph-verified! ctx target-sym source-sym [net-supply-cost 0])
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define unit-types (l2-ctx-unit-types ctx))
    (define m-cost (sc2-min-cost target-sym))
    (define g-cost (sc2-gas-cost target-sym))
    (define avail-src (hash-ref open-prod-slots source-sym 0))
    (cond
      [(and (or (> avail-src 0)
                (and (not live-game?) (memq source-sym unit-types)))
            (or (<= net-supply-cost 0) (l2-can-spend-supply? ctx net-supply-cost))
            (>= (l2-ctx-minerals ctx) m-cost)
            (>= (l2-ctx-gas ctx) g-cost))
       (when (> avail-src 0)
         (hash-set! open-prod-slots source-sym (sub1 avail-src)))
       (l2-emit! ctx (list 'morph target-sym))
       (order-ledger-record-issued! oledger (+ 865000 (modulo frame 10000) (length (l2-ctx-actions ctx)))
                                    'morph target-sym base-x base-y frame)
       (set-l2-ctx-unit-counts! ctx (hash-update (l2-ctx-unit-counts ctx) (sc2-canonical-unit-sym target-sym) add1 0))
       (l2-spend-resources-and-supply! ctx m-cost g-cost (max 0 net-supply-cost))
       #t]
      [else #f]))

(define (l2-third-base-prereqs-ready-for-escrow? ctx)
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define race (l2-ctx-race ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
    (case race
      [(Zerg)
       (and (>= eff-phase-supply 30)
            (memq 'spawning-pool ready-bldg-types))]
      [(Protoss)
       (and (>= eff-phase-supply 50)
            (>= live-army-supply 12)
            (not (and (memq 'robotics-bay ready-bldg-types)
                      (= (l2-unit-count ctx 'colossus) 0)))
            (or (memq 'robotics-facility (l2-ctx-bldg-types ctx))
                (memq 'twilight-council (l2-ctx-bldg-types ctx))
                (memq 'stargate (l2-ctx-bldg-types ctx))
                (l2-plan-wants-now? ctx 'nexus)))]
      [(Terran)
       (and (>= eff-phase-supply 42)
            (or (not live-game?) (>= live-army-supply 10) (>= (l2-ctx-minerals ctx) 550))
            (or (not live-game?)
                (memq 'starport ready-bldg-types)
                (>= (l2-ctx-minerals ctx) 550))
            (or live-game?
                (memq 'starport (l2-ctx-bldg-types ctx))
                (and (not (memq 'factory ready-bldg-types))
                     (or (memq 'factory (l2-ctx-bldg-types ctx))
                         (l2-plan-wants-now? ctx 'command-center)))))]
      [else #f]))

(define (l2-saving-for-expansion-now? ctx cur-base-count)
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define crisis-freeze-expand-or-gas? (l2-ctx-crisis-freeze-expand-or-gas? ctx))
  (define cur-escrow-age-frames (l2-ctx-cur-escrow-age-frames ctx))
  (define desired-bases (l2-ctx-desired-bases ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define escrow-suppressed-active? (l2-ctx-escrow-suppressed-active? ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define max-escrow-timeout-frames (l2-ctx-max-escrow-timeout-frames ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define orphaned-prereqs (l2-ctx-orphaned-prereqs ctx))
  (define pressure-metrics (l2-ctx-pressure-metrics ctx))
  (define race (l2-ctx-race ctx))
  (define race-th-sym (l2-ctx-race-th-sym ctx))
  (define severe-intel-blindness? (l2-ctx-severe-intel-blindness? ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
    (and (not under-base-attack?)
         (not under-early-cheese?)
         (not early-survival-crisis?)
         (not crisis-freeze-expand-or-gas?)
         (<= live-enemy-threat-supply 0)
         (not urgent-combat-or-intel-need?)
         (not escrow-suppressed-active?)
         (< cur-escrow-age-frames max-escrow-timeout-frames)
         (or (not live-game?)
             (and (= cur-base-count 1) (< frame 3800))
             (>= live-army-supply 2))
         (or (not live-game?) (not severe-intel-blindness?) (not (null? ally-combat-units)))
         (null? orphaned-prereqs)
         (< (hash-ref pressure-metrics 'threat-pressure 0.0) 0.85)
         (= (order-ledger-pending-count-for-type oledger race-th-sym frame) 0)
         (< (l2-ctx-minerals ctx) (sc2-min-cost race-th-sym))
         (or (and live-game?
                  (= cur-base-count 1)
                  (case race
                    [(Zerg) (>= total-workers 15)]
                    [(Protoss) (and (>= total-workers 17)
                                    (or (memq 'gateway (l2-ctx-bldg-types ctx)) (memq 'warp-gate (l2-ctx-bldg-types ctx)))
                                    (memq 'assimilator (l2-ctx-bldg-types ctx)))]
                    [(Terran) (and (>= total-workers 18)
                                   (memq 'barracks (l2-ctx-bldg-types ctx))
                                   (memq 'refinery (l2-ctx-bldg-types ctx))
                                   (l2-building-present-or-pending? ctx 'orbital-command))]
                    [else #f]))
             (and live-game?
                  (eq? bo-goal-sym race-th-sym)
                  (or (= cur-base-count 1)
                      (and (= cur-base-count 2) (l2-third-base-prereqs-ready-for-escrow? ctx))
                      (and (>= cur-base-count 3)
                           (>= eff-phase-supply (case race [(Protoss) 66] [(Terran) 62] [else 48]))
                           (>= live-army-supply (if (eq? race 'Zerg) 8 18))))
                  (>= total-workers (if (eq? race 'Zerg) 15 18)))
             (and (> frame 1800)
                  (< cur-base-count desired-bases)
                  (>= total-workers
                      (if (and live-game? (= cur-base-count 2))
                          (if (eq? race 'Zerg) 28 35)
                          (* (max 1 cur-base-count) SC2-IDEAL-WORKERS-PER-BASE)))
                  (if live-game?
                      (or (= cur-base-count 1)
                          (and (= cur-base-count 2) (l2-third-base-prereqs-ready-for-escrow? ctx))
                          (and (>= cur-base-count 3)
                               (>= eff-phase-supply (case race [(Protoss) 66] [(Terran) 62] [else 48]))
                               (>= live-army-supply (* (if (eq? race 'Zerg) 4 7) cur-base-count))))
                      (>= (length ally-combat-units) 4))))
         ;; Keep expensive uncamped-pad check last so failed scalar/prereq checks short-circuit cleanly.
         (or (not live-game?)
             (= cur-base-count 1)
             (let-values ([(ux uy) (l2-select-uncamped-expansion-pad ctx #f)])
               (and ux uy #t)))))

(define (l2-heavy-siege-record? ctx e)
    (define sym (unit-type-sym e))
    (define cached (hash-ref HEAVY-SIEGE-CACHE sym 'miss))
    (if (eq? cached 'miss)
        (let ([v (and (memq (fast-canonical-unit-sym sym)
                            '(siege-tank siege-tank-sieged colossus archon immortal thor planetary-fortress))
                      #t)])
          (hash-set! HEAVY-SIEGE-CACHE sym v)
          v)
        cached))

(define (l2-active-gas-bldg? ctx b)
    (> (hash-ref b 'vespene-contents 1) 0))

(define (l2-wall-slot-powered? ctx slot-pt)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define bypass-wall-pylon? (l2-ctx-bypass-wall-pylon? ctx))
  (define live-game-obs? (l2-ctx-live-game-obs? ctx))
       (and (pair? slot-pt)
            (not bypass-wall-pylon?)
            (or (not live-game-obs?)
                (ormap (lambda (b)
                         (and (hash? b)
                              (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'pylon)
                              (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                              (<= (dist2d (car slot-pt) (cdr slot-pt)
                                          (hash-ref b 'x -999.0)
                                          (hash-ref b 'y -999.0))
                                  6.2)))
                       ally-bldgs))))

(define (l2-protoss-holding-colossus-now? ctx)
  (define colossus-goal-cap (l2-ctx-colossus-goal-cap ctx))
  (define cur-escrow-age-frames (l2-ctx-cur-escrow-age-frames ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define escrow-suppressed-active? (l2-ctx-escrow-suppressed-active? ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define max-escrow-timeout-frames (l2-ctx-max-escrow-timeout-frames ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define protoss-saving-for-expand? (l2-ctx-protoss-saving-for-expand? ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
       (and live-game?
            (not protoss-saving-for-expand?)
            (not early-survival-crisis?)
            (not under-base-attack?)
            (not escrow-suppressed-active?)
            (< cur-escrow-age-frames max-escrow-timeout-frames)
            (memq 'robotics-bay ready-bldg-types)
            (memq 'robotics-facility ready-bldg-types)
            (> (hash-ref open-prod-slots 'robotics-facility 0) 0)
            (< (l2-unit-count ctx 'colossus) colossus-goal-cap)
            (l2-can-spend-supply? ctx (sc2-supply-cost 'colossus))))

(define (l2-protoss-colossus-escrow-ok? ctx m-cost g-cost)
       (or (not (l2-protoss-holding-colossus-now? ctx))
           (and (>= (- (l2-ctx-minerals ctx) m-cost) (sc2-min-cost 'colossus))
                (>= (- (l2-ctx-gas ctx) g-cost) (sc2-gas-cost 'colossus)))))

(define (l2-terran-facility-has-addon? ctx b)
  (define terran-addon-ox (l2-ctx-terran-addon-ox ctx))
  (define terran-addon-oy (l2-ctx-terran-addon-oy ctx))
  (define terran-addon-xs (l2-ctx-terran-addon-xs ctx))
  (define terran-addon-ys (l2-ctx-terran-addon-ys ctx))
       (or (eq? (hash-ref b 'has-addon? #f) #t)
           (not (not (hash-ref b 'addon #f)))
           (> (hash-ref b 'add-on-tag 0) 0)
           (and (pair? terran-addon-xs)
                (let ([tx (fl+ (exact->inexact (hash-ref b 'x -999.0)) terran-addon-ox)]
                      [ty (fl+ (exact->inexact (hash-ref b 'y -999.0)) terran-addon-oy)])
                  (for/or ([ax (in-list terran-addon-xs)]
                           [ay (in-list terran-addon-ys)])
                    (define dx (fl- tx ax))
                    (define dy (fl- ty ay))
                    (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 3.0625))))))

(define (l2-facility-being-swapped? ctx b)
  (define addon-swap-acts (l2-ctx-addon-swap-acts ctx))
       (define bid (hash-ref b 'id -1))
       (for/or ([a (in-list addon-swap-acts)])
         (and (pair? a)
              (eq? (car a) 'terran-addon-swap)
              (>= (length a) 3)
              (or (equal? (second a) bid)
                  (equal? (third a) bid)))))

(define (l2-grounded-bare-facility ctx sym)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define claimed-addon-fac-ids (l2-ctx-claimed-addon-fac-ids ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define oledger (l2-ctx-oledger ctx))
       (for/first ([b (in-list ally-bldgs)]
                   #:when (and (eq? (unit-type-sym b) sym)
                               (l2-building-grounded-and-powered? ctx b)
                               (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                               (or (not live-game?) (= (hash-ref b 'order-count 0) 0))
                               (not (l2-terran-facility-has-addon? ctx b))
                               (not (l2-facility-being-swapped? ctx b))
                               (not (set-member? claimed-addon-fac-ids (hash-ref b 'id -1)))
                               (or (not live-game?)
                                   (not (order-ledger-facility-busy? oledger b frame)))))
         b))

(define (l2-holding-for-first-starport? ctx)
  (define cur-escrow-age-frames (l2-ctx-cur-escrow-age-frames ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define escrow-suppressed-active? (l2-ctx-escrow-suppressed-active? ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define max-escrow-timeout-frames (l2-ctx-max-escrow-timeout-frames ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define terran-cannon-breakout-mode? (l2-ctx-terran-cannon-breakout-mode? ctx))
  (define terran-saving-for-expand? (l2-ctx-terran-saving-for-expand? ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
       (and live-game?
            (memq 'factory ready-bldg-types)
            (not terran-cannon-breakout-mode?)
            (not terran-saving-for-expand?)
            (not early-survival-crisis?)
            (not under-base-attack?)
            (not escrow-suppressed-active?)
            (< cur-escrow-age-frames max-escrow-timeout-frames)
            (not (l2-building-present-or-pending? ctx 'starport))))

(define (l2-starport-escrow-ok? ctx m-cost g-cost)
       (or (not (l2-holding-for-first-starport? ctx))
           (and (>= (- (l2-ctx-minerals ctx) m-cost) (sc2-min-cost 'starport))
                (>= (- (l2-ctx-gas ctx) g-cost) (sc2-gas-cost 'starport)))))

(define (l2-phase1-setup! ctx rt raw-obs orig-raw-obs sanitized?)
  (set-l2-ctx-rt! ctx rt)
  (set-l2-ctx-raw-obs! ctx raw-obs)
  (set-l2-ctx-orig-raw-obs! ctx orig-raw-obs)
  (define obs (if sanitized? raw-obs (sanitize-obs-hash raw-obs)))
  (set-l2-ctx-obs! ctx obs)
  (define raw-rt-race (live-bot-runtime-actual-race rt))
  (define race
    (if (eq? raw-rt-race 'Random)
        (detect-actual-race-from-obs obs 'Zerg)
        raw-rt-race))
  (set-l2-ctx-race! ctx race)
  (define frame (hash-ref obs 'frame 0))
  (set-l2-ctx-frame! ctx frame)
  (set-l2-ctx-minerals! ctx (hash-ref obs 'minerals 200))
  (set-l2-ctx-gas! ctx (hash-ref obs 'gas SC2-STARTING-GAS))
  (define supply-used (hash-ref obs 'supply-used SC2-STARTING-WORKERS))
  (set-l2-ctx-supply-used! ctx supply-used)
  (define supply-cap (hash-ref obs 'supply-cap SC2-TOWN-HALL-SUPPLY-PROVIDED))
  (set-l2-ctx-supply-cap! ctx supply-cap)
  (set-l2-ctx-pending-supply! ctx (hash-ref obs 'pending-supply 0))
  (set-l2-ctx-supply-left! ctx (hash-ref obs 'supply-left (- supply-cap supply-used)))
  (define ally-units (hash-ref obs 'ally-units '()))
  (set-l2-ctx-ally-units! ctx ally-units)
  (define ally-bldgs (hash-ref obs 'ally-buildings '()))
  (set-l2-ctx-ally-bldgs! ctx ally-bldgs)
  (define enemy-units (hash-ref obs 'enemy-units '()))
  (set-l2-ctx-enemy-units! ctx enemy-units)
  (define enemy-bldgs (hash-ref obs 'enemy-buildings '()))
  (set-l2-ctx-enemy-bldgs! ctx enemy-bldgs)
  (define base-x (hash-ref obs 'base-x SC2-DEFAULT-HOME-BASE-X))
  (set-l2-ctx-base-x! ctx base-x)
  (define base-y (hash-ref obs 'base-y SC2-DEFAULT-HOME-BASE-Y))
  (set-l2-ctx-base-y! ctx base-y)
  (define nat-x (hash-ref obs 'natural-x SC2-DEFAULT-NATURAL-X))
  (set-l2-ctx-nat-x! ctx nat-x)
  (define nat-y (hash-ref obs 'natural-y SC2-DEFAULT-NATURAL-Y))
  (set-l2-ctx-nat-y! ctx nat-y)
  (define third-x (hash-ref obs 'third-x SC2-DEFAULT-THIRD-X))
  (set-l2-ctx-third-x! ctx third-x)
  (define third-y (hash-ref obs 'third-y SC2-DEFAULT-THIRD-Y))
  (set-l2-ctx-third-y! ctx third-y)
  (define enemy-x (hash-ref obs 'enemy-x SC2-DEFAULT-ENEMY-BASE-X))
  (set-l2-ctx-enemy-x! ctx enemy-x)
  (define enemy-y (hash-ref obs 'enemy-y SC2-DEFAULT-ENEMY-BASE-Y))
  (set-l2-ctx-enemy-y! ctx enemy-y)
  (set-l2-ctx-actions! ctx '())
  (define protoss-powered-structure-syms
    SC2-PROTOSS-PYLON-POWERED-STRUCTURE-SYMS)
  (set-l2-ctx-bldg-types! ctx
    (for/list ([b (in-list ally-bldgs)])
      (fast-canonical-structure-sym (unit-type-sym b))))
  (define-values (unit-types raw-workers workers obs-frozen-workers)
    (for/fold ([ut-rev '()] [rw-rev '()] [w-rev '()] [frozen-cnt 0]
               #:result (values (reverse ut-rev)
                                (reverse rw-rev)
                                (reverse w-rev)
                                frozen-cnt))
              ([u (in-list ally-units)])
      (define ut (unit-type-sym u))
      (define ut-rev2 (cons ut ut-rev))
      (if (memq ut '(drone probe scv))
          (if (l2-unit-stasis-frozen? ctx u)
              (values ut-rev2 (cons u rw-rev) w-rev (+ frozen-cnt 1))
              (values ut-rev2 (cons u rw-rev) (cons u w-rev) frozen-cnt))
          (values ut-rev2 rw-rev w-rev frozen-cnt))))
  (set-l2-ctx-unit-types! ctx unit-types)
  (set-l2-ctx-workers! ctx workers)
  (define frozen-worker-count
    (max obs-frozen-workers
         (safe-nonneg-int (hash-ref obs 'stasis-frozen-worker-count 0) 0)))
  (define active-worker-count
    (max 0 (- (length raw-workers) frozen-worker-count)))
  (set-l2-ctx-active-worker-count! ctx active-worker-count)
  (define pending-workers (hash-ref obs 'pending-workers 0))
  (set-l2-ctx-pending-workers! ctx pending-workers)
  (define total-workers (+ active-worker-count pending-workers))
  (set-l2-ctx-total-workers! ctx total-workers)
  (when (> frozen-worker-count 0)
    (l2-emit! ctx (list 'stasis-worker-stoppage-compensation frozen-worker-count)))
  (define cd-tracker (live-bot-runtime-cooldown-tracker rt))
  (set-l2-ctx-cd-tracker! ctx cd-tracker)
  (define leases (rt-role-leases rt))
  (set-l2-ctx-leases! ctx leases)
  (define oledger-early (live-bot-runtime-order-ledger rt))
  (set-l2-ctx-oledger-early! ctx oledger-early)
  (define map-grids (hash-ref obs 'map-grids #f))
  (set-l2-ctx-map-grids! ctx map-grids)
  (define step-mineral-patches
    (let ([raw (hash-ref obs 'mineral-patches '())])
      (cond
        [(or (not (list? raw)) (null? raw)) '()]
        [(for/and ([m (in-list raw)])
           (and (hash? m) (or (hash-has-key? m 'type) (hash-has-key? m 'unit-type-id))))
         raw]
        [else
         (for/list ([m (in-list raw)] #:when (hash? m))
           (if (or (hash-has-key? m 'type) (hash-has-key? m 'unit-type-id))
               m
               (hash-set m 'type 'mineral-field)))])))
  (set-l2-ctx-step-mineral-patches! ctx step-mineral-patches)
  (define step-geysers
    (let ([raw (hash-ref obs 'geysers '())])
      (cond
        [(or (not (list? raw)) (null? raw)) '()]
        [(for/and ([g (in-list raw)]) (hash? g)) raw]
        [else (for/list ([g (in-list raw)] #:when (hash? g)) g)])))
  (set-l2-ctx-step-geysers! ctx step-geysers)
  (define step-neutral-units
    (let ([raw (hash-ref obs 'neutral-units '())])
      (cond
        [(and (list? raw) (pair? raw))
         (if (for/and ([u (in-list raw)]) (hash? u))
             raw
             (for/list ([u (in-list raw)] #:when (hash? u)) u))]
        [(null? step-geysers) step-mineral-patches]
        [(null? step-mineral-patches) step-geysers]
        [else (append step-mineral-patches step-geysers)])))
  (set-l2-ctx-step-neutral-units! ctx step-neutral-units)
  (define expansion-pads
    (let ([raw-pads (hash-ref obs 'expansion-candidates #f)])
      (if (and (list? raw-pads) (pair? raw-pads))
          raw-pads
          (list (cons nat-x nat-y) (cons third-x third-y)))))
  (set-l2-ctx-expansion-pads! ctx expansion-pads)
  (for ([w (in-list workers)])
    (define wid (hash-ref w 'id 0))
    (when (and (> wid 0)
               (or (worker-has-engine-build-order? w)
                   (order-ledger-unit-has-active-build? oledger-early wid w)))
      (acquire-unit-lease! leases wid 'builder frame 24
                           #:x (hash-ref w 'x base-x)
                           #:y (hash-ref w 'y base-y))))
  (when (<= frame 4)
    (set-box! (rt-enemy-race-box rt) 'Unknown)
    (set-box! (rt-initial-enemy-race-box rt) #f)
    (set-box! (rt-experiment-box rt) #f)
    (hash-clear! (rt-simcity-cache rt))
    (set-box! (rt-sit-plan-cache rt) #f))
  (define raw-req-race
    (let ([req (hash-ref obs 'opponent-requested-race
                         (hash-ref obs 'enemy-race 'Random))])
      (case req
        [(Zerg zerg "Zerg" "zerg") 'Zerg]
        [(Protoss protoss "Protoss" "protoss") 'Protoss]
        [(Terran terran "Terran" "terran") 'Terran]
        [else 'Random])))
  (when (and (not (unbox (rt-initial-enemy-race-box rt)))
             (or (not (eq? (hash-ref raw-obs 'mineral-harvesters RUNTIME-MISSING) RUNTIME-MISSING))
                 (not (eq? (hash-ref obs 'opponent-requested-race RUNTIME-MISSING) RUNTIME-MISSING))
                 (not (eq? (hash-ref obs 'enemy-race RUNTIME-MISSING) RUNTIME-MISSING))))
    (set-box! (rt-initial-enemy-race-box rt) raw-req-race))
  (define initial-enemy-race
    (or (unbox (rt-initial-enemy-race-box rt)) raw-req-race))
  (set-l2-ctx-initial-enemy-race! ctx initial-enemy-race)
  (define scouted-enemy-race
    (let ([seen-z #f] [seen-t #f] [seen-p #f])
      (define (scan-list! lst)
        (for ([e (in-list lst)] #:break seen-z)
          (when (and (hash? e)
                     (not (eq? (hash-ref e 'is-hallucination #f) #t))
                     (not (eq? (hash-ref e 'hallucination #f) #t))
                     (not (eq? (hash-ref e 'hallucination? #f) #t))
                     (not (eq? (hash-ref e 'changeling? #f) #t)))
            (define r (hash-ref ENEMY-RACE-BY-CANON-HT (fast-canonical-unit-sym (unit-type-sym e)) #f))
            (case r
              [(Zerg) (set! seen-z #t)]
              [(Terran) (unless seen-t (set! seen-t #t))]
              [(Protoss) (unless seen-p (set! seen-p #t))]))))
      (scan-list! enemy-units)
      (unless seen-z (scan-list! enemy-bldgs))
      (cond [seen-z 'Zerg]
            [seen-t 'Terran]
            [seen-p 'Protoss]
            [else 'Unknown])))
  (when (memq scouted-enemy-race '(Zerg Terran Protoss))
    (set-box! (rt-enemy-race-box rt) scouted-enemy-race))
  (define effective-enemy-race
    (let ([known (if (memq scouted-enemy-race '(Zerg Terran Protoss))
                     scouted-enemy-race
                     (unbox (rt-enemy-race-box rt)))])
      (if (memq known '(Zerg Terran Protoss))
          known
          raw-req-race)))
  (set-l2-ctx-effective-enemy-race! ctx effective-enemy-race)
  (define townhall-bldg-cnt
    (for/sum ([ab (in-list ally-bldgs)])
      (if (memq (fast-canonical-structure-sym (unit-type-sym ab))
                '(command-center orbital-command planetary-fortress nexus hatchery lair hive))
          1
          0)))
  (define raw-obs-live-harvesters? (hash-has-key? raw-obs 'mineral-harvesters))
  (for ([b (in-list ally-bldgs)])
    (define raw-prog (hash-ref b 'build-progress SANITIZE-MISSING))
    (define prog (if (eq? raw-prog SANITIZE-MISSING) (if (hash-ref b 'under-construction #f) 0.5 1.0) raw-prog))
    (define hp (hash-ref b 'hp 100))
    (define max-hp (hash-ref b 'max-hp 500))
    (define raw-hp-pct (hash-ref b 'hp-pct SANITIZE-MISSING))
    (define hp-pct (if (eq? raw-hp-pct SANITIZE-MISSING) (/ (exact->inexact hp) (max 1 max-hp)) raw-hp-pct))
    (when (and (< prog SC2-BUILD-COMPLETE-PROGRESS)
               (< hp-pct SC2-DYING-BLDG-CANCEL-HP-PCT))
      (define bx (hash-ref b 'x base-x))
      (define by (hash-ref b 'y base-y))
      (define canon-bt (fast-canonical-structure-sym (unit-type-sym b)))
      (define main-townhall?
        (and (memq canon-bt
                   '(command-center orbital-command planetary-fortress nexus hatchery lair hive))
             (or (<= (fast-dist2d bx by base-x base-y) 8.0)
                 (and raw-obs-live-harvesters? (<= townhall-bldg-cnt 1)))))
      (define enemy-near?
        (or (eq? (hash-ref b 'under-attack #f) #t)
            (for/or ([e (in-list enemy-units)])
              (define et (unit-type-sym e))
              (and (fast-enemy-unit-targetable? et)
                   (not (hash-ref NON-COMBAT-AND-SCOUT-ENEMY-HT et #f))
                   (<= (fast-dist2d bx by (hash-ref e 'x 9999) (hash-ref e 'y 9999))
                       SC2-BLDG-UNDER-ATTACK-RADIUS)))))
      (when (and enemy-near?
                 (not (and main-townhall?
                           (or (>= hp-pct 0.05) (> prog 0.25)))))
        (define cancel-cd-key
          (string->symbol
           (format "save-cancel-rebuild-~a" canon-bt)))
        (refractory-allow-action?! cd-tracker cancel-cd-key frame 96)
        (when (and (refractory-cooldown-tracker? cd-tracker)
                   (hash? (refractory-cooldown-tracker-table cd-tracker)))
          (hash-set! (refractory-cooldown-tracker-table cd-tracker) cancel-cd-key frame))
        (l2-emit! ctx (list 'cancel (hash-ref b 'id 701))))))
  (set-l2-ctx-uncontested-zerg-hatch-cache! ctx 'uninit)
  (when (eq? race 'Terran)
    (define assigned-resume-scvs (mutable-set))
    (for ([b (in-list ally-bldgs)])
      (define prog (hash-ref b 'build-progress 1.0))
      (define halted? (or (hash-ref b 'halted #f)
                          (and (< prog 1.0) (not (hash-ref b 'has-builder #t)))))
      (define bid (hash-ref b 'id 902))
      (define avail-scv
        (findf (lambda (w) (not (set-member? assigned-resume-scvs (hash-ref w 'id 10))))
               workers))
      (when (and halted?
                 avail-scv
                 (refractory-allow-action?! cd-tracker
                                            (list 'resume-halted-building bid)
                                            frame
                                            SC2-RESUME-BLDG-COOLDOWN-FRAMES))
        (define scv-id (hash-ref avail-scv 'id 10))
        (set-add! assigned-resume-scvs scv-id)
        (l2-emit! ctx (list 'resume-halted-building scv-id bid)))))
  (define enemy-gas-steals
    (filter (lambda (eb)
              (and (memq (unit-type-sym eb) '(assimilator extractor refinery))
                   (<= (dist2d base-x base-y (hash-ref eb 'x 9999) (hash-ref eb 'y 9999))
                       SC2-GAS-STEAL-RADIUS)))
            enemy-bldgs))
  (for ([eg (in-list enemy-gas-steals)])
    (l2-emit! ctx (list 'clear-gas-steal
                 (hash-ref eg 'id 901)
                 (hash-ref eg 'x (safe-coord (+ base-x 3.0)))
                 (hash-ref eg 'y (safe-coord (+ base-y 3.0))))))
  (define live-obs-harvesters? (hash-has-key? raw-obs 'mineral-harvesters))
  (set-l2-ctx-live-obs-harvesters?! ctx live-obs-harvesters?)
  (define prev-tel-early
    (let ([t (live-bot-runtime-last-telemetry rt)])
      (if (hash? t) t (hash))))
  (set-l2-ctx-prev-tel-early! ctx prev-tel-early)
  (define townhalls
    (for/list ([b (in-list ally-bldgs)]
               #:when (memq (fast-canonical-structure-sym (unit-type-sym b))
                            '(hatchery lair hive nexus command-center orbital-command planetary-fortress)))
      b))
  (set-l2-ctx-townhalls! ctx townhalls)
  (define active-bases (max 1 (length townhalls)))
  (set-l2-ctx-active-bases! ctx active-bases)
  (define early-race-th-sym
    (case race
      [(Zerg) 'hatchery]
      [(Protoss) 'nexus]
      [else 'command-center]))
  (set-l2-ctx-early-race-th-sym! ctx early-race-th-sym)
  (define th-coords
    (let loop ([rem (if (list? townhalls) townhalls '())] [acc '()])
      (if (null? rem)
          (reverse acc)
          (let* ([b (car rem)]
                 [bx (and (hash? b) (hash-ref b 'x #f))]
                 [by (and bx (hash-ref b 'y #f))])
            (loop (cdr rem)
                  (if (and bx by)
                      (cons (cons bx by) acc)
                      (if (and (hash? b) (hash-has-key? b 'x) (hash-has-key? b 'y))
                          (cons (cons (hash-ref b 'x base-x) (hash-ref b 'y base-y)) acc)
                          acc)))))))
  (define owned-base-coords
    (cons (cons base-x base-y)
          (if (>= active-bases 2)
              (cons (cons nat-x nat-y)
                    (if (>= active-bases 3)
                        (cons (cons third-x third-y) th-coords)
                        th-coords))
              (if (>= active-bases 3)
                  (cons (cons third-x third-y) th-coords)
                  th-coords))))
  (set-l2-ctx-owned-base-coords! ctx owned-base-coords)
  (define ally-combat-units
    (for/list ([u (in-list ally-units)]
               #:when (combat-unit-record? u))
      u))
  (set-l2-ctx-ally-combat-units! ctx ally-combat-units)
  (define ally-combat-supply-early
    (hash-ref obs 'army-supply
              (lambda ()
                (for/sum ([u (in-list ally-combat-units)])
                  (unit-supply-cost (unit-type-sym u))))))
  (set-l2-ctx-ally-combat-supply-early! ctx ally-combat-supply-early)
  (define early-enemy-nat-x
    (hash-ref obs 'enemy-natural-x (hash-ref obs 'enemy-expand-x SC2-DEFAULT-ENEMY-EXPAND-X)))
  (set-l2-ctx-early-enemy-nat-x! ctx early-enemy-nat-x)
  (define early-enemy-nat-y
    (hash-ref obs 'enemy-natural-y (hash-ref obs 'enemy-expand-y SC2-DEFAULT-ENEMY-EXPAND-Y)))
  (set-l2-ctx-early-enemy-nat-y! ctx early-enemy-nat-y)
  (define early-enemy-third-x
    (hash-ref obs 'enemy-third-x (safe-coord (* 0.72 enemy-x) 132.0)))
  (set-l2-ctx-early-enemy-third-x! ctx early-enemy-third-x)
  (define early-enemy-third-y
    (hash-ref obs 'enemy-third-y (safe-coord (* 0.72 enemy-y) 132.0)))
  (set-l2-ctx-early-enemy-third-y! ctx early-enemy-third-y)
  (define worker-rush-r2 (* SC2-WORKER-RUSH-DETECT-RADIUS SC2-WORKER-RUSH-DETECT-RADIUS))
  (define check-midmap-rush? (< frame 3360))
  (define check-nat-rush? (>= active-bases 2))
  (define-values (ground-enemy-units-for-cheese enemy-rush-workers enemy-midmap-rush-workers)
    (let loop ([rem enemy-units] [g-rev '()] [r-rev '()] [m-rev '()])
      (cond
        [(null? rem)
         (values (reverse g-rev) (reverse r-rev) (reverse m-rev))]
        [else
         (define e (car rem))
         (define ut (unit-type-sym e))
         (cond
           [(or (hash-has-key? NON-WORKER-PULL-ENEMY-UNIT-HT ut)
                (eq? (hash-ref e 'changeling? #f) #t)
                (eq? (hash-ref e 'hallucination? #f) #t)
                (eq? (hash-ref e 'hallucination #f) #t)
                (eq? (hash-ref e 'flying? #f) #t))
            (loop (cdr rem) g-rev r-rev m-rev)]
           [(or (eq? ut 'probe) (eq? ut 'scv) (eq? ut 'drone))
            (define rx (hash-ref e 'x 9999.0))
            (define ry (hash-ref e 'y 9999.0))
            (define ex (if (flonum? rx) rx (exact->inexact rx)))
            (define ey (if (flonum? ry) ry (exact->inexact ry)))
            (define bx-fl (if (flonum? base-x) base-x (exact->inexact base-x)))
            (define by-fl (if (flonum? base-y) base-y (exact->inexact base-y)))
            (define r2-fl (if (flonum? worker-rush-r2) worker-rush-r2 (exact->inexact worker-rush-r2)))
            (define dx-b (fl- ex bx-fl))
            (define dy-b (fl- ey by-fl))
            (define near-rush?
              (or (fl<= (fl+ (fl* dx-b dx-b) (fl* dy-b dy-b)) r2-fl)
                  (and check-nat-rush?
                       (let ([dx-n (fl- ex (if (flonum? nat-x) nat-x (exact->inexact nat-x)))]
                             [dy-n (fl- ey (if (flonum? nat-y) nat-y (exact->inexact nat-y)))])
                         (fl<= (fl+ (fl* dx-n dx-n) (fl* dy-n dy-n)) r2-fl)))))
            (define mid-rush?
              (and check-midmap-rush?
                   (let ([dx-e (- ex enemy-x)] [dy-e (- ey enemy-y)]
                         [dx-en (- ex early-enemy-nat-x)] [dy-en (- ey early-enemy-nat-y)])
                     (and (> (+ (* dx-e dx-e) (* dy-e dy-e)) 676.0)
                          (> (+ (* dx-en dx-en) (* dy-en dy-en)) 400.0)))))
            (loop (cdr rem)
                  (cons e g-rev)
                  (if near-rush? (cons e r-rev) r-rev)
                  (if mid-rush? (cons e m-rev) m-rev))]
           [else
            (loop (cdr rem) (cons e g-rev) r-rev m-rev)])])))
  (set-l2-ctx-ground-enemy-units-for-cheese! ctx ground-enemy-units-for-cheese)
  (set-l2-ctx-enemy-rush-workers! ctx enemy-rush-workers)
  (define worker-rush-active?
    (and (or (>= (length enemy-rush-workers) SC2-WORKER-RUSH-MIN-ENEMY-WORKERS)
             (>= (length enemy-midmap-rush-workers) 4))
         (< ally-combat-supply-early 6)))
  (set-l2-ctx-worker-rush-active?! ctx worker-rush-active?)
  (define all-proxy-enemy-structures
    (if (< frame 5376)
        (filter (lambda (eb) (l2-enemy-bldg-is-proxy? ctx eb)) enemy-bldgs)
        '()))
  (define raw-in-base-proxy-structures
    (if (< frame SC2-IN-BASE-PROXY-MAX-FRAME)
        (filter (lambda (eb)
                  (define canon (fast-canonical-structure-sym (unit-type-sym eb)))
                  (define ebx (hash-ref eb 'x 9999.0))
                  (define eby (hash-ref eb 'y 9999.0))
                  (and (l2-enemy-bldg-is-proxy? ctx eb)
                       (memq canon
                             '(pylon photon-cannon forge barracks bunker
                               spine-crawler gateway shield-battery hatchery))
                       (or (<= (dist2d base-x base-y ebx eby) SC2-IN-BASE-PROXY-DETECT-RADIUS)
                           (<= (dist2d nat-x nat-y ebx eby) SC2-IN-BASE-PROXY-DETECT-RADIUS))))
                enemy-bldgs)
        '()))
  (define in-base-proxy-structures
    (if (and (not live-obs-harvesters?)
             (< active-bases 2)
             (= (length raw-in-base-proxy-structures) 1)
             (let ([eb0 (car raw-in-base-proxy-structures)])
               (and (eq? (fast-canonical-structure-sym (unit-type-sym eb0)) 'pylon)
                    (> (dist2d base-x base-y (hash-ref eb0 'x 9999.0) (hash-ref eb0 'y 9999.0)) 24.0)
                    (<= (dist2d nat-x nat-y (hash-ref eb0 'x 9999.0) (hash-ref eb0 'y 9999.0))
                        SC2-NATURAL-BLOCK-RADIUS))))
        '()
        raw-in-base-proxy-structures))
  (set-l2-ctx-in-base-proxy-structures! ctx in-base-proxy-structures)
  (define in-base-proxy-detected?
    (and (not (null? in-base-proxy-structures))
         (< ally-combat-supply-early 8)))
  (set-l2-ctx-in-base-proxy-detected?! ctx in-base-proxy-detected?)
  (define raw-obs-unmodified (or orig-raw-obs raw-obs))
  (define raw-enemy-bldgs-early
    (let ([ebs (and (hash? raw-obs-unmodified) (hash-ref raw-obs-unmodified 'enemy-buildings #f))])
      (if (list? ebs) ebs '())))
  (set-l2-ctx-raw-enemy-bldgs-early! ctx raw-enemy-bldgs-early)
  (define in-base-proxy-completed-cannons
    (if in-base-proxy-detected?
        (filter (lambda (eb)
                  (and (eq? (fast-canonical-structure-sym (unit-type-sym eb)) 'photon-cannon)
                       (or live-obs-harvesters? (l2-raw-eb-explicit-build-progress? ctx eb))
                       (>= (hash-ref eb 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                       (not (eq? (hash-ref eb 'powered? #t) #f))))
                in-base-proxy-structures)
        '()))
  (set-l2-ctx-in-base-proxy-completed-cannons! ctx in-base-proxy-completed-cannons)
  (define in-base-proxy-completed-cannon?
    (not (null? in-base-proxy-completed-cannons)))
  (set-l2-ctx-in-base-proxy-completed-cannon?! ctx in-base-proxy-completed-cannon?)
  (define forward-proxy-structures
    (if (< frame 5376)
        (filter (lambda (eb)
                  (define ebx (hash-ref eb 'x 9999.0))
                  (define eby (hash-ref eb 'y 9999.0))
                  (and (> (dist2d base-x base-y ebx eby) SC2-IN-BASE-PROXY-DETECT-RADIUS)
                       (> (dist2d nat-x nat-y ebx eby) SC2-IN-BASE-PROXY-DETECT-RADIUS)))
                all-proxy-enemy-structures)
        '()))
  (set-l2-ctx-forward-proxy-structures! ctx forward-proxy-structures)
  (define forward-proxy-detected?
    (and (not (null? forward-proxy-structures))
         (< ally-combat-supply-early 14)))
  (set-l2-ctx-forward-proxy-detected?! ctx forward-proxy-detected?)
  (define cheese-dist-thresh SC2-CHEESE-RUSH-RADIUS)
  (set-l2-ctx-cheese-dist-thresh! ctx cheese-dist-thresh)
  (define proxy-or-cheese-enemies
    (if (or (< frame SC2-EARLY-CHEESE-MAX-FRAME)
            (hash-ref obs 'under-cheese-rush #f))
        (let ([cheese-r2 (* cheese-dist-thresh cheese-dist-thresh)])
          (define (near-cheese? e)
            (define dx (- (exact->inexact (hash-ref e 'x 9999)) base-x))
            (define dy (- (exact->inexact (hash-ref e 'y 9999)) base-y))
            (<= (+ (* dx dx) (* dy dy)) cheese-r2))
          (append (filter near-cheese? ground-enemy-units-for-cheese)
                  (filter near-cheese? enemy-bldgs)))
        '()))
  (set-l2-ctx-proxy-or-cheese-enemies! ctx proxy-or-cheese-enemies)
  (define under-early-cheese?
    (or worker-rush-active?
        in-base-proxy-detected?
        (and (not (null? proxy-or-cheese-enemies))
             (or (hash-ref obs 'under-cheese-rush #f)
                 (ormap (lambda (e)
                          (and (<= (dist2d base-x base-y (hash-ref e 'x 9999) (hash-ref e 'y 9999)) cheese-dist-thresh)
                               (memq (unit-type-sym e) '(photon-cannon pylon bunker spine-crawler barracks))))
                        enemy-bldgs)
                 (>= (length proxy-or-cheese-enemies) 2)))))
  (set-l2-ctx-under-early-cheese?! ctx under-early-cheese?)
  (define early-survival-crisis?
    (or worker-rush-active?
        in-base-proxy-detected?
        (and under-early-cheese? (< ally-combat-supply-early 6))))
  (set-l2-ctx-early-survival-crisis?! ctx early-survival-crisis?)
  (when (and worker-rush-active?
             (< ally-combat-supply-early 4)
             (not (ormap (lambda (b)
                           (and (hash? b)
                                (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                                (memq (fast-canonical-structure-sym (unit-type-sym b))
                                      '(spawning-pool barracks gateway warp-gate
                                        spine-crawler photon-cannon bunker))))
                         ally-bldgs)))
    (for ([b (in-list ally-bldgs)])
      (when (and (hash? b)
                 (memq (fast-canonical-structure-sym (unit-type-sym b))
                       '(hatchery nexus command-center))
                 (< (hash-ref b 'build-progress 1.0) 0.85)
                 (> (dist2d base-x base-y (hash-ref b 'x base-x) (hash-ref b 'y base-y)) 8.0))
        (define exp-bid (hash-ref b 'id 0))
        (when (and (> exp-bid 0)
                   (refractory-allow-action?! cd-tracker
                                              (list 'cancel-greedy-expand exp-bid)
                                              frame
                                              96))
          (l2-emit! ctx (list 'cancel exp-bid))))))
  (define rush-def-st (rt-rush-defense-state rt))
  (set-l2-ctx-rush-def-st! ctx rush-def-st)
  (when (<= frame 4)
    (hash-clear! rush-def-st))
  (define prev-rush-fighting-wids
    (let ([s (hash-ref prev-tel-early 'rush-fighting-worker-ids '())])
      (if (list? s) s '())))
  (set-l2-ctx-prev-rush-fighting-wids! ctx prev-rush-fighting-wids)
  (set-l2-ctx-cur-rush-fighting-wids! ctx '())
  (set-l2-ctx-cur-rush-disengaging-wids! ctx '())
  (set-l2-ctx-worker-pull-emitted-1ab?! ctx #f)
  (define non-builder-defense-workers
    (filter (lambda (w)
              (and (not (worker-has-engine-build-order? w))
                   (not (order-ledger-unit-has-active-build? oledger-early (hash-ref w 'id 0) w))))
            workers))
  (set-l2-ctx-non-builder-defense-workers! ctx non-builder-defense-workers))

(define (l2-phase2-worker-rush! ctx)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define enemy-rush-workers (l2-ctx-enemy-rush-workers ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define ground-enemy-units-for-cheese (l2-ctx-ground-enemy-units-for-cheese ctx))
  (define live-obs-harvesters? (l2-ctx-live-obs-harvesters? ctx))
  (define non-builder-defense-workers (l2-ctx-non-builder-defense-workers ctx))
  (define obs (l2-ctx-obs ctx))
  (define prev-rush-fighting-wids (l2-ctx-prev-rush-fighting-wids ctx))
  (define rush-def-st (l2-ctx-rush-def-st ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define workers (l2-ctx-workers ctx))
  (when (and (or worker-rush-active? (not (null? prev-rush-fighting-wids)))
             (not (null? non-builder-defense-workers)))
    (define ready-townhall-coords
      (let ([pts (for/list ([b (in-list ally-bldgs)]
                            #:when (and (hash? b)
                                        (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                                        (memq (fast-canonical-structure-sym (unit-type-sym b))
                                              '(hatchery lair hive nexus
                                                command-center orbital-command planetary-fortress))))
                   (cons (exact->inexact (hash-ref b 'x base-x))
                         (exact->inexact (hash-ref b 'y base-y))))])
        (if (null? pts)
            (list (cons (exact->inexact base-x) (exact->inexact base-y)))
            pts)))
    (define (dist-to-owned-townhall x y)
      (for/fold ([best +inf.0]) ([bc (in-list ready-townhall-coords)])
        (min best (dist2d x y (car bc) (cdr bc)))))
    (define base-mineral-patches
      (filter (lambda (mp)
                (and (hash? mp)
                     (<= (dist-to-owned-townhall
                          (hash-ref mp 'x base-x)
                          (hash-ref mp 'y base-y))
                         14.0)))
              (let ([mps (hash-ref obs 'mineral-patches '())])
                (if (list? mps) mps '()))))
    (define (dist-to-mineral-line x y)
      (if (null? base-mineral-patches)
          +inf.0
          (for/fold ([best +inf.0]) ([mp (in-list base-mineral-patches)])
            (min best (dist2d x y (hash-ref mp 'x base-x) (hash-ref mp 'y base-y))))))

    (define ew-cnt (max 1 (length enemy-rush-workers)))
    (define ew-cx
      (if (null? enemy-rush-workers)
          (exact->inexact enemy-x)
          (/ (for/sum ([ew (in-list enemy-rush-workers)]) (exact->inexact (hash-ref ew 'x base-x)))
             ew-cnt)))
    (define ew-cy
      (if (null? enemy-rush-workers)
          (exact->inexact enemy-y)
          (/ (for/sum ([ew (in-list enemy-rush-workers)]) (exact->inexact (hash-ref ew 'y base-y)))
             ew-cnt)))
    (define far-mp
      (and (not (null? base-mineral-patches))
           (argmax (lambda (mp)
                     (dist2d ew-cx ew-cy
                             (hash-ref mp 'x base-x)
                             (hash-ref mp 'y base-y)))
                   base-mineral-patches)))
    (define fallback-dx (- base-x ew-cx))
    (define fallback-dy (- base-y ew-cy))
    (define fallback-d (max 1.0 (sqrt (+ (* fallback-dx fallback-dx) (* fallback-dy fallback-dy)))))
    (define far-px
      (if far-mp
          (safe-coord (hash-ref far-mp 'x base-x) base-x)
          (safe-coord (+ base-x (* 4.0 (/ fallback-dx fallback-d))) base-x)))
    (define far-py
      (if far-mp
          (safe-coord (hash-ref far-mp 'y base-y) base-y)
          (safe-coord (+ base-y (* 4.0 (/ fallback-dy fallback-d))) base-y)))
    (define far-patch-id
      (if far-mp
          (safe-nonneg-int (hash-ref far-mp 'id 0) 0)
          (safe-nonneg-int (hash-ref obs 'mineral-patch-id 0) 0)))

    ;; Physical pull trigger: ONLY once rush workers enter <= 9.0 tiles of TownHall (<= 7.0 vs >= 8-worker all-ins
    ;; with 0 combat units so workers NEVER conga-line single-file out to an 8.8-tile ramp Pylon!),
    ;; <= 6.5 tiles of mineral line, or <= 4.5 tiles of an in-main friendly structure.
    (define heavy-worker-allin-no-army?
      (and (>= (length enemy-rush-workers) 8)
           (null? ally-combat-units)))
    (define rush-th-pull-rad (if heavy-worker-allin-no-army? 7.0 9.0))
    (define rush-bldg-th-rad (if heavy-worker-allin-no-army? 6.8 9.5))
    (define rush-chase-leash-rad (if heavy-worker-allin-no-army? 8.5 10.5))
    (define primary-engage-enemies
      (if worker-rush-active?
          (filter (lambda (ew)
                    (define ex (hash-ref ew 'x 9999.0))
                    (define ey (hash-ref ew 'y 9999.0))
                    (and (<= (dist-to-owned-townhall ex ey) rush-chase-leash-rad)
                         (or (<= (dist-to-owned-townhall ex ey) rush-th-pull-rad)
                             (<= (dist-to-mineral-line ex ey) 6.5)
                             (ormap (lambda (b)
                                      (and (hash? b)
                                           (<= (dist-to-owned-townhall
                                                (hash-ref b 'x base-x)
                                                (hash-ref b 'y base-y))
                                               rush-bldg-th-rad)
                                           (<= (dist2d ex ey
                                                       (hash-ref b 'x base-x)
                                                       (hash-ref b 'y base-y))
                                               4.5)))
                                    ally-bldgs))))
                  enemy-rush-workers)
          '()))
    (unless (null? primary-engage-enemies)
      (hash-set! rush-def-st 'last-rush-engage-frame frame))
    (define last-engage-frame (hash-ref rush-def-st 'last-rush-engage-frame -9999))
    ;; 14-frame hysteresis prevents ping-ponging between fighting and mining when enemy workers
    ;; step just outside `rush-th-pull-rad` (7.0 tiles).
    (define in-engage-hysteresis?
      (and worker-rush-active?
           (not (null? prev-rush-fighting-wids))
           (<= (- frame last-engage-frame) 14)))
    (define worker-rush-engage-enemies
      (cond
        [(not (null? primary-engage-enemies)) primary-engage-enemies]
        [in-engage-hysteresis?
         (filter (lambda (ew)
                   (<= (dist-to-owned-townhall
                        (hash-ref ew 'x 9999.0)
                        (hash-ref ew 'y 9999.0))
                       rush-chase-leash-rad))
                 enemy-rush-workers)]
        [else '()]))

    ;; Mixed Probe+Zealot / worker+combat rush detection near main mineral line
    (define enemy-combat-near-main
      (filter (lambda (e)
                (and (not (memq (unit-type-sym e) '(probe scv drone)))
                     (or (combat-unit-record? e)
                         (memq (fast-canonical-unit-sym (unit-type-sym e))
                               '(zealot zergling adept stalker marine reaper hellion hellbat roach marauder)))
                     (let ([ex (hash-ref e 'x 9999.0)]
                           [ey (hash-ref e 'y 9999.0)])
                       (or (<= (dist-to-owned-townhall ex ey) 11.0)
                           (<= (dist-to-mineral-line ex ey) 8.5)))))
              ground-enemy-units-for-cheese))
    (define mixed-worker-combat-rush?
      (and (not (null? enemy-combat-near-main))
           (not (null? enemy-rush-workers))))
    (define safe-evac-mp
      (if (and (not (null? enemy-combat-near-main))
               (not (null? base-mineral-patches)))
          (argmax (lambda (mp)
                    (define mpx (hash-ref mp 'x base-x))
                    (define mpy (hash-ref mp 'y base-y))
                    (for/fold ([best +inf.0]) ([ec (in-list enemy-combat-near-main)])
                      (min best (dist2d mpx mpy (hash-ref ec 'x 9999.0) (hash-ref ec 'y 9999.0)))))
                  base-mineral-patches)
          far-mp))
    (define evac-patch-id
      (if safe-evac-mp
          (safe-nonneg-int (hash-ref safe-evac-mp 'id 0) 0)
          far-patch-id))
    (define evac-px
      (if safe-evac-mp
          (safe-coord (hash-ref safe-evac-mp 'x far-px) far-px)
          far-px))
    (define evac-py
      (if safe-evac-mp
          (safe-coord (hash-ref safe-evac-mp 'y far-py) far-py)
          far-py))

    ;; 1.1s (24-frame) mineral-walk slide + 21-frame post-slide cooldown (`+45` total) for bruised workers,
    ;; with `<= 20` EHP (or Probe `shield <= 2` and `hp < 20`) threshold and immediate `<= 10` HP override.
    (define eff-disengage-hp
      (if worker-rush-active?
          20
          SC2-FIGHTING-WORKER-DISENGAGE-HP))
    (define eff-reengage-hp
      (if (and worker-rush-active? (>= (length enemy-rush-workers) 8))
          6
          SC2-FIGHTING-WORKER-REENGAGE-HP))
    (for ([w (in-list non-builder-defense-workers)])
      (define wid (hash-ref w 'id 10))
      (define whp (unit-total-hp-and-shield w))
      (define wx (hash-ref w 'x base-x))
      (define wy (hash-ref w 'y base-y))
      (define entry (hash-ref rush-def-st wid #f))
      (define prev-dis-until (cond [(pair? entry) (car entry)] [(exact-integer? entry) entry] [else 0]))
      (define prev-cd-until  (cond [(pair? entry) (cdr entry)] [(exact-integer? entry) entry] [else 0]))
      (define enemy-close?
        (ormap (lambda (e)
                 (<= (dist2d wx wy (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 6.0))
               ground-enemy-units-for-cheese))
      (define probe-shield-depleted?
        (and worker-rush-active?
             (eq? (unit-type-sym w) 'probe)
             (<= (hash-ref w 'shield (hash-ref w 'max-shield 20)) 2)
             (< (hash-ref w 'hp 20) 20)))
      (define needs-disengage?
        (or (<= whp eff-disengage-hp)
            probe-shield-depleted?))
      (when (and needs-disengage?
                 enemy-close?
                 (or (>= frame prev-cd-until)
                     (and (<= whp 10)
                          (>= frame prev-dis-until))))
        (set! prev-dis-until (+ frame 24))
        (set! prev-cd-until  (+ frame 45))
        (hash-set! rush-def-st wid (cons prev-dis-until prev-cd-until)))
      (define near-enemy-combat?
        (and mixed-worker-combat-rush?
             (ormap (lambda (ec)
                      (<= (dist2d wx wy (hash-ref ec 'x 9999.0) (hash-ref ec 'y 9999.0)) 3.8))
                    enemy-combat-near-main)))
      (define cornered-at-evac?
        (and (<= (dist2d wx wy evac-px evac-py) 2.0)
             (<= (for/fold ([best +inf.0]) ([ec (in-list enemy-combat-near-main)])
                   (min best (dist2d evac-px evac-py (hash-ref ec 'x 9999.0) (hash-ref ec 'y 9999.0))))
                 3.8)))
      (define disengaging-now?
        (or (< frame prev-dis-until)
            (and near-enemy-combat? (not cornered-at-evac?))))
      (when disengaging-now?
        (set-l2-ctx-cur-rush-disengaging-wids! ctx (cons wid (l2-ctx-cur-rush-disengaging-wids ctx)))
        (if (> evac-patch-id 0)
            (l2-emit! ctx (list 'mineral-walk wid evac-patch-id evac-px evac-py))
            (l2-emit! ctx (list 'mineral-walk wid evac-px evac-py)))))

    (unless (null? worker-rush-engage-enemies)
      (define (dist-to-nearest-engage-enemy wx wy)
        (for/fold ([best +inf.0]) ([ew (in-list worker-rush-engage-enemies)])
          (min best (dist2d wx wy (hash-ref ew 'x ew-cx) (hash-ref ew 'y ew-cy)))))

      ;; Only workers inside `rush-chase-leash-rad` and not disengaging are eligible to fight
      (define healthy-rush-workers
        (filter (lambda (w)
                  (define wid (hash-ref w 'id 10))
                  (define whp (unit-total-hp-and-shield w))
                  (define wx (hash-ref w 'x base-x))
                  (define wy (hash-ref w 'y base-y))
                  (define entry (hash-ref rush-def-st wid #f))
                  (define in-post-slide-window?
                    (and (pair? entry) (>= frame (car entry)) (< frame (cdr entry))))
                  (and (not (memv wid (l2-ctx-cur-rush-disengaging-wids ctx)))
                       (<= (dist-to-owned-townhall wx wy) rush-chase-leash-rad)
                       (cond
                         [in-post-slide-window? (> whp 5)]
                         [(memv wid prev-rush-fighting-wids) (> whp eff-disengage-hp)]
                         [else (>= whp eff-reengage-hp)])))
                non-builder-defense-workers))

      ;; Sort farthest from engaging enemies first so kept miners are ALWAYS the safest far-patch workers
      (define safest-first
        (sort healthy-rush-workers
              >
              #:key (lambda (w)
                      (dist-to-nearest-engage-enemy
                       (hash-ref w 'x base-x)
                       (hash-ref w 'y base-y)))))

      (define unthreatened-miners-cnt
        (count (lambda (w)
                 (> (dist-to-nearest-engage-enemy
                     (hash-ref w 'x base-x)
                     (hash-ref w 'y base-y))
                    4.5))
               safest-first))
      (define enemies-inside-7.5?
        (ormap (lambda (ew)
                 (define ex (hash-ref ew 'x 9999.0))
                 (define ey (hash-ref ew 'y 9999.0))
                 (or (<= (dist-to-owned-townhall ex ey) 7.5)
                     (<= (dist-to-mineral-line ex ey) 7.5)))
               worker-rush-engage-enemies))

      (define total-w-cnt (length workers))
      (define h-cnt (length safest-first))
      (define e-cnt (length worker-rush-engage-enemies))
      (define eff-e-cnt (max e-cnt (length enemy-rush-workers)))
      (define breached-mineral-cnt
        (count (lambda (ew)
                 (<= (dist-to-mineral-line (hash-ref ew 'x 9999.0)
                                           (hash-ref ew 'y 9999.0))
                     5.5))
               worker-rush-engage-enemies))
      (define all-hands-mineral-brawl?
        (and (>= eff-e-cnt 6)
             (or (>= breached-mineral-cnt 3)
                 (ormap (lambda (b)
                          (and (hash? b)
                               (<= (dist-to-owned-townhall (hash-ref b 'x base-x)
                                                           (hash-ref b 'y base-y))
                                   (if heavy-worker-allin-no-army? 7.5 9.5))
                               (let* ([b-hp (hash-ref b 'hp 1500)]
                                      [b-max-hp (hash-ref b 'max-hp b-hp)]
                                      [b-sh (hash-ref b 'shield 0)]
                                      [b-max-sh (hash-ref b 'max-shield b-sh)]
                                      [tot-max (+ b-max-hp b-max-sh)])
                                 (and (> tot-max 0)
                                      (< (+ b-hp b-sh) (* 0.96 tot-max))))))
                        ally-bldgs))))
      (define surplus-miners (max 0 (- h-cnt (+ eff-e-cnt 2))))
      (define keep-mining-cnt
        (min h-cnt
             (cond
               [all-hands-mineral-brawl?
                (cond
                  [(>= h-cnt (+ eff-e-cnt 4)) (max 4 (- h-cnt (+ eff-e-cnt 2)))]
                  [(> h-cnt (+ eff-e-cnt 2)) (min 4 (- h-cnt (+ eff-e-cnt 1)))]
                  [(> h-cnt 4) 1]
                  [else 0])]
               [(and (>= total-w-cnt 8) (>= unthreatened-miners-cnt 3))
                (max 4 surplus-miners)]
               [(and (>= total-w-cnt 7) (>= unthreatened-miners-cnt 3))
                (max 3 surplus-miners)]
               [(and enemies-inside-7.5? (< h-cnt 8))
                (min 2 (max 0 (sub1 h-cnt)))]
               [(>= total-w-cnt 8)
                (max 4 surplus-miners)]
               [(>= total-w-cnt 7)
                (max 3 surplus-miners)]
               [else
                (min 2 surplus-miners)])))

      (define pulled-rush-workers
        (drop safest-first keep-mining-cnt))

      (unless (null? pulled-rush-workers)
        (set-l2-ctx-cur-rush-fighting-wids! ctx
              (map (lambda (w) (hash-ref w 'id 10)) pulled-rush-workers))
        ;; Compute clamped enemy cluster centroid inside our mineral line / main (<= rush-chase-leash-rad)
        (define raw-cl-x
          (/ (for/sum ([ew (in-list worker-rush-engage-enemies)])
               (exact->inexact (hash-ref ew 'x base-x)))
             e-cnt))
        (define raw-cl-y
          (/ (for/sum ([ew (in-list worker-rush-engage-enemies)])
               (exact->inexact (hash-ref ew 'y base-y)))
             e-cnt))
        (define cl-dx (- raw-cl-x (exact->inexact base-x)))
        (define cl-dy (- raw-cl-y (exact->inexact base-y)))
        (define cl-d (sqrt (+ (* cl-dx cl-dx) (* cl-dy cl-dy))))
        (define cl-x
          (safe-coord (if (> cl-d rush-chase-leash-rad) (+ base-x (* rush-chase-leash-rad (/ cl-dx cl-d))) raw-cl-x) base-x))
        (define cl-y
          (safe-coord (if (> cl-d rush-chase-leash-rad) (+ base-y (* rush-chase-leash-rad (/ cl-dy cl-d))) raw-cl-y) base-y))
        (define in-pack-engage-enemies
          (let ([near-pack
                 (filter (lambda (ew)
                           (<= (dist2d cl-x cl-y
                                       (hash-ref ew 'x cl-x)
                                       (hash-ref ew 'y cl-y))
                               3.5))
                         worker-rush-engage-enemies)])
            (if (null? near-pack) worker-rush-engage-enemies near-pack)))
        (define lowest-ehp-enemy
          (argmin (lambda (ew)
                    (+ (* 5.0 (unit-total-hp-and-shield ew))
                       (dist-to-owned-townhall (hash-ref ew 'x cl-x) (hash-ref ew 'y cl-y))))
                  in-pack-engage-enemies))
        (define raw-focus-x
          (if lowest-ehp-enemy
              (safe-coord (hash-ref lowest-ehp-enemy 'x cl-x) cl-x)
              cl-x))
        (define raw-focus-y
          (if lowest-ehp-enemy
              (safe-coord (hash-ref lowest-ehp-enemy 'y cl-y) cl-y)
              cl-y))
        (define fa-dx (- (exact->inexact raw-focus-x) (exact->inexact base-x)))
        (define fa-dy (- (exact->inexact raw-focus-y) (exact->inexact base-y)))
        (define fa-d (sqrt (+ (* fa-dx fa-dx) (* fa-dy fa-dy))))
        (define fa-max-rad (if heavy-worker-allin-no-army? 7.5 10.5))
        (define focus-amove-x
          (safe-coord (if (> fa-d fa-max-rad) (+ base-x (* fa-max-rad (/ fa-dx fa-d))) raw-focus-x) cl-x))
        (define focus-amove-y
          (safe-coord (if (> fa-d fa-max-rad) (+ base-y (* fa-max-rad (/ fa-dy fa-d))) raw-focus-y) cl-y))

        ;; Partition defenders per-worker locally: max 3 normally (and always <= 3 for Pass-2 chasers to avoid
        ;; conga-lining in open space), or up to 8 in Pass-1 melee range when >= 6 enemy workers are mineral-walk
        ;; stacked inside our mineral line (<= 5.0 tiles from mineral patches) so 8 * 5 = 40 one-shots a stacked Probe!
        (define primary-focus-id
          (and lowest-ehp-enemy (hash-ref lowest-ehp-enemy 'id -1)))
        (define (mineral-line-stacked-enemy? ew)
          (define ex (hash-ref ew 'x cl-x))
          (define ey (hash-ref ew 'y cl-y))
          (and (>= e-cnt 6)
               (or (and (or (<= (dist-to-mineral-line ex ey) 5.0)
                            (<= (dist-to-owned-townhall ex ey) 4.8))
                        (>= (count (lambda (other)
                                     (<= (dist2d ex ey
                                                 (hash-ref other 'x cl-x)
                                                 (hash-ref other 'y cl-y))
                                         1.75))
                                   worker-rush-engage-enemies)
                            4))
                   (and live-obs-harvesters?
                        primary-focus-id
                        (equal? (hash-ref ew 'id 0) primary-focus-id)
                        (or (<= (dist-to-mineral-line ex ey) 5.5)
                            (<= (dist-to-owned-townhall ex ey) 4.8))))))
        (define (effective-melee-cap ew)
          (define ehp (max 1.0 (exact->inexact (unit-total-hp-and-shield ew))))
          (define swings-needed (inexact->exact (ceiling (/ ehp 5.0))))
          (define cap (if (mineral-line-stacked-enemy? ew) 8 3))
          (min cap (max 2 swings-needed)))
        (define (effective-chaser-cap ew)
          (min 3 (effective-melee-cap ew)))
        (define assigned-target-counts (make-hasheqv))
        (define worker-assignments (make-hasheqv))
        (define frontline-first
          (sort pulled-rush-workers
                <
                #:key (lambda (w)
                        (dist-to-nearest-engage-enemy
                         (hash-ref w 'x base-x)
                         (hash-ref w 'y base-y)))))

        (define (enemy-worker-safe-from-combat? ew)
          (or (not mixed-worker-combat-rush?)
              (let ([ex (hash-ref ew 'x cl-x)]
                    [ey (hash-ref ew 'y cl-y)])
                (andmap (lambda (ec)
                          (> (dist2d ex ey (hash-ref ec 'x 9999.0) (hash-ref ec 'y 9999.0)) 2.5))
                        enemy-combat-near-main))))
        (define safe-engage-workers
          (let ([safe (filter enemy-worker-safe-from-combat? worker-rush-engage-enemies)])
            (if (null? safe) worker-rush-engage-enemies safe)))
        (define (non-retreating-engage-worker? ew)
          (define ex (hash-ref ew 'x cl-x))
          (define ey (hash-ref ew 'y cl-y))
          (or (<= (dist-to-owned-townhall ex ey) rush-th-pull-rad)
              (<= (dist-to-mineral-line ex ey) 6.5)
              (ormap (lambda (b)
                       (and (hash? b)
                            (<= (dist-to-owned-townhall
                                 (hash-ref b 'x base-x)
                                 (hash-ref b 'y base-y))
                                rush-bldg-th-rad)
                            (<= (dist2d ex ey
                                        (hash-ref b 'x base-x)
                                        (hash-ref b 'y base-y))
                                4.5)))
                     ally-bldgs)))

        ;; Pass 1: Immediate melee swing (<= 2.5 tiles normally, <= 3.2 tiles on primary mineral-line focus target in live games), lowest (hp + shield)
        (for ([w (in-list frontline-first)])
          (define wid (hash-ref w 'id 10))
          (define wx (hash-ref w 'x base-x))
          (define wy (hash-ref w 'y base-y))
          (define melee-cands
            (filter (lambda (ew)
                      (define eid (hash-ref ew 'id 0))
                      (define reach
                        (if (and live-obs-harvesters?
                                 (>= e-cnt 6)
                                 primary-focus-id
                                 (equal? eid primary-focus-id)
                                 (<= (dist-to-mineral-line (hash-ref ew 'x cl-x) (hash-ref ew 'y cl-y)) 5.5))
                            3.2
                            2.5))
                      (and (> eid 0)
                           (< (hash-ref assigned-target-counts eid 0) (effective-melee-cap ew))
                           (<= (dist2d wx wy (hash-ref ew 'x cl-x) (hash-ref ew 'y cl-y)) reach)))
                    safe-engage-workers))
          (unless (null? melee-cands)
            (define chosen
              (argmin (lambda (ew)
                        (+ (* 100.0 (unit-total-hp-and-shield ew))
                           (dist2d wx wy (hash-ref ew 'x cl-x) (hash-ref ew 'y cl-y))))
                      melee-cands))
            (define cid (hash-ref chosen 'id 0))
            (hash-update! assigned-target-counts cid add1 0)
            (hash-set! worker-assignments wid
                       (list cid
                             (safe-coord (hash-ref chosen 'x cl-x) cl-x)
                             (safe-coord (hash-ref chosen 'y cl-y) cl-y)))))

        ;; Pass 2: Targeted focus-fire within 4.5-6.0 tiles (7.0 for < 6 workers) onto the lowest (hp + shield)
        ;; non-retreating enemy worker (capped at `effective-chaser-cap`), avoiding blind Attack-Move spread
        ;; and avoiding pulling Probes into enemy Zealots during mixed rushes.
        (define pass2-reach (if (>= e-cnt 6) 6.0 7.0))
        (for ([w (in-list frontline-first)]
              #:unless (hash-has-key? worker-assignments (hash-ref w 'id 10)))
          (define wid (hash-ref w 'id 10))
          (define wx (hash-ref w 'x base-x))
          (define wy (hash-ref w 'y base-y))
          (define raw-local-cands
            (filter (lambda (ew)
                      (define eid (hash-ref ew 'id 0))
                      (and (> eid 0)
                           (< (hash-ref assigned-target-counts eid 0) (effective-chaser-cap ew))
                           (<= (dist2d wx wy (hash-ref ew 'x cl-x) (hash-ref ew 'y cl-y)) pass2-reach)))
                    safe-engage-workers))
          (define local-cands
            (let ([non-ret (filter non-retreating-engage-worker? raw-local-cands)])
              (if (null? non-ret) raw-local-cands non-ret)))
          (cond
            [(not (null? local-cands))
             (define chosen
               (argmin (lambda (ew)
                         (+ (* 5.0 (unit-total-hp-and-shield ew))
                            (* 2.5 (dist2d wx wy (hash-ref ew 'x cl-x) (hash-ref ew 'y cl-y)))))
                       local-cands))
             (define cid (hash-ref chosen 'id 0))
             (hash-update! assigned-target-counts cid add1 0)
             (hash-set! worker-assignments wid
                        (list cid
                              (safe-coord (hash-ref chosen 'x cl-x) cl-x)
                              (safe-coord (hash-ref chosen 'y cl-y) cl-y)))]
            [mixed-worker-combat-rush?
             (define safe-fallback
               (let ([cand (findf (lambda (ew)
                                    (and (> (hash-ref ew 'id 0) 0)
                                         (enemy-worker-safe-from-combat? ew)))
                                  safe-engage-workers)])
                 cand))
             (when safe-fallback
               (hash-set! worker-assignments wid
                          (list (hash-ref safe-fallback 'id 0)
                                (safe-coord (hash-ref safe-fallback 'x cl-x) cl-x)
                                (safe-coord (hash-ref safe-fallback 'y cl-y) cl-y))))]
            [else
             (hash-set! worker-assignments wid (list 0 focus-amove-x focus-amove-y))]))

        ;; Emit grouped pull-workers-attack commands (unit-targeted groups + Attack-Move group)
        (define target-order '())
        (define target-groups (make-hasheqv))
        (define target-coords (make-hasheqv))
        (for ([w (in-list frontline-first)])
          (define wid (hash-ref w 'id 10))
          (define asgn (hash-ref worker-assignments wid #f))
          (when asgn
            (match-define (list tid tx ty) asgn)
            (unless (hash-has-key? target-groups tid)
              (set! target-order (cons tid target-order))
              (hash-set! target-coords tid (cons tx ty)))
            (hash-set! target-groups tid (cons wid (hash-ref target-groups tid '())))))
        (set-l2-ctx-worker-pull-emitted-1ab?! ctx #t)
        (for ([tid (in-list (reverse target-order))])
          (define wids (reverse (hash-ref target-groups tid '())))
          (define tc (hash-ref target-coords tid (cons focus-amove-x focus-amove-y)))
          (unless (null? wids)
            (l2-emit! ctx (list 'pull-workers-attack wids tid (car tc) (cdr tc)))))
        (define all-pulled-wids
          (filter positive? (map (lambda (w) (hash-ref w 'id 0)) frontline-first)))
        (define stacked-enemy-workers-near-th-or-min?
          (and (>= e-cnt 6)
               (ormap mineral-line-stacked-enemy? worker-rush-engage-enemies)))
        (when (and stacked-enemy-workers-near-th-or-min?
                   (not (null? all-pulled-wids))
                   (not (null? base-mineral-patches)))
          (define th-coord
            (argmin (lambda (bc) (dist2d cl-x cl-y (car bc) (cdr bc)))
                    ready-townhall-coords))
          (define drill-patch
            (placement:select-worker-drill-stack-mineral-patch
             cl-x cl-y (car th-coord) (cdr th-coord) base-mineral-patches))
          (define drill-patch-id
            (and (hash? drill-patch) (safe-nonneg-int (hash-ref drill-patch 'id 0) 0)))
          (when (and (exact-integer? drill-patch-id) (> drill-patch-id 0))
            (l2-emit! ctx (list 'worker-drill-stack-attack
                         all-pulled-wids
                         drill-patch-id
                         (if (and (exact-integer? primary-focus-id) (>= primary-focus-id 0))
                             primary-focus-id
                             0)
                         focus-amove-x
                         focus-amove-y))))))

    ;; During the 14-frame hysteresis window, keep previously-pulled defenders (within leash and not disengaging)
    ;; from immediately snapping back to mining if enemy workers momentarily kite outside `rush-chase-leash-rad`.
    (when (and (null? worker-rush-engage-enemies)
               in-engage-hysteresis?)
      (set-l2-ctx-cur-rush-fighting-wids! ctx
            (for/list ([w (in-list non-builder-defense-workers)]
                       #:when (let ([wid (hash-ref w 'id 10)])
                                (and (memv wid prev-rush-fighting-wids)
                                     (not (memv wid (l2-ctx-cur-rush-disengaging-wids ctx)))
                                     (<= (dist-to-owned-townhall
                                          (hash-ref w 'x base-x)
                                          (hash-ref w 'y base-y))
                                         rush-chase-leash-rad))))
              (hash-ref w 'id 10))))

    ;; Snap back to mining any previously-pulled worker (or worker outside `rush-chase-leash-rad`)
    ;; once hysteresis expires or that worker is assigned to keep mining!
    (for ([w (in-list non-builder-defense-workers)])
      (define wid (hash-ref w 'id 10))
      (define wx (hash-ref w 'x base-x))
      (define wy (hash-ref w 'y base-y))
      (when (and (not (memv wid (l2-ctx-cur-rush-fighting-wids ctx)))
                 (not (memv wid (l2-ctx-cur-rush-disengaging-wids ctx)))
                 (or (memv wid prev-rush-fighting-wids)
                     (and worker-rush-active?
                          (> (dist-to-owned-townhall wx wy) rush-chase-leash-rad))))
        (if (> far-patch-id 0)
            (l2-emit! ctx (list 'harvest-mineral wid far-patch-id))
            (l2-emit! ctx (list 'mineral-walk wid far-px far-py)))))))

(define (l2-phase3-recall-cancel-scout! ctx)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-supply-early (l2-ctx-ally-combat-supply-early ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define cheese-dist-thresh (l2-ctx-cheese-dist-thresh ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-rush-workers (l2-ctx-enemy-rush-workers ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define ground-enemy-units-for-cheese (l2-ctx-ground-enemy-units-for-cheese ctx))
  (define in-base-proxy-completed-cannon? (l2-ctx-in-base-proxy-completed-cannon? ctx))
  (define in-base-proxy-completed-cannons (l2-ctx-in-base-proxy-completed-cannons ctx))
  (define in-base-proxy-detected? (l2-ctx-in-base-proxy-detected? ctx))
  (define in-base-proxy-structures (l2-ctx-in-base-proxy-structures ctx))
  (define leases (l2-ctx-leases ctx))
  (define live-obs-harvesters? (l2-ctx-live-obs-harvesters? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define non-builder-defense-workers (l2-ctx-non-builder-defense-workers ctx))
  (define obs (l2-ctx-obs ctx))
  (define oledger-early (l2-ctx-oledger-early ctx))
  (define owned-base-coords (l2-ctx-owned-base-coords ctx))
  (define proxy-or-cheese-enemies (l2-ctx-proxy-or-cheese-enemies ctx))
  (define race (l2-ctx-race ctx))
  (define raw-obs (l2-ctx-raw-obs ctx))
  (define rt (l2-ctx-rt ctx))
  (define rush-def-st (l2-ctx-rush-def-st ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define workers (l2-ctx-workers ctx))
  (when (and in-base-proxy-detected?
             (not worker-rush-active?)
             (not (null? non-builder-defense-workers)))
    (define completed-powered-cannons (length in-base-proxy-completed-cannons))
    ;; Disengage critically wounded proxy-fighting workers (<= 12 HP) every step
    (define base-mps
      (filter (lambda (mp)
                (and (hash? mp)
                     (<= (dist2d base-x base-y (hash-ref mp 'x base-x) (hash-ref mp 'y base-y)) 14.0)))
              (let ([mps (hash-ref obs 'mineral-patches '())])
                (if (list? mps) mps '()))))
    (define safe-mp (and (not (null? base-mps)) (car base-mps)))
    (for ([w (in-list non-builder-defense-workers)])
      (define wid (hash-ref w 'id 10))
      (define whp (unit-total-hp-and-shield w))
      (when (and (<= whp SC2-FIGHTING-WORKER-DISENGAGE-HP)
                 (ormap (lambda (e)
                          (<= (dist2d (hash-ref w 'x base-x) (hash-ref w 'y base-y)
                                      (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0))
                              7.5))
                        (append ground-enemy-units-for-cheese in-base-proxy-structures)))
        (if safe-mp
            (l2-emit! ctx (list 'mineral-walk wid
                         (safe-nonneg-int (hash-ref safe-mp 'id 0) 0)
                         (safe-coord (hash-ref safe-mp 'x base-x) base-x)
                         (safe-coord (hash-ref safe-mp 'y base-y) base-y)))
            (l2-emit! ctx (list 'mineral-walk wid base-x base-y)))))
    ;; Once >= 1 completed powered Photon Cannon exists, stop pulling SCVs onto proxy pylons/cannons
    ;; (and never pull into 8.5-tile cannon range); switch to Bunker + Tank breakout instead (`#89` [UNCOVERED-T2]).
    (define pullable-proxy-structures
      (if (> completed-powered-cannons 0)
          '()
          in-base-proxy-structures))
    (when (and (= completed-powered-cannons 0)
               (not (null? pullable-proxy-structures)))
      (define healthy-proxy-workers
        (filter (lambda (w) (> (unit-total-hp-and-shield w) SC2-FIGHTING-WORKER-DISENGAGE-HP))
                non-builder-defense-workers))
      ;; Keep at least 4 workers mining so economy never hits 0 income while clearing proxy!
      (define surplus-cnt (max 0 (- (length healthy-proxy-workers) 4)))
      (when (> surplus-cnt 0)
        (define sorted-proxies
          (sort pullable-proxy-structures
                <
                #:key (lambda (eb)
                        (define canon (fast-canonical-structure-sym (unit-type-sym eb)))
                        (define prog (hash-ref eb 'build-progress 1.0))
                        (define prio-rank
                          (cond
                            [(eq? canon 'pylon) 0.0]
                            [(and (memq canon '(photon-cannon bunker spine-crawler))
                                  (< prog SC2-BUILD-COMPLETE-PROGRESS))
                             100.0]
                            [(memq canon '(forge barracks gateway shield-battery)) 200.0]
                            [else 300.0]))
                        (+ prio-rank
                           (* 0.1 (hash-ref eb 'hp 200))
                           (dist2d base-x base-y
                                   (hash-ref eb 'x base-x)
                                   (hash-ref eb 'y base-y))))))
        ;; Pick workers closest to the primary proxy structure
        (define p0 (car sorted-proxies))
        (define p0x (hash-ref p0 'x base-x))
        (define p0y (hash-ref p0 'y base-y))
        (define pull-pool
          (take (sort healthy-proxy-workers
                      <
                      #:key (lambda (w)
                              (dist2d p0x p0y (hash-ref w 'x base-x) (hash-ref w 'y base-y))))
                surplus-cnt))
        (let assign-loop ([rem-workers pull-pool]
                          [rem-proxies sorted-proxies])
          (cond
            [(or (null? rem-workers) (null? rem-proxies))
             ;; Any leftover surplus worker chases visible enemy proxy builder Probe/SCV
             (define proxy-builder
               (findf (lambda (e)
                        (and (memq (unit-type-sym e) '(probe scv drone))
                             (or (<= (dist2d base-x base-y (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0))
                                     SC2-IN-BASE-PROXY-DETECT-RADIUS)
                                 (<= (dist2d nat-x nat-y (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0))
                                     SC2-IN-BASE-PROXY-DETECT-RADIUS))))
                      ground-enemy-units-for-cheese))
             (when (and proxy-builder (not (null? rem-workers)))
               (define hunter-wids
                 (map (lambda (w) (hash-ref w 'id 10))
                      (take rem-workers (min 2 (length rem-workers)))))
               (set-l2-ctx-worker-pull-emitted-1ab?! ctx #t)
               (l2-emit! ctx (list 'pull-workers-attack
                            hunter-wids
                            (hash-ref proxy-builder 'id 0)
                            (safe-coord (hash-ref proxy-builder 'x p0x) base-x)
                            (safe-coord (hash-ref proxy-builder 'y p0y) base-y))))]
            [else
             (define eb (car rem-proxies))
             (define take-n (min 4 (length rem-workers)))
             (define assigned (take rem-workers take-n))
             (define assigned-ids (map (lambda (w) (hash-ref w 'id 10)) assigned))
             (set-l2-ctx-worker-pull-emitted-1ab?! ctx #t)
             (l2-emit! ctx (list 'pull-workers-attack
                          assigned-ids
                          (hash-ref eb 'id 0)
                          (safe-coord (hash-ref eb 'x base-x) base-x)
                          (safe-coord (hash-ref eb 'y base-y) base-y)))
             (assign-loop (drop rem-workers take-n) (cdr rem-proxies))])))))
  (when (and under-early-cheese?
             (not in-base-proxy-completed-cannon?)
             (not (null? workers))
             (or (not live-obs-harvesters?)
                 (and (not worker-rush-active?)
                      (not in-base-proxy-detected?)
                      (< frame 2500)
                      (<= (length ally-combat-units) 2)
                      (refractory-allow-action?! cd-tracker 'early-cheese-worker-pull frame 112))))
    (define healthy-workers
      (filter (lambda (w)
                (and (or (not live-obs-harvesters?)
                         (and (not (worker-has-engine-build-order? w))
                              (not (order-ledger-unit-has-active-build? oledger-early (hash-ref w 'id 0) w))))
                     (>= (hash-ref w 'hp SC2-DRONE-MAX-HP) SC2-HEALTHY-WORKER-PULL-MIN-HP)))
              workers))
    (define pull-ids
      (map (lambda (w) (hash-ref w 'id 10))
           (take healthy-workers (min SC2-MAX-WORKER-PULL-COUNT (length healthy-workers)))))
    (define fallback-threats
      (cond
        [(not (null? proxy-or-cheese-enemies)) proxy-or-cheese-enemies]
        [(not (null? enemy-rush-workers)) enemy-rush-workers]
        [else in-base-proxy-structures]))
    (when (not (null? fallback-threats))
      (define fallback-worker-threats
        (filter (lambda (e) (memq (unit-type-sym e) '(probe scv drone))) fallback-threats))
      (define threat
        (if (not (null? fallback-worker-threats))
            (car fallback-worker-threats)
            (car fallback-threats)))
      (define threat-is-combat-unit?
        (and (combat-unit-record? threat)
             (not (memq (unit-type-sym threat) '(probe scv drone)))))
      (define skip-suicidal-combat-pull?
        (and threat-is-combat-unit?
             (or (not (null? ally-combat-units))
                 (and live-obs-harvesters?
                      (eq? (fast-canonical-unit-sym (unit-type-sym threat)) 'zealot)))))
      (define tx (hash-ref threat 'x (safe-coord (+ base-x 5.0))))
      (define ty (hash-ref threat 'y (safe-coord (+ base-y 5.0))))
      (define drill-patch-id (hash-ref obs 'mineral-patch-id SC2-SYNTHETIC-MINERAL-PATCH-ID))
      (unless (or (null? pull-ids) skip-suicidal-combat-pull?)
        (unless (l2-ctx-worker-pull-emitted-1ab? ctx)
          (if live-obs-harvesters?
              (l2-emit! ctx (list 'pull-workers-attack pull-ids (hash-ref threat 'id 0) tx ty))
              (l2-emit! ctx (list 'pull-workers-attack pull-ids tx ty))))
        (l2-emit! ctx (list 'worker-drill-stack-attack
                     pull-ids
                     drill-patch-id
                     (hash-ref threat 'id 0)
                     (exact-round tx)
                     (exact-round ty))))
      ;; Harass enemy proxy builder if present
      (define enemy-builder
        (findf (lambda (e)
                 (and (memq (unit-type-sym e) '(probe scv drone))
                      (<= (dist2d base-x base-y (hash-ref e 'x 9999) (hash-ref e 'y 9999)) cheese-dist-thresh)))
               ground-enemy-units-for-cheese))
      (when (and enemy-builder (not (null? healthy-workers)))
        (l2-emit! ctx (list 'worker-harass
                     (hash-ref (car healthy-workers) 'id 10)
                     (hash-ref enemy-builder 'x tx)
                     (hash-ref enemy-builder 'y ty))))))
  (define stasis-threats
    (let ()
      (define (near-worker-or-base? e)
        (and (memq (unit-type-sym e) '(oracle-stasis-trap stasis-ward))
             (let ([ex (hash-ref e 'x 9999)]
                   [ey (hash-ref e 'y 9999)])
               (or (<= (dist2d base-x base-y ex ey) 7.5)
                   (ormap (lambda (w)
                            (<= (dist2d (hash-ref w 'x base-x) (hash-ref w 'y base-y) ex ey) 7.5))
                          workers)))))
      (define acc-units
        (for/fold ([acc '()]) ([e (in-list enemy-units)])
          (if (near-worker-or-base? e) (cons e acc) acc)))
      (define acc-all
        (for/fold ([acc acc-units]) ([e (in-list enemy-bldgs)])
          (if (near-worker-or-base? e) (cons e acc) acc)))
      (if (null? acc-all) '() (reverse acc-all))))
  (when (and (not (null? stasis-threats)) (not (null? workers)))
    (define st (car stasis-threats))
    (define stx (hash-ref st 'x base-x))
    (define sty (hash-ref st 'y base-y))
    (define evac-workers
      (filter (lambda (w)
                (<= (dist2d stx sty (hash-ref w 'x base-x) (hash-ref w 'y base-y)) 6.5))
              workers))
    (when (not (null? evac-workers))
      (define ref-x (if (> (dist2d stx sty base-x base-y) 1.0) base-x nat-x))
      (define ref-y (if (> (dist2d stx sty base-x base-y) 1.0) base-y nat-y))
      (define dx (- ref-x stx))
      (define dy (- ref-y sty))
      (define d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
      (define safe-x (safe-coord (+ stx (* 8.5 (/ dx d))) base-x))
      (define safe-y (safe-coord (+ sty (* 8.5 (/ dy d))) base-y))
      (define evac-ids (map (lambda (w) (hash-ref w 'id 10)) evac-workers))
      (l2-emit! ctx (list 'evacuate-workers-from-stasis-ward evac-ids safe-x safe-y))
      (for ([wid (in-list evac-ids)])
        (l2-emit! ctx (list 'mineral-walk wid safe-x safe-y)))))
  (when (and live-obs-harvesters?
             (not worker-rush-active?)
             (not in-base-proxy-detected?)
             (not (null? non-builder-defense-workers)))
    (define harasser-syms
      '(oracle reaper hellion hellbat mutalisk banshee adept dark-templar void-ray zergling zealot))
    (define (harasser-is-flying? e)
      (or (eq? (hash-ref e 'flying? #f) #t)
          (memq (fast-canonical-unit-sym (unit-type-sym e))
                '(oracle mutalisk banshee void-ray))))
    (define (harass-defender-matches? u h-flying?)
      (define raw-sym (unit-type-sym u))
      (define canon (sc2-canonical-structure-sym (sc2-canonical-unit-sym raw-sym)))
      (and (or (combat-unit-record? u)
               (memq canon '(queen photon-cannon spore-crawler missile-turret bunker spine-crawler planetary-fortress)))
           (or (not h-flying?)
               (memq canon '(photon-cannon spore-crawler missile-turret bunker queen))
               (sc2-unit-can-attack-air? canon))))
    (define (within-dist2? x1 y1 x2 y2 r2 r)
      (if (and (real? x1) (= (- x1 x1) 0)
               (real? y1) (= (- y1 y1) 0)
               (real? x2) (= (- x2 x2) 0)
               (real? y2) (= (- y2 y2) 0))
          (let ([dx (- (exact->inexact x1) (exact->inexact x2))]
                [dy (- (exact->inexact y1) (exact->inexact y2))])
            (<= (+ (* dx dx) (* dy dy)) r2))
          (<= (dist2d x1 y1 x2 y2) r)))
    (define-values (w-min-x w-max-x w-min-y w-max-y worker-pts)
      (for/fold ([mnx +inf.0] [mxx -inf.0] [mny +inf.0] [mxy -inf.0] [pts '()])
                ([w (in-list non-builder-defense-workers)])
        (define wx (exact->inexact (hash-ref w 'x base-x)))
        (define wy (exact->inexact (hash-ref w 'y base-y)))
        (values (min mnx wx) (max mxx wx) (min mny wy) (max mxy wy)
                (cons (cons wx wy) pts))))
    (define wb-min-x (- w-min-x 7.0))
    (define wb-max-x (+ w-max-x 7.0))
    (define wb-min-y (- w-min-y 7.0))
    (define wb-max-y (+ w-max-y 7.0))
    (define raw-harassers
      (for/list ([e (in-list enemy-units)]
                 #:when (and (hash? e)
                             (memq (fast-canonical-unit-sym (unit-type-sym e)) harasser-syms)
                             (not (eq? (hash-ref e 'is-hallucination #f) #t))
                             (not (eq? (hash-ref e 'hallucination #f) #t))
                             (not (eq? (hash-ref e 'hallucination? #f) #t))
                             (not (eq? (hash-ref e 'changeling? #f) #t))
                             (let ([ex (hash-ref e 'x 9999.0)]
                                   [ey (hash-ref e 'y 9999.0)])
                               (or (for/or ([bc (in-list owned-base-coords)])
                                     (within-dist2? (car bc) (cdr bc) ex ey 90.25 9.5))
                                   (and (>= ex wb-min-x) (<= ex wb-max-x)
                                        (>= ey wb-min-y) (<= ey wb-max-y)
                                        (for/or ([wpt (in-list worker-pts)])
                                          (within-dist2? (car wpt) (cdr wpt) ex ey 49.0 7.0)))))))
        e))
    (define undefended-harassers
      (if (null? raw-harassers)
          '()
          (let ([evac-defender-pool
                 (append ally-units
                         (filter (lambda (b)
                                   (and (hash? b)
                                        (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                                        (let ([canon (fast-canonical-structure-sym (unit-type-sym b))])
                                          (and (memq canon '(photon-cannon spore-crawler missile-turret bunker spine-crawler planetary-fortress))
                                               (or (not (eq? race 'Protoss))
                                                   (not (sc2-structure-requires-pylon-power? canon))
                                                   (not (eq? (hash-ref b 'powered? #t) #f)))))))
                                 ally-bldgs))])
            (filter (lambda (h)
                      (define hx (hash-ref h 'x 9999.0))
                      (define hy (hash-ref h 'y 9999.0))
                      (define h-flying? (harasser-is-flying? h))
                      (< (count (lambda (d)
                                  (and (harass-defender-matches? d h-flying?)
                                       (within-dist2? (hash-ref d 'x -9999.0) (hash-ref d 'y -9999.0) hx hy 72.25 8.5)))
                                evac-defender-pool)
                         2))
                    raw-harassers))))
    (define owned-mineral-patches
      (if (null? undefended-harassers)
          '()
          (filter (lambda (mp)
                    (and (hash? mp)
                         (let ([mpx (hash-ref mp 'x -9999.0)]
                               [mpy (hash-ref mp 'y -9999.0)])
                           (ormap (lambda (bc) (<= (dist2d (car bc) (cdr bc) mpx mpy) 14.0))
                                  owned-base-coords))))
                  (let ([mps (hash-ref obs 'mineral-patches '())])
                    (if (list? mps) mps '())))))
    (define safe-harass-mps
      (if (null? undefended-harassers)
          '()
          (filter (lambda (mp)
                    (define mpx (hash-ref mp 'x -9999.0))
                    (define mpy (hash-ref mp 'y -9999.0))
                    (andmap (lambda (h)
                              (>= (dist2d mpx mpy (hash-ref h 'x 9999.0) (hash-ref h 'y 9999.0)) 14.0))
                            undefended-harassers))
                  owned-mineral-patches)))
    (define h-cx
      (if (null? undefended-harassers)
          enemy-x
          (/ (for/sum ([h (in-list undefended-harassers)])
               (exact->inexact (hash-ref h 'x base-x)))
             (length undefended-harassers))))
    (define h-cy
      (if (null? undefended-harassers)
          enemy-y
          (/ (for/sum ([h (in-list undefended-harassers)])
               (exact->inexact (hash-ref h 'y base-y)))
             (length undefended-harassers))))
    (define best-safe-mp
      (and (not (null? safe-harass-mps))
           (argmax (lambda (mp)
                     (dist2d h-cx h-cy (hash-ref mp 'x base-x) (hash-ref mp 'y base-y)))
                   safe-harass-mps)))
    (define max-harass-evac-until (hash-ref rush-def-st 'max-harass-evac-until 0))
    (when (or (pair? undefended-harassers)
              (< frame max-harass-evac-until))
      (define harass-evac-ht
        (let ([h (hash-ref rush-def-st 'harass-evac-by-wid #f)])
          (and (hash? h) h)))
      (for ([w (in-list non-builder-defense-workers)])
        (define wid (hash-ref w 'id 10))
        (unless (memv wid (l2-ctx-cur-rush-disengaging-wids ctx))
          (define wx (hash-ref w 'x base-x))
          (define wy (hash-ref w 'y base-y))
          (define prev-evac-until (if harass-evac-ht (hash-ref harass-evac-ht wid 0) 0))
          (define near-harasser
            (and (pair? undefended-harassers)
                 (let ([cand (argmin (lambda (h) (dist2d wx wy (hash-ref h 'x 9999.0) (hash-ref h 'y 9999.0)))
                                     undefended-harassers)])
                   (and (<= (dist2d wx wy (hash-ref cand 'x 9999.0) (hash-ref cand 'y 9999.0)) 7.0)
                        cand))))
          (define threatened? (not (not near-harasser)))
          (define evac-until
            (cond
              [(and threatened?
                    (refractory-allow-action?! cd-tracker (list 'harass-evac wid) frame 24))
               (define new-until (+ frame 24))
               (unless harass-evac-ht
                 (set! harass-evac-ht (make-hasheqv))
                 (hash-set! rush-def-st 'harass-evac-by-wid harass-evac-ht))
               (hash-set! harass-evac-ht wid new-until)
               (when (> new-until max-harass-evac-until)
                 (set! max-harass-evac-until new-until)
                 (hash-set! rush-def-st 'max-harass-evac-until new-until))
               (cond
                 [best-safe-mp
                  (l2-emit! ctx (list 'mineral-walk
                               wid
                               (safe-nonneg-int (hash-ref best-safe-mp 'id 0) 0)
                               (safe-coord (hash-ref best-safe-mp 'x base-x) base-x)
                               (safe-coord (hash-ref best-safe-mp 'y base-y) base-y)))]
                 [else
                  (define hx (hash-ref near-harasser 'x base-x))
                  (define hy (hash-ref near-harasser 'y base-y))
                  (define raw-dx (- (exact->inexact wx) (exact->inexact hx)))
                  (define raw-dy (- (exact->inexact wy) (exact->inexact hy)))
                  (define raw-d (sqrt (+ (* raw-dx raw-dx) (* raw-dy raw-dy))))
                  (define-values (ux uy)
                    (if (>= raw-d 0.25)
                        (values (/ raw-dx raw-d) (/ raw-dy raw-d))
                        (let* ([bdx (- (exact->inexact base-x) (exact->inexact hx))]
                               [bdy (- (exact->inexact base-y) (exact->inexact hy))]
                               [bd (sqrt (+ (* bdx bdx) (* bdy bdy)))])
                          (if (>= bd 0.25)
                              (values (/ bdx bd) (/ bdy bd))
                              (values 1.0 0.0)))))
                  (define away-x (safe-coord (+ wx (* 9.0 ux)) base-x))
                  (define away-y (safe-coord (+ wy (* 9.0 uy)) base-y))
                  (l2-emit! ctx (list 'mineral-walk wid 0 away-x away-y))])
               new-until]
              [else prev-evac-until]))
          (when (or threatened? (< frame evac-until))
            (define ttl (if (> evac-until frame) (max 1 (- evac-until frame)) 24))
            (acquire-unit-lease! leases wid 'evac frame ttl #:x wx #:y wy))))))
  (define raw-enemy-units-for-drill
    (let ([reu (and (hash? raw-obs) (hash-ref raw-obs 'enemy-units #f))])
      (if (and (list? reu) (for/and ([e (in-list reu)]) (hash? e)))
          reu
          enemy-units)))
  (define owned-base-fxys
    (for/list ([bc (in-list owned-base-coords)])
      (let ([bx (car bc)] [by (cdr bc)])
        (cons (if (flonum? bx) bx (exact->inexact bx))
              (if (flonum? by) by (exact->inexact by))))))
  (define enemy-workers-near-base
    (if (or (null? raw-enemy-units-for-drill) (null? owned-base-fxys))
        '()
        (for/list ([e (in-list raw-enemy-units-for-drill)]
                   #:when (let ([et (unit-type-sym e)])
                            (and (or (eq? et 'drone) (eq? et 'probe) (eq? et 'scv))
                                 (not (eq? (hash-ref e 'is-hallucination #f) #t))
                                 (let* ([rx (hash-ref e 'x 9999.0)]
                                        [ry (hash-ref e 'y 9999.0)]
                                        [ex (if (flonum? rx) rx (exact->inexact rx))]
                                        [ey (if (flonum? ry) ry (exact->inexact ry))])
                                   (for/or ([bc (in-list owned-base-fxys)])
                                     (define dx (fl- (car bc) ex))
                                     (define dy (fl- (cdr bc) ey))
                                     (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 484.0))))))
          e)))
  (define drill-stack-min-count (if live-obs-harvesters? 6 4))
  (define stacked-enemy-workers
    (if (or (< (length enemy-workers-near-base) drill-stack-min-count)
            (and live-obs-harvesters?
                 worker-rush-active?
                 (<= ally-combat-supply-early 0)))
        '()
        (let* ([n (length enemy-workers-near-base)]
               [xs (make-flvector n)]
               [ys (make-flvector n)])
          (for ([o (in-list enemy-workers-near-base)] [i (in-naturals)])
            (flvector-set! xs i (exact->inexact (hash-ref o 'x base-x)))
            (flvector-set! ys i (exact->inexact (hash-ref o 'y base-y))))
          (define anchor-idx
            (for/first ([i (in-range n)]
                        #:when (let ([ex (flvector-ref xs i)]
                                     [ey (flvector-ref ys i)])
                                 (>= (for/sum ([j (in-range n)])
                                       (define dx (fl- ex (flvector-ref xs j)))
                                       (define dy (fl- ey (flvector-ref ys j)))
                                       (if (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 0.2025) 1 0))
                                     drill-stack-min-count)))
              i))
          (if anchor-idx
              (let ([ax (flvector-ref xs anchor-idx)]
                    [ay (flvector-ref ys anchor-idx)])
                (for/list ([o (in-list enemy-workers-near-base)]
                           [ox (in-flvector xs)]
                           [oy (in-flvector ys)]
                           #:when (let ([dx (fl- ax ox)]
                                        [dy (fl- ay oy)])
                                    (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 0.2025)))
                  o))
              '()))))
  (when (>= (length stacked-enemy-workers) drill-stack-min-count)
    (define ew0 (car stacked-enemy-workers))
    (define ewx (hash-ref ew0 'x base-x))
    (define ewy (hash-ref ew0 'y base-y))
    (define anchor-bc
      (argmin (lambda (bc) (dist2d (car bc) (cdr bc) ewx ewy))
              owned-base-coords))
    (define dx (- (car anchor-bc) ewx))
    (define dy (- (cdr anchor-bc) ewy))
    (define d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
    (define perp-x (safe-coord (+ ewx (* 4.0 (- (/ dy d)))) (car anchor-bc)))
    (define perp-y (safe-coord (+ ewy (* 4.0 (/ dx d))) (cdr anchor-bc)))
    (l2-emit! ctx (list 'counter-enemy-worker-drill (length stacked-enemy-workers) perp-x perp-y))
    ;; NEVER emit passive `(move wid perp-x perp-y)` during worker rush or in-base proxy defense!
    (when (and (not worker-rush-active?)
               (not in-base-proxy-detected?))
      (for ([w (in-list workers)]
            #:when (and (not (worker-has-engine-build-order? w))
                        (not (order-ledger-unit-has-active-build? oledger-early (hash-ref w 'id 0) w))
                        (<= (dist2d ewx ewy (hash-ref w 'x base-x) (hash-ref w 'y base-y)) 8.0)))
        (l2-emit! ctx (list 'move (hash-ref w 'id 10) perp-x perp-y)))))
  (define mmstate-pad (live-bot-runtime-mirror-mind rt))
  (define mmstate-rush-post
    (let ([ar (and mmstate-pad (mirror-mind-state-last-action-reading mmstate-pad))]
          [hyp (and mmstate-pad (mirror-mind-state-strategic-hypothesis mmstate-pad))])
      (if (or (and ar (action-lens-reading-proxy-or-rush-detected? ar))
              (memq hyp '(proxy-production-or-all-in rush early-aggression)))
          0.65
          0.12)))
  (set-l2-ctx-mmstate-rush-post! ctx mmstate-rush-post))

(define (l2-phase4-expansion-pads! ctx)
  (define active-bases (l2-ctx-active-bases ctx))
  (define active-worker-count (l2-ctx-active-worker-count ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define early-race-th-sym (l2-ctx-early-race-th-sym ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define expansion-pads (l2-ctx-expansion-pads ctx))
  (define frame (l2-ctx-frame ctx))
  (define in-base-proxy-detected? (l2-ctx-in-base-proxy-detected? ctx))
  (define leases (l2-ctx-leases ctx))
  (define live-obs-harvesters? (l2-ctx-live-obs-harvesters? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define obs (l2-ctx-obs ctx))
  (define oledger-early (l2-ctx-oledger-early ctx))
  (define pending-workers (l2-ctx-pending-workers ctx))
  (define prev-tel-early (l2-ctx-prev-tel-early ctx))
  (define race (l2-ctx-race ctx))
  (define rt (l2-ctx-rt ctx))
  (define step-mineral-patches (l2-ctx-step-mineral-patches ctx))
  (define supply-cap (l2-ctx-supply-cap ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define third-x (l2-ctx-third-x ctx))
  (define third-y (l2-ctx-third-y ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define townhalls (l2-ctx-townhalls ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define unit-types (l2-ctx-unit-types ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define workers (l2-ctx-workers ctx))
  (set-l2-ctx-pad-camped-cache! ctx #f)
  (set-l2-ctx-pad-last-px! ctx #f)
  (set-l2-ctx-pad-last-py! ctx #f)
  (set-l2-ctx-pad-last-r! ctx #f)
  (set-l2-ctx-pad-last-val! ctx 0.0)
  (define nat-block-thresh2
    (let ([r (exact->inexact SC2-NATURAL-BLOCK-RADIUS)]) (* r r)))
  (set-l2-ctx-nat-block-thresh2! ctx nat-block-thresh2)
  (define natural-blocked?
    (or (hash-ref obs 'natural-blocked #f)
        (l2-pad-camped-by-enemy? ctx nat-x nat-y 11.5)
        (and (<= (length townhalls) 1)
             (< frame 2500)
             (l2-any-natural-blocker? ctx))))
  (set-l2-ctx-natural-blocked?! ctx natural-blocked?)
  (define uncamped-pad-cache (make-hasheq))
  (set-l2-ctx-uncamped-pad-cache! ctx uncamped-pad-cache)
  (define early-base-under-attack?
    (or early-survival-crisis?
        (for/or ([b (in-list ally-bldgs)])
          (eq? (hash-ref b 'under-attack #f) #t))
        (let ([fbx (if (real? base-x) (exact->inexact base-x) #f)]
              [fby (if (real? base-y) (exact->inexact base-y) #f)]
              [fnx (if (real? nat-x) (exact->inexact nat-x) #f)]
              [fny (if (real? nat-y) (exact->inexact nat-y) #f)])
          (for/or ([e (in-list enemy-units)])
            (and (combat-unit-record? e)
                 (let ([ex (hash-ref e 'x 9999.0)]
                       [ey (hash-ref e 'y 9999.0)])
                   (if (and (real? ex) (= (- ex ex) 0)
                            (real? ey) (= (- ey ey) 0)
                            fbx fby fnx fny)
                       (let* ([fex (exact->inexact ex)]
                              [fey (exact->inexact ey)]
                              [dx1 (fl- fex fbx)]
                              [dy1 (fl- fey fby)]
                              [d1sq (fl+ (fl* dx1 dx1) (fl* dy1 dy1))])
                         (or (fl<= d1sq 784.0)
                             (and (or (>= active-bases 2) live-obs-harvesters?)
                                  (let* ([dx2 (fl- fex fnx)]
                                         [dy2 (fl- fey fny)]
                                         [d2sq (fl+ (fl* dx2 dx2) (fl* dy2 dy2))])
                                    (or (and (>= active-bases 2) (fl<= d2sq 784.0))
                                        (and live-obs-harvesters? (fl<= d2sq 256.0)))))))
                       (or (<= (min (dist2d base-x base-y ex ey)
                                    (if (>= active-bases 2)
                                        (dist2d nat-x nat-y ex ey)
                                        +inf.0))
                               28.0)
                           (and live-obs-harvesters?
                                (<= (dist2d nat-x nat-y ex ey) 16.0))))))))))
  (define blocked-nat-expanded-early? #f)
  (set-l2-ctx-blocked-nat-expanded-early?! ctx blocked-nat-expanded-early?)
  (when (and natural-blocked?
             (not early-survival-crisis?)
             (not early-base-under-attack?)
             (< active-bases SC2-MAX-ACTIVE-BASES)
             (= (order-ledger-pending-count-for-type oledger-early early-race-th-sym frame) 0)
             (or (not (eq? race 'Terran)) (memq 'barracks (l2-ctx-bldg-types ctx)))
             (or (not live-obs-harvesters?)
                 (and (<= active-bases 1)
                      (or (memq 'barracks (l2-ctx-bldg-types ctx))
                          (memq 'spawning-pool (l2-ctx-bldg-types ctx))
                          (memq 'gateway (l2-ctx-bldg-types ctx))
                          (memq 'warp-gate (l2-ctx-bldg-types ctx)))))
             (or (hash-ref obs 'natural-blocked #f)
                 (refractory-allow-action?! cd-tracker (list 'blocked-nat-expand race) frame SC2-EXPANSION-COOLDOWN-FRAMES)))
    (l2-emit! ctx (list 'clear-expansion-block nat-x nat-y))
    (if (eq? race 'Terran)
        (when (>= (l2-ctx-minerals ctx) (sc2-min-cost 'command-center))
          (set! blocked-nat-expanded-early? #t)
          (if live-obs-harvesters?
              (let-values ([(ccx ccy)
                            (order-ledger-resolve-build-coords!
                             oledger-early 'command-center
                             (safe-coord (+ base-x 6.0)) (safe-coord (- base-y 5.0))
                             ally-bldgs frame 2.5
                             #:expansion-pads expansion-pads)])
                (define sx (safe-coord ccx (+ base-x 6.0)))
                (define sy (safe-coord ccy (- base-y 5.0)))
                (l2-emit! ctx (list 'build 'command-center sx sy))
                (order-ledger-record-issued! oledger-early (+ 820000 (modulo frame 10000))
                                             'build 'command-center sx sy frame)
                (set-l2-ctx-bldg-types! ctx (cons 'command-center (l2-ctx-bldg-types ctx))))
              (l2-emit! ctx (list 'build 'command-center (safe-coord (+ base-x 4.0)) base-y)))
          (set-l2-ctx-minerals! ctx (max 0 (- (l2-ctx-minerals ctx) (sc2-min-cost 'command-center)))))
        (when (>= (l2-ctx-minerals ctx) (sc2-race-townhall-min-cost race))
          (define-values (bx3 by3)
            (if live-obs-harvesters?
                (l2-select-uncamped-expansion-pad ctx #f)
                (values third-x third-y)))
          (when (and bx3 by3)
            (set! blocked-nat-expanded-early? #t)
            (l2-emit! ctx (list 'expand bx3 by3))
            (order-ledger-record-issued! oledger-early (+ 830000 (modulo frame 10000))
                                         'expand early-race-th-sym bx3 by3 frame)
            (set-l2-ctx-minerals! ctx (max 0 (- (l2-ctx-minerals ctx) (sc2-race-townhall-min-cost race))))))))
  (define depleting-bases
    (hash-ref obs 'depleting-bases (if (hash-ref obs 'mined-out #f) 1 0)))
  (set-l2-ctx-depleting-bases! ctx depleting-bases)
  (define-values (prod-facilities gas-bldgs)
    (let ([pf-rev '()] [gb-rev '()])
      (for ([b (in-list ally-bldgs)])
        (define cs (fast-canonical-structure-sym (unit-type-sym b)))
        (cond
          [(memq cs '(hatchery lair hive gateway warp-gate warpgate robotics-facility stargate
                      barracks factory starport))
           (set! pf-rev (cons b pf-rev))]
          [(memq cs '(extractor assimilator refinery))
           (set! gb-rev (cons b gb-rev))]))
      (values (reverse pf-rev) (reverse gb-rev))))
  (set-l2-ctx-prod-facilities! ctx prod-facilities)
  (define mmstate (live-bot-runtime-mirror-mind rt))
  (define mstate (live-bot-runtime-mastermind rt))
  (define tech-obs
    (or (mirror-mind-state-last-tech-observation mmstate)
        (infer-enemy-implied-tech-and-upgrades enemy-units enemy-bldgs)))
  (set-l2-ctx-tech-obs! ctx tech-obs)
  (define has-th-harvesters?
    (or (hash-has-key? obs 'mineral-harvesters)
        (hash-has-key? obs 'ideal-mineral-harvesters)
        (for/or ([b (in-list townhalls)]) (and (hash? b) (hash-has-key? b 'assigned-harvesters)))))
  (define live-min-harvesters
    (and has-th-harvesters?
         (hash-ref obs 'mineral-harvesters
                   (lambda ()
                     (for/sum ([b (in-list townhalls)])
                       (if (hash? b) (safe-nonneg-int (hash-ref b 'assigned-harvesters 0) 0) 0))))))
  (define live-ideal-min-harvesters
    (and has-th-harvesters?
         (hash-ref obs 'ideal-mineral-harvesters
                   (lambda ()
                     (for/sum ([b (in-list townhalls)])
                       (if (hash? b)
                           (safe-nonneg-int (hash-ref b 'ideal-harvesters SC2-IDEAL-WORKERS-PER-MINERAL-LINE)
                                            SC2-IDEAL-WORKERS-PER-MINERAL-LINE)
                           SC2-IDEAL-WORKERS-PER-MINERAL-LINE))))))
  (define has-gas-harvesters?
    (or (hash-has-key? obs 'gas-harvesters)
        (hash-has-key? obs 'ideal-gas-harvesters)
        (for/or ([b (in-list gas-bldgs)]) (and (hash? b) (hash-has-key? b 'assigned-harvesters)))))
  (set-l2-ctx-has-gas-harvesters?! ctx has-gas-harvesters?)
  (define live-gas-harvesters
    (and has-gas-harvesters?
         (hash-ref obs 'gas-harvesters
                   (lambda ()
                     (for/sum ([b (in-list gas-bldgs)])
                       (if (hash? b) (safe-nonneg-int (hash-ref b 'assigned-harvesters 0) 0) 0))))))
  (set-l2-ctx-live-gas-harvesters! ctx live-gas-harvesters)
  (define live-ideal-gas-harvesters
    (and has-gas-harvesters?
         (hash-ref obs 'ideal-gas-harvesters
                   (lambda ()
                     (for/sum ([b (in-list gas-bldgs)])
                       (if (hash? b)
                           (safe-nonneg-int (hash-ref b 'ideal-harvesters SC2-IDEAL-WORKERS-PER-GEYSER)
                                            SC2-IDEAL-WORKERS-PER-GEYSER)
                           SC2-IDEAL-WORKERS-PER-GEYSER))))))
  (define macro-plan
    (evaluate-coupled-macro-governor
     #:race race
     #:frame frame
     #:minerals (l2-ctx-minerals ctx)
     #:gas (l2-ctx-gas ctx)
     #:supply-left (l2-ctx-supply-left ctx)
     #:active-bases active-bases
     #:depleting-bases depleting-bases
     #:workers active-worker-count
     #:pending-workers pending-workers
     #:mineral-harvesters live-min-harvesters
     #:ideal-mineral-harvesters live-ideal-min-harvesters
     #:gas-harvesters live-gas-harvesters
     #:ideal-gas-harvesters live-ideal-gas-harvesters
     #:production-facilities (max 1 (length prod-facilities))
     #:busy-facilities (hash-ref obs 'busy-facilities 0)
     #:busy-townhalls (hash-ref obs 'busy-townhalls 0)
     #:under-crisis? (or under-early-cheese? early-survival-crisis?)
     #:recommended-min-bases (mirror-mind-state-recommended-min-bases mmstate)))
  (set-l2-ctx-macro-plan! ctx macro-plan)
  (define target-workers (coupled-macro-plan-target-workers macro-plan))
  (set-l2-ctx-target-workers! ctx target-workers)
  (define desired-bases
    (max SC2-MIN-DESIRED-BASES
         (min SC2-MAX-ACTIVE-BASES (coupled-macro-plan-desired-bases macro-plan))))
  (set-l2-ctx-desired-bases! ctx desired-bases)
  (define res-upgs-tech (hash-ref obs 'researched-upgrades '()))
  (define uniq-bldg-types
    (let ([seen (make-hasheq)])
      (let loop ([xs (l2-ctx-bldg-types ctx)] [acc '()])
        (if (null? xs)
            (reverse acc)
            (let ([s (car xs)])
              (if (hash-has-key? seen s)
                  (loop (cdr xs) acc)
                  (begin (hash-set! seen s #t) (loop (cdr xs) (cons s acc)))))))))
  (define uniq-unit-types
    (let ([seen (make-hasheq)])
      (let loop ([xs unit-types] [acc '()])
        (if (null? xs)
            (reverse acc)
            (let ([s (car xs)])
              (if (hash-has-key? seen s)
                  (loop (cdr xs) acc)
                  (begin (hash-set! seen s #t) (loop (cdr xs) (cons s acc)))))))))
  (define tech-cache-tbl (hash-ref! (rt-door-state rt) 'adaptive-tech-plan-cache make-hash))
  (define tech-cache-key
    (list race
          uniq-bldg-types
          uniq-unit-types
          res-upgs-tech
          (mastermind-state-enemy-archetype mstate)
          (mirror-mind-state-predicted-enemy-unit mmstate)
          (mirror-mind-state-mirror-macro-verdict mmstate)
          (enemy-tech-observation-requires-detection? tech-obs)
          (enemy-tech-observation-requires-anti-air? tech-obs)
          (enemy-tech-observation-enemy-upgrade-advantage tech-obs)))
  (define tech-plan
    (hash-ref!
     tech-cache-tbl
     tech-cache-key
     (lambda ()
       (evaluate-adaptive-build-and-tech-plan
        race
        #:ally-buildings uniq-bldg-types
        #:ally-units uniq-unit-types
        #:researched-upgrades res-upgs-tech
        #:enemy-archetype (mastermind-state-enemy-archetype mstate)
        #:mirror-predicted-unit (mirror-mind-state-predicted-enemy-unit mmstate)
        #:mirror-macro-verdict (mirror-mind-state-mirror-macro-verdict mmstate)
        #:requires-detection? (enemy-tech-observation-requires-detection? tech-obs)
        #:requires-anti-air? (enemy-tech-observation-requires-anti-air? tech-obs)
        #:enemy-upgrade-advantage (enemy-tech-observation-enemy-upgrade-advantage tech-obs)
        #:minerals (l2-ctx-minerals ctx)
        #:gas (l2-ctx-gas ctx)))))
  (define ppf
    (evaluate-guns-vs-butter-ppf
     #:race race
     #:frame frame
     #:minerals (l2-ctx-minerals ctx)
     #:gas (l2-ctx-gas ctx)
     #:supply-left (l2-ctx-supply-left ctx)
     #:supply-cap supply-cap
     #:workers total-workers
     #:target-workers target-workers
     #:active-bases active-bases
     #:depleting-bases depleting-bases
     #:active-geysers (length gas-bldgs)
     #:current-gas-workers (hash-ref obs 'gas-workers (* SC2-IDEAL-WORKERS-PER-GEYSER (length gas-bldgs)))
     #:production-facilities (max 1 (length prod-facilities))
     #:busy-facilities (hash-ref obs 'busy-facilities 0)
     #:army-count (length ally-combat-units)
     #:missing-synergy-count (length (adaptive-tech-plan-missing-synergy-reqs tech-plan))
     #:under-crisis? (or under-early-cheese? early-survival-crisis?)
     #:mirror-macro-verdict (mirror-mind-state-mirror-macro-verdict mmstate)
     #:enemy-upgrade-advantage (enemy-tech-observation-enemy-upgrade-advantage tech-obs)
     #:enemy-active-research-count (length (enemy-tech-observation-active-research-buildings tech-obs))
     #:requires-detection? (enemy-tech-observation-requires-detection? tech-obs)
     #:requires-anti-air? (enemy-tech-observation-requires-anti-air? tech-obs)))
  (define gas-alloc (guns-vs-butter-ppf-recommended-gas-allocation ppf))
  (define worker-escape-threat-r2 (* SC2-WORKER-ESCAPE-THREAT-RADIUS SC2-WORKER-ESCAPE-THREAT-RADIUS))
  (for ([w (in-list workers)]
        #:unless worker-rush-active?)
    (define wsym (unit-type-sym w))
    (define whp (unit-total-hp-and-shield w))
    (define wmax
      (+ (hash-ref w 'max-hp (case wsym [(probe) 20] [(scv) 45] [else SC2-DRONE-MAX-HP]))
         (if (eq? wsym 'probe) (hash-ref w 'max-shield (hash-ref w 'shield-max 20)) 0)))
    (when (or (< whp SC2-WOUNDED-WORKER-MIN-HP)
              (< (/ (exact->inexact whp) (max 1 wmax)) SC2-WOUNDED-WORKER-HP-PCT))
      (define wid (hash-ref w 'id 10))
      (when (and (not (worker-has-engine-build-order? w))
                 (not (order-ledger-unit-has-active-build? oledger-early wid w)))
        (define wx (exact->inexact (hash-ref w 'x base-x)))
        (define wy (exact->inexact (hash-ref w 'y base-y)))
        (define enemy-close?
          (for/or ([e (in-list enemy-units)])
            (define dx (- wx (exact->inexact (hash-ref e 'x 9999.0))))
            (define dy (- wy (exact->inexact (hash-ref e 'y 9999.0))))
            (<= (+ (* dx dx) (* dy dy)) worker-escape-threat-r2)))
        (when (and enemy-close?
                   (or (not live-obs-harvesters?)
                       (refractory-allow-action?! cd-tracker
                                                  (list 'wounded-mineral-walk wid)
                                                  frame
                                                  24)))
          (l2-emit! ctx (list 'mineral-walk wid base-x base-y))))))
  (define enemy-exp-x (hash-ref obs 'enemy-expand-x (safe-coord (* 0.85 enemy-x) 148.0)))
  (set-l2-ctx-enemy-exp-x! ctx enemy-exp-x)
  (define enemy-exp-y (hash-ref obs 'enemy-expand-y (safe-coord (* 0.85 enemy-y) 148.0)))
  (set-l2-ctx-enemy-exp-y! ctx enemy-exp-y)
  (define corridor-mid-x (safe-coord (* 0.5 (+ nat-x enemy-exp-x)) 96.0))
  (set-l2-ctx-corridor-mid-x! ctx corridor-mid-x)
  (define corridor-mid-y (safe-coord (* 0.5 (+ nat-y enemy-exp-y)) 96.0))
  (set-l2-ctx-corridor-mid-y! ctx corridor-mid-y)
  (define scout-st (rt-scout-state rt))
  (set-l2-ctx-scout-st! ctx scout-st)
  (when (<= frame 4)
    (hash-clear! scout-st))
  (define non-building-workers
    (filter (lambda (w)
              (and (not (worker-has-engine-build-order? w))
                   (not (order-ledger-unit-has-active-build? oledger-early (hash-ref w 'id 0) w))))
            workers))
  (set-l2-ctx-non-building-workers! ctx non-building-workers)
  (define force-synth-harass? (eq? (hash-ref obs 'enable-worker-harass #f) #t))
  (define already-dispatched-scout? (eq? (hash-ref scout-st 'dispatched? #f) #t))
  (define scout-rush-aborted-latch?
    (and (< frame 3600)
         (eq? (hash-ref scout-st 'aborted-rush? #f) #t)))
  (set-l2-ctx-scout-rush-aborted-latch?! ctx scout-rush-aborted-latch?)
  (define scout-eligible-window?
    (and (not (null? non-building-workers))
         (not worker-rush-active?)
         (not scout-rush-aborted-latch?)
         (not in-base-proxy-detected?)
         (or force-synth-harass?
             (and (>= frame 300)
                  (>= supply-used 14)
                  (< frame 3600)
                  (not under-early-cheese?)
                  (not early-survival-crisis?)
                  (>= (length workers) (if live-obs-harvesters? 13 2))))))
  (define latched-scout-id
    (or (hash-ref scout-st 'scout-id #f)
        (and (not already-dispatched-scout?)
             (hash-ref prev-tel-early 'scout-worker-id #f))))
  (define raw-scout-candidate
    (cond
      [in-base-proxy-detected? #f]
      [(and latched-scout-id
            (findf (lambda (w) (equal? (hash-ref w 'id -1) latched-scout-id))
                   non-building-workers))
       => values]
      [(and worker-rush-active? (< frame 3360))
       ;; Also catch a forward scout worker already out on the map in stateless/first-step rush encounters
       (findf (lambda (w)
                (define wx (hash-ref w 'x base-x))
                (define wy (hash-ref w 'y base-y))
                (and (> (dist2d wx wy base-x base-y) 16.0)
                     (or (< active-bases 2)
                         (> (dist2d wx wy nat-x nat-y) 14.0))))
              non-building-workers)]
      [already-dispatched-scout?
       (and force-synth-harass?
            (not worker-rush-active?)
            (not scout-rush-aborted-latch?)
            (not live-obs-harvesters?)
            (pair? non-building-workers)
            (select-far-mineral-patch-non-carrying-worker
             non-building-workers base-x base-y step-mineral-patches))]
      [scout-eligible-window?
       (select-far-mineral-patch-non-carrying-worker
        non-building-workers base-x base-y step-mineral-patches)]
      [else #f]))
  (define rush-retreating-scout
    (and (l2-scout-encounters-early-worker-rush? ctx raw-scout-candidate)
         raw-scout-candidate))
  (when rush-retreating-scout
    (hash-set! scout-st 'dispatched? #t)
    (hash-set! scout-st 'scout-id (hash-ref rush-retreating-scout 'id #f))
    (hash-set! scout-st 'aborted-rush? #t))
  (define scout-worker
    (cond
      [(or rush-retreating-scout
           worker-rush-active?
           scout-rush-aborted-latch?
           in-base-proxy-detected?)
       #f]
      [already-dispatched-scout? raw-scout-candidate]
      [(and scout-eligible-window? raw-scout-candidate)
       (hash-set! scout-st 'dispatched? #t)
       (hash-set! scout-st 'scout-id (hash-ref raw-scout-candidate 'id #f))
       (hash-set! scout-st 'orbit-idx 0)
       (hash-set! scout-st 'evading-until 0)
       raw-scout-candidate]
      [else #f]))
  (set-l2-ctx-scout-worker! ctx scout-worker)
  (define rush-retreating-scout-id
    (and rush-retreating-scout (hash-ref rush-retreating-scout 'id #f)))
  (define scout-worker-id (and scout-worker (hash-ref scout-worker 'id #f)))
  (set-l2-ctx-scout-worker-id! ctx scout-worker-id)
  (define active-leased-scout (or rush-retreating-scout scout-worker))
  (define active-leased-scout-id (and active-leased-scout (hash-ref active-leased-scout 'id #f)))
  (when active-leased-scout-id
    (acquire-unit-lease! leases active-leased-scout-id 'scout frame 32
                         #:x (hash-ref active-leased-scout 'x base-x)
                         #:y (hash-ref active-leased-scout 'y base-y)))
  (define harvest-eligible-workers
    (for/list ([w (in-list workers)]
               #:when (let ([wid (hash-ref w 'id -1)])
                        (and (not (worker-has-engine-build-order? w))
                             (not (order-ledger-unit-has-active-build? oledger-early wid w))
                             (not (and active-leased-scout-id (equal? wid active-leased-scout-id)))
                             (not (unit-leased-above? leases wid 'harvester frame)))))
      w))
  (define harvest-workers-pool
    (if (not (null? harvest-eligible-workers)) harvest-eligible-workers non-building-workers))
  (define gas-float-starved?
    (and (>= (l2-ctx-gas ctx) SC2-GAS-FLOAT-REBALANCE-THRESH)
         (< (l2-ctx-minerals ctx) SC2-MINERAL-STARVED-REBALANCE-THRESH)))
  (define gas-bldg
    (for/first ([b (in-list ally-bldgs)]
                #:when (let ([cs (fast-canonical-structure-sym (unit-type-sym b))])
                         (or (eq? cs 'extractor) (eq? cs 'assimilator) (eq? cs 'refinery))))
      b))
  (when (and (not live-obs-harvesters?)
             gas-bldg
             (not (null? harvest-workers-pool))
             (not gas-float-starved?)
             (> (gas-worker-allocation-desired-gas-workers gas-alloc) 0))
    (l2-emit! ctx (list 'harvest-gas (hash-ref (car harvest-workers-pool) 'id 10) (hash-ref gas-bldg 'id 103))))
  (when (not (null? harvest-workers-pool))
    (define patch-id (hash-ref obs 'mineral-patch-id SC2-SYNTHETIC-MINERAL-PATCH-ID))
    (when (and (not live-obs-harvesters?) gas-float-starved?)
      (define pull-workers
        (take harvest-workers-pool
              (min (if (>= (l2-ctx-gas ctx) SC2-GAS-FLOAT-CRITICAL-THRESH) 4 2)
                   (length harvest-workers-pool))))
      (l2-emit! ctx (list 'rebalance-gas-to-minerals
                   (for/list ([w (in-list pull-workers)]) (hash-ref w 'id 10))
                   patch-id)))
    (unless live-obs-harvesters?
      (l2-emit! ctx (list 'harvest-mineral (hash-ref (car harvest-workers-pool) 'id 10) patch-id)))
    (define lazy-enemy-bbox #f)
    (define (get-idle-enemy-bbox)
      (or lazy-enemy-bbox
          (let-values ([(mnx mxx mny mxy)
                        (for/fold ([mnx +inf.0] [mxx -inf.0] [mny +inf.0] [mxy -inf.0])
                                  ([e (in-sequences (in-list enemy-units) (in-list enemy-bldgs))])
                          (define ex (exact->inexact (hash-ref e 'x 9999)))
                          (define ey (exact->inexact (hash-ref e 'y 9999)))
                          (values (flmin mnx ex) (flmax mxx ex) (flmin mny ey) (flmax mxy ey)))])
            (define res (vector (fl- mnx 6.5) (fl+ mxx 6.5) (fl- mny 6.5) (fl+ mxy 6.5)))
            (set! lazy-enemy-bbox res)
            res)))
    (define (worker-near-enemy-list? wx wy es)
      (for/or ([e (in-list es)])
        (define dx (fl- wx (exact->inexact (hash-ref e 'x 9999))))
        (define dy (fl- wy (exact->inexact (hash-ref e 'y 9999))))
        (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 42.25)))
    (define idle-return-workers
      (for/list ([w (in-list harvest-workers-pool)]
                 #:when (let ([ords (hash-ref w 'orders SANITIZE-MISSING)])
                          (and (not (eq? ords SANITIZE-MISSING))
                               (or (null? ords) (equal? ords '(idle)))
                               (let ([wid (hash-ref w 'id 10)])
                                 (and (not (memv wid (l2-ctx-cur-rush-fighting-wids ctx)))
                                      (not (memv wid (l2-ctx-cur-rush-disengaging-wids ctx)))))
                               (let* ([wx (exact->inexact (hash-ref w 'x base-x))]
                                      [wy (exact->inexact (hash-ref w 'y base-y))]
                                      [ep (get-idle-enemy-bbox)])
                                 (or (fl< wx (vector-ref ep 0))
                                     (fl> wx (vector-ref ep 1))
                                     (fl< wy (vector-ref ep 2))
                                     (fl> wy (vector-ref ep 3))
                                     (not (or (worker-near-enemy-list? wx wy enemy-units)
                                              (worker-near-enemy-list? wx wy enemy-bldgs))))))))
        w))
    (when (not (null? idle-return-workers))
      (define idle-ids (map (lambda (w) (hash-ref w 'id 10)) idle-return-workers))
      (l2-emit! ctx (list 'return-workers-to-gather idle-ids))
      (for ([wid (in-list idle-ids)]
            #:unless (and (not live-obs-harvesters?)
                          (equal? wid (hash-ref (car harvest-workers-pool) 'id 10))))
        (l2-emit! ctx (list 'harvest-mineral wid patch-id)))))
  (when rush-retreating-scout-id
    (l2-emit! ctx (list 'mineral-walk rush-retreating-scout-id base-x base-y)))
  (when (and force-synth-harass?
             (not rush-retreating-scout)
             (not worker-rush-active?)
             (not scout-rush-aborted-latch?)
             (not in-base-proxy-detected?)
             (not (null? workers)))
    (l2-emit! ctx (list 'worker-harass
                 (or scout-worker-id
                     (let ([pick (select-far-mineral-patch-non-carrying-worker
                                  (if (pair? non-building-workers) non-building-workers workers)
                                  base-x base-y step-mineral-patches)])
                       (hash-ref (or pick (last workers)) 'id 10)))
                 enemy-x enemy-y))))

(define (l2-phase5-threat-proxy! ctx)
  (define active-bases (l2-ctx-active-bases ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-supply-early (l2-ctx-ally-combat-supply-early ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define blocked-nat-expanded-early? (l2-ctx-blocked-nat-expanded-early? ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define depleting-bases (l2-ctx-depleting-bases ctx))
  (define desired-bases (l2-ctx-desired-bases ctx))
  (define early-race-th-sym (l2-ctx-early-race-th-sym ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-exp-x (l2-ctx-enemy-exp-x ctx))
  (define enemy-exp-y (l2-ctx-enemy-exp-y ctx))
  (define enemy-rush-workers (l2-ctx-enemy-rush-workers ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define forward-proxy-detected? (l2-ctx-forward-proxy-detected? ctx))
  (define forward-proxy-structures (l2-ctx-forward-proxy-structures ctx))
  (define frame (l2-ctx-frame ctx))
  (define in-base-proxy-structures (l2-ctx-in-base-proxy-structures ctx))
  (define leases (l2-ctx-leases ctx))
  (define live-obs-harvesters? (l2-ctx-live-obs-harvesters? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define obs (l2-ctx-obs ctx))
  (define oledger-early (l2-ctx-oledger-early ctx))
  (define race (l2-ctx-race ctx))
  (define rt (l2-ctx-rt ctx))
  (define scout-st (l2-ctx-scout-st ctx))
  (define scout-worker (l2-ctx-scout-worker ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define unit-types (l2-ctx-unit-types ctx))
  (when scout-worker
    (define sw-id (hash-ref scout-worker 'id 10))
    (define sw-x (hash-ref scout-worker 'x base-x))
    (define sw-y (hash-ref scout-worker 'y base-y))
    (define dist-to-enemy (dist2d sw-x sw-y enemy-x enemy-y))
    (cond
      [(not live-obs-harvesters?)
       (define wp-x (if (and (> (dist2d sw-x sw-y enemy-exp-x enemy-exp-y) 9.0)
                             (> dist-to-enemy 20.0)
                             (< (modulo frame 672) 336))
                        enemy-exp-x
                        enemy-x))
       (define wp-y (if (and (> (dist2d sw-x sw-y enemy-exp-x enemy-exp-y) 9.0)
                             (> dist-to-enemy 20.0)
                             (< (modulo frame 672) 336))
                        enemy-exp-y
                        enemy-y))
       (l2-emit! ctx (list 'worker-scout sw-id wp-x wp-y))
       (l2-emit! ctx (list 'mineral-harass sw-id enemy-x enemy-y enemy-exp-x enemy-exp-y))]
      [else
       (define ex (exact->inexact enemy-x))
       (define ey (exact->inexact enemy-y))
       (define vdx (- ex (exact->inexact base-x)))
       (define vdy (- ey (exact->inexact base-y)))
       (define vlen (max 1.0 (sqrt (+ (* vdx vdx) (* vdy vdy)))))
       (define ux (/ vdx vlen))
       (define uy (/ vdy vlen))
       (define px (- uy))
       (define py ux)
       (define orbit-waypoints
         (list (cons (safe-coord (+ ex (* 6.0 ux) (* 5.5 px)) enemy-x)
                     (safe-coord (+ ey (* 6.0 uy) (* 5.5 py)) enemy-y))
               (cons (safe-coord (+ ex (* 7.5 ux) (* 2.5 px)) enemy-x)
                     (safe-coord (+ ey (* 7.5 uy) (* 2.5 py)) enemy-y))
               (cons (safe-coord (+ ex (* 7.5 ux) (* -2.5 px)) enemy-x)
                     (safe-coord (+ ey (* 7.5 uy) (* -2.5 py)) enemy-y))
               (cons (safe-coord (+ ex (* 6.0 ux) (* -5.5 px)) enemy-x)
                     (safe-coord (+ ey (* 6.0 uy) (* -5.5 py)) enemy-y))
               (cons (safe-coord (+ ex (* 3.5 ux) (* -7.0 px)) enemy-x)
                     (safe-coord (+ ey (* 3.5 uy) (* -7.0 py)) enemy-y))))
       (when (<= (dist2d sw-x sw-y enemy-exp-x enemy-exp-y) 10.5)
         (hash-set! scout-st 'visited-nat? #t))
       (define ranged-enemies-near
         (count (lambda (e)
                  (define et (fast-canonical-unit-sym (unit-type-sym e)))
                  (and (<= (dist2d sw-x sw-y (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 7.5)
                       (or (>= (safe-finite-real (hash-ref e 'range 0.0) 0.0) 2.0)
                           (memq et '(marine marauder reaper stalker adept sentry queen
                                      hydralisk roach cyclone hellion photon-cannon bunker
                                      planetary-fortress spine-crawler)))))
                (append enemy-units enemy-bldgs)))
       (define pulled-workers-chasing
         (count (lambda (e)
                  (and (memq (unit-type-sym e) '(probe scv drone))
                       (<= (dist2d sw-x sw-y (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 4.5)))
                enemy-units))
       (define sw-total-hp (unit-total-hp-and-shield scout-worker 40))
       (define sw-low-hp? (< sw-total-hp 22))
       (when (or (> ranged-enemies-near 0)
                 (>= pulled-workers-chasing 2)
                 sw-low-hp?)
         (hash-set! scout-st 'evading-until (+ frame 40)))
       (define evading? (< frame (hash-ref scout-st 'evading-until 0)))
       (cond
         [evading?
          (when (refractory-allow-action?! cd-tracker (list 'scout-evade sw-id) frame 12)
            (if (or sw-low-hp? (> ranged-enemies-near 0) (>= pulled-workers-chasing 2))
                (l2-emit! ctx (list 'mineral-walk sw-id base-x base-y))
                (let* ([next-idx (modulo (+ (hash-ref scout-st 'orbit-idx 0) 2) 5)]
                       [esc-wp (list-ref orbit-waypoints next-idx)])
                  (hash-set! scout-st 'orbit-idx next-idx)
                  (l2-emit! ctx (list 'move sw-id (car esc-wp) (cdr esc-wp))))))]
         [else
          (define exposed-builder-scv
            (and (= ranged-enemies-near 0)
                 (<= pulled-workers-chasing 1)
                 (findf (lambda (e)
                          (define ex0 (hash-ref e 'x 9999.0))
                          (define ey0 (hash-ref e 'y 9999.0))
                          (and (eq? (unit-type-sym e) 'scv)
                               (<= (dist2d sw-x sw-y ex0 ey0) 9.5)
                               (or (eq? (hash-ref e 'has-build-order? #f) #t)
                                   (ormap (lambda (eb)
                                            (and (< (hash-ref eb 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                                                 (<= (dist2d ex0 ey0
                                                             (hash-ref eb 'x 9999.0)
                                                             (hash-ref eb 'y 9999.0))
                                                     3.2)))
                                          enemy-bldgs))))
                        enemy-units)))
          (cond
            [exposed-builder-scv
             (when (refractory-allow-action?! cd-tracker (list 'scout-poke-scv sw-id) frame 16)
               (l2-emit! ctx (list 'attack sw-id (hash-ref exposed-builder-scv 'id 0))))]
            [else
             (define cur-idx (modulo (hash-ref scout-st 'orbit-idx 0) 5))
             (define cur-wp0 (list-ref orbit-waypoints cur-idx))
             (define next-idx
               (if (<= (dist2d sw-x sw-y (car cur-wp0) (cdr cur-wp0)) 3.2)
                   (modulo (add1 cur-idx) 5)
                   cur-idx))
             (hash-set! scout-st 'orbit-idx next-idx)
             (define target-wp
               (if (and (not (hash-ref scout-st 'visited-nat? #f))
                        (> dist-to-enemy 26.0)
                        (> (dist2d sw-x sw-y enemy-exp-x enemy-exp-y) 9.5))
                   (cons enemy-exp-x enemy-exp-y)
                   (list-ref orbit-waypoints next-idx)))
             (when (refractory-allow-action?! cd-tracker (list 'opening-worker-scout sw-id) frame 20)
               (l2-emit! ctx (list 'worker-scout sw-id (car target-wp) (cdr target-wp))))])])]))
  (when (eq? race 'Zerg)
    (define already-ov-aborted? (hash-ref scout-st 'opening-overlord-aborted? #f))
    (define need-ov-scan?
      (or (and (< frame 2800) (not already-ov-aborted?))
          live-obs-harvesters?))
    (define all-overlords
      (if need-ov-scan?
          (for/list ([u (in-list ally-units)]
                     #:when (eq? (unit-type-sym u) 'overlord))
            u)
          '()))
    (define aa-enemy-pts-box #f)
    (define (get-aa-enemy-pts)
      (unless aa-enemy-pts-box
        (define-values (min-x min-y max-x max-y xs ys)
          (for/fold ([mnx +inf.0] [mny +inf.0] [mxx -inf.0] [mxy -inf.0] [axs '()] [ays '()])
                    ([e (in-list enemy-units)])
            (define et (unit-type-sym e))
            (if (fast-can-attack-air? et)
                (let ([ex (exact->inexact (hash-ref e 'x 9999))]
                      [ey (exact->inexact (hash-ref e 'y 9999))])
                  (values (flmin mnx ex) (flmin mny ey) (flmax mxx ex) (flmax mxy ey)
                          (cons ex axs) (cons ey ays)))
                (values mnx mny mxx mxy axs ays))))
        (set! aa-enemy-pts-box (vector min-x min-y max-x max-y xs ys)))
      aa-enemy-pts-box)
    (define ov-threat-r (exact->inexact SC2-OVERLORD-THREAT-RADIUS))
    (define ov-threat-r2 (fl* ov-threat-r ov-threat-r))
    (define ov-unsafe-cache (and (pair? all-overlords) (make-hasheq)))
    (define (overlord-unsafe? u)
      (define cached (if ov-unsafe-cache (hash-ref ov-unsafe-cache u 'miss) 'miss))
      (if (not (eq? cached 'miss))
          cached
          (let ([res
                 (or (hash-ref u 'under-attack #f)
                     (< (hash-ref u 'hp SC2-OVERLORD-MAX-HP) SC2-OVERLORD-DAMAGED-HP-THRESH)
                     (let ([ux (exact->inexact (hash-ref u 'x base-x))]
                           [uy (exact->inexact (hash-ref u 'y base-y))]
                           [b (get-aa-enemy-pts)])
                       (define xs (vector-ref b 4))
                       (and (pair? xs)
                            (fl>= ux (fl- (vector-ref b 0) ov-threat-r))
                            (fl<= ux (fl+ (vector-ref b 2) ov-threat-r))
                            (fl>= uy (fl- (vector-ref b 1) ov-threat-r))
                            (fl<= uy (fl+ (vector-ref b 3) ov-threat-r))
                            (for/or ([ex (in-list xs)]
                                     [ey (in-list (vector-ref b 5))])
                              (define dx (fl- ux ex))
                              (define dy (fl- uy ey))
                              (fl<= (fl+ (fl* dx dx) (fl* dy dy)) ov-threat-r2)))))])
            (when ov-unsafe-cache (hash-set! ov-unsafe-cache u res))
            res)))
    (unless already-ov-aborted?
      (if (>= frame 2800)
          (hash-set! scout-st 'opening-overlord-aborted? #t)
          (let ()
            (define ov-and-overseers-cnt
              (for/sum ([u (in-list ally-units)])
                (let ([ut (unit-type-sym u)])
                  (if (or (eq? ut 'overlord) (eq? ut 'overseer)) 1 0))))
            (define prev-ov-max (hash-ref scout-st 'opening-overlord-max-seen 0))
            (when (> ov-and-overseers-cnt prev-ov-max)
              (hash-set! scout-st 'opening-overlord-max-seen ov-and-overseers-cnt))
            (define enemy-has-nonworker-aa?
              (or (enemy-tech-observation-requires-anti-air? tech-obs)
                  (for/or ([e (in-list enemy-units)])
                    (define et (unit-type-sym e))
                    (and (not (or (eq? et 'probe) (eq? et 'scv) (eq? et 'drone) (eq? et 'overlord)))
                         (fast-can-attack-air? et)))))
            (define any-ov-lost-or-hurt?
              (or (and (> prev-ov-max 0) (< ov-and-overseers-cnt prev-ov-max))
                  (for/or ([ov (in-list all-overlords)]) (overlord-unsafe? ov))))
            (when (or any-ov-lost-or-hurt? enemy-has-nonworker-aa?)
              (hash-set! scout-st 'opening-overlord-aborted? #t)))))
    (define ov-aborted? (hash-ref scout-st 'opening-overlord-aborted? #f))
    (define base-x-fl (exact->inexact base-x))
    (define base-y-fl (exact->inexact base-y))
    (define enemy-x-fl (exact->inexact enemy-x))
    (define enemy-y-fl (exact->inexact enemy-y))
    (define safe-ov-vec-dx (fl- base-x-fl enemy-x-fl))
    (define safe-ov-vec-dy (fl- base-y-fl enemy-y-fl))
    (define safe-ov-vec-d (flmax 1.0 (flsqrt (fl+ (fl* safe-ov-vec-dx safe-ov-vec-dx)
                                                  (fl* safe-ov-vec-dy safe-ov-vec-dy)))))
    (define safe-ov-x (safe-coord (fl+ base-x-fl (fl* 5.5 (fl/ safe-ov-vec-dx safe-ov-vec-d))) base-x))
    (define safe-ov-y (safe-coord (fl+ base-y-fl (fl* 5.5 (fl/ safe-ov-vec-dy safe-ov-vec-d))) base-y))
    (define safe-ov-x-fl (exact->inexact safe-ov-x))
    (define safe-ov-y-fl (exact->inexact safe-ov-y))
    (define base->enemy-dx (fl- base-x-fl enemy-x-fl))
    (define base->enemy-dy (fl- base-y-fl enemy-y-fl))
    (define base->enemy-d (flsqrt (fl+ (fl* base->enemy-dx base->enemy-dx)
                                       (fl* base->enemy-dy base->enemy-dy))))
    (define ov-forward-thresh (fl- base->enemy-d 4.5))
    (define ov-forward-thresh-sq (if (fl> ov-forward-thresh 0.0) (fl* ov-forward-thresh ov-forward-thresh) -1.0))
    (define active-scout-ov-id #f)
    (cond
      [(and (< frame 2800)
            (not ov-aborted?)
            (or (not live-obs-harvesters?)
                (refractory-allow-action?! cd-tracker 'opening-overlord-scout frame 64)))
       (define tracked-ov-ids (hash-ref scout-st 'opening-overlord-ids '()))
       (define safe-overlords
         (for/list ([u (in-list all-overlords)]
                    #:when (and (not (overlord-unsafe? u))
                                (or (memv (hash-ref u 'id 102) tracked-ov-ids)
                                    (< (length tracked-ov-ids) 1))))
           u))
       (define rplan-now
         (evaluate-random-stealth-harass-plan (live-bot-runtime-configured-race rt) race frame))
       (define perim-flight?
         (and (random-stealth-harass-plan-perimeter-flight-path? rplan-now) (< frame 1200)))
       (when (pair? safe-overlords)
         (define ov1 (car safe-overlords))
         (define ov1-id (hash-ref ov1 'id 102))
         (unless (memv ov1-id tracked-ov-ids)
           (set! tracked-ov-ids (list ov1-id)))
         (set! active-scout-ov-id ov1-id)
         (define ov1-tx enemy-exp-x)
         (define ov1-ty (if perim-flight? base-y enemy-exp-y))
         (l2-emit! ctx (list 'overlord-scout ov1-id ov1-tx ov1-ty)))
       (hash-set! scout-st 'opening-overlord-ids
                  (if (> (length tracked-ov-ids) 1)
                      (list (car tracked-ov-ids))
                      tracked-ov-ids))]
      [(and (not ov-aborted?) (< frame 2800))
       (define tracked-ov-ids (hash-ref scout-st 'opening-overlord-ids '()))
       (when (pair? tracked-ov-ids)
         (set! active-scout-ov-id (car tracked-ov-ids)))])
    ;; Park all non-Overseer Overlords (other than the single pre-abort scout) behind our main mineral line (`#5124062`).
    (when (and live-obs-harvesters? (pair? all-overlords))
      (for ([ov (in-list all-overlords)]
            #:when (eq? (unit-type-sym ov) 'overlord))
        (define ov-id (hash-ref ov 'id 102))
        (unless (and active-scout-ov-id (equal? ov-id active-scout-ov-id) (not ov-aborted?) (< frame 2800))
          (define ovx (exact->inexact (hash-ref ov 'x safe-ov-x)))
          (define ovy (exact->inexact (hash-ref ov 'y safe-ov-y)))
          (define unsafe-ov? (overlord-unsafe? ov))
          (define sdx (fl- ovx safe-ov-x-fl))
          (define sdy (fl- ovy safe-ov-y-fl))
          (define dist-to-safe-sq (fl+ (fl* sdx sdx) (fl* sdy sdy)))
          (define bdx (fl- ovx base-x-fl))
          (define bdy (fl- ovy base-y-fl))
          (define near-home-base? (fl<= (fl+ (fl* bdx bdx) (fl* bdy bdy)) 72.25))
          (define too-far-or-forward?
            (or unsafe-ov?
                (and (not near-home-base?)
                     (or (fl> dist-to-safe-sq 90.25)
                         (and (fl> ov-forward-thresh-sq 0.0)
                              (let ([edx (fl- ovx enemy-x-fl)]
                                    [edy (fl- ovy enemy-y-fl)])
                                (fl< (fl+ (fl* edx edx) (fl* edy edy)) ov-forward-thresh-sq)))))))
          (when (and too-far-or-forward?
                     (refractory-allow-action?! cd-tracker
                                                (list 'ov-retreat-home ov-id)
                                                frame
                                                (if unsafe-ov? 24 48)))
            ;; Step far Overlords in 14-tile segments so human-cortex box-coalescing never merges and drops cross-map Overlords
            (define dist-to-safe-ov (flsqrt dist-to-safe-sq))
            (define-values (ov-rx ov-ry)
              (if (fl> dist-to-safe-ov 22.0)
                  (let ([d (flmax 1.0 dist-to-safe-ov)])
                    (values (safe-coord (fl+ ovx (fl* 14.0 (fl/ (fl- safe-ov-x-fl ovx) d))) safe-ov-x)
                            (safe-coord (fl+ ovy (fl* 14.0 (fl/ (fl- safe-ov-y-fl ovy) d))) safe-ov-y)))
                  (values safe-ov-x safe-ov-y)))
            (l2-emit! ctx (list 'kite ov-id ov-rx ov-ry)))))))
  (define pre-depleting-bases (safe-nonneg-int (hash-ref obs 'pre-depleting-bases depleting-bases) depleting-bases))
  (when (and (or (hash-ref obs 'mined-out #f)
                 (and (> (max depleting-bases pre-depleting-bases) 0)
                      (>= (l2-ctx-minerals ctx) (sc2-race-townhall-min-cost race))))
             (not blocked-nat-expanded-early?)
             (not under-early-cheese?)
             (not early-survival-crisis?)
             (= (order-ledger-pending-count-for-type oledger-early early-race-th-sym frame) 0)
             (< active-bases desired-bases)
             (< active-bases SC2-MAX-ACTIVE-BASES)
             (or (< active-bases 4)
                 (>= (l2-ctx-minerals ctx) 600)
                 (> depleting-bases 0))
             (refractory-allow-action?! cd-tracker (list 'auto-expand race) frame SC2-EXPANSION-COOLDOWN-FRAMES))
    (define-values (exp-x exp-y)
      (l2-select-uncamped-expansion-pad ctx (< active-bases 2)))
    (when (and exp-x exp-y)
      (l2-emit! ctx (list 'expand exp-x exp-y))
      (order-ledger-record-issued! oledger-early (+ 815000 (modulo frame 10000)) 'expand early-race-th-sym exp-x exp-y frame)
      (set-l2-ctx-minerals! ctx (max 0 (- (l2-ctx-minerals ctx) (sc2-race-townhall-min-cost race))))))
  (define oledger (live-bot-runtime-order-ledger rt))
  (set-l2-ctx-oledger! ctx oledger)
  (order-ledger-reconcile-observation! oledger obs)
  (define cortex (live-bot-runtime-cortex rt))
  (set-l2-ctx-cortex! ctx cortex)
  (define cg-sync-actions
    (cortex-sync-control-groups! cortex ally-units ally-bldgs base-x base-y
                                 #:excluded-tags (leased-tags-above leases 'army frame)))
  (for ([cga (in-list cg-sync-actions)])
    (l2-emit! ctx cga))
  (define cg4-cap (cortex-production-group-capacity cortex ally-bldgs 4))
  (set-l2-ctx-cg4-cap! ctx cg4-cap)
  (define cg5-cap (cortex-production-group-capacity cortex ally-bldgs 5))
  (set-l2-ctx-cg5-cap! ctx cg5-cap)
  (define cg6-cap (cortex-production-group-capacity cortex ally-bldgs 6))
  (set-l2-ctx-cg6-cap! ctx cg6-cap)
  (define cg7-cap (cortex-production-group-capacity cortex ally-bldgs 7))
  (set-l2-ctx-cg7-cap! ctx cg7-cap)
  (define l2-sc (rt-l2-scratch rt))
  (set-l2-ctx-l2-sc! ctx l2-sc)
  (define recalled-groups (pooled-mutable-set! l2-sc 'recalled-groups))
  (set-l2-ctx-recalled-groups! ctx recalled-groups)
  (define has-ally-overlord? (not (not (memq 'overlord unit-types))))
  (define threatened-overlords
    (if has-ally-overlord?
        (let ()
          (define overlord-threat-radius-sq (* SC2-OVERLORD-THREAT-RADIUS SC2-OVERLORD-THREAT-RADIUS))
          (define r2 (if (flonum? overlord-threat-radius-sq)
                         overlord-threat-radius-sq
                         (exact->inexact overlord-threat-radius-sq)))
          (define air-state #f)
          (define (get-air-state)
            (or air-state
                (let-values ([(xs-rev ys-rev)
                              (for/fold ([xs '()] [ys '()]) ([e (in-list enemy-units)])
                                (if (fast-can-attack-air? (unit-type-sym e))
                                    (let ([rx (hash-ref e 'x 9999.0)]
                                          [ry (hash-ref e 'y 9999.0)])
                                      (values (cons (if (flonum? rx) rx (exact->inexact rx)) xs)
                                              (cons (if (flonum? ry) ry (exact->inexact ry)) ys)))
                                    (values xs ys)))])
                  (define v (vector xs-rev ys-rev (or (null? enemy-units) (pair? xs-rev))))
                  (set! air-state v)
                  v)))
          (for/list ([u (in-list ally-units)]
                     #:when (and (eq? (unit-type-sym u) 'overlord)
                                 (or (hash-ref u 'under-attack #f)
                                     (and (< (hash-ref u 'hp SC2-OVERLORD-MAX-HP) SC2-OVERLORD-DAMAGED-HP-THRESH)
                                          (vector-ref (get-air-state) 2))
                                     (let* ([st (get-air-state)]
                                            [axs (vector-ref st 0)]
                                            [ays (vector-ref st 1)]
                                            [ux (hash-ref u 'x base-x)]
                                            [uy (hash-ref u 'y base-y)])
                                       (and (pair? axs)
                                            (if (and (real? ux) (= (- ux ux) 0)
                                                     (real? uy) (= (- uy uy) 0))
                                                (let ([fux (if (flonum? ux) ux (exact->inexact ux))]
                                                      [fuy (if (flonum? uy) uy (exact->inexact uy))])
                                                  (for/or ([ax (in-list axs)] [ay (in-list ays)])
                                                    (define dx (fl- ax fux))
                                                    (define dy (fl- ay fuy))
                                                    (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2)))
                                                (for/or ([ax (in-list axs)] [ay (in-list ays)])
                                                  (<= (dist2d ux uy ax ay) SC2-OVERLORD-THREAT-RADIUS))))))))
            u))
        '()))
  (for ([ov (in-list threatened-overlords)])
    (l2-emit! ctx (list 'kite (hash-ref ov 'id 102) base-x base-y)))
  (define has-supply-bldg-candidate?
    (or (memq 'supply-depot (l2-ctx-bldg-types ctx))
        (memq 'supply-depot-lowered (l2-ctx-bldg-types ctx))
        (memq 'pylon (l2-ctx-bldg-types ctx))
        (memq 'pylon-overcharged (l2-ctx-bldg-types ctx))))
  (define threatened-supply-bldgs
    (if has-supply-bldg-candidate?
        (for/list ([b (in-list ally-bldgs)]
                   #:when (let ([bt (unit-type-sym b)])
                            (and (memq bt '(supply-depot supply-depot-lowered pylon pylon-overcharged))
                                 (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                                 (or (< (hash-ref b 'hp-pct 1.0) SC2-SUPPLY-BLDG-DAMAGED-HP-PCT)
                                     (and (eq? (hash-ref b 'hp-pct RUNTIME-MISSING) RUNTIME-MISSING)
                                          (< (hash-ref b 'hp SC2-PYLON-TOTAL-MAX-HP)
                                             (if (memq bt '(pylon pylon-overcharged))
                                                 SC2-PYLON-DAMAGED-HULL-THRESH
                                                 SC2-SUPPLY-DEPOT-DAMAGED-HP-THRESH)))
                                     (hash-ref b 'under-attack #f)))))
          b)
        '()))
  (define supply-at-risk?
    (or (not (null? threatened-overlords))
        (not (null? threatened-supply-bldgs))
        (hash-ref obs 'supply-at-risk #f)))
  (set-l2-ctx-supply-at-risk?! ctx supply-at-risk?)
  (define supply-provider-sym
    (case race
      [(Zerg) 'overlord]
      [(Protoss) 'pylon]
      [(Terran) 'supply-depot]
      [else 'overlord]))
  (set-l2-ctx-supply-provider-sym! ctx supply-provider-sym)
  (set-l2-ctx-pending-supply! ctx
        (max (l2-ctx-pending-supply ctx)
             (order-ledger-pending-count-for-type oledger supply-provider-sym frame)))
  (define ready-bldgs
    (filter (lambda (b)
              (and (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                   (l2-building-grounded-and-powered? ctx b)))
            ally-bldgs))
  (set-l2-ctx-ready-bldgs! ctx ready-bldgs)
  (define ready-bldg-types
    (map (lambda (b) (fast-canonical-structure-sym (unit-type-sym b))) ready-bldgs))
  (set-l2-ctx-ready-bldg-types! ctx ready-bldg-types)
  (define rush-threat-enemies (filter-rush-threat-enemies enemy-units base-x base-y nat-x nat-y))
  (set-l2-ctx-rush-threat-enemies! ctx rush-threat-enemies)
  (define live-army-supply ally-combat-supply-early)
  (set-l2-ctx-live-army-supply! ctx live-army-supply)
  (define rush-worker-swarm?
    (>= (length enemy-rush-workers) SC2-WORKER-RUSH-MIN-ENEMY-WORKERS))
  (set-l2-ctx-rush-worker-swarm?! ctx rush-worker-swarm?)
  (define forward-proxy-prod-cnt
    (if forward-proxy-detected?
        (count (lambda (eb)
                 (memq (fast-canonical-structure-sym (unit-type-sym eb))
                       '(barracks factory starport gateway warp-gate robotics-facility stargate)))
               forward-proxy-structures)
        0))
  (define proxy-structure-threat-supply
    (+ (* 4 (length in-base-proxy-structures))
       (if forward-proxy-detected?
           (max 4 (* 4 forward-proxy-prod-cnt))
           0)))
  (set-l2-ctx-proxy-structure-threat-supply! ctx proxy-structure-threat-supply))

(define (l2-phase6-crisis-supply! ctx)
  (define active-bases (l2-ctx-active-bases ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define corridor-mid-x (l2-ctx-corridor-mid-x ctx))
  (define corridor-mid-y (l2-ctx-corridor-mid-y ctx))
  (define desired-bases (l2-ctx-desired-bases ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-exp-x (l2-ctx-enemy-exp-x ctx))
  (define enemy-exp-y (l2-ctx-enemy-exp-y ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define in-base-proxy-detected? (l2-ctx-in-base-proxy-detected? ctx))
  (define initial-enemy-race (l2-ctx-initial-enemy-race ctx))
  (define leases (l2-ctx-leases ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-obs-harvesters? (l2-ctx-live-obs-harvesters? ctx))
  (define map-grids (l2-ctx-map-grids ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define obs (l2-ctx-obs ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define prev-tel-early (l2-ctx-prev-tel-early ctx))
  (define prod-facilities (l2-ctx-prod-facilities ctx))
  (define proxy-structure-threat-supply (l2-ctx-proxy-structure-threat-supply ctx))
  (define race (l2-ctx-race ctx))
  (define ready-bldgs (l2-ctx-ready-bldgs ctx))
  (define rt (l2-ctx-rt ctx))
  (define rush-threat-enemies (l2-ctx-rush-threat-enemies ctx))
  (define rush-worker-swarm? (l2-ctx-rush-worker-swarm? ctx))
  (define scout-worker-id (l2-ctx-scout-worker-id ctx))
  (define supply-at-risk? (l2-ctx-supply-at-risk? ctx))
  (define supply-cap (l2-ctx-supply-cap ctx))
  (define supply-provider-sym (l2-ctx-supply-provider-sym ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define target-workers (l2-ctx-target-workers ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define third-x (l2-ctx-third-x ctx))
  (define third-y (l2-ctx-third-y ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define workers (l2-ctx-workers ctx))
  (define fbx (exact->inexact base-x))
  (set-l2-ctx-fbx! ctx fbx)
  (define fby (exact->inexact base-y))
  (set-l2-ctx-fby! ctx fby)
  (define fnx (exact->inexact nat-x))
  (set-l2-ctx-fnx! ctx fnx)
  (define fny (exact->inexact nat-y))
  (set-l2-ctx-fny! ctx fny)
  (define ftx (exact->inexact third-x))
  (set-l2-ctx-ftx! ctx ftx)
  (define fty (exact->inexact third-y))
  (set-l2-ctx-fty! ctx fty)
  (define has-nat? (>= active-bases 2))
  (set-l2-ctx-has-nat?! ctx has-nat?)
  (define has-third? (>= active-bases 3))
  (set-l2-ctx-has-third?! ctx has-third?)
  (define-values (raw-prox-sup distant-enemy-combat-supply)
    (if live-obs-harvesters?
        (for/fold ([prox 0.0] [dist-sup 0.0]) ([e (in-list rush-threat-enemies)])
          (define et (unit-type-sym e))
          (define min-d2 (l2-min-dist2-to-owned-base ctx (hash-ref e 'x fbx) (hash-ref e 'y fby)))
          (define base-sup
            (if (and rush-worker-swarm? (memq et '(probe scv drone)))
                1.5
                (unit-supply-cost et)))
          (if (<= min-d2 3025.0)
              (let* ([d (sqrt min-d2)]
                     [u (/ (max 0.0 (- d 28.0)) 18.0)]
                     [w (/ 1.0 (+ 1.0 (* u u)))])
                (values (+ prox (* w base-sup)) dist-sup))
              (values prox (+ dist-sup (unit-supply-cost et)))))
        (let ([prox (for/sum ([e (in-list rush-threat-enemies)])
                      (define et (unit-type-sym e))
                      (if (and rush-worker-swarm? (memq et '(probe scv drone)))
                          1.5
                          (unit-supply-cost et)))])
          (values prox 0))))
  (define proximate-enemy-threat-supply
    (+ proxy-structure-threat-supply (exact-round raw-prox-sup)))
  (define enemy-prod-bldg-cnt
    (for/sum ([eb (in-list enemy-bldgs)])
      (if (memq (unit-type-sym eb)
                '(barracks factory starport gateway warp-gate robotics-facility stargate
                  roach-warren hydralisk-den baneling-nest spire))
          1
          0)))
  (define implied-prod-threat-supply
    (if live-obs-harvesters?
        (* 2 (max 0 (- enemy-prod-bldg-cnt (+ 1 (* 2 (max 1 active-bases))))))
        (if (>= enemy-prod-bldg-cnt 2)
            (* 2 enemy-prod-bldg-cnt)
            0)))
  (define live-defending-force-supply
    (+ live-army-supply
       (* 2 (for/sum ([u (in-list ally-units)])
              (if (eq? (unit-type-sym u) 'queen) 1 0)))
       (* 2 (for/sum ([b (in-list ready-bldgs)])
              (if (memq (unit-type-sym b)
                        '(spine-crawler photon-cannon bunker planetary-fortress))
                  1
                  0)))))
  (define distant-excess-threat
    (if live-obs-harvesters?
        (max 0 (- (max distant-enemy-combat-supply implied-prod-threat-supply)
                  (+ live-defending-force-supply 8)))
        implied-prod-threat-supply))
  (define visible-enemy-threat-supply
    (+ proximate-enemy-threat-supply
       (if live-obs-harvesters? distant-excess-threat 0)))
  (define prev-rem-threat (hash-ref prev-tel-early 'remembered-enemy-threat-supply 0))
  (define prev-rem-frame (hash-ref prev-tel-early 'remembered-enemy-threat-frame -9999))
  (define rem-window-frames (if live-obs-harvesters? 224 672))
  (define cur-visible-or-implied-threat
    (if live-obs-harvesters?
        visible-enemy-threat-supply
        (max visible-enemy-threat-supply implied-prod-threat-supply)))
  (define-values (remembered-enemy-threat-supply remembered-enemy-threat-frame)
    (cond
      [(> cur-visible-or-implied-threat 0)
       (values (if (<= (- frame prev-rem-frame) rem-window-frames)
                   (max cur-visible-or-implied-threat prev-rem-threat)
                   cur-visible-or-implied-threat)
               frame)]
      [(and (> prev-rem-threat 0) (<= (- frame prev-rem-frame) rem-window-frames))
       (values prev-rem-threat prev-rem-frame)]
      [else
       (values 0 prev-rem-frame)]))
  (set-l2-ctx-remembered-enemy-threat-supply! ctx remembered-enemy-threat-supply)
  (set-l2-ctx-remembered-enemy-threat-frame! ctx remembered-enemy-threat-frame)
  (define raw-enemy-threat-supply
    (max visible-enemy-threat-supply remembered-enemy-threat-supply))
  (define live-enemy-threat-supply
    (if (and live-obs-harvesters?
             (not (hash-ref obs 'under-attack #f)))
        (max 0 (exact-round (- raw-enemy-threat-supply (* 0.85 live-defending-force-supply))))
        raw-enemy-threat-supply))
  (set-l2-ctx-live-enemy-threat-supply! ctx live-enemy-threat-supply)
  (define enemy-third-x (hash-ref obs 'enemy-third-x (safe-coord (* 0.72 enemy-x) 132.0)))
  (define enemy-third-y (hash-ref obs 'enemy-third-y (safe-coord (* 0.72 enemy-y) 132.0)))
  (define last-seen-main-frame
    (cond
      [(hash-has-key? obs 'last-seen-main-frame)
       (hash-ref obs 'last-seen-main-frame 0)]
      [(or (ormap (lambda (eb) (not (l2-enemy-bldg-is-proxy? ctx eb))) enemy-bldgs)
           (l2-enemy-seen-near? ctx enemy-x enemy-y 28.0)
           (l2-ally-has-vision-of? ctx enemy-x enemy-y))
       frame]
      [else
       (hash-ref prev-tel-early 'last-seen-main-frame 0)]))
  (set-l2-ctx-last-seen-main-frame! ctx last-seen-main-frame)
  (define last-seen-natural-frame
    (cond
      [(hash-has-key? obs 'last-seen-natural-frame)
       (hash-ref obs 'last-seen-natural-frame 0)]
      [(or (l2-enemy-seen-near? ctx enemy-exp-x enemy-exp-y 22.0)
           (l2-ally-has-vision-of? ctx enemy-exp-x enemy-exp-y))
       frame]
      [else
       (hash-ref prev-tel-early 'last-seen-natural-frame 0)]))
  (set-l2-ctx-last-seen-natural-frame! ctx last-seen-natural-frame)
  (define last-seen-third-frame
    (cond
      [(hash-has-key? obs 'last-seen-third-frame)
       (hash-ref obs 'last-seen-third-frame 0)]
      [(or (l2-enemy-seen-near? ctx enemy-third-x enemy-third-y 22.0)
           (l2-ally-has-vision-of? ctx enemy-third-x enemy-third-y))
       frame]
      [else
       (hash-ref prev-tel-early 'last-seen-third-frame 0)]))
  (set-l2-ctx-last-seen-third-frame! ctx last-seen-third-frame)
  (define last-seen-army-frame
    (cond
      [(hash-has-key? obs 'last-seen-army-frame)
       (hash-ref obs 'last-seen-army-frame 0)]
      [(or (not (null? enemy-units))
           (l2-enemy-seen-near? ctx corridor-mid-x corridor-mid-y 25.0)
           (and (>= frame 336) (l2-ally-has-vision-of? ctx corridor-mid-x corridor-mid-y)))
       frame]
      [else
       (hash-ref prev-tel-early 'last-seen-army-frame 0)]))
  (set-l2-ctx-last-seen-army-frame! ctx last-seen-army-frame)
  (define last-enemy-seen-frame
    (if (hash-has-key? obs 'last-enemy-seen-frame)
        (hash-ref obs 'last-enemy-seen-frame 0)
        (max last-seen-main-frame
             last-seen-natural-frame
             last-seen-third-frame
             last-seen-army-frame
             (if (or (not (null? enemy-units)) (not (null? enemy-bldgs)))
                 frame
                 (hash-ref prev-tel-early 'last-enemy-seen-frame 0)))))
  (set-l2-ctx-last-enemy-seen-frame! ctx last-enemy-seen-frame)
  (define intel-staleness-frames (max 0 (- frame last-enemy-seen-frame)))
  (set-l2-ctx-intel-staleness-frames! ctx intel-staleness-frames)
  (define intel-qual
    (evaluate-opponent-intel-quality
     #:frame frame
     #:last-seen-main-frame last-seen-main-frame
     #:last-seen-natural-frame last-seen-natural-frame
     #:last-seen-third-frame last-seen-third-frame
     #:last-seen-army-frame last-seen-army-frame
     #:intel-staleness-frames (if (and (<= last-seen-main-frame 0)
                                       (<= last-seen-natural-frame 0)
                                       (<= last-seen-army-frame 0))
                                  intel-staleness-frames
                                  #f)
     #:army-supply live-army-supply
     #:ally-units ally-combat-units))
  (define intel-freshness (opponent-intel-quality-freshness intel-qual))
  (set-l2-ctx-intel-freshness! ctx intel-freshness)
  (define intel-coverage (opponent-intel-quality-coverage intel-qual))
  (set-l2-ctx-intel-coverage! ctx intel-coverage)
  (define intel-confidence (opponent-intel-quality-confidence intel-qual))
  (set-l2-ctx-intel-confidence! ctx intel-confidence)
  (define intel-deficit (opponent-intel-quality-deficit intel-qual))
  (set-l2-ctx-intel-deficit! ctx intel-deficit)
  (define intel-priority-sector (opponent-intel-quality-priority-sector intel-qual))
  (set-l2-ctx-intel-priority-sector! ctx intel-priority-sector)
  (define intel-target-goal (opponent-intel-quality-target-goal intel-qual))
  (set-l2-ctx-intel-target-goal! ctx intel-target-goal)
  (define bldg-actively-damaged?
    (ormap (lambda (b) (eq? (hash-ref b 'under-attack #f) #t)) ally-bldgs))
  (set-l2-ctx-bldg-actively-damaged?! ctx bldg-actively-damaged?)
  (define enemy-inside-owned-base-perimeter?
    (ormap (lambda (e)
             (<= (l2-min-dist2-to-owned-base ctx (hash-ref e 'x 9999) (hash-ref e 'y 9999)) 784.0))
           rush-threat-enemies))
  (define enemy-attacking-base-or-nat?
    (or worker-rush-active?
        in-base-proxy-detected?
        under-early-cheese?
        bldg-actively-damaged?
        (and enemy-inside-owned-base-perimeter?
             (or (not live-obs-harvesters?)
                 (> live-enemy-threat-supply 0)
                 (<= live-defending-force-supply 2)))))
  (define under-base-attack?
    (or worker-rush-active?
        in-base-proxy-detected?
        enemy-attacking-base-or-nat?
        (and (> live-enemy-threat-supply 0)
             (> live-enemy-threat-supply (max 4 live-army-supply)))))
  (set-l2-ctx-under-base-attack?! ctx under-base-attack?)
  (define crisis-tech-upgrade-deferral?
    (and under-base-attack?
         (or (< live-army-supply (* 1.15 live-enemy-threat-supply))
             (< total-workers 30))))
  (set-l2-ctx-crisis-tech-upgrade-deferral?! ctx crisis-tech-upgrade-deferral?)
  (when (and (>= frame 448)
             (or (< intel-confidence 0.65)
                 (zero? (modulo frame 672)))
             (or (not live-obs-harvesters?)
                 (refractory-allow-action?! cd-tracker 'live-periodic-scout frame 96)))
    (define recon-tx
      (case intel-priority-sector
        [(enemy-natural) enemy-exp-x]
        [(enemy-main)    enemy-x]
        [(enemy-third)   enemy-third-x]
        [else            corridor-mid-x]))
    (define recon-ty
      (case intel-priority-sector
        [(enemy-natural) enemy-exp-y]
        [(enemy-main)    enemy-y]
        [(enemy-third)   enemy-third-y]
        [else            corridor-mid-y]))
    (case race
      [(Protoss)
       (define obs-unit (findf (lambda (u) (eq? (unit-type-sym u) 'observer)) ally-units))
       (when obs-unit
         (l2-emit! ctx (list 'periodic-scout (hash-ref obs-unit 'id 191) recon-tx recon-ty)))
       (define sentry-caster
         (findf (lambda (u)
                  (and (eq? (unit-type-sym u) 'sentry)
                       (>= (hash-ref u 'energy 0) 75)))
                ally-units))
       (when (and sentry-caster
                  (< intel-confidence 0.65)
                  (refractory-allow-action?! cd-tracker 'periodic-hallucination-scout frame 448))
         (l2-emit! ctx (list 'cast-deception-and-scout-spells
                      'sentry-hallucination-phoenix-scout
                      (hash-ref sentry-caster 'id 180)
                      recon-tx recon-ty)))]
      [(Zerg)
       (define ovs-caster
         (findf (lambda (u)
                  (and (eq? (unit-type-sym u) 'overseer)
                       (>= (hash-ref u 'energy 0) 50)))
                ally-units))
       (when (and ovs-caster
                  (refractory-allow-action?! cd-tracker 'periodic-changeling-scout frame 336))
         (l2-emit! ctx (list 'cast (hash-ref ovs-caster 'id 190) 'spawn-changeling recon-tx recon-ty)))]
      [(Terran)
       (define scan-oc
         (findf (lambda (b)
                  (and (eq? (unit-type-sym b) 'orbital-command)
                       (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                       (>= (hash-ref b 'energy 0) (if (>= frame 3000) 50 75))))
                ally-bldgs))
       (when (and scan-oc
                  (< intel-confidence 0.50)
                  (refractory-allow-action?! cd-tracker 'periodic-scanner-sweep frame 672))
         (l2-emit! ctx (list 'cast-spell (hash-ref scan-oc 'id 301) 'scanner-sweep recon-tx recon-ty)))])
    (define spotter-candidates
      (if (and live-obs-harvesters?
               (or under-base-attack? (< (length ally-combat-units) 6)))
          '()
          (filter (lambda (u)
                    (and (not (unit-leased-above? leases (hash-ref u 'id 0) 'army frame))
                         (memq (unit-type-sym u)
                               '(zergling reaper hellion adept marine stalker zealot mutalisk phoenix oracle))))
                  ally-combat-units)))
    (define chosen-spotter
      (and (not (null? spotter-candidates))
           (argmin (lambda (u)
                     (dist2d recon-tx recon-ty
                             (hash-ref u 'x base-x)
                             (hash-ref u 'y base-y)))
                   spotter-candidates)))
    (cond
      [chosen-spotter
       (l2-emit! ctx (list 'periodic-scout (hash-ref chosen-spotter 'id 101) recon-tx recon-ty))]
      [(and scout-worker-id
            (not live-obs-harvesters?)
            (< intel-confidence 0.65))
       (l2-emit! ctx (list 'periodic-scout scout-worker-id recon-tx recon-ty))]))
  (define live-game-obs? live-obs-harvesters?)
  (set-l2-ctx-live-game-obs?! ctx live-game-obs?)
  (define supply-threshold
    (cond
      [live-game-obs?
       (compute-production-coupled-supply-buffer
        #:active-bases active-bases
        #:production-facilities (length prod-facilities)
        #:workers total-workers
        #:target-workers target-workers
        #:min-buffer 2
        #:max-buffer 18)]
      [(>= supply-cap SC2-MID-SUPPLY-CAP-THRESHOLD) SC2-MID-SUPPLY-BUFFER]
      [(>= supply-cap SC2-EARLY-SUPPLY-CAP-THRESHOLD) SC2-EARLY-SUPPLY-BUFFER]
      [else SC2-BASE-SUPPLY-BUFFER]))
  (set-l2-ctx-supply-threshold! ctx supply-threshold)
  (define active-intel-method
    (select-intel-gathering-method
     #:race race
     #:frame frame
     #:army-supply live-army-supply
     #:ally-units ally-combat-units
     #:intel-staleness-frames intel-staleness-frames))
  (set-l2-ctx-active-intel-method! ctx active-intel-method)
  (define pressure-metrics
    (compute-state-pressure-metrics
     #:race race
     #:frame frame
     #:minerals (l2-ctx-minerals ctx)
     #:gas (l2-ctx-gas ctx)
     #:supply-left (l2-ctx-supply-left ctx)
     #:supply-cap supply-cap
     #:pending-supply (l2-ctx-pending-supply ctx)
     #:workers total-workers
     #:target-workers target-workers
     #:active-bases active-bases
     #:desired-bases desired-bases
     #:production-facilities (max 1 (length prod-facilities))
     #:max-facilities (max 2 (* SC2-TERRAN-FACILITIES-PER-BASE active-bases))
     #:army-supply live-army-supply
     #:enemy-threat-supply live-enemy-threat-supply
     #:under-attack? under-base-attack?
     #:requires-anti-air? (enemy-tech-observation-requires-anti-air? tech-obs)
     #:requires-detection? (enemy-tech-observation-requires-detection? tech-obs)
     #:intel-staleness-frames intel-staleness-frames
     #:intel-freshness intel-freshness
     #:intel-coverage intel-coverage
     #:intel-confidence intel-confidence
     #:supply-at-risk? supply-at-risk?
     #:supply-buffer (and live-game-obs? supply-threshold)))
  (set-l2-ctx-pressure-metrics! ctx pressure-metrics)
  (define max-pending-supply
    (cond
      [live-game-obs?
       (define cycle-providers
         (exact-ceiling (/ (exact->inexact (+ supply-threshold (if (<= (l2-ctx-supply-left ctx) 4) 4 0)))
                           (exact->inexact SC2-SUPPLY-PER-PROVIDER))))
       (max 1 (min 4 (if (and (eq? race 'Zerg)
                              (>= active-bases 3)
                              (<= (l2-ctx-supply-left ctx) (max 10 supply-threshold)))
                         (max 3 cycle-providers)
                         cycle-providers)))]
      [(and (< supply-cap SC2-MID-SUPPLY-CAP-THRESHOLD)
            (> (l2-ctx-supply-left ctx) 2))
       SC2-MAX-PENDING-SUPPLY-EARLY]
      [else SC2-MAX-PENDING-SUPPLY-LATE]))
  (define supply-credit-per-pending
    (if (and live-game-obs? (eq? race 'Zerg) (>= supply-cap 28))
        4
        SC2-SUPPLY-PER-PROVIDER))
  (define effective-supply-with-pending
    (+ (l2-ctx-supply-left ctx) (* supply-credit-per-pending (l2-ctx-pending-supply ctx))))
  (define wall-st (rt-wall-state rt))
  (set-l2-ctx-wall-st! ctx wall-st)
  (when (<= frame 4)
    (hash-clear! wall-st))
  (define real-pylon-count
    (if (eq? race 'Protoss)
        (count (lambda (b)
                 (and (hash? b)
                      (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'pylon)))
               ally-bldgs)
        0))
  (set-l2-ctx-real-pylon-count! ctx real-pylon-count)
  (define real-depot-count
    (if (eq? race 'Terran)
        (count (lambda (b)
                 (and (hash? b)
                      (memq (fast-canonical-structure-sym (unit-type-sym b))
                            '(supply-depot supply-depot-lowered))))
               ally-bldgs)
        0))
  (set-l2-ctx-real-depot-count! ctx real-depot-count)
  (define real-supply-bldg-count
    (case race
      [(Protoss) real-pylon-count]
      [(Terran) real-depot-count]
      [else 0]))
  (define any-worker-building-in-engine?
    (ormap worker-has-engine-build-order? workers))
  (define last-supply-issue-f (hash-ref wall-st 'supply-last-issue-frame #f))
  (define stale-phantom-wall-supply?
    (and live-game-obs?
         (memq race '(Protoss Terran))
         (= real-supply-bldg-count 0)
         (not any-worker-building-in-engine?)
         (exact-integer? last-supply-issue-f)
         (>= (- frame last-supply-issue-f) 16)))
  (when (and stale-phantom-wall-supply?
             (> last-supply-issue-f (hash-ref wall-st 'supply-failure-counted-at -1)))
    (hash-set! wall-st 'supply-failure-counted-at last-supply-issue-f)
    (hash-set! wall-st 'wall-supply-failures
               (add1 (hash-ref wall-st 'wall-supply-failures 0))))
  (define eff-pending-supply
    (if stale-phantom-wall-supply?
        (l2-ctx-pending-supply ctx)
        (max (l2-ctx-pending-supply ctx)
             (order-ledger-pending-count-for-type oledger supply-provider-sym frame))))
  (set-l2-ctx-eff-pending-supply! ctx eff-pending-supply)
  (define effective-supply-with-pending-ledger
    (+ (l2-ctx-supply-left ctx) (* supply-credit-per-pending eff-pending-supply)))
  (define protoss-pylon-count
    (count (lambda (t) (eq? t 'pylon)) (l2-ctx-bldg-types ctx)))
  (set-l2-ctx-protoss-pylon-count! ctx protoss-pylon-count)
  (define unpowered-protoss-bldg
    (and (eq? race 'Protoss)
         (findf (lambda (b)
                  (and (hash? b)
                       (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                       (sc2-structure-requires-pylon-power?
                        (fast-canonical-structure-sym (unit-type-sym b)))
                       (eq? (hash-ref b 'powered? #t) #f)))
                ally-bldgs)))
  (set-l2-ctx-unpowered-protoss-bldg! ctx unpowered-protoss-bldg)
  (define has-unpowered-bldg? (not (not unpowered-protoss-bldg)))
  (set-l2-ctx-has-unpowered-bldg?! ctx has-unpowered-bldg?)
  (define powered-protoss-bldg-count
    (if (eq? race 'Protoss)
        (count (lambda (b)
                 (and (hash? b)
                      (sc2-structure-requires-pylon-power?
                       (fast-canonical-structure-sym (unit-type-sym b)))))
               ally-bldgs)
        0))
  (define power-placement-failed?
    (and live-game-obs? (eq? (hash-ref obs 'power-placement-failed? #f) #t)))
  (set-l2-ctx-power-placement-failed?! ctx power-placement-failed?)
  (define protoss-power-grid-saturated?
    (and live-game-obs?
         (>= real-pylon-count 1)
         (< real-pylon-count 16)
         (<= (l2-ctx-supply-left ctx) 16)
         (>= (l2-ctx-minerals ctx) 300)
         (or (and power-placement-failed? (< real-pylon-count 16))
             (and (< real-pylon-count 10)
                  (>= powered-protoss-bldg-count (* 3 real-pylon-count)))
             (and (<= real-pylon-count 4)
                  (>= frame 2500)
                  (>= (l2-ctx-minerals ctx) 450)))))
  (define safe-inmain-pylon-count
    (if (eq? race 'Protoss)
        (count (lambda (b)
                 (and (hash? b)
                      (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'pylon)
                      (<= (dist2d base-x base-y
                                  (hash-ref b 'x -999.0)
                                  (hash-ref b 'y -999.0))
                          7.5)))
               ally-bldgs)
        0))
  (define protoss-emergency-pylon?
    (and (eq? race 'Protoss)
         (not (null? workers))
         (<= eff-pending-supply 0)
         (or (and (= protoss-pylon-count 0)
                  (or (> (length ally-bldgs) 1)
                      (>= supply-used 13)
                      (<= (l2-ctx-supply-left ctx) 0)
                      (and live-game-obs? (>= (l2-ctx-minerals ctx) 100) (< frame 3000))))
             (and live-game-obs?
                  (or worker-rush-active? in-base-proxy-detected?)
                  (= safe-inmain-pylon-count 0))
             has-unpowered-bldg?
             protoss-power-grid-saturated?)))
  (set-l2-ctx-protoss-emergency-pylon?! ctx protoss-emergency-pylon?)
  (define terran-depot-count
    (count (lambda (t) (eq? t 'supply-depot)) (l2-ctx-bldg-types ctx)))
  (define terran-emergency-depot?
    (and (eq? race 'Terran)
         (not (null? workers))
         (<= eff-pending-supply 0)
         (= terran-depot-count 0)
         (or (<= supply-cap (* 15 (max 1 active-bases)))
             (<= (l2-ctx-supply-left ctx) 0))
         (or (>= supply-used 13)
             (<= (l2-ctx-supply-left ctx) 0)
             (> (length ally-bldgs) 1)
             (and live-game-obs? (>= (l2-ctx-minerals ctx) 100) (< frame 3000)))))
  (set-l2-ctx-terran-emergency-depot?! ctx terran-emergency-depot?)
  (define need-supply?
    (and (< supply-cap SC2-MAX-SUPPLY)
         (< eff-pending-supply max-pending-supply)
         (or (and (<= eff-pending-supply 0)
                  (or (<= (l2-ctx-supply-left ctx) 0) (>= supply-used supply-cap)))
             (and supply-at-risk?
                  (or (<= eff-pending-supply 0) (hash-ref obs 'supply-at-risk #f))
                  (<= effective-supply-with-pending-ledger (+ supply-threshold SC2-SUPPLY-PER-PROVIDER)))
             (and (> (hash-ref pressure-metrics 'supply-hazard 0.0) 0.0)
                  (<= effective-supply-with-pending-ledger supply-threshold))
             (and (<= effective-supply-with-pending-ledger supply-threshold)
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost supply-provider-sym))))))
  (set-l2-ctx-need-supply?! ctx need-supply?)
  (define defer-f0-wall-solve?
    (and live-game-obs? (= frame 0) (< (l2-ctx-minerals ctx) 100)))
  (define terran-ramp-wall
    (cond
      [(or (not (eq? race 'Terran)) defer-f0-wall-solve?)
       (hash)]
      [else
       (let ([tkey (list base-x base-y nat-x nat-y (eq-hash-code map-grids))]
             [cached (hash-ref wall-st 'cached-terran-wall #f)])
         (if (and (pair? cached) (equal? (car cached) tkey))
             (cdr cached)
             (let ([res (solve-terran-ramp-wall base-x base-y nat-x nat-y #:map-grids map-grids)])
               (hash-set! wall-st 'cached-terran-wall (cons tkey res))
               res)))]))
  (set-l2-ctx-terran-ramp-wall! ctx terran-ramp-wall)
  (define protoss-matchup-wall
    (cond
      [(or (not (eq? race 'Protoss)) defer-f0-wall-solve?)
       (hash)]
      [else
       (let* ([force-main-ramp?
               (placement:should-wall-main-ramp-vs-random?
                race effective-enemy-race initial-enemy-race)]
              [pkey (list base-x base-y nat-x nat-y effective-enemy-race
                          initial-enemy-race force-main-ramp?
                          enemy-x enemy-y (eq-hash-code map-grids))]
              [cached (hash-ref wall-st 'cached-protoss-wall #f)])
         (if (and (pair? cached) (equal? (car cached) pkey))
             (cdr cached)
             (let ([res (solve-protoss-matchup-wall base-x base-y nat-x nat-y effective-enemy-race
                                                    #:map-grids map-grids
                                                    #:enemy-x enemy-x
                                                    #:enemy-y enemy-y
                                                    #:initial-enemy-race initial-enemy-race
                                                    #:force-main-ramp? force-main-ramp?)])
               (hash-set! wall-st 'cached-protoss-wall (cons pkey res))
               res)))]))
  (set-l2-ctx-protoss-matchup-wall! ctx protoss-matchup-wall)
  (define wall-supply-attempts (hash-ref wall-st 'wall-supply-attempts 0))
  (set-l2-ctx-wall-supply-attempts! ctx wall-supply-attempts)
  (define wall-supply-failures (hash-ref wall-st 'wall-supply-failures 0))
  (define wall-supply-first-f (hash-ref wall-st 'wall-supply-first-frame #f))
  (define bypass-wall-pylon?
    (and (eq? race 'Protoss)
         (or (and (or worker-rush-active? in-base-proxy-detected?)
                  (= safe-inmain-pylon-count 0))
             (and (= real-pylon-count 0)
                  (or (> wall-supply-failures 0)
                      (and (>= wall-supply-attempts 1)
                           (exact-integer? wall-supply-first-f)
                           (>= (- frame wall-supply-first-f) 24))
                      (and (> frame 650) (or (> wall-supply-attempts 0) live-game-obs?))
                      (and live-game-obs? (<= (l2-ctx-supply-left ctx) 0)))))))
  (set-l2-ctx-bypass-wall-pylon?! ctx bypass-wall-pylon?)
  (define bypass-wall-depot1?
    (and (eq? race 'Terran)
         (= real-depot-count 0)
         (or worker-rush-active?
             in-base-proxy-detected?
             (> wall-supply-failures 0)
             (and (>= wall-supply-attempts 1)
                  (exact-integer? wall-supply-first-f)
                  (>= (- frame wall-supply-first-f) 24))
             (and (> frame 650) (or (> wall-supply-attempts 0) live-game-obs?))
             (and live-game-obs? (<= (l2-ctx-supply-left ctx) 0)))))
  (set-l2-ctx-bypass-wall-depot1?! ctx bypass-wall-depot1?))

(define (l2-phase7-wall-counts! ctx)
  (define active-bases (l2-ctx-active-bases ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bypass-wall-depot1? (l2-ctx-bypass-wall-depot1? ctx))
  (define bypass-wall-pylon? (l2-ctx-bypass-wall-pylon? ctx))
  (define cg4-cap (l2-ctx-cg4-cap ctx))
  (define cg5-cap (l2-ctx-cg5-cap ctx))
  (define cg6-cap (l2-ctx-cg6-cap ctx))
  (define cg7-cap (l2-ctx-cg7-cap ctx))
  (define eff-pending-supply (l2-ctx-eff-pending-supply ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define expansion-pads (l2-ctx-expansion-pads ctx))
  (define frame (l2-ctx-frame ctx))
  (define has-unpowered-bldg? (l2-ctx-has-unpowered-bldg? ctx))
  (define live-game-obs? (l2-ctx-live-game-obs? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define need-supply? (l2-ctx-need-supply? ctx))
  (define obs (l2-ctx-obs ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define power-placement-failed? (l2-ctx-power-placement-failed? ctx))
  (define prod-facilities (l2-ctx-prod-facilities ctx))
  (define protoss-emergency-pylon? (l2-ctx-protoss-emergency-pylon? ctx))
  (define protoss-matchup-wall (l2-ctx-protoss-matchup-wall ctx))
  (define protoss-pylon-count (l2-ctx-protoss-pylon-count ctx))
  (define race (l2-ctx-race ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define ready-bldgs (l2-ctx-ready-bldgs ctx))
  (define real-depot-count (l2-ctx-real-depot-count ctx))
  (define real-pylon-count (l2-ctx-real-pylon-count ctx))
  (define rt (l2-ctx-rt ctx))
  (define supply-at-risk? (l2-ctx-supply-at-risk? ctx))
  (define supply-cap (l2-ctx-supply-cap ctx))
  (define supply-provider-sym (l2-ctx-supply-provider-sym ctx))
  (define supply-threshold (l2-ctx-supply-threshold ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define target-workers (l2-ctx-target-workers ctx))
  (define terran-emergency-depot? (l2-ctx-terran-emergency-depot? ctx))
  (define terran-ramp-wall (l2-ctx-terran-ramp-wall ctx))
  (define third-x (l2-ctx-third-x ctx))
  (define third-y (l2-ctx-third-y ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define unit-types (l2-ctx-unit-types ctx))
  (define unpowered-protoss-bldg (l2-ctx-unpowered-protoss-bldg ctx))
  (define wall-st (l2-ctx-wall-st ctx))
  (define wall-supply-attempts (l2-ctx-wall-supply-attempts ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define step-wall-aabbs
    (cond
      [(eq? race 'Terran)
       (filter values
               (list (let ([p (and (not bypass-wall-depot1?) (hash-ref terran-ramp-wall 'depot-1 #f))])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.0 1.0 'wall-slot 0 0)))
                     (let ([p (and (not bypass-wall-depot1?) (hash-ref terran-ramp-wall 'barracks #f))])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.5 1.5 'wall-slot 0 0)))
                     (let ([p (hash-ref terran-ramp-wall 'depot-2 #f)])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.0 1.0 'wall-slot 0 0)))
                     (let ([p (hash-ref terran-ramp-wall 'barracks-addon #f)])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.0 1.0 'terran-addon-pad 0 0)))))]
      [(eq? race 'Protoss)
       (filter values
               (list (let ([p (and (not bypass-wall-pylon?) (hash-ref protoss-matchup-wall 'pylon #f))])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.0 1.0 'wall-slot 0 0)))
                     (let ([p (and (not bypass-wall-pylon?) (hash-ref protoss-matchup-wall 'slot-1 #f))])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.5 1.5 'wall-slot 0 0)))
                     (let ([p (and (not bypass-wall-pylon?) (hash-ref protoss-matchup-wall 'slot-2 #f))])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.5 1.5 'wall-slot 0 0)))
                     (let ([p (and (not bypass-wall-pylon?) (hash-ref protoss-matchup-wall 'slot-3 #f))])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.5 1.5 'wall-slot 0 0)))
                     (let ([p (and (not bypass-wall-pylon?) (hash-ref protoss-matchup-wall 'door #f))])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.2 1.2 'doorway-corridor 0 0)))
                     (let ([p (and (not bypass-wall-pylon?) (hash-ref protoss-matchup-wall 'door-park #f))])
                       (and (pair? p) (reserved-aabb (car p) (cdr p) 1.2 1.2 'doorway-corridor 0 0)))))]
      [else '()]))
  (set-l2-ctx-step-wall-aabbs! ctx step-wall-aabbs)
  (set-box! (rt-wall-aabbs-box rt) step-wall-aabbs)
  (define allow-exact-wall-slot?
    (and (< frame 4000) (<= active-bases 2)))
  (set-l2-ctx-allow-exact-wall-slot?! ctx allow-exact-wall-slot?)
  (define explicit-larvae-early
    (count (lambda (u) (eq? (unit-type-sym u) 'larva)) ally-units))
  (define live-larva-tracking-early?
    (and live-game-obs?
         (ormap (lambda (u) (memq (unit-type-sym u) '(larva egg baneling-cocoon ravager-cocoon))) ally-units)))
  (define early-larvae-consumed 0)
  (when (and (or need-supply? protoss-emergency-pylon? terran-emergency-depot?)
             (>= (l2-ctx-minerals ctx) (sc2-min-cost supply-provider-sym)))
    (case race
      [(Zerg)
       (when (or (not live-larva-tracking-early?) (> explicit-larvae-early 0))
         (l2-recall-building-group! ctx 4)
         (l2-emit! ctx '(train overlord))
         (order-ledger-record-issued! oledger (+ 800000 (modulo frame 10000)) 'train 'overlord base-x base-y frame)
         (set! early-larvae-consumed (add1 early-larvae-consumed))
         (set-l2-ctx-minerals! ctx (- (l2-ctx-minerals ctx) (sc2-min-cost 'overlord)))
         (set-l2-ctx-pending-supply! ctx (add1 (l2-ctx-pending-supply ctx)))
         (set! eff-pending-supply (add1 eff-pending-supply)))]
      [(Protoss)
       (define wall-pylon-pt
         (and allow-exact-wall-slot?
              (not bypass-wall-pylon?)
              (= protoss-pylon-count 0)
              (not has-unpowered-bldg?)
              (hash-ref protoss-matchup-wall 'pylon #f)))
       (define use-exact-pylon? (pair? wall-pylon-pt))
       (define inmain-retry-idx (hash-ref wall-st 'inmain-supply-attempts 0))
       (define-values (em-px em-py)
         (l2-emergency-inmain-supply-anchor ctx
          (+ inmain-retry-idx (if power-placement-failed? (+ protoss-pylon-count 1) 0))))
       (define use-nat-pylon-anchor?
         (and live-game-obs?
              (>= active-bases 2)
              (>= protoss-pylon-count 2)
              (if power-placement-failed?
                  (even? inmain-retry-idx)
                  (odd? protoss-pylon-count))))
       (define raw-px
         (cond
           [use-exact-pylon? (safe-coord (car wall-pylon-pt) em-px)]
           [has-unpowered-bldg?
            (safe-coord (+ (hash-ref unpowered-protoss-bldg 'x (+ base-x 4.0)) 2.5) em-px)]
           [bypass-wall-pylon? em-px]
           [use-nat-pylon-anchor?
            (safe-coord (+ nat-x 4.5 (* 2.0 (modulo (quotient protoss-pylon-count 2) 3))) (+ base-x 4.0))]
           [power-placement-failed? em-px]
           [else (safe-coord (+ base-x 4.0 (* 2.5 (modulo protoss-pylon-count 4))))]))
       (define raw-py
         (cond
           [use-exact-pylon? (safe-coord (cdr wall-pylon-pt) em-py)]
           [has-unpowered-bldg?
            (safe-coord (+ (hash-ref unpowered-protoss-bldg 'y (+ base-y 4.0)) 0.5) em-py)]
           [bypass-wall-pylon? em-py]
           [use-nat-pylon-anchor?
            (safe-coord (+ nat-y 4.5 (* 2.0 (quotient protoss-pylon-count 6))) (+ base-y 4.0))]
           [power-placement-failed? em-py]
           [else (safe-coord (+ base-y 4.0 (* 2.5 (quotient protoss-pylon-count 4))))]))
       (define-values (px py)
         (order-ledger-resolve-build-coords!
          oledger 'pylon raw-px raw-py ally-bldgs frame 2.5
          #:expansion-pads expansion-pads
          #:exact-wall-slot? use-exact-pylon?
          #:reserved-aabbs (l2-wall-aabbs-for-build ctx use-exact-pylon?)))
       (define sx (safe-coord px raw-px))
       (define sy (safe-coord py raw-py))
       (when (= real-pylon-count 0)
         (hash-set! wall-st 'supply-last-issue-frame frame)
         (when use-exact-pylon?
           (unless (hash-has-key? wall-st 'wall-supply-first-frame)
             (hash-set! wall-st 'wall-supply-first-frame frame))
           (hash-set! wall-st 'wall-supply-attempts (add1 wall-supply-attempts))))
       (when (and (not use-exact-pylon?)
                  (or (= real-pylon-count 0) power-placement-failed?))
         (hash-set! wall-st 'inmain-supply-attempts (add1 inmain-retry-idx)))
       (l2-emit! ctx (list 'build 'pylon sx sy))
       (order-ledger-record-issued! oledger (+ 800000 (modulo frame 10000)) 'build 'pylon sx sy frame)
       (set-l2-ctx-bldg-types! ctx (cons 'pylon (l2-ctx-bldg-types ctx)))
       (set-l2-ctx-minerals! ctx (- (l2-ctx-minerals ctx) (sc2-min-cost 'pylon)))
       (set-l2-ctx-pending-supply! ctx (add1 (l2-ctx-pending-supply ctx)))
       (set! eff-pending-supply (add1 eff-pending-supply))]
      [(Terran)
       (define depot-count
         (count (lambda (t) (eq? t 'supply-depot)) (l2-ctx-bldg-types ctx)))
       (define wall-depot-entry
         (and allow-exact-wall-slot?
              (cond
                [(and (= depot-count 0) (not bypass-wall-depot1?))
                 (hash-ref terran-ramp-wall 'depot-1 #f)]
                [(= depot-count 1)
                 (hash-ref terran-ramp-wall 'depot-2 #f)]
                [else #f])))
       (define use-exact-depot? (pair? wall-depot-entry))
       (define inmain-retry-idx (hash-ref wall-st 'inmain-supply-attempts 0))
       (define-values (em-dx em-dy) (l2-emergency-inmain-supply-anchor ctx inmain-retry-idx))
       (define raw-dx
         (cond
           [use-exact-depot? (safe-coord (car wall-depot-entry) em-dx)]
           [(and (= depot-count 0) bypass-wall-depot1?) em-dx]
           [else (safe-coord (+ base-x 4.0 (* 2.5 (modulo depot-count 4))))]))
       (define raw-dy
         (cond
           [use-exact-depot? (safe-coord (cdr wall-depot-entry) em-dy)]
           [(and (= depot-count 0) bypass-wall-depot1?) em-dy]
           [else (safe-coord (- base-y 3.0 (* 2.5 (quotient depot-count 4))))]))
       (define-values (dx dy)
         (order-ledger-resolve-build-coords!
          oledger 'supply-depot raw-dx raw-dy ally-bldgs frame 2.0
          #:expansion-pads expansion-pads
          #:exact-wall-slot? use-exact-depot?
          #:reserved-aabbs (l2-wall-aabbs-for-build ctx use-exact-depot?)))
       (define sx (safe-coord dx raw-dx))
       (define sy (safe-coord dy raw-dy))
       (when (= real-depot-count 0)
         (hash-set! wall-st 'supply-last-issue-frame frame)
         (cond
           [use-exact-depot?
            (unless (hash-has-key? wall-st 'wall-supply-first-frame)
              (hash-set! wall-st 'wall-supply-first-frame frame))
            (hash-set! wall-st 'wall-supply-attempts (add1 wall-supply-attempts))]
           [else
            (hash-set! wall-st 'inmain-supply-attempts (add1 inmain-retry-idx))]))
       (l2-emit! ctx (list 'build 'supply-depot sx sy))
       (order-ledger-record-issued! oledger (+ 800000 (modulo frame 10000)) 'build 'supply-depot sx sy frame)
       (set-l2-ctx-bldg-types! ctx (cons 'supply-depot (l2-ctx-bldg-types ctx)))
       (set-l2-ctx-minerals! ctx (- (l2-ctx-minerals ctx) (sc2-min-cost 'supply-depot)))
       (set-l2-ctx-pending-supply! ctx (add1 (l2-ctx-pending-supply ctx)))
       (set! eff-pending-supply (add1 eff-pending-supply))]
      [else (void)]))
  (define hard-supply-lockout?
    (and (< supply-cap SC2-MAX-SUPPLY)
         (<= eff-pending-supply 0)
         (or (<= (l2-ctx-supply-left ctx) 0)
             (>= supply-used supply-cap)
             (and (<= (l2-ctx-supply-left ctx) 1)
                  (<= supply-cap (* 15 (max 1 active-bases)))
                  (or (and (eq? race 'Protoss) (= real-pylon-count 0) (>= supply-used 14))
                      (and (eq? race 'Terran) (= real-depot-count 0) (>= supply-used 14)))))))
  (set-l2-ctx-hard-supply-lockout?! ctx hard-supply-lockout?)
  (define hard-supply-lockout-reserve-min
    (if hard-supply-lockout?
        (sc2-min-cost supply-provider-sym)
        0))
  (set-l2-ctx-hard-supply-lockout-reserve-min! ctx hard-supply-lockout-reserve-min)
  (define zerg-emergency-rush-lings?
    (and (eq? race 'Zerg)
         worker-rush-active?
         (< (count (lambda (t) (eq? t 'zergling)) unit-types) 4)))
  (define zerg-hold-overlord-min?
    (and live-game-obs?
         (eq? race 'Zerg)
         (not zerg-emergency-rush-lings?)
         (< supply-cap SC2-MAX-SUPPLY)
         (>= supply-used 14)
         (or (and (<= eff-pending-supply 0)
                  (or supply-at-risk?
                      (<= (l2-ctx-supply-left ctx) (if (and (<= active-bases 1) (<= (length prod-facilities) 1) (<= total-workers 15)) 1 supply-threshold))))
             (and (>= active-bases 3)
                  (= eff-pending-supply 1)
                  (<= (l2-ctx-supply-left ctx) 4)))))
  (set-l2-ctx-zerg-hold-overlord-min?! ctx zerg-hold-overlord-min?)
  (define reserve-supply-floor?
    (and (not zerg-emergency-rush-lings?)
         (<= eff-pending-supply 0)
         (or (not live-game-obs?) (>= supply-used 14))
         (or supply-at-risk?
             (<= (l2-ctx-supply-left ctx) (if (and live-game-obs? (< supply-cap 20)) 1 SC2-CRITICAL-LOW-SUPPLY)))
         (< (l2-ctx-minerals ctx) (+ (sc2-min-cost supply-provider-sym) (sc2-min-cost 'drone)))))
  (set-l2-ctx-reserve-supply-floor?! ctx reserve-supply-floor?)
  (set-l2-ctx-effective-free-supply! ctx
    (max 0 (+ (l2-ctx-supply-left ctx) (if (> eff-pending-supply 0) SC2-PENDING-SUPPLY-CREDIT 0))))
  (define researched-upgs (hash-ref obs 'researched-upgrades '()))
  (set-l2-ctx-researched-upgs! ctx researched-upgs)
  (set-l2-ctx-pending-upgs! ctx (hash-ref obs 'pending-upgrades '()))
  (define ledger-unit-orders (in-progress-order-ledger-unit-orders oledger))
  (set-l2-ctx-morphing-bldg-types! ctx
    (for/list ([b (in-list ally-bldgs)]
               #:when (hash? b)
               #:do [(define ms
                       (case (hash-ref b 'order-ability-id 0)
                         [(1516) 'orbital-command]
                         [(1450) 'planetary-fortress]
                         [(1216) 'lair]
                         [(1218) 'hive]
                         [(1220) 'greater-spire]
                         [(2112) 'lurker-den]
                         [else #f]))]
               #:when (and ms
                           (let ([tord (hash-ref ledger-unit-orders (hash-ref b 'id -1) #f)])
                             (not (and tord (eq? (tracked-order-kind tord) 'morph))))))
      ms))
  (set-l2-ctx-ally-canon-bldg-counts-ht! ctx #f)
  (define SIMCITY-EXCLUDED-BLDG-SYMS
    '(hatchery lair hive nexus command-center orbital-command planetary-fortress
      extractor extractor-rich assimilator assimilator-rich refinery refinery-rich
      spine-crawler spore-crawler photon-cannon shield-battery missile-turret bunker sensor-tower
      creep-tumor pylon supply-depot supply-depot-lowered
      tech-lab reactor barracks-techlab barracks-reactor factory-techlab factory-reactor
      starport-techlab starport-reactor nydus-worm))
  (set-l2-ctx-SIMCITY-EXCLUDED-BLDG-SYMS! ctx SIMCITY-EXCLUDED-BLDG-SYMS)
  (define ready-bldg-counts
    (let ([mht (make-hasheq)])
      (for ([t (in-list ready-bldg-types)])
        (define cs (fast-canonical-structure-sym t))
        (hash-set! mht cs (add1 (hash-ref mht cs 0))))
      (for/hash ([(k v) (in-hash mht)]) (values k v))))
  (set-l2-ctx-ready-bldg-counts! ctx ready-bldg-counts)
  (define pending-order-types-ht (in-progress-order-ledger-type-order-counts oledger))
  (define has-pending-orders? (> (hash-count pending-order-types-ht) 0))
  (define total-bldg-counts
    (let ([mht (make-hasheq)])
      (for ([t (in-list (l2-ctx-bldg-types ctx))])
        (define cs (fast-canonical-structure-sym t))
        (hash-set! mht cs (add1 (hash-ref mht cs 0))))
      (for ([t (in-list (l2-ctx-morphing-bldg-types ctx))])
        (define cs (fast-canonical-structure-sym t))
        (hash-set! mht cs (add1 (hash-ref mht cs 0))))
      (when has-pending-orders?
        (define bldg-syms-to-check
          (case race
            [(Zerg) ZERG-MACRO-BLDG-SYMS]
            [(Protoss) PROTOSS-MACRO-BLDG-SYMS]
            [(Terran) TERRAN-MACRO-BLDG-SYMS]
            [else ALL-MACRO-BLDG-SYMS]))
        (for ([sym (in-list bldg-syms-to-check)])
          (define pend (order-ledger-pending-count-for-type oledger sym frame))
          (when (> pend 0)
            (define csym (fast-canonical-structure-sym sym))
            (hash-set! mht csym (+ (hash-ref mht csym 0) pend)))))
      (for/hash ([(k v) (in-hash mht)]) (values k v))))
  (set-l2-ctx-total-bldg-counts! ctx total-bldg-counts)
  (define-values (real-ally-units cocoon-unit-counts _l2-init-unit-counts)
    (let ([real-rev '()]
          [m-cocoons (make-hasheq)]
          [m-units (make-hasheq)])
      (for ([u (in-list ally-units)])
        (when (and (hash? u)
                   (not (eq? (hash-ref u 'is-hallucination #f) #t))
                   (not (eq? (hash-ref u 'hallucination #f) #t))
                   (not (eq? (hash-ref u 'hallucination? #f) #t)))
          (set! real-rev (cons u real-rev))
          (define raw-ut (unit-type-sym u))
          (case raw-ut
            [(baneling-cocoon)   (hash-set! m-cocoons 'baneling (add1 (hash-ref m-cocoons 'baneling 0)))]
            [(ravager-cocoon)    (hash-set! m-cocoons 'ravager (add1 (hash-ref m-cocoons 'ravager 0)))]
            [(lurker-egg lurker-mp-egg) (hash-set! m-cocoons 'lurker (add1 (hash-ref m-cocoons 'lurker 0)))]
            [(brood-lord-cocoon) (hash-set! m-cocoons 'brood-lord (add1 (hash-ref m-cocoons 'brood-lord 0)))]
            [(overlord-cocoon)   (hash-set! m-cocoons 'overseer (add1 (hash-ref m-cocoons 'overseer 0)))])
          (unless (hash-has-key? EXCLUDED-MACRO-UNIT-COUNT-HT raw-ut)
            (define cu (fast-canonical-unit-sym raw-ut))
            (hash-set! m-units cu (add1 (hash-ref m-units cu 0))))))
      (when has-pending-orders?
        (define unit-syms-to-check
          (case race
            [(Zerg) ZERG-MACRO-UNIT-SYMS]
            [(Protoss) PROTOSS-MACRO-UNIT-SYMS]
            [(Terran) TERRAN-MACRO-UNIT-SYMS]
            [else ALL-MACRO-UNIT-SYMS]))
        (for ([usym (in-list unit-syms-to-check)])
          (define raw-pend
            (+ (order-ledger-pending-count-for-type oledger usym frame)
               (if (eq? usym 'viking)
                   (order-ledger-pending-count-for-type oledger 'viking-fighter frame)
                   0)))
          (define eff-pend
            (max 0 (- raw-pend (hash-ref m-cocoons usym 0))))
          (when (> eff-pend 0)
            (hash-set! m-units usym (+ (hash-ref m-units usym 0) eff-pend)))))
      (values (reverse real-rev)
              (for/hash ([(k v) (in-hash m-cocoons)]) (values k v))
              (for/hash ([(k v) (in-hash m-units)]) (values k v)))))
  (set-l2-ctx-unit-counts! ctx _l2-init-unit-counts)
  (define enemy-race-guess effective-enemy-race)
  (define prev-telemetry-ht
    (let ([t (live-bot-runtime-last-telemetry rt)])
      (if (hash? t) t (hash))))
  (set-l2-ctx-prev-telemetry-ht! ctx prev-telemetry-ht)
  (define cur-peak-supply
    (max supply-used (hash-ref prev-telemetry-ht 'peak-supply-reached 0)))
  (set-l2-ctx-cur-peak-supply! ctx cur-peak-supply)
  (define eff-phase-supply (max supply-used cur-peak-supply))
  (set-l2-ctx-eff-phase-supply! ctx eff-phase-supply)
  (define mb-pair
    (let ([v (unbox (rt-macro-bundle-cache rt))])
      (if (and (pair? v) (vector? (car v)) (vector? (cdr v)))
          v
          (let ([p (cons (make-vector 20 #f) (make-vector 38 #f))])
            (vector-set! (car p) 0 -1)
            (vector-set! (cdr p) 0 -1)
            (set-box! (rt-macro-bundle-cache rt) p)
            p))))
  (define bo-cv (car mb-pair))
  (define mc-cv (cdr mb-pair))
  (set-l2-ctx-mc-cv! ctx mc-cv)
  (define min-bkt25 (quotient (min (max (l2-ctx-minerals ctx) 0) 800) 25))
  (set-l2-ctx-min-bkt25! ctx min-bkt25)
  (define gas-bkt25 (quotient (min (max (l2-ctx-gas ctx) 0) 600) 25))
  (set-l2-ctx-gas-bkt25! ctx gas-bkt25)
  (define sup-left-key (if (<= (l2-ctx-supply-left ctx) 8) (l2-ctx-supply-left ctx) (quotient (l2-ctx-supply-left ctx) 4)))
  (set-l2-ctx-sup-left-key! ctx sup-left-key)
  (define bo-cache-ok?
    (and live-game-obs?
         (> frame 60)
         (let ([cf (vector-ref bo-cv 0)])
           (and (exact-integer? cf) (>= frame cf) (< (- frame cf) 16)))
         (eq? (vector-ref bo-cv 2) race)
         (eq? (vector-ref bo-cv 3) effective-enemy-race)
         (= (vector-ref bo-cv 4) min-bkt25)
         (= (vector-ref bo-cv 5) gas-bkt25)
         (= (vector-ref bo-cv 6) eff-phase-supply)
         (= (vector-ref bo-cv 7) sup-left-key)
         (= (vector-ref bo-cv 8) active-bases)
         (equal? (vector-ref bo-cv 9) ready-bldg-counts)
         (equal? (vector-ref bo-cv 10) total-bldg-counts)
         (equal? (vector-ref bo-cv 11) (l2-ctx-unit-counts ctx))
         (equal? (vector-ref bo-cv 12) researched-upgs)
         (equal? (vector-ref bo-cv 13) (l2-ctx-pending-upgs ctx))
         (equal? (vector-ref bo-cv 14) base-x)
         (equal? (vector-ref bo-cv 15) base-y)
         (equal? (vector-ref bo-cv 16) nat-x)
         (equal? (vector-ref bo-cv 17) nat-y)
         (equal? (vector-ref bo-cv 18) third-x)
         (equal? (vector-ref bo-cv 19) third-y)))
  (define bo-eval
    (if bo-cache-ok?
        (vector-ref bo-cv 1)
        (let ([res
               (evaluate-build-order-next-step
                #:race race
                #:enemy-race effective-enemy-race
                #:frame frame
                #:minerals (l2-ctx-minerals ctx)
                #:gas (l2-ctx-gas ctx)
                #:supply-used eff-phase-supply
                #:supply-left (l2-ctx-supply-left ctx)
                #:active-bases active-bases
                #:ready-building-counts ready-bldg-counts
                #:total-building-counts total-bldg-counts
                #:unit-counts (l2-ctx-unit-counts ctx)
                #:researched-upgrades researched-upgs
                #:pending-upgrades (l2-ctx-pending-upgs ctx)
                #:base-x base-x #:base-y base-y
                #:nat-x nat-x #:nat-y nat-y
                #:third-x third-x #:third-y third-y)])
          (when (and live-game-obs? (> frame 60))
            (vector-set! bo-cv 0 frame)
            (vector-set! bo-cv 1 res)
            (vector-set! bo-cv 2 race)
            (vector-set! bo-cv 3 effective-enemy-race)
            (vector-set! bo-cv 4 min-bkt25)
            (vector-set! bo-cv 5 gas-bkt25)
            (vector-set! bo-cv 6 eff-phase-supply)
            (vector-set! bo-cv 7 sup-left-key)
            (vector-set! bo-cv 8 active-bases)
            (vector-set! bo-cv 9 ready-bldg-counts)
            (vector-set! bo-cv 10 total-bldg-counts)
            (vector-set! bo-cv 11 (l2-ctx-unit-counts ctx))
            (vector-set! bo-cv 12 researched-upgs)
            (vector-set! bo-cv 13 (l2-ctx-pending-upgs ctx))
            (vector-set! bo-cv 14 base-x)
            (vector-set! bo-cv 15 base-y)
            (vector-set! bo-cv 16 nat-x)
            (vector-set! bo-cv 17 nat-y)
            (vector-set! bo-cv 18 third-x)
            (vector-set! bo-cv 19 third-y))
          res)))
  (set-l2-ctx-bo-eval! ctx bo-eval)
  (define bo-active-goal (pro-bo-eval-result-active-goal bo-eval))
  (set-l2-ctx-bo-active-goal! ctx bo-active-goal)
  (define bo-goal-sym (and bo-active-goal (pro-bo-goal-target-sym bo-active-goal)))
  (set-l2-ctx-bo-goal-sym! ctx bo-goal-sym)
  (set-l2-ctx-bo-reserved-min! ctx (pro-bo-eval-result-reserved-minerals bo-eval))
  (set-l2-ctx-bo-reserved-gas! ctx (pro-bo-eval-result-reserved-gas bo-eval))
  (set! target-workers (max target-workers (pro-bo-eval-result-target-workers bo-eval)))
  (define open-prod-slots (make-hash))
  (set-l2-ctx-open-prod-slots! ctx open-prod-slots)
  (for ([cap (in-list (list cg4-cap cg5-cap cg6-cap cg7-cap))])
    (for ([(btype cnt) (in-hash (hash-ref cap 'open-slots-by-type (hash)))])
      (define norm-k (l2-normalize-facility-slot-sym ctx btype))
      (hash-update! open-prod-slots norm-k (lambda (old) (+ old cnt)) 0)))
  (define fallback-prod-slots (make-hash))
  (define-values (terran-rax-techlab-bldgs terran-rax-reactor-bldgs)
    (if (eq? race 'Terran)
        (let ([tl '()] [rc '()])
          (for ([ab (in-list ally-bldgs)])
            (define ut (unit-type-sym ab))
            (cond
              [(memq ut '(barracks-techlab barracks-tech-lab tech-lab techlab))
               (set! tl (cons ab tl))]
              [(memq ut '(barracks-reactor reactor))
               (set! rc (cons ab rc))]))
          (values tl rc))
        (values '() '())))
  (set-l2-ctx-terran-rax-techlab-bldgs! ctx terran-rax-techlab-bldgs)
  (set-l2-ctx-terran-rax-reactor-bldgs! ctx terran-rax-reactor-bldgs)
  (define rax-techlab-open-slots 0)
  (define rax-basic-open-slots 0)
  (for ([b (in-list ready-bldgs)])
    (define bt (fast-canonical-structure-sym (unit-type-sym b)))
    (define norm-k (l2-normalize-facility-slot-sym ctx bt))
    (define raw-ords (hash-ref b 'order-count SANITIZE-MISSING))
    (define b-ords
      (if (eq? raw-ords SANITIZE-MISSING)
          (let ([o (hash-ref b 'orders '())]) (if (list? o) (length o) 0))
          raw-ords))
    (define rax-addon (and (eq? bt 'barracks) (l2-barracks-addon-kind ctx b)))
    (define b-max (if (or (eq? (hash-ref b 'addon #f) 'reactor)
                          (eq? rax-addon 'reactor))
                      2
                      1))
    (define b-open (if (or (eq? (hash-ref b 'busy? #f) #t)
                           (eq? (hash-ref b 'in-transit? #f) #t)
                           (and (eq? race 'Protoss)
                                (fast-requires-pylon-power? bt)
                                (eq? (hash-ref b 'powered? #t) #f))
                           (order-ledger-facility-busy? oledger b frame))
                       0
                       (max 0 (- b-max b-ords))))
    (when (eq? bt 'barracks)
      (if (eq? rax-addon 'techlab)
          (set! rax-techlab-open-slots (+ rax-techlab-open-slots b-open))
          (set! rax-basic-open-slots (+ rax-basic-open-slots b-open))))
    (hash-set! fallback-prod-slots norm-k
               (+ (hash-ref fallback-prod-slots norm-k 0) b-open)))
  (for ([(norm-k cnt) (in-hash fallback-prod-slots)])
    (when (> cnt (hash-ref open-prod-slots norm-k 0))
      (hash-set! open-prod-slots norm-k cnt)))
  (hash-set! open-prod-slots 'barracks-techlab-open rax-techlab-open-slots)
  (hash-set! open-prod-slots 'barracks-basic-open rax-basic-open-slots)
  (define explicit-larvae 0)
  (define live-larva-tracking? #f)
  (for ([u (in-list ally-units)])
    (define ut (unit-type-sym u))
    (cond
      [(eq? ut 'larva)
       (set! explicit-larvae (add1 explicit-larvae))
       (set! live-larva-tracking? #t)]
      [(or (eq? ut 'egg) (eq? ut 'baneling-cocoon) (eq? ut 'ravager-cocoon))
       (set! live-larva-tracking? #t)]))
  (hash-set! open-prod-slots 'larva
             (if live-larva-tracking?
                 (max 0 (- explicit-larvae early-larvae-consumed))
                 (* 3 (max 1 active-bases))))
  (define morph-source-counts (make-hasheq))
  (for ([u (in-list real-ally-units)])
    (define cs (fast-canonical-unit-sym (unit-type-sym u)))
    (case cs
      [(zergling roach hydralisk corruptor overlord high-templar dark-templar)
       (define uid (hash-ref u 'id -1))
       (define tord (hash-ref ledger-unit-orders uid #f))
       (when (and (not (and tord (eq? (tracked-order-kind tord) 'morph)))
                  (not (eq? (fast-order-protection-class (hash-ref u 'order-ability-id 0)) 'morph)))
         (hash-set! morph-source-counts cs (add1 (hash-ref morph-source-counts cs 0))))]))
  (for ([msym (in-list '(zergling roach hydralisk corruptor overlord high-templar dark-templar))])
    (hash-set! open-prod-slots msym (hash-ref morph-source-counts msym 0)))
  (define live-game? live-game-obs?)
  (set-l2-ctx-live-game?! ctx live-game?)
  (define open-prod-slots-snapshot
    (and live-game?
         (for/hasheq ([(k v) (in-hash open-prod-slots)])
           (values k v))))
  (set-l2-ctx-open-prod-slots-snapshot! ctx open-prod-slots-snapshot))

(define (l2-phase8-macro-escrow! ctx)
  (define active-bases (l2-ctx-active-bases ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bo-active-goal (l2-ctx-bo-active-goal ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define cur-peak-supply (l2-ctx-cur-peak-supply ctx))
  (define desired-bases (l2-ctx-desired-bases ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define eff-pending-supply (l2-ctx-eff-pending-supply ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define frame (l2-ctx-frame ctx))
  (define gas-bkt25 (l2-ctx-gas-bkt25 ctx))
  (define hard-supply-lockout? (l2-ctx-hard-supply-lockout? ctx))
  (define has-gas-harvesters? (l2-ctx-has-gas-harvesters? ctx))
  (define intel-confidence (l2-ctx-intel-confidence ctx))
  (define intel-staleness-frames (l2-ctx-intel-staleness-frames ctx))
  (define l2-sc (l2-ctx-l2-sc ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define live-gas-harvesters (l2-ctx-live-gas-harvesters ctx))
  (define live-obs-harvesters? (l2-ctx-live-obs-harvesters? ctx))
  (define mc-cv (l2-ctx-mc-cv ctx))
  (define min-bkt25 (l2-ctx-min-bkt25 ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define non-building-workers (l2-ctx-non-building-workers ctx))
  (define obs (l2-ctx-obs ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define open-prod-slots-snapshot (l2-ctx-open-prod-slots-snapshot ctx))
  (define prev-telemetry-ht (l2-ctx-prev-telemetry-ht ctx))
  (define prod-facilities (l2-ctx-prod-facilities ctx))
  (define race (l2-ctx-race ctx))
  (define raw-obs (l2-ctx-raw-obs ctx))
  (define ready-bldg-counts (l2-ctx-ready-bldg-counts ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define researched-upgs (l2-ctx-researched-upgs ctx))
  (define sup-left-key (l2-ctx-sup-left-key ctx))
  (define supply-at-risk? (l2-ctx-supply-at-risk? ctx))
  (define supply-cap (l2-ctx-supply-cap ctx))
  (define supply-provider-sym (l2-ctx-supply-provider-sym ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define third-x (l2-ctx-third-x ctx))
  (define third-y (l2-ctx-third-y ctx))
  (define total-bldg-counts (l2-ctx-total-bldg-counts ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define has-explicit-gas-harvesters?
    (or has-gas-harvesters?
        (hash-has-key? raw-obs 'vespene-harvesters)))
  (define eff-gas-harvesters
    (if has-explicit-gas-harvesters?
        (safe-nonneg-int (or live-gas-harvesters (hash-ref obs 'vespene-harvesters 0)) 0)
        (if (> (l2-ctx-gas ctx) 0) 3 0)))
  (define eff-min-harvesters
    (if live-obs-harvesters?
        (max (safe-nonneg-int (hash-ref obs 'mineral-harvesters 0) 0)
             (max 0 (- (length non-building-workers)
                       (+ (length (l2-ctx-cur-rush-fighting-wids ctx))
                          (length (l2-ctx-cur-rush-disengaging-wids ctx))))))
        (and (= total-workers 0) 0)))
  (define enemy-u-counts
    (let ([m (pooled-hasheq! l2-sc 'enemy-u-counts-m)])
      (for ([eu (in-list enemy-units)])
        (define sym (unit-type-sym eu))
        (hash-set! m sym (+ 1 (hash-ref m sym 0))))
      (reuse-or-freeze-hasheq! l2-sc 'enemy-u-counts-immut m)))
  (set-l2-ctx-enemy-u-counts! ctx enemy-u-counts)
  (define eff-gas-harv-arg (and has-explicit-gas-harvesters? eff-gas-harvesters))
  (define req-aa? (enemy-tech-observation-requires-anti-air? tech-obs))
  (define req-det? (enemy-tech-observation-requires-detection? tech-obs))
  (define sup-used-bkt (quotient (max supply-used 0) 4))
  (define pend-sup-key (min eff-pending-supply 8))
  (define macro-cache-ok?
    (and live-game?
         (> frame 60)
         (let ([cf (vector-ref mc-cv 0)])
           (and (exact-integer? cf) (>= frame cf) (< (- frame cf) 16)))
         (eq? (vector-ref mc-cv 6) race)
         (eq? (vector-ref mc-cv 7) effective-enemy-race)
         (= (vector-ref mc-cv 8) min-bkt25)
         (= (vector-ref mc-cv 9) gas-bkt25)
         (= (vector-ref mc-cv 10) sup-used-bkt)
         (= (vector-ref mc-cv 11) supply-cap)
         (= (vector-ref mc-cv 12) sup-left-key)
         (= (vector-ref mc-cv 13) pend-sup-key)
         (= (vector-ref mc-cv 14) total-workers)
         (= (vector-ref mc-cv 15) active-bases)
         (= (vector-ref mc-cv 16) eff-min-harvesters)
         (equal? (vector-ref mc-cv 17) eff-gas-harv-arg)
         (equal? (vector-ref mc-cv 18) ready-bldg-counts)
         (equal? (vector-ref mc-cv 19) total-bldg-counts)
         (equal? (vector-ref mc-cv 20) (l2-ctx-unit-counts ctx))
         (equal? (vector-ref mc-cv 21) enemy-u-counts)
         (equal? (vector-ref mc-cv 22) researched-upgs)
         (equal? (vector-ref mc-cv 23) (l2-ctx-pending-upgs ctx))
         (equal? (vector-ref mc-cv 24) open-prod-slots-snapshot)
         (equal? (vector-ref mc-cv 25) live-army-supply)
         (equal? (vector-ref mc-cv 26) live-enemy-threat-supply)
         (eq? (vector-ref mc-cv 27) (not (not under-base-attack?)))
         (eq? (vector-ref mc-cv 28) (not (not req-aa?)))
         (eq? (vector-ref mc-cv 29) (not (not req-det?)))
         (eq? (vector-ref mc-cv 30) (not (not supply-at-risk?)))
         (= (vector-ref mc-cv 31) cur-peak-supply)
         (equal? (vector-ref mc-cv 32) base-x)
         (equal? (vector-ref mc-cv 33) base-y)
         (equal? (vector-ref mc-cv 34) nat-x)
         (equal? (vector-ref mc-cv 35) nat-y)
         (equal? (vector-ref mc-cv 36) third-x)
         (equal? (vector-ref mc-cv 37) third-y)))
  (define-values (macro-world macro-decision dyn-plan plan-next-actions-ht repaired-prereqs)
    (if macro-cache-ok?
        (values (vector-ref mc-cv 1)
                (vector-ref mc-cv 2)
                (vector-ref mc-cv 3)
                (vector-ref mc-cv 4)
                (vector-ref mc-cv 5))
        (let* ([mw (make-macro-world-state
                    #:race race
                    #:enemy-race effective-enemy-race
                    #:frame frame
                    #:minerals (l2-ctx-minerals ctx)
                    #:gas (l2-ctx-gas ctx)
                    #:supply-used supply-used
                    #:supply-cap supply-cap
                    #:supply-left (l2-ctx-supply-left ctx)
                    #:pending-supply eff-pending-supply
                    #:workers total-workers
                    #:active-bases active-bases
                    #:mineral-harvesters eff-min-harvesters
                    #:gas-harvesters eff-gas-harv-arg
                    #:ready-building-counts ready-bldg-counts
                    #:total-building-counts total-bldg-counts
                    #:unit-counts (l2-ctx-unit-counts ctx)
                    #:enemy-unit-counts enemy-u-counts
                    #:researched-upgrades researched-upgs
                    #:pending-upgrades (l2-ctx-pending-upgs ctx)
                    #:open-facility-slots open-prod-slots-snapshot
                    #:army-supply live-army-supply
                    #:enemy-threat-supply live-enemy-threat-supply
                    #:under-attack? under-base-attack?
                    #:requires-anti-air? req-aa?
                    #:requires-detection? req-det?
                    #:supply-at-risk? supply-at-risk?
                    #:peak-supply-reached cur-peak-supply
                    #:base-x base-x #:base-y base-y
                    #:nat-x nat-x #:nat-y nat-y
                    #:third-x third-x #:third-y third-y)]
               [md (step-priority-macro-brain mw)]
               [dp (macro-brain-decision-dynamic-plan md)]
               [pn (if (dynamic-macro-plan? dp)
                       (dynamic-macro-plan-translated-next-actions dp)
                       (hasheq))]
               [rp (macro-brain-decision-repaired-prereqs md)])
          (when (and live-game? (> frame 60))
            (vector-set! mc-cv 0 frame)
            (vector-set! mc-cv 1 mw)
            (vector-set! mc-cv 2 md)
            (vector-set! mc-cv 3 dp)
            (vector-set! mc-cv 4 pn)
            (vector-set! mc-cv 5 rp)
            (vector-set! mc-cv 6 race)
            (vector-set! mc-cv 7 effective-enemy-race)
            (vector-set! mc-cv 8 min-bkt25)
            (vector-set! mc-cv 9 gas-bkt25)
            (vector-set! mc-cv 10 sup-used-bkt)
            (vector-set! mc-cv 11 supply-cap)
            (vector-set! mc-cv 12 sup-left-key)
            (vector-set! mc-cv 13 pend-sup-key)
            (vector-set! mc-cv 14 total-workers)
            (vector-set! mc-cv 15 active-bases)
            (vector-set! mc-cv 16 eff-min-harvesters)
            (vector-set! mc-cv 17 eff-gas-harv-arg)
            (vector-set! mc-cv 18 ready-bldg-counts)
            (vector-set! mc-cv 19 total-bldg-counts)
            (vector-set! mc-cv 20 (l2-ctx-unit-counts ctx))
            (vector-set! mc-cv 21 enemy-u-counts)
            (vector-set! mc-cv 22 researched-upgs)
            (vector-set! mc-cv 23 (l2-ctx-pending-upgs ctx))
            (vector-set! mc-cv 24 open-prod-slots-snapshot)
            (vector-set! mc-cv 25 live-army-supply)
            (vector-set! mc-cv 26 live-enemy-threat-supply)
            (vector-set! mc-cv 27 (not (not under-base-attack?)))
            (vector-set! mc-cv 28 (not (not req-aa?)))
            (vector-set! mc-cv 29 (not (not req-det?)))
            (vector-set! mc-cv 30 (not (not supply-at-risk?)))
            (vector-set! mc-cv 31 cur-peak-supply)
            (vector-set! mc-cv 32 base-x)
            (vector-set! mc-cv 33 base-y)
            (vector-set! mc-cv 34 nat-x)
            (vector-set! mc-cv 35 nat-y)
            (vector-set! mc-cv 36 third-x)
            (vector-set! mc-cv 37 third-y))
          (values mw md dp pn rp))))
  (set-l2-ctx-macro-decision! ctx macro-decision)
  (set-l2-ctx-dyn-plan! ctx dyn-plan)
  (set-l2-ctx-plan-next-actions-ht! ctx plan-next-actions-ht)
  (set-l2-ctx-repaired-prereqs! ctx repaired-prereqs)
  (when live-game?
    (set! bo-active-goal (macro-brain-decision-bo-active-goal macro-decision))
    (set! bo-goal-sym (and bo-active-goal (pro-bo-goal-target-sym bo-active-goal)))
    (set-l2-ctx-bo-reserved-min! ctx (macro-brain-decision-reserved-min-floor macro-decision))
    (set-l2-ctx-bo-reserved-gas! ctx (macro-brain-decision-reserved-gas-floor macro-decision))
    (when (and (<= eff-gas-harvesters 0)
               (> (l2-ctx-bo-reserved-gas ctx) 0)
               (< (l2-ctx-gas ctx) (l2-ctx-bo-reserved-gas ctx)))
      (set-l2-ctx-bo-reserved-min! ctx 0)
      (set-l2-ctx-bo-reserved-gas! ctx 0))
    (when (and (or (<= total-workers 0)
                   (and (exact-integer? eff-min-harvesters) (<= eff-min-harvesters 0)))
               (> (l2-ctx-bo-reserved-min ctx) 0)
               (< (l2-ctx-minerals ctx) (l2-ctx-bo-reserved-min ctx)))
      (set-l2-ctx-bo-reserved-min! ctx 0)
      (set-l2-ctx-bo-reserved-gas! ctx 0)))
  (define active-escrow-sym
    (let ([sf (macro-brain-decision-saving-for macro-decision)])
      (if (and sf (not (eq? sf 'none)))
          sf
          bo-goal-sym)))
  (set-l2-ctx-active-escrow-sym! ctx active-escrow-sym)
  (define obs-minerals (safe-nonneg-int (hash-ref obs 'minerals 0)))
  (set-l2-ctx-obs-minerals! ctx obs-minerals)
  (define prev-escrow-goal (hash-ref prev-telemetry-ht 'escrow-goal-sym #f))
  (define prev-escrow-age (hash-ref prev-telemetry-ht 'escrow-age-frames 0))
  (define prev-escrow-frame (hash-ref prev-telemetry-ht 'escrow-last-frame frame))
  (define prev-escrow-peak-min (hash-ref prev-telemetry-ht 'escrow-peak-min obs-minerals))
  (define prev-escrow-min (hash-ref prev-telemetry-ht 'escrow-prev-min obs-minerals))
  (define prev-escrow-start-frame (hash-ref prev-telemetry-ht 'escrow-start-frame frame))
  (define prev-suppressed-goal (hash-ref prev-telemetry-ht 'escrow-suppressed-goal #f))
  (define prev-suppressed-until
    (safe-nonneg-int (hash-ref prev-telemetry-ht 'escrow-suppressed-until-frame 0) 0))
  (define cur-th-total-cnt
    (+ (count (lambda (t)
                (memq t '(hatchery lair hive nexus command-center orbital-command planetary-fortress)))
              (l2-ctx-bldg-types ctx))
       (order-ledger-pending-count-for-type
        oledger
        (case race [(Zerg) 'hatchery] [(Protoss) 'nexus] [else 'command-center])
        frame)))
  (set-l2-ctx-cur-th-total-cnt! ctx cur-th-total-cnt)
  (define exp-goal-sym-this-step
    (cond
      [(and active-escrow-sym (memq active-escrow-sym '(hatchery nexus command-center))) active-escrow-sym]
      [(and bo-goal-sym (memq bo-goal-sym '(hatchery nexus command-center))) bo-goal-sym]
      [else #f]))
  (set-l2-ctx-exp-goal-sym-this-step! ctx exp-goal-sym-this-step)
  (define prev-exp-streak-start (hash-ref prev-telemetry-ht 'exp-goal-streak-start #f))
  (define prev-exp-th-cnt (hash-ref prev-telemetry-ht 'exp-goal-th-count cur-th-total-cnt))
  (define prev-exp-last-f (hash-ref prev-telemetry-ht 'exp-goal-last-frame -9999))
  (set-l2-ctx-prev-exp-last-f! ctx prev-exp-last-f)
  (define th-count-increased? (> cur-th-total-cnt prev-exp-th-cnt))
  (define already-suppressed-goal?
    (and prev-suppressed-goal
         (not th-count-increased?)
         (< frame prev-suppressed-until)
         (or (and active-escrow-sym (eq? active-escrow-sym prev-suppressed-goal))
             (and exp-goal-sym-this-step (eq? exp-goal-sym-this-step prev-suppressed-goal)))))
  (define escrow-same-goal?
    (and active-escrow-sym
         (eq? active-escrow-sym prev-escrow-goal)
         (> (+ (l2-ctx-bo-reserved-min ctx) (l2-ctx-bo-reserved-gas ctx)) 0)))
  (define escrow-unsuppressed-start
    (if (and prev-suppressed-goal
             (eq? active-escrow-sym prev-suppressed-goal)
             (< prev-escrow-frame prev-suppressed-until)
             (<= prev-suppressed-until frame))
        prev-suppressed-until
        prev-escrow-frame))
  (define cur-escrow-start-frame
    (cond
      [(or (not escrow-same-goal?) already-suppressed-goal?) frame]
      [(and prev-suppressed-goal
            (eq? active-escrow-sym prev-suppressed-goal)
            (< prev-escrow-start-frame prev-suppressed-until)
            (<= prev-suppressed-until frame))
       prev-suppressed-until]
      [else prev-escrow-start-frame]))
  (set-l2-ctx-cur-escrow-start-frame! ctx cur-escrow-start-frame)
  (define escrow-making-progress?
    (and escrow-same-goal?
         (not already-suppressed-goal?)
         (memq active-escrow-sym '(hatchery nexus command-center))
         (> total-workers 0)
         (< (- frame cur-escrow-start-frame) 448)
         (< obs-minerals (sc2-min-cost active-escrow-sym))
         (> obs-minerals prev-escrow-peak-min)))
  (define cur-escrow-peak-min
    (if escrow-same-goal?
        (max prev-escrow-peak-min obs-minerals)
        obs-minerals))
  (set-l2-ctx-cur-escrow-peak-min! ctx cur-escrow-peak-min)
  (define cur-escrow-age-frames
    (cond
      [(or (not escrow-same-goal?) already-suppressed-goal?) 0]
      [escrow-making-progress? 0]
      [else (+ prev-escrow-age (max 1 (- frame escrow-unsuppressed-start)))]))
  (set-l2-ctx-cur-escrow-age-frames! ctx cur-escrow-age-frames)
  (define prev-exp-timeout-cnt
    (if th-count-increased?
        0
        (safe-nonneg-int (hash-ref prev-telemetry-ht 'exp-timeout-count 0) 0)))
  (define cur-exp-streak-start
    (cond
      [(or (not exp-goal-sym-this-step) already-suppressed-goal?) #f]
      [th-count-increased? frame]
      [(and (exact-integer? prev-exp-streak-start)
            (<= (- frame prev-exp-last-f) 96))
       prev-exp-streak-start]
      [else frame]))
  (set-l2-ctx-cur-exp-streak-start! ctx cur-exp-streak-start)
  (define exp-streak-stalled?
    (and live-game?
         exp-goal-sym-this-step
         (not (< frame prev-suppressed-until))
         (exact-integer? cur-exp-streak-start)
         (>= (- frame cur-exp-streak-start) 448)
         (or (>= obs-minerals 350) (>= (- frame cur-exp-streak-start) 672))))
  (define max-escrow-timeout-frames 224)
  (set-l2-ctx-max-escrow-timeout-frames! ctx max-escrow-timeout-frames)
  (define escrow-timed-out-now?
    (and (not already-suppressed-goal?)
         (or (and active-escrow-sym
                  (>= cur-escrow-age-frames max-escrow-timeout-frames))
             exp-streak-stalled?)))
  (set-l2-ctx-escrow-timed-out-now?! ctx escrow-timed-out-now?)
  (define timeout-target-sym
    (or exp-goal-sym-this-step active-escrow-sym))
  (define next-exp-timeout-cnt
    (if (and escrow-timed-out-now?
             timeout-target-sym
             (memq timeout-target-sym '(hatchery nexus command-center)))
        (add1 prev-exp-timeout-cnt)
        prev-exp-timeout-cnt))
  (set-l2-ctx-next-exp-timeout-cnt! ctx next-exp-timeout-cnt)
  (define escrow-suppressed-goal
    (cond
      [escrow-timed-out-now? timeout-target-sym]
      [(and prev-suppressed-goal
            (not th-count-increased?)
            (< frame prev-suppressed-until))
       prev-suppressed-goal]
      [else #f]))
  (set-l2-ctx-escrow-suppressed-goal! ctx escrow-suppressed-goal)
  (define escrow-suppressed-until-frame
    (cond
      [escrow-timed-out-now?
       (+ frame (if (and timeout-target-sym
                         (memq timeout-target-sym '(hatchery nexus command-center)))
                    (* 224 (min 3 (max 1 next-exp-timeout-cnt)))
                    160))]
      [(and prev-suppressed-goal
            (not th-count-increased?)
            (< frame prev-suppressed-until))
       prev-suppressed-until]
      [else 0]))
  (set-l2-ctx-escrow-suppressed-until-frame! ctx escrow-suppressed-until-frame)
  (define escrow-suppressed-active?
    (or escrow-timed-out-now?
        (and escrow-suppressed-goal
             (< frame escrow-suppressed-until-frame)
             (or (and active-escrow-sym (eq? active-escrow-sym escrow-suppressed-goal))
                 (and exp-goal-sym-this-step (eq? exp-goal-sym-this-step escrow-suppressed-goal))))))
  (set-l2-ctx-escrow-suppressed-active?! ctx escrow-suppressed-active?)
  (define severe-intel-blindness?
    (and (>= frame 1800)
         (or (>= supply-used 22) (>= frame 2240) (>= active-bases 2))
         (>= intel-staleness-frames 896)
         (< intel-confidence 0.35)))
  (set-l2-ctx-severe-intel-blindness?! ctx severe-intel-blindness?)
  (define urgent-combat-or-intel-need?
    (or (and (< live-army-supply 8)
             (or under-base-attack?
                 (> live-enemy-threat-supply 0)))
        (and live-game?
             (null? ally-combat-units)
             (or escrow-suppressed-active?
                 severe-intel-blindness?))))
  (set-l2-ctx-urgent-combat-or-intel-need?! ctx urgent-combat-or-intel-need?)
  (define can-train-basic-combat-now?
    (case race
      [(Zerg)    (and (memq 'spawning-pool ready-bldg-types)
                      (> (hash-ref open-prod-slots 'larva 0) 0))]
      [(Protoss) (and (or (memq 'gateway ready-bldg-types) (memq 'warp-gate ready-bldg-types))
                      (> (hash-ref open-prod-slots 'gateway 0) 0))]
      [(Terran)  (and (memq 'barracks ready-bldg-types)
                      (> (hash-ref open-prod-slots 'barracks 0) 0))]
      [else #f]))
  (define basic-combat-min-floor
    (if (and (null? ally-combat-units) can-train-basic-combat-now?)
        (case race
          [(Protoss) (if (and (memq 'cybernetics-core ready-bldg-types)
                              (>= (l2-ctx-gas ctx) (sc2-gas-cost 'stalker)))
                         (sc2-min-cost 'stalker)
                         (sc2-min-cost 'zealot))]
          [else 50])
        0))
  (set-l2-ctx-basic-combat-min-floor! ctx basic-combat-min-floor)
  (when (or escrow-suppressed-active?
            urgent-combat-or-intel-need?
            crisis-tech-upgrade-deferral?)
    (set-l2-ctx-bo-reserved-min! ctx 0)
    (set-l2-ctx-bo-reserved-gas! ctx 0))
  (define orphaned-prereqs
    (find-all-broken-tech-dependencies race ready-bldg-counts total-bldg-counts #:active-goals '()))
  (set-l2-ctx-orphaned-prereqs! ctx orphaned-prereqs)
  (define in-prog-bldg-syms
    (for/list ([b (in-list ally-bldgs)]
               #:when (< (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS))
      (fast-canonical-structure-sym (unit-type-sym b))))
  (define larva-slot-cnt
    (cond
      [(hash? open-prod-slots-snapshot) (hash-ref open-prod-slots-snapshot 'larva 0)]
      [(hash? open-prod-slots) (hash-ref open-prod-slots 'larva 0)]
      [else 0]))
  (set-l2-ctx-larva-slot-cnt! ctx larva-slot-cnt)
  (define wg-slot-cnt
    (count (lambda (b) (memq (unit-type-sym b) '(warp-gate warpgate))) ally-bldgs))
  (define live-open-combat-slots
    (and live-game?
         (for/sum ([k (in-list '(barracks factory starport gateway robotics-facility stargate))])
           (hash-ref open-prod-slots k 0))))
  (set-l2-ctx-live-open-combat-slots! ctx live-open-combat-slots)
  (define bank-target
    (compute-bank-targets
     #:race race
     #:frame frame
     #:minerals (l2-ctx-minerals ctx)
     #:gas (l2-ctx-gas ctx)
     #:supply-used supply-used
     #:supply-cap supply-cap
     #:workers total-workers
     #:active-bases active-bases
     #:larva-count larva-slot-cnt
     #:warpgate-count wg-slot-cnt
     #:production-facility-count (max 1 (length prod-facilities))
     #:open-production-slots live-open-combat-slots
     #:ready-buildings ready-bldg-types
     #:in-progress-buildings in-prog-bldg-syms
     #:under-attack? under-base-attack?))
  (set-l2-ctx-bank-target! ctx bank-target)
  (define goal-stream-alloc
    (allocate-decoupled-goal-streams
     #:race race
     #:frame frame
     #:minerals (l2-ctx-minerals ctx)
     #:gas (l2-ctx-gas ctx)
     #:supply-used supply-used
     #:supply-cap supply-cap
     #:pending-supply eff-pending-supply
     #:workers total-workers
     #:active-bases active-bases
     #:gas-harvesters eff-gas-harvesters
     #:under-attack? under-base-attack?
     #:wants-expand? (and (< active-bases desired-bases)
                          (not under-base-attack?)
                          (not escrow-suppressed-active?))
     #:tech-goal-sym (and (not escrow-suppressed-active?) bo-goal-sym)
     #:tech-prereq-ready? (null? orphaned-prereqs)
     #:bank-target bank-target))
  (set-l2-ctx-goal-stream-alloc! ctx goal-stream-alloc)
  (define stream-spendable-ht
    (decoupled-bank-allocation-spendable-by-stream goal-stream-alloc))
  (set-l2-ctx-stream-spendable-ht! ctx stream-spendable-ht)
  (define prio-sched (macro-brain-decision-priority-schedule macro-decision))
  (define prio-scheduled-actions (macro-brain-decision-scheduled-actions macro-decision))
  (set-l2-ctx-prio-scheduled-actions! ctx prio-scheduled-actions)
  (define prio-saving-for-sym (macro-brain-decision-saving-for macro-decision))
  (set-l2-ctx-prio-saving-for-sym! ctx prio-saving-for-sym)
  (define zerg-pool-nearly-done-under-rush?
    (and (eq? race 'Zerg)
         worker-rush-active?
         (< (l2-unit-count ctx 'zergling) 4)
         (< (l2-ctx-minerals ctx) 200)
         (ormap (lambda (b)
                  (and (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'spawning-pool)
                       (>= (hash-ref b 'build-progress 1.0) 0.72)))
                ally-bldgs)))
  (define crisis-freeze-workers?
    (or zerg-pool-nearly-done-under-rush?
        (and early-survival-crisis?
             (not (and (or worker-rush-active? (< total-workers 14))
                       (or (< total-workers 10)
                           (ormap (lambda (s) (memq s (l2-ctx-bldg-types ctx)))
                                  '(spawning-pool barracks gateway warp-gate)))
                       (or (not can-train-basic-combat-now?)
                           (>= (- (l2-ctx-minerals ctx) 50) basic-combat-min-floor))))
             (not (and (< total-workers 10)
                       (null? prod-facilities)
                       (< (l2-ctx-minerals ctx) 200)))
             (or (>= total-workers 12)
                 (< live-army-supply 4)))))
  (set-l2-ctx-crisis-freeze-workers?! ctx crisis-freeze-workers?)
  (define crisis-freeze-expand-or-gas?
    (or (and early-survival-crisis?
             (< live-army-supply 6))
        (and hard-supply-lockout?
             (< (l2-ctx-minerals ctx) (+ (sc2-min-cost supply-provider-sym) 75)))))
  (set-l2-ctx-crisis-freeze-expand-or-gas?! ctx crisis-freeze-expand-or-gas?)
  (define zerg-vs-tp-or-fog-floor
    (if (and live-game?
             (eq? race 'Zerg)
             (memq effective-enemy-race '(Terran Protoss Unknown Random)))
        (cond
          [(>= total-workers 54) 34.0]
          [(>= total-workers 46) 22.0]
          [(>= total-workers 38) 12.0]
          [else 0.0])
        0.0))
  (set-l2-ctx-zerg-vs-tp-or-fog-floor! ctx zerg-vs-tp-or-fog-floor)
  (define zerg-larva-mineral-surplus-ok?
    (and (eq? race 'Zerg)
         (>= (l2-ctx-minerals ctx) 900)
         (>= larva-slot-cnt 4)))
  (set-l2-ctx-zerg-larva-mineral-surplus-ok?! ctx zerg-larva-mineral-surplus-ok?)
  (define zerg-fog-army-floor-ok?
    (or (<= zerg-vs-tp-or-fog-floor 0.0)
        zerg-larva-mineral-surplus-ok?
        (>= live-army-supply zerg-vs-tp-or-fog-floor)))
  (set-l2-ctx-zerg-fog-army-floor-ok?! ctx zerg-fog-army-floor-ok?)
  (define prio-summary
    (priority-schedule-summary-hash
     prio-sched
     #:frame frame
     #:race race
     #:minerals (l2-ctx-minerals ctx)
     #:gas (l2-ctx-gas ctx)
     #:supply-used supply-used
     #:supply-cap supply-cap
     #:bo-goal-sym bo-goal-sym
     #:bo-reserved-min (l2-ctx-bo-reserved-min ctx)
     #:bo-reserved-gas (l2-ctx-bo-reserved-gas ctx)))
  (set-l2-ctx-prio-summary! ctx prio-summary)
  (define prio-log-line (macro-brain-decision-log-line macro-decision))
  (set-l2-ctx-prio-log-line! ctx prio-log-line)
  (define protoss-pending-robo-gas-reserve
    (if (and (eq? race 'Protoss)
             (= (sc2-count-equivalent-structures total-bldg-counts 'robotics-facility #f) 0)
             (> (sc2-count-equivalent-structures ready-bldg-counts 'cybernetics-core #f) 0)
             (>= supply-used 34)
             (>= (length ally-combat-units) 4)
             (not (and under-base-attack?
                       (enemy-tech-observation-requires-anti-air? tech-obs))))
        (sc2-gas-cost 'robotics-facility)
        0))
  (set-l2-ctx-protoss-pending-robo-gas-reserve! ctx protoss-pending-robo-gas-reserve)
  (for ([req-sym (in-list orphaned-prereqs)])
    (when (and (not (l2-crisis-tech-bldg-deferred? ctx req-sym))
               (not (l2-building-present-or-pending? ctx req-sym))
               (not (memq req-sym '(hatchery nexus command-center extractor assimilator refinery
                                    supply-depot overlord)))
               (not (and (eq? req-sym 'pylon) (not live-game?) (>= (l2-ctx-supply-left ctx) 8))))
      (define m-cost (sc2-min-cost req-sym))
      (define g-cost (sc2-gas-cost req-sym))
      (cond
        [(and (>= (l2-ctx-minerals ctx) m-cost) (>= (l2-ctx-gas ctx) g-cost))
         (case req-sym
           [(lair)
            (l2-emit-building-morph-verified! ctx 'lair '(hatchery) 4)]
           [(hive)
            (l2-emit-building-morph-verified! ctx 'hive '(lair) 4)]
           [(greater-spire)
            (l2-emit-building-morph-verified! ctx 'greater-spire '(spire) 4)]
           [(orbital-command planetary-fortress)
            (l2-emit-building-morph-verified! ctx req-sym '(command-center) 4)]
           [else
            (if (eq? race 'Zerg)
                (when (l2-save-cancel-rebuild-ready? ctx req-sym 60)
                  (define-values (req-ax req-ay)
                    (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 3.5)) (safe-coord (+ base-y 3.5))))
                  (l2-emit-build-verified! ctx req-sym req-ax req-ay))
                (l2-emit-build-verified! ctx req-sym (safe-coord (+ base-x 3.5)) (safe-coord (+ base-y 3.5))))])]
        [(and (not urgent-combat-or-intel-need?)
              (not escrow-suppressed-active?))
         (set-l2-ctx-bo-reserved-min! ctx (max (l2-ctx-bo-reserved-min ctx) m-cost))
         (set-l2-ctx-bo-reserved-gas! ctx (max (l2-ctx-bo-reserved-gas ctx) g-cost))])))
  (define race-th-sym
    (case race
      [(Zerg) 'hatchery]
      [(Protoss) 'nexus]
      [else 'command-center]))
  (set-l2-ctx-race-th-sym! ctx race-th-sym)
  (define enemy-heavy-ground-siege?
    (or (for/or ([e (in-list enemy-units)]) (l2-heavy-siege-record? ctx e))
        (for/or ([b (in-list enemy-bldgs)]) (l2-heavy-siege-record? ctx b))))
  (set-l2-ctx-enemy-heavy-ground-siege?! ctx enemy-heavy-ground-siege?)
  (define endgame-corner-hunt?
    (and live-game? (>= frame 6000) (null? enemy-bldgs)))
  (set-l2-ctx-endgame-corner-hunt?! ctx endgame-corner-hunt?))

(define (l2-zerg-phase1-inject-creep! ctx)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define corridor-mid-x (l2-ctx-corridor-mid-x ctx))
  (define corridor-mid-y (l2-ctx-corridor-mid-y ctx))
  (define enemy-exp-x (l2-ctx-enemy-exp-x ctx))
  (define enemy-exp-y (l2-ctx-enemy-exp-y ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define leases (l2-ctx-leases ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define ready-bldgs (l2-ctx-ready-bldgs ctx))
  (define rt (l2-ctx-rt ctx))
  (define third-x (l2-ctx-third-x ctx))
  (define third-y (l2-ctx-third-y ctx))
  (define queens
       (let ([rev '()])
         (for ([u (in-list ally-units)])
           (when (eq? (fast-canonical-unit-sym (unit-type-sym u)) 'queen)
             (set! rev (cons u rev))))
         (reverse rev)))
  (define hatcheries-rev '())
  (define extractors-rev '())
  (define active-extractors-rev '())
  (for ([b (in-list ally-bldgs)])
       (define cs (fast-canonical-structure-sym (unit-type-sym b)))
       (cond
         [(memq cs '(hatchery lair hive))
          (set! hatcheries-rev (cons b hatcheries-rev))]
         [(eq? cs 'extractor)
          (set! extractors-rev (cons b extractors-rev))
          (when (l2-active-gas-bldg? ctx b)
            (set! active-extractors-rev (cons b active-extractors-rev)))]))
  (define hatcheries (reverse hatcheries-rev))
  (set-l2-ctx-hatcheries! ctx hatcheries)
  (define extractors (reverse extractors-rev))
  (define active-extractors (reverse active-extractors-rev))
  (set-l2-ctx-active-extractors! ctx active-extractors)
  (define ready-hatcheries
       (let ([rev '()])
         (for ([b (in-list ready-bldgs)])
           (when (memq (fast-canonical-structure-sym (unit-type-sym b)) '(hatchery lair hive))
             (set! rev (cons b rev))))
         (reverse rev)))
  (define inject-hatcheries
       (if (not (null? ready-hatcheries)) ready-hatcheries hatcheries))
  (define (queen-protected-order? q)
       (define q-ab-id (hash-ref q 'order-ability-id 0))
       (define q-ab-sym (hash-ref q 'order-ability-sym #f))
       (or (memv q-ab-id '(251 1694 3691))
           (memq (fast-order-protection-class q-ab-id) '(macro-spell tumor-spread))
           (memq q-ab-sym '(inject-larva spawn-creep-tumor spread-creep-tumor))))
  (define (hatchery-needs-inject? h)
       (define timer (safe-nonneg-int (hash-ref h 'queen-spawn-larva-timer 0) 0))
       (define bs (hash-ref h 'buffs '()))
       (and (<= timer 0)
            (not (and (list? bs)
                      (or (memq 'inject-larva bs)
                          (memq 'queen-spawn-larva bs)
                          (memv 11 bs))))))
  (define uninjected-hatches
       (let ([rev '()])
         (for ([h (in-list inject-hatcheries)])
           (when (hatchery-needs-inject? h)
             (set! rev (cons h rev))))
         (reverse rev)))
  (define claimed-inject-hatch-ids (mutable-seteqv))
  (define used-queen-ids (mutable-seteqv))
  (for ([q (in-list queens)]
           #:when (queen-protected-order? q))
       (define qid (hash-ref q 'id 120))
       (set-add! used-queen-ids qid)
       (acquire-unit-lease! leases qid 'inject-queen frame 16
                            #:x (hash-ref q 'x base-x)
                            #:y (hash-ref q 'y base-y)))
  (define (nudge-off-expansion-pads cx cy [min-dist 5.0])
       (let loop ([rx cx] [ry cy]
                  [pads (list (cons nat-x nat-y) (cons third-x third-y))])
         (cond
           [(null? pads) (values (safe-coord rx cx) (safe-coord ry cy))]
           [else
            (define px (caar pads))
            (define py (cdar pads))
            (define d (dist2d rx ry px py))
            (if (< d min-dist)
                (let* ([vx (if (< d 0.1) (- enemy-x px) (- rx px))]
                       [vy (if (< d 0.1) (- enemy-y py) (- ry py))]
                       [vd (max 1.0 (sqrt (+ (* vx vx) (* vy vy))))])
                  (loop (+ px (* min-dist (/ vx vd)))
                        (+ py (* min-dist (/ vy vd)))
                        (cdr pads)))
                (loop rx ry (cdr pads)))])))
  (define tumor-state-ht (rt-tumor-state rt))
  (define all-ally-tumors
       (let ([rev '()] [seen #f])
         (define (add-tumor! obj)
           (define ut (unit-type-sym obj))
           (when (or (eq? ut 'creep-tumor)
                     (eq? ut 'creep-tumor-burrowed)
                     (eq? ut 'creep-tumor-queen))
             (define tid (hash-ref obj 'id 0))
             (when (or (<= tid 0)
                       (not seen)
                       (not (set-member? seen tid)))
               (when (> tid 0)
                 (unless seen (set! seen (mutable-seteqv)))
                 (set-add! seen tid))
               (set! rev (cons obj rev)))))
         (for ([u (in-list ally-units)]) (add-tumor! u))
         (for ([b (in-list ally-bldgs)]) (add-tumor! b))
         (reverse rev)))
  (define active-creep-tumors all-ally-tumors)
  (define creep-target-for-self-sustaining
       (min 6 (* 2 (max 1 (length hatcheries)))))
  (define creep-self-sustaining?
       (>= (length active-creep-tumors) creep-target-for-self-sustaining))
  (set-l2-ctx-creep-self-sustaining?! ctx creep-self-sustaining?)
  (define creep-highway-wps
       (list (cons nat-x nat-y)
             (cons third-x third-y)
             (cons corridor-mid-x corridor-mid-y)
             (cons enemy-exp-x enemy-exp-y)
             (cons enemy-x enemy-y)))
  (define (rotate-step-target ax ay bx by step-dist att-idx)
       (define dx (- bx ax))
       (define dy (- by ay))
       (define d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
       (define base-ang (atan (/ dy d) (/ dx d)))
       (define offsets '(0.0 0.65 -0.65 1.30 -1.30 1.95 -1.95 2.60))
       (define ang (+ base-ang (list-ref offsets (modulo att-idx (length offsets)))))
       (nudge-off-expansion-pads (+ ax (* step-dist (cos ang)))
                                 (+ ay (* step-dist (sin ang)))
                                 5.2))
  (define (next-creep-highway-target ax ay step-dist [att-idx 0])
       (define wp
         (or (findf (lambda (pt) (> (dist2d ax ay (car pt) (cdr pt)) 6.0))
                    creep-highway-wps)
             (cons enemy-x enemy-y)))
       (rotate-step-target ax ay (car wp) (cdr wp) step-dist att-idx))
  (define queen-threat-pts #f)
  (define (queen-close-combat? q)
       (and live-game?
            (begin
              (unless queen-threat-pts
                (set! queen-threat-pts
                      (for/list ([e (in-list enemy-units)]
                                 #:when (combat-unit-record? e))
                        (cons (exact->inexact (hash-ref e 'x 9999.0))
                              (exact->inexact (hash-ref e 'y 9999.0))))))
              (let ([qx (exact->inexact (hash-ref q 'x base-x))]
                    [qy (exact->inexact (hash-ref q 'y base-y))])
                (for/or ([pt (in-list queen-threat-pts)])
                  (define dx (fl- qx (car pt)))
                  (define dy (fl- qy (cdr pt)))
                  (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 64.0))))))
  (define (queen-dispatch-creep-tumor! q #:surplus-pass? [surplus-pass? #f])
       (define qid (hash-ref q 'id 120))
       (define qx (hash-ref q 'x base-x))
       (define qy (hash-ref q 'y base-y))
       (define fqx (exact->inexact qx))
       (define fqy (exact->inexact qy))
       (define fex (exact->inexact enemy-x))
       (define fey (exact->inexact enemy-y))
       (define att-key (list 'queen-att qid))
       (define att-idx (hash-ref tumor-state-ht att-key 0))
       (define th0
         (and (pair? inject-hatcheries)
              (let ([best #f] [best-d2 +inf.0])
                (for ([h (in-list inject-hatcheries)])
                  (define dx (fl- fqx (exact->inexact (hash-ref h 'x base-x))))
                  (define dy (fl- fqy (exact->inexact (hash-ref h 'y base-y))))
                  (define d2 (fl+ (fl* dx dx) (fl* dy dy)))
                  (when (fl< d2 best-d2)
                    (set! best h)
                    (set! best-d2 d2)))
                best)))
       (define local-tumor
         (and (pair? all-ally-tumors)
              (let ([best #f] [best-ed2 +inf.0])
                (for ([t (in-list all-ally-tumors)])
                  (define tx (exact->inexact (hash-ref t 'x base-x)))
                  (define ty (exact->inexact (hash-ref t 'y base-y)))
                  (define dx (fl- fqx tx))
                  (define dy (fl- fqy ty))
                  (when (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 256.0)
                    (define edx (fl- fex tx))
                    (define edy (fl- fey ty))
                    (define ed2 (fl+ (fl* edx edx) (fl* edy edy)))
                    (when (fl< ed2 best-ed2)
                      (set! best t)
                      (set! best-ed2 ed2))))
                best)))
       (define-values (tx ty)
         (cond
           [(and (not live-game?) surplus-pass?)
            (define hx (if th0 (hash-ref th0 'x base-x) base-x))
            (define hy (if th0 (hash-ref th0 'y base-y) base-y))
            (define hdx (- nat-x hx))
            (define hdy (- nat-y hy))
            (define hd (max 1.0 (sqrt (+ (* hdx hdx) (* hdy hdy)))))
            (nudge-off-expansion-pads (+ hx (* 3.5 (/ hdx hd)))
                                      (+ hy (* 3.5 (/ hdy hd)))
                                      4.5)]
           [local-tumor
            (next-creep-highway-target (hash-ref local-tumor 'x qx)
                                       (hash-ref local-tumor 'y qy)
                                       6.0
                                       att-idx)]
           [th0
            (define hx (hash-ref th0 'x base-x))
            (define hy (hash-ref th0 'y base-y))
            (define d-qh (dist2d qx qy hx hy))
            (if (<= d-qh 18.0)
                ;; Place outside the 4.5-tile pad exclusion box along the creep highway
                (next-creep-highway-target hx hy 6.2 att-idx)
                (next-creep-highway-target qx qy 5.5 att-idx))]
           [else
            (next-creep-highway-target qx qy 5.5 att-idx)]))
       (define q->target-d (dist2d qx qy tx ty))
       (cond
         [(and live-game? (> q->target-d 12.0))
          (when (refractory-allow-action?! cd-tracker (list 'queen-tumor-walk qid) frame 16)
            (define vdx (- tx qx))
            (define vdy (- ty qy))
            (define vd (max 1.0 (sqrt (+ (* vdx vdx) (* vdy vdy)))))
            (define mx (safe-coord (- tx (* 2.0 (/ vdx vd))) tx))
            (define my (safe-coord (- ty (* 2.0 (/ vdy vd))) ty))
            (set-add! used-queen-ids qid)
            (acquire-unit-lease! leases qid 'creep-queen frame 16 #:x mx #:y my)
            (l2-emit! ctx (list 'move qid mx my)))]
         [(refractory-allow-action?! cd-tracker
                                     (list 'queen-tumor qid)
                                     frame
                                     (if live-game? 44 SC2-CREEP-TUMOR-COOLDOWN-FRAMES))
          (hash-set! tumor-state-ht att-key (add1 att-idx))
          (set-add! used-queen-ids qid)
          (acquire-unit-lease! leases qid 'creep-queen frame (if live-game? 16 24) #:x tx #:y ty)
          (l2-emit! ctx (list 'cast-spell qid 'spawn-creep-tumor tx ty))
          (order-ledger-record-issued! oledger qid 'cast-spell 'spawn-creep-tumor tx ty frame)]))
  (define base-inject-queen-ids (mutable-seteqv))
  (define dedicated-creeping-queen-ids (mutable-seteqv))
  (define all-ready-hatches-injected? (null? uninjected-hatches))
  (define ready-hatch-count (length ready-hatcheries))
  (set-l2-ctx-ready-hatch-count! ctx ready-hatch-count)
  (when (pair? queens)
       (define claimed-hids (mutable-seteqv))
       (define (claim-nearest-inject-queen-for-hatch! h)
         (when (< (set-count base-inject-queen-ids) ready-hatch-count)
           (define hid (hash-ref h 'id 101))
           (unless (set-member? claimed-hids hid)
             (define hx (exact->inexact (hash-ref h 'x base-x)))
             (define hy (exact->inexact (hash-ref h 'y base-y)))
             (define best-q #f)
             (define best-d2 +inf.0)
             (for ([q (in-list queens)])
               (define qid (hash-ref q 'id 120))
               (unless (or (set-member? base-inject-queen-ids qid)
                           (and (queen-protected-order? q)
                                (let ([ab (hash-ref q 'order-ability-sym #f)]
                                      [ab-id (hash-ref q 'order-ability-id 0)])
                                  (or (memq ab '(spawn-creep-tumor spread-creep-tumor))
                                      (= ab-id 3691)
                                      (= ab-id 1694)))))
                 (define qx (exact->inexact (hash-ref q 'x base-x)))
                 (define qy (exact->inexact (hash-ref q 'y base-y)))
                 (define dx (fl- qx hx))
                 (define dy (fl- qy hy))
                 (define d2 (fl+ (fl* dx dx) (fl* dy dy)))
                 (when (fl< d2 best-d2)
                   (set! best-q q)
                   (set! best-d2 d2))))
             (when best-q
               (set-add! claimed-hids hid)
               (set-add! base-inject-queen-ids (hash-ref best-q 'id 120))))))
       (when (> ready-hatch-count 0)
         (for ([h (in-list uninjected-hatches)])
           (claim-nearest-inject-queen-for-hatch! h))
         (for ([h (in-list ready-hatcheries)])
           (claim-nearest-inject-queen-for-hatch! h)))
       (for ([q (in-list queens)])
         (define qid (hash-ref q 'id 120))
         (unless (set-member? base-inject-queen-ids qid)
           (set-add! dedicated-creeping-queen-ids qid)))
       (when (and (= (set-count dedicated-creeping-queen-ids) 0)
                  (not creep-self-sustaining?)
                  (or all-ready-hatches-injected?
                      (and (null? active-creep-tumors)
                           (>= frame 2400)
                           (pair? (cdr queens)))))
         (define promo-q
           (or (for/first ([q (in-list queens)]
                           #:when (let ([qid (hash-ref q 'id 120)])
                                    (and (not (set-member? used-queen-ids qid))
                                         (>= (hash-ref q 'energy (if live-game? 0 SC2-QUEEN-INJECT-ENERGY))
                                             SC2-QUEEN-INJECT-ENERGY)
                                         (not (queen-close-combat? q)))))
                 q)
               (car queens)))
         (set-add! dedicated-creeping-queen-ids (hash-ref promo-q 'id 120))))
  (define zero-tumors-2plus-queens?
       (and (null? active-creep-tumors) (pair? queens) (pair? (cdr queens))))
  (define base-inject-catchup-tumor-ok?
       (and (not creep-self-sustaining?)
            (null? active-creep-tumors)
            (>= frame 2200)
            (or all-ready-hatches-injected?
                (>= (length queens) (length inject-hatcheries)))))
  (define pass1-dispatched-emergency-tumor? #f)
  (for ([q (in-list queens)]
           #:when (and (not (set-member? used-queen-ids (hash-ref q 'id 120)))
                       (not (queen-close-combat? q))))
       (define qid (hash-ref q 'id 120))
       (define q-energy (hash-ref q 'energy (if live-game? 0 SC2-QUEEN-INJECT-ENERGY)))
       (define dedicated-creeper? (set-member? dedicated-creeping-queen-ids qid))
       (define can-creep-at-25?
         (or dedicated-creeper?
             (and (not creep-self-sustaining?) all-ready-hatches-injected?)
             (and (not pass1-dispatched-emergency-tumor?)
                  (or zero-tumors-2plus-queens? base-inject-catchup-tumor-ok?))))
       (define req-energy
         (if can-creep-at-25?
             SC2-QUEEN-INJECT-ENERGY
             SC2-QUEEN-TUMOR-SURPLUS-ENERGY))
       (when (>= q-energy req-energy)
         (queen-dispatch-creep-tumor! q #:surplus-pass? (>= q-energy SC2-QUEEN-TUMOR-SURPLUS-ENERGY))
         (when (and (not dedicated-creeper?)
                    (set-member? used-queen-ids qid))
           (set! pass1-dispatched-emergency-tumor? #t))))
  (fast-dispatch-macro-energy!
      queens
      uninjected-hatches
      frame
      claimed-inject-hatch-ids
      #:min-energy SC2-QUEEN-INJECT-ENERGY
      #:valid-caster?
      (lambda (q)
        (not (set-member? used-queen-ids (hash-ref q 'id 120))))
      #:valid-pair?
      (lambda (q h)
        (or (not live-game?)
            (<= (dist2d (hash-ref q 'x base-x) (hash-ref q 'y base-y)
                        (hash-ref h 'x base-x) (hash-ref h 'y base-y))
                18.0)))
      #:score-pair
      (lambda (q h)
        (- (dist2d (hash-ref q 'x base-x) (hash-ref q 'y base-y)
                   (hash-ref h 'x base-x) (hash-ref h 'y base-y))))
      #:emit-cast!
      (lambda (q h)
        (define qid (hash-ref q 'id 120))
        (define hid (hash-ref h 'id 101))
        (define hx (hash-ref h 'x base-x))
        (define hy (hash-ref h 'y base-y))
        (set-add! used-queen-ids qid)
        (set-add! claimed-inject-hatch-ids hid)
        (acquire-unit-lease! leases qid 'inject-queen frame 24
                             #:target-id hid #:x hx #:y hy)
        (l2-emit! ctx (list 'cast-spell qid 'inject-larva hid))
        (order-ledger-record-issued! oledger qid 'cast-spell 'inject-larva hx hy frame)))
  (for ([h (in-list uninjected-hatches)]
           #:when (not (set-member? claimed-inject-hatch-ids (hash-ref h 'id 101))))
       (define hid (hash-ref h 'id 101))
       (define hx (exact->inexact (hash-ref h 'x base-x)))
       (define hy (exact->inexact (hash-ref h 'y base-y)))
       (define-values (guard-q _guard-d2)
         (for/fold ([best #f] [best-d2 +inf.0]) ([q (in-list queens)])
           (define qid (hash-ref q 'id 120))
           (if (and (not (set-member? used-queen-ids qid))
                    (or (not (set-member? dedicated-creeping-queen-ids qid))
                        (<= (length queens) ready-hatch-count))
                    (< (hash-ref q 'energy 0) SC2-QUEEN-TUMOR-SURPLUS-ENERGY))
               (let* ([dx (fl- hx (exact->inexact (hash-ref q 'x base-x)))]
                      [dy (fl- hy (exact->inexact (hash-ref q 'y base-y)))]
                      [d2 (fl+ (fl* dx dx) (fl* dy dy))])
                 (if (and (fl<= d2 196.0) (fl< d2 best-d2))
                     (values q d2)
                     (values best best-d2)))
               (values best best-d2))))
       (when guard-q
         (define gqid (hash-ref guard-q 'id 120))
         (set-add! used-queen-ids gqid)
         (set-add! claimed-inject-hatch-ids hid)
         (acquire-unit-lease! leases gqid 'inject-queen frame 24
                              #:target-id hid #:x hx #:y hy)))
  (for ([q (in-list queens)]
           #:when (and (not (set-member? used-queen-ids (hash-ref q 'id 120)))
                       (>= (hash-ref q 'energy 0) SC2-QUEEN-INJECT-ENERGY)
                       (not (queen-close-combat? q))))
       (queen-dispatch-creep-tumor! q #:surplus-pass? #f))
  (define max-tumor-attempts (if live-game? 8 4))
  (define used-tumors-set (live-bot-runtime-used-creep-tumors rt))
  (define mature-ready-tumors
       (let ([rev '()])
         (define (collect-tumors! src)
           (for ([u (in-list src)])
             (define ut (unit-type-sym u))
             (when (or (eq? ut 'creep-tumor) (eq? ut 'creep-tumor-burrowed))
               (define tid (hash-ref u 'id 0))
               (unless (set-member? used-tumors-set tid)
                 (define st (hash-ref tumor-state-ht tid #f))
                 (cond
                   [(not st)
                    (define init-ready-f (if live-game? (+ frame 232) frame))
                    (define new-st (hash 'mature-frame init-ready-f 'attempts 0 'next-try init-ready-f))
                    (hash-set! tumor-state-ht tid new-st)
                    (when (and (>= frame init-ready-f))
                      (set! rev (cons u rev)))]
                   [else
                    (define att (hash-ref st 'attempts 0))
                    (cond
                      [(>= att max-tumor-attempts)
                       (set-add! used-tumors-set tid)]
                      [(and (>= frame (hash-ref st 'mature-frame 0))
                            (>= frame (hash-ref st 'next-try 0)))
                       (set! rev (cons u rev))])])))))
         (collect-tumors! ally-units)
         (collect-tumors! ready-bldgs)
         (reverse rev)))
  (for ([t (in-list (take mature-ready-tumors
                             (min SC2-MAX-TUMOR-SPREADS-PER-FRAME (length mature-ready-tumors))))])
       (define tid (hash-ref t 'id 702))
       (define tx (hash-ref t 'x base-x))
       (define ty (hash-ref t 'y base-y))
       (define st (hash-ref tumor-state-ht tid (hash)))
       (define att (hash-ref st 'attempts 0))
       (define-values (target-x target-y)
         (if live-game?
             (next-creep-highway-target tx ty SC2-CREEP-TUMOR-STEP-DISTANCE att)
             (let* ([dx (- enemy-x tx)]
                    [dy (- enemy-y ty)]
                    [d (max 1.0 (sqrt (+ (* dx dx) (* dy dy))))])
               (values (safe-coord (+ tx (* SC2-CREEP-TUMOR-STEP-DISTANCE (/ dx d))) tx)
                       (safe-coord (+ ty (* SC2-CREEP-TUMOR-STEP-DISTANCE (/ dy d))) ty)))))
       (define next-att (add1 att))
       (hash-set! tumor-state-ht tid
                  (hash-set* st 'attempts next-att 'next-try (+ frame (if live-game? 40 68))))
       (when (or (not live-game?) (>= next-att max-tumor-attempts))
         (set-add! (live-bot-runtime-used-creep-tumors rt) tid))
       (l2-emit! ctx (list 'cast tid 'spread-creep-tumor target-x target-y))))

(define (l2-zerg-phase2-expand-tech-def! ctx)
  (define active-extractors (l2-ctx-active-extractors ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bldg-actively-damaged? (l2-ctx-bldg-actively-damaged? ctx))
  (define blocked-nat-expanded-early? (l2-ctx-blocked-nat-expanded-early? ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define creep-self-sustaining? (l2-ctx-creep-self-sustaining? ctx))
  (define crisis-freeze-expand-or-gas? (l2-ctx-crisis-freeze-expand-or-gas? ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define desired-bases (l2-ctx-desired-bases ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define endgame-corner-hunt? (l2-ctx-endgame-corner-hunt? ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define frame (l2-ctx-frame ctx))
  (define hard-supply-lockout-reserve-min (l2-ctx-hard-supply-lockout-reserve-min ctx))
  (define hatcheries (l2-ctx-hatcheries ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define macro-plan (l2-ctx-macro-plan ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define prio-saving-for-sym (l2-ctx-prio-saving-for-sym ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define ready-hatch-count (l2-ctx-ready-hatch-count ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define zerg-fog-army-floor-ok? (l2-ctx-zerg-fog-army-floor-ok? ctx))
  (define zerg-4th-hatch-mineral-overflow?
       (and live-game?
            (>= (length hatcheries) 3)
            (>= (l2-ctx-minerals ctx) 900)
            (>= total-workers 38)
            (not worker-rush-active?)
            (not early-survival-crisis?)
            (not bldg-actively-damaged?)
            (<= live-enemy-threat-supply (max 10 (+ live-army-supply 4)))))
  (define zerg-exp-x #f)
  (define zerg-exp-y #f)
  (when (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'hatchery))
                (or zerg-4th-hatch-mineral-overflow?
                    (l2-non-combat-min-ok? ctx (sc2-min-cost 'hatchery) 'hatchery))
                (not blocked-nat-expanded-early?)
                (not worker-rush-active?)
                (not under-early-cheese?)
                (not early-survival-crisis?)
                (not crisis-freeze-expand-or-gas?)
                (or (not under-base-attack?) zerg-4th-hatch-mineral-overflow?)
                (= (order-ledger-pending-count-for-type oledger 'hatchery frame) 0)
                (or (< (length hatcheries) SC2-MIN-DESIRED-BASES)
                    (and (= (length hatcheries) 2)
                         (>= eff-phase-supply 30)
                         (memq 'spawning-pool ready-bldg-types))
                    (and zerg-4th-hatch-mineral-overflow?
                         (< (length hatcheries) 7)
                         (memq 'spawning-pool (l2-ctx-bldg-types ctx)))
                    (and (< (length hatcheries) desired-bases)
                         (memq 'spawning-pool (l2-ctx-bldg-types ctx))
                         (or (not (and endgame-corner-hunt?
                                       (< (+ (l2-unit-count ctx 'mutalisk) (l2-unit-count ctx 'corruptor)) 2)))
                             (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'hatchery)) 150))
                         (>= total-workers (* (length hatcheries)
                                              (if (>= (length hatcheries) 3) 16 SC2-MIN-WORKERS-PER-BASE-FOR-EXPAND)))
                         (or (coupled-macro-plan-should-expand? macro-plan)
                             (>= frame SC2-MACRO-EXPAND-FRAME-THRESHOLD))))
                (refractory-ready? cd-tracker '(macro-expand Zerg) frame SC2-EXPANSION-COOLDOWN-FRAMES)
                (let-values ([(cand-ex cand-ey)
                              (l2-select-uncamped-expansion-pad ctx (< (length hatcheries) SC2-MIN-DESIRED-BASES))])
                  (and cand-ex cand-ey
                       (begin (set! zerg-exp-x cand-ex)
                              (set! zerg-exp-y cand-ey)
                              #t)))
                (refractory-allow-action?! cd-tracker
                                           '(macro-expand Zerg)
                                           frame
                                           SC2-EXPANSION-COOLDOWN-FRAMES))
       (when (and zerg-exp-x zerg-exp-y)
         (l2-emit! ctx (list 'expand zerg-exp-x zerg-exp-y))
         (order-ledger-record-issued! oledger (+ 810000 (modulo frame 10000)) 'expand 'hatchery zerg-exp-x zerg-exp-y frame)
         (l2-spend-resources-and-supply! ctx (sc2-min-cost 'hatchery) 0 0)))
  (define zerg-saving-for-expand? (l2-saving-for-expansion-now? ctx (length hatcheries)))
  (set-l2-ctx-zerg-saving-for-expand?! ctx zerg-saving-for-expand?)
  (when (and (not (l2-building-present-or-pending? ctx 'spawning-pool))
                (l2-save-cancel-rebuild-ready? ctx 'spawning-pool 60)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'spawning-pool))
                (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'spawning-pool)) hard-supply-lockout-reserve-min))
       (define-values (pool-ax pool-ay)
         (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 3.0)) (safe-coord (+ base-y 3.0))))
       (l2-emit-build-verified! ctx 'spawning-pool pool-ax pool-ay))
  (when (and (or worker-rush-active? early-survival-crisis?)
                (memq 'spawning-pool ready-bldg-types)
                (< live-army-supply (max 8 (+ live-enemy-threat-supply 4))))
       (when (and (>= (l2-ctx-minerals ctx) 200)
                  (>= total-workers 2)
                  (not (l2-building-present-or-pending? ctx 'spine-crawler))
                  (l2-save-cancel-rebuild-ready? ctx 'spine-crawler 60))
         (define-values (er-spine-x er-spine-y)
           (if (<= (length hatcheries) 1)
               (let* ([sdx (- nat-x base-x)]
                      [sdy (- nat-y base-y)]
                      [sd (max 1.0 (sqrt (+ (* sdx sdx) (* sdy sdy))))])
                 (values (safe-coord (+ base-x (* 3.5 (/ sdx sd))) base-x)
                         (safe-coord (+ base-y (* 3.5 (/ sdy sd))) base-y)))
               (l2-offset-defense-anchor ctx nat-x nat-y 5.5)))
         (l2-emit-build-verified! ctx 'spine-crawler er-spine-x er-spine-y 2.0))
       (when (and (not worker-rush-active?)
                  (not (ormap (lambda (e)
                                (memq (unit-type-sym e)
                                      '(mutalisk void-ray voidray carrier tempest oracle phoenix
                                        banshee liberator liberator-ag battlecruiser
                                        viking viking-fighter brood-lord broodlord colossus)))
                              enemy-units))
                  (memq 'roach-warren ready-bldg-types)
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'roach))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'roach)))
         (l2-try-train-unit! ctx 'roach 'larva 4 #:respect-bo-reserve? #f))
       (when (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'zergling))
                  (or (>= total-workers 1) worker-rush-active?))
         (l2-try-train-unit! ctx 'zergling 'larva 4 #:respect-bo-reserve? #f)))
  (define desired-extractors
       (if (and early-survival-crisis? (null? active-extractors))
           0
           (min (* SC2-GEYSERS-PER-BASE (length hatcheries))
                (if live-game?
                    (cond
                      [(and (>= (length hatcheries) 4) (>= total-workers 62) (< (l2-ctx-gas ctx) 1000)) 8]
                      [(and (>= (length hatcheries) 3) (>= total-workers 48) (< (l2-ctx-gas ctx) 700)) 6]
                      [(and (>= (length hatcheries) 2) (>= total-workers 34) (< (l2-ctx-gas ctx) 450)) 4]
                      [(and (>= eff-phase-supply 44) (>= total-workers 32) (< (l2-ctx-gas ctx) 350)) 3]
                      [(and (>= (length hatcheries) 2) (>= eff-phase-supply 34) (>= total-workers 24) (< (l2-ctx-gas ctx) 250)) 2]
                      [(>= total-workers (add1 SC2-MIN-WORKERS-FOR-GAS)) 1]
                      [else 0])
                    (cond
                      [(>= supply-used 84) 6]
                      [(>= supply-used 60) 4]
                      [(>= supply-used 44) 3]
                      [(>= supply-used 38) 2]
                      [(>= total-workers (add1 SC2-MIN-WORKERS-FOR-GAS)) 1]
                      [else 0])))))
  (define zerg-holding-for-aa-spire?
       (and live-game?
            (not crisis-tech-upgrade-deferral?)
            (>= (length hatcheries) 3)
            (enemy-tech-observation-requires-anti-air? tech-obs)
            (or (memq 'lair ready-bldg-types) (memq 'hive ready-bldg-types))
            (not (l2-building-present-or-pending? ctx 'spire))
            (not (l2-building-present-or-pending? ctx 'greater-spire))
            (>= (l2-ctx-gas ctx) (sc2-gas-cost 'spire))))
  (set-l2-ctx-zerg-holding-for-aa-spire?! ctx zerg-holding-for-aa-spire?)
  (define zerg-real-anti-air-threat?
       (let ([real-air-units 0]
             [heavy-air-units 0]
             [transport-air-units 0])
         (for ([e (in-list enemy-units)])
           (define et (unit-type-sym e))
           (case et
             [(mutalisk void-ray voidray carrier tempest battlecruiser brood-lord broodlord colossus)
              (set! real-air-units (add1 real-air-units))
              (set! heavy-air-units (add1 heavy-air-units))]
             [(oracle phoenix banshee liberator liberator-ag viking viking-fighter)
              (set! real-air-units (add1 real-air-units))]
             [(medivac warp-prism warp-prism-phasing)
              (set! transport-air-units (add1 transport-air-units))]))
         (define air-tech-bldgs
           (for/sum ([eb (in-list enemy-bldgs)])
             (if (memq (fast-canonical-structure-sym (unit-type-sym eb))
                       '(stargate fleet-beacon spire greater-spire
                         starport-techlab starport-tech-lab fusion-core))
                 1
                 0)))
         (define medivac-or-prism-only?
           (and (> transport-air-units 0)
                (= real-air-units 0)
                (= air-tech-bldgs 0)))
         (cond
           [(not live-game?)
            (enemy-tech-observation-requires-anti-air? tech-obs)]
           [medivac-or-prism-only? #f]
           [(or (> heavy-air-units 0) (>= real-air-units 2) (> air-tech-bldgs 0)) #t]
           [(and (null? enemy-units) (null? enemy-bldgs)
                 (not (eq? effective-enemy-race 'Terran)))
            (enemy-tech-observation-requires-anti-air? tech-obs)]
           [else #f])))
  (set-l2-ctx-zerg-real-anti-air-threat?! ctx zerg-real-anti-air-threat?)
  (define zerg-holding-for-aa-corruptor?
       (and live-game?
            zerg-real-anti-air-threat?
            (or (memq 'spire ready-bldg-types) (memq 'greater-spire ready-bldg-types))
            (< (l2-unit-count ctx 'corruptor) 4)
            (>= (l2-ctx-minerals ctx) (sc2-min-cost 'corruptor))
            (>= (l2-ctx-gas ctx) (sc2-gas-cost 'corruptor))))
  (set-l2-ctx-zerg-holding-for-aa-corruptor?! ctx zerg-holding-for-aa-corruptor?)
  (when (and (memq 'spawning-pool (l2-ctx-bldg-types ctx))
                (not crisis-freeze-expand-or-gas?)
                (not (and zerg-holding-for-aa-spire?
                          (>= (length active-extractors) 2)
                          (< (- (l2-ctx-minerals ctx) (sc2-min-cost 'gas-building-reserve))
                             (sc2-min-cost 'spire))))
                (not (and zerg-holding-for-aa-corruptor?
                          (>= (length active-extractors) 2)
                          (< (- (l2-ctx-minerals ctx) (sc2-min-cost 'gas-building-reserve))
                             (sc2-min-cost 'corruptor))))
                (< (+ (length active-extractors) (order-ledger-pending-count-for-type oledger 'extractor frame))
                   desired-extractors)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'gas-building-reserve))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'gas-building-reserve)))
       (l2-emit-gas-build-verified! ctx 'extractor (safe-coord (+ base-x 4.0)) (safe-coord (+ base-y 4.0)) 'gas-building-reserve))
  (define zerg-wants-lair-now?
       (and (not crisis-tech-upgrade-deferral?)
            (memq 'spawning-pool ready-bldg-types)
            (not (l2-building-present-or-pending? ctx 'lair))
            (not (memq 'hive (l2-ctx-bldg-types ctx)))
            (not (l2-building-present-or-pending? ctx 'hive))
            (or (eq? bo-goal-sym 'lair)
                (eq? prio-saving-for-sym 'lair)
                (l2-plan-wants-now? ctx 'lair)
                endgame-corner-hunt?
                (and (>= (l2-ctx-gas ctx) 100)
                     (or (not live-game?)
                         (not (l2-upgrade-needed? ctx 'metabolic-boost))
                         (>= (l2-ctx-gas ctx) 200)
                         (>= eff-phase-supply 36)
                         (memq 'roach-warren (l2-ctx-bldg-types ctx)))))))
  (when (and (memq 'spawning-pool ready-bldg-types)
                (not zerg-saving-for-expand?)
                (or (not live-game?)
                    zerg-wants-lair-now?
                    (>= eff-phase-supply 42)
                    (l2-plan-wants-now? ctx 'lair)
                    (memq 'roach-warren (l2-ctx-bldg-types ctx)))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'lair))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'lair))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'lair) 'lair)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'lair) 'lair)
                (not (l2-building-present-or-pending? ctx 'lair))
                (not (memq 'hive (l2-ctx-bldg-types ctx)))
                (not (l2-building-present-or-pending? ctx 'hive)))
       (l2-emit-building-morph-verified! ctx 'lair '(hatchery) 4))
  (define lair-reserving-last-hatchery?
       (and live-game?
            zerg-wants-lair-now?
            (>= (l2-ctx-gas ctx) 80)
            (not (l2-building-present-or-pending? ctx 'lair))
            (<= (hash-ref open-prod-slots 'townhall 0) 1)))
  (define queen-allowed-in-crisis?
       (or (not early-survival-crisis?)
           (>= live-army-supply 4)
           (>= (l2-ctx-minerals ctx) 250)))
  (define total-queens-now (l2-unit-count ctx 'queen))
  (define hatch-count-now (length hatcheries))
  (define creeping-queen-target
       (cond
         [(>= hatch-count-now 3) 3]
         [(>= hatch-count-now 2) 2]
         [else 1]))
  (define desired-queens
       (min SC2-MAX-QUEENS-CAP
            (+ (max 1 ready-hatch-count) creeping-queen-target)))
  (when (and (memq 'spawning-pool ready-bldg-types)
                (= total-queens-now 0)
                queen-allowed-in-crisis?
                (not lair-reserving-last-hatchery?)
                (not zerg-saving-for-expand?)
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'queen) 'queen))
       (l2-try-train-unit! ctx 'queen 'townhall 4))
  (define enemy-cloaked-or-air?
       (ormap (lambda (e)
                (or (hash-ref e 'cloaked #f)
                    (hash-ref e 'burrowed #f)
                    (memq (fast-canonical-unit-sym (unit-type-sym e))
                          '(banshee dark-templar ghost lurker mutalisk void-ray carrier oracle widow-mine))))
              enemy-units))
  (set-l2-ctx-enemy-cloaked-or-air?! ctx enemy-cloaked-or-air?)
  (when (and live-game?
                (or (memq 'lair ready-bldg-types) (memq 'hive ready-bldg-types))
                (or (and (not zerg-holding-for-aa-spire?)
                         (not zerg-holding-for-aa-corruptor?))
                    enemy-cloaked-or-air?)
                (< (l2-unit-count ctx 'overseer)
                   (if (or (>= live-army-supply 40)
                           enemy-cloaked-or-air?
                           (enemy-tech-observation-requires-detection? tech-obs))
                       2
                       1)))
       (when (and (= (l2-unit-count ctx 'overlord) 0)
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'overlord)))
         (l2-try-train-unit! ctx 'overlord 'larva 4))
       (l2-emit-unit-morph-verified! ctx 'overseer 'overlord 0))
  (define zerg-holding-lair-min?
       (and live-game?
            (not crisis-tech-upgrade-deferral?)
            (not (l2-building-present-or-pending? ctx 'lair))
            (or (and (>= (l2-ctx-gas ctx) 80) zerg-wants-lair-now?)
                (and (>= (l2-ctx-gas ctx) (sc2-gas-cost 'lair))
                     (or (>= eff-phase-supply 42) (l2-plan-wants-now? ctx 'lair))))))
  (define zerg-spire-res-min
       (cond
         [zerg-holding-for-aa-spire? (sc2-min-cost 'spire)]
         [zerg-holding-for-aa-corruptor? (sc2-min-cost 'corruptor)]
         [else 0]))
  (set-l2-ctx-zerg-spire-res-min! ctx zerg-spire-res-min)
  (define zerg-spire-res-gas
       (cond
         [zerg-holding-for-aa-spire? (sc2-gas-cost 'spire)]
         [zerg-holding-for-aa-corruptor? (sc2-gas-cost 'corruptor)]
         [else 0]))
  (set-l2-ctx-zerg-spire-res-gas! ctx zerg-spire-res-gas)
  (when (and (memq 'spawning-pool ready-bldg-types)
                (or (not live-game?) (> total-queens-now 0))
                queen-allowed-in-crisis?
                (not lair-reserving-last-hatchery?)
                (not zerg-saving-for-expand?)
                (or (not live-game?)
                    (< total-queens-now
                       (+ (max 1 ready-hatch-count)
                          (if (not creep-self-sustaining?) creeping-queen-target 1)))
                    (and zerg-fog-army-floor-ok?
                         (not under-base-attack?)
                         (not early-survival-crisis?)))
                (or (not live-game?)
                    (not under-base-attack?)
                    (and (pair? ally-combat-units) (pair? (cdr ally-combat-units))))
                (>= (- (l2-ctx-minerals ctx) (max (if zerg-holding-lair-min? (sc2-min-cost 'lair) 0)
                                     zerg-spire-res-min))
                    (sc2-min-cost 'queen))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'queen) 'queen)
                (< (l2-unit-count ctx 'queen) desired-queens))
       (l2-try-train-unit! ctx 'queen 'townhall 4))
  (when (and (memq 'spawning-pool ready-bldg-types)
                (l2-upgrade-needed? ctx 'metabolic-boost)
                (>= (- (l2-ctx-minerals ctx) zerg-spire-res-min) (sc2-min-cost 'metabolic-boost))
                (>= (- (l2-ctx-gas ctx) zerg-spire-res-gas) (sc2-gas-cost 'metabolic-boost))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'metabolic-boost) 'metabolic-boost)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'metabolic-boost) 'metabolic-boost))
       (l2-emit-research-verified! ctx 'metabolic-boost))
  (define zerg-hive-t3-tech-ready?
       (and live-game?
            (memq 'hive ready-bldg-types)
            (or (memq 'ultralisk-cavern ready-bldg-types)
                (memq 'greater-spire ready-bldg-types))))
  (when (and (memq 'spawning-pool ready-bldg-types)
                (not zerg-saving-for-expand?)
                (not (l2-building-present-or-pending? ctx 'roach-warren))
                (l2-save-cancel-rebuild-ready? ctx 'roach-warren 60)
                (or (l2-plan-wants-now? ctx 'roach-warren)
                    (and (not zerg-hive-t3-tech-ready?)
                         (or (>= eff-phase-supply 26)
                             (>= (l2-ctx-gas ctx) 80)
                             (>= total-workers SC2-PRIORITY-WORKERS-PER-BASE))))
                (>= (- (l2-ctx-minerals ctx) zerg-spire-res-min) (sc2-min-cost 'roach-warren))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'roach-warren) 'roach-warren))
       (define-values (rw-ax rw-ay)
         (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 4.0)) (safe-coord (- base-y 4.0))))
       (l2-emit-build-verified! ctx 'roach-warren rw-ax rw-ay))
  (when (and (memq 'spawning-pool ready-bldg-types)
                (or (not live-game?)
                    (and zerg-fog-army-floor-ok?
                         (not under-base-attack?)
                         (not early-survival-crisis?)))
                (not zerg-saving-for-expand?)
                (not (l2-building-present-or-pending? ctx 'baneling-nest))
                (l2-save-cancel-rebuild-ready? ctx 'baneling-nest 60)
                (or (l2-plan-wants-now? ctx 'baneling-nest)
                    (and (not zerg-hive-t3-tech-ready?)
                         (or (>= eff-phase-supply 36)
                             (memq 'lair ready-bldg-types)
                             (memq 'hive ready-bldg-types))))
                (>= (- (l2-ctx-minerals ctx) zerg-spire-res-min) (sc2-min-cost 'baneling-nest))
                (>= (- (l2-ctx-gas ctx) zerg-spire-res-gas) (sc2-gas-cost 'baneling-nest))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'baneling-nest) 'baneling-nest)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'baneling-nest) 'baneling-nest))
       (define-values (bn-ax bn-ay)
         (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 3.0)) (safe-coord (- base-y 3.0))))
       (l2-emit-build-verified! ctx 'baneling-nest bn-ax bn-ay))
  (when (and (or (memq 'roach-warren ready-bldg-types)
                    (and crisis-tech-upgrade-deferral? (> (hash-ref open-prod-slots 'roach 0) 0)))
                (or crisis-tech-upgrade-deferral? (not zerg-saving-for-expand?))
                (or (not live-game?)
                    (< (l2-unit-count ctx 'ravager)
                       (if crisis-tech-upgrade-deferral?
                           (max 3 (l2-unit-count ctx 'roach))
                           (max 2 (quotient (max 1 (l2-unit-count ctx 'roach)) 2)))))
                (or crisis-tech-upgrade-deferral?
                    (l2-can-spend-by-priority? ctx 'ravager 'combat-unit)))
       (l2-emit-unit-morph-verified! ctx 'ravager 'roach 1))
  (define cur-spine-cnt
       (+ (for/sum ([b (in-list ally-bldgs)])
            (if (memq (fast-canonical-structure-sym (unit-type-sym b))
                      '(spine-crawler spine-crawler-uprooted))
                1
                0))
          (order-ledger-pending-count-for-type oledger 'spine-crawler frame)))
  (define desired-spine-cnt (if crisis-tech-upgrade-deferral? 2 1))
  (when (and (memq 'spawning-pool ready-bldg-types)
                (>= total-workers 2)
                (< cur-spine-cnt desired-spine-cnt)
                (= (order-ledger-pending-count-for-type oledger 'spine-crawler frame) 0)
                (l2-save-cancel-rebuild-ready? ctx 'spine-crawler 60)
                (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'spine-crawler)) hard-supply-lockout-reserve-min)
                (or (and crisis-tech-upgrade-deferral?
                         (or (<= (hash-ref open-prod-slots 'larva 0) 0)
                             (>= (l2-ctx-minerals ctx) 200))
                         (>= (l2-ctx-minerals ctx) (sc2-min-cost 'spine-crawler)))
                    (and (or early-survival-crisis?
                             (and under-base-attack? (< live-army-supply 6)))
                         (or (not worker-rush-active?)
                             (>= (l2-ctx-minerals ctx) 200)
                             (>= live-army-supply 4))
                         (>= (l2-ctx-minerals ctx) (sc2-min-cost 'spine-crawler)))
                    (and (not zerg-saving-for-expand?)
                         (>= (l2-ctx-minerals ctx) (+ (sc2-min-cost 'spine-crawler) (sc2-min-cost 'roach-warren)))
                         (l2-non-combat-min-ok? ctx (sc2-min-cost 'spine-crawler))
                         (or under-early-cheese? (>= total-workers SC2-IDEAL-WORKERS-PER-BASE)))))
       (define-values (spine-x spine-y)
         (if (<= (length hatcheries) 1)
             (let* ([sdx (- nat-x base-x)]
                    [sdy (- nat-y base-y)]
                    [sd (max 1.0 (sqrt (+ (* sdx sdx) (* sdy sdy))))])
               (values (safe-coord (+ base-x (* 3.5 (/ sdx sd))) base-x)
                       (safe-coord (+ base-y (* 3.5 (/ sdy sd))) base-y)))
             (l2-offset-defense-anchor ctx nat-x nat-y 5.5)))
       (l2-emit-build-verified! ctx 'spine-crawler spine-x spine-y 2.0))
  (when (and (memq 'spawning-pool ready-bldg-types)
                (not zerg-saving-for-expand?)
                (or (l2-plan-wants-now? ctx 'evolution-chamber)
                    (>= eff-phase-supply 36))
                (not (l2-building-present-or-pending? ctx 'evolution-chamber))
                (l2-save-cancel-rebuild-ready? ctx 'evolution-chamber 60)
                (>= (- (l2-ctx-minerals ctx) zerg-spire-res-min) (sc2-min-cost 'evolution-chamber))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'evolution-chamber)))
       (define-values (evo-ax evo-ay)
         (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 3.0)) (safe-coord (- base-y 4.0))))
       (l2-emit-build-verified! ctx 'evolution-chamber evo-ax evo-ay))
  (when (and (memq 'evolution-chamber ready-bldg-types)
                (or (not live-game?)
                    (and zerg-fog-army-floor-ok?
                         (not under-base-attack?)
                         (not early-survival-crisis?))))
       (cond
         [(l2-upgrade-needed? ctx 'zerg-missile-weapons-1)
          (l2-emit-research-verified! ctx 'zerg-missile-weapons-1)]
         [(l2-upgrade-needed? ctx 'zerg-ground-armor-1)
          (l2-emit-research-verified! ctx 'zerg-ground-armor-1)]
         [(and (or (l2-plan-wants-now? ctx 'zerg-melee-weapons-1) (>= (l2-unit-count ctx 'zergling) 12))
               (l2-upgrade-needed? ctx 'zerg-melee-weapons-1))
          (l2-emit-research-verified! ctx 'zerg-melee-weapons-1)]
         [(and (or (memq 'lair ready-bldg-types) (memq 'hive ready-bldg-types))
               (l2-upgrade-needed? ctx 'zerg-missile-weapons-2))
          (l2-emit-research-verified! ctx 'zerg-missile-weapons-2)]
         [(and (or (memq 'lair ready-bldg-types) (memq 'hive ready-bldg-types))
               (l2-upgrade-needed? ctx 'zerg-ground-armor-2))
          (l2-emit-research-verified! ctx 'zerg-ground-armor-2)]
         [(and (or (memq 'lair ready-bldg-types) (memq 'hive ready-bldg-types))
               (or (l2-plan-wants-now? ctx 'zerg-melee-weapons-2) (>= (l2-unit-count ctx 'zergling) 16))
               (l2-upgrade-needed? ctx 'zerg-melee-weapons-2))
          (l2-emit-research-verified! ctx 'zerg-melee-weapons-2)]
         [(and (memq 'hive ready-bldg-types)
               (l2-upgrade-needed? ctx 'zerg-missile-weapons-3))
          (l2-emit-research-verified! ctx 'zerg-missile-weapons-3)]
         [(and (memq 'hive ready-bldg-types)
               (l2-upgrade-needed? ctx 'zerg-ground-armor-3))
          (l2-emit-research-verified! ctx 'zerg-ground-armor-3)])))

(define (l2-zerg-phase3-units-drones! ctx)
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define crisis-freeze-workers? (l2-ctx-crisis-freeze-workers? ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define endgame-corner-hunt? (l2-ctx-endgame-corner-hunt? ctx))
  (define enemy-bldgs (l2-ctx-enemy-bldgs ctx))
  (define enemy-cloaked-or-air? (l2-ctx-enemy-cloaked-or-air? ctx))
  (define enemy-heavy-ground-siege? (l2-ctx-enemy-heavy-ground-siege? ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define frame (l2-ctx-frame ctx))
  (define hatcheries (l2-ctx-hatcheries ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define pressure-metrics (l2-ctx-pressure-metrics ctx))
  (define prio-scheduled-actions (l2-ctx-prio-scheduled-actions ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define researched-upgs (l2-ctx-researched-upgs ctx))
  (define target-workers (l2-ctx-target-workers ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define unit-types (l2-ctx-unit-types ctx))
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
  (define zerg-fog-army-floor-ok? (l2-ctx-zerg-fog-army-floor-ok? ctx))
  (define zerg-holding-for-aa-corruptor? (l2-ctx-zerg-holding-for-aa-corruptor? ctx))
  (define zerg-holding-for-aa-spire? (l2-ctx-zerg-holding-for-aa-spire? ctx))
  (define zerg-larva-mineral-surplus-ok? (l2-ctx-zerg-larva-mineral-surplus-ok? ctx))
  (define zerg-real-anti-air-threat? (l2-ctx-zerg-real-anti-air-threat? ctx))
  (define zerg-saving-for-expand? (l2-ctx-zerg-saving-for-expand? ctx))
  (define zerg-spire-res-gas (l2-ctx-zerg-spire-res-gas ctx))
  (define zerg-spire-res-min (l2-ctx-zerg-spire-res-min ctx))
  (define zerg-vs-tp-or-fog-floor (l2-ctx-zerg-vs-tp-or-fog-floor ctx))
  (when (or (memq 'lair ready-bldg-types) (memq 'hive ready-bldg-types))
       (define zerg-lair-upgs-safe?
         (or (not live-game?)
             (and zerg-fog-army-floor-ok?
                  (not under-base-attack?)
                  (not early-survival-crisis?))))
       (when (and zerg-lair-upgs-safe?
                  (l2-upgrade-needed? ctx 'burrow)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'burrow)
                      (and (>= (l2-unit-count ctx 'roach) 4)
                           (memq 'hydralisk-den (l2-ctx-bldg-types ctx))))
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'burrow))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'burrow)))
         (l2-emit-research-verified! ctx 'burrow))
       (when (and zerg-lair-upgs-safe?
                  (memq 'roach-warren ready-bldg-types))
         (cond
           [(and (or (not live-game?)
                     (l2-plan-wants-now? ctx 'glial-reconstitution)
                     (>= (l2-unit-count ctx 'roach) 2))
                 (l2-upgrade-needed? ctx 'glial-reconstitution))
            (l2-emit-research-verified! ctx 'glial-reconstitution)]
           [(and (or (not live-game?)
                     (l2-plan-wants-now? ctx 'tunneling-claws)
                     (and (>= (l2-unit-count ctx 'roach) 4)
                          (memq 'burrow researched-upgs)))
                 (l2-upgrade-needed? ctx 'tunneling-claws))
            (l2-emit-research-verified! ctx 'tunneling-claws)]))
       (when (and zerg-lair-upgs-safe?
                  (memq 'baneling-nest ready-bldg-types)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'centrifical-hooks)
                      (>= (+ (l2-unit-count ctx 'baneling) (quotient (l2-unit-count ctx 'zergling) 2)) 3))
                  (l2-upgrade-needed? ctx 'centrifical-hooks))
         (l2-emit-research-verified! ctx 'centrifical-hooks))
       (when (and (or (not zerg-saving-for-expand?)
                      (and (>= (length hatcheries) 3)
                           (enemy-tech-observation-requires-anti-air? tech-obs)))
                  (not (l2-building-present-or-pending? ctx 'spire))
                  (not (l2-building-present-or-pending? ctx 'greater-spire))
                  (l2-save-cancel-rebuild-ready? ctx 'spire 60)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'spire)
                      zerg-real-anti-air-threat?
                      enemy-heavy-ground-siege?
                      endgame-corner-hunt?
                      (>= eff-phase-supply 68))
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'spire))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'spire)))
         (define-values (sp-ax sp-ay)
           (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 5.0)) (safe-coord (+ base-y 4.0))))
         (l2-emit-build-verified! ctx 'spire sp-ax sp-ay))
       (when (and (or (not zerg-saving-for-expand?)
                      (and (>= (length hatcheries) 3)
                           zerg-real-anti-air-threat?))
                  (or (not crisis-tech-upgrade-deferral?) zerg-real-anti-air-threat?)
                  (not zerg-holding-for-aa-corruptor?)
                  (not (l2-building-present-or-pending? ctx 'hydralisk-den))
                  (l2-save-cancel-rebuild-ready? ctx 'hydralisk-den 60)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'hydralisk-den)
                      zerg-real-anti-air-threat?
                      (>= eff-phase-supply 52))
                  (>= (- (l2-ctx-minerals ctx) zerg-spire-res-min) (sc2-min-cost 'hydralisk-den))
                  (>= (- (l2-ctx-gas ctx) zerg-spire-res-gas) (sc2-gas-cost 'hydralisk-den)))
         (define-values (hd-ax hd-ay)
           (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 4.0)) (safe-coord (+ base-y 5.0))))
         (l2-emit-build-verified! ctx 'hydralisk-den hd-ax hd-ay))
       (when (and (not zerg-saving-for-expand?)
                  (not zerg-holding-for-aa-corruptor?)
                  (not (l2-building-present-or-pending? ctx 'infestation-pit))
                  (l2-save-cancel-rebuild-ready? ctx 'infestation-pit 60)
                  (or (not live-game?)
                      (>= live-army-supply 26)
                      (>= eff-phase-supply 76))
                  (or (l2-plan-wants-now? ctx 'infestation-pit)
                      (l2-plan-wants-now? ctx 'hive)
                      (and live-game?
                           (or (>= (length hatcheries) 3)
                               (>= total-workers 52)
                               (>= eff-phase-supply 76))))
                  (>= (- (l2-ctx-minerals ctx) zerg-spire-res-min) (sc2-min-cost 'infestation-pit))
                  (>= (- (l2-ctx-gas ctx) zerg-spire-res-gas) (sc2-gas-cost 'infestation-pit)))
         (define-values (ip-ax ip-ay)
           (l2-safe-zerg-build-anchor ctx (safe-coord (- base-x 4.0)) (safe-coord (+ base-y 4.0))))
         (l2-emit-build-verified! ctx 'infestation-pit ip-ax ip-ay))
       (when (and (memq 'lair ready-bldg-types)
                  (memq 'infestation-pit ready-bldg-types)
                  (not zerg-holding-for-aa-corruptor?)
                  (not zerg-saving-for-expand?))
         (l2-emit-building-morph-verified! ctx 'hive '(lair) 4))
       (when (and (memq 'hive ready-bldg-types)
                  (memq 'spire ready-bldg-types)
                  (not zerg-saving-for-expand?)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'greater-spire)
                      enemy-heavy-ground-siege?
                      (>= (length hatcheries) 4)
                      (>= total-workers 64)
                      (>= eff-phase-supply 100)))
         (l2-emit-building-morph-verified! ctx 'greater-spire '(spire) 4))
       (when (and (memq 'hive ready-bldg-types)
                  (not zerg-saving-for-expand?)
                  (not zerg-holding-for-aa-corruptor?)
                  (not (l2-building-present-or-pending? ctx 'ultralisk-cavern))
                  (l2-save-cancel-rebuild-ready? ctx 'ultralisk-cavern 60)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'ultralisk-cavern)
                      (>= (length hatcheries) 4)
                      (>= eff-phase-supply 96))
                  (>= (- (l2-ctx-minerals ctx) zerg-spire-res-min) (sc2-min-cost 'ultralisk-cavern))
                  (>= (- (l2-ctx-gas ctx) zerg-spire-res-gas) (sc2-gas-cost 'ultralisk-cavern)))
         (define-values (uc-ax uc-ay)
           (l2-safe-zerg-build-anchor ctx (safe-coord (- base-x 5.0)) (safe-coord (- base-y 4.0))))
         (l2-emit-build-verified! ctx 'ultralisk-cavern uc-ax uc-ay))
       (when (memq 'hydralisk-den ready-bldg-types)
         (cond
           [(l2-upgrade-needed? ctx 'grooved-spines)
            (l2-emit-research-verified! ctx 'grooved-spines)]
           [(l2-upgrade-needed? ctx 'muscular-augments)
            (l2-emit-research-verified! ctx 'muscular-augments)]))
       (when (and (memq 'infestation-pit ready-bldg-types)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'neural-parasite)
                      (>= (l2-unit-count ctx 'infestor) 1))
                  (l2-upgrade-needed? ctx 'neural-parasite))
         (l2-emit-research-verified! ctx 'neural-parasite))
       (when (and (memq 'hive ready-bldg-types)
                  (memq 'spawning-pool ready-bldg-types)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'zergling-attackspeed)
                      (>= (l2-unit-count ctx 'zergling) 6))
                  (l2-upgrade-needed? ctx 'zergling-attackspeed))
         (l2-emit-research-verified! ctx 'zergling-attackspeed))
       (when (memq 'ultralisk-cavern ready-bldg-types)
         (cond
           [(l2-upgrade-needed? ctx 'chitinous-plating)
            (l2-emit-research-verified! ctx 'chitinous-plating)]
           [(l2-upgrade-needed? ctx 'anabolic-synthesis)
            (l2-emit-research-verified! ctx 'anabolic-synthesis)]))
       (when (and (memq 'hydralisk-den ready-bldg-types)
                  (not zerg-saving-for-expand?)
                  (not (l2-building-present-or-pending? ctx 'lurker-den))
                  (l2-save-cancel-rebuild-ready? ctx 'lurker-den 60)
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'lurker-den))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'lurker-den)))
         (define-values (ld-ax ld-ay)
           (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 5.0)) (safe-coord (- base-y 5.0))))
         (l2-emit-build-verified! ctx 'lurker-den ld-ax ld-ay))
       (when (and (or (memq 'lurker-den ready-bldg-types)
                      (and (not live-game?) (memq 'hydralisk-den ready-bldg-types)))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'adaptive-talons))
                  (l2-upgrade-needed? ctx 'adaptive-talons))
         (l2-emit-research-verified! ctx 'adaptive-talons))
       (when (and (memq 'lurker-den ready-bldg-types)
                  (memq 'hive ready-bldg-types)
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'seismic-spines))
                  (l2-upgrade-needed? ctx 'seismic-spines))
         (l2-emit-research-verified! ctx 'seismic-spines)))
  (when (or enemy-cloaked-or-air?
               (enemy-tech-observation-requires-detection? tech-obs)
               (and (not live-game?) (memq 'spire (l2-ctx-bldg-types ctx))))
       (when (and (or (not live-game?)
                      (and (memq 'spawning-pool ready-bldg-types)
                           (not (l2-building-present-or-pending? ctx 'spore-crawler))
                           (l2-save-cancel-rebuild-ready? ctx 'spore-crawler 60)
                           (>= (- (l2-ctx-minerals ctx) zerg-spire-res-min) (sc2-min-cost 'spore-crawler))))
                  (refractory-allow-action?! cd-tracker
                                             (list 'static-detector 'spore-crawler)
                                             frame
                                             SC2-STATIC-DETECTOR-COOLDOWN-FRAMES))
         (if live-game?
             (let-values ([(spc-ax spc-ay)
                           (l2-safe-zerg-build-anchor ctx (safe-coord (+ base-x 3.0)) (safe-coord (+ base-y 3.0)))])
               (l2-emit-build-verified! ctx 'spore-crawler spc-ax spc-ay))
             (l2-emit! ctx (list 'build 'spore-crawler (safe-coord (+ base-x 3.0)) (safe-coord (+ base-y 3.0))))))
       (if live-game?
           (when (and (or (memq 'lair ready-bldg-types) (memq 'hive ready-bldg-types))
                      (or (and (not zerg-holding-for-aa-spire?)
                               (not zerg-holding-for-aa-corruptor?))
                          enemy-cloaked-or-air?)
                      (< (l2-unit-count ctx 'overseer) 2))
             (l2-emit-unit-morph-verified! ctx 'overseer 'overlord 0))
           (when (not (memq 'overseer unit-types))
             (l2-emit! ctx '(morph overseer)))))
  (define-values (overseers active-changelings)
       (let ([ov-rev '()] [ch-cnt 0])
         (for ([u (in-list ally-units)])
           (define ut (unit-type-sym u))
           (cond
             [(eq? (fast-canonical-unit-sym ut) 'overseer)
              (set! ov-rev (cons u ov-rev))]
             [(and live-game?
                   (memq ut '(changeling changeling-zealot changeling-marine
                              changeling-marine-shield changeling-zergling
                              changeling-zergling-wings)))
              (set! ch-cnt (add1 ch-cnt))]))
         (values (reverse ov-rev) ch-cnt)))
  (for ([ov (in-list overseers)])
       (when (and (>= (hash-ref ov 'energy SC2-OVERSEER-CHANGELING-ENERGY) SC2-OVERSEER-CHANGELING-ENERGY)
                  (or (not live-game?)
                      (and (< active-changelings 2)
                           (refractory-allow-action?! cd-tracker 'overseer-changeling frame 336))))
         (l2-emit! ctx (list 'cast (hash-ref ov 'id 190) 'spawn-changeling enemy-x enemy-y))))
  (cond
       [(memq 'lurker-den ready-bldg-types)
        (when (or (not live-game?)
                  (and (not zerg-saving-for-expand?)
                       (< (l2-unit-count ctx 'lurker) 8)
                       (l2-can-spend-by-priority? ctx 'lurker 'combat-unit)))
          (l2-emit-unit-morph-verified! ctx 'lurker 'hydralisk 1))]
       [(and (not live-game?)
             (memq 'spire ready-bldg-types)
             (memq 'hydralisk-den ready-bldg-types))
        (l2-emit! ctx '(morph lurker))])
  (when (and (not live-game?)
                (memq 'spire ready-bldg-types)
                (memq 'hydralisk-den ready-bldg-types)
                (not (l2-building-present-or-pending? ctx 'hive)))
       (l2-emit! ctx '(morph hive)))
  (when (memq 'greater-spire ready-bldg-types)
       (l2-emit-unit-morph-verified! ctx 'brood-lord 'corruptor 2))
  (define zerg-ideal-worker-cap
       (l2-compute-race-ideal-worker-cap ctx hatcheries))
  (define zerg-3base-interleave-drone-ok?
       (and (not under-base-attack?)
            (>= (length hatcheries) 3)
            (< total-workers 55)
            (or (< total-workers 38)
                zerg-larva-mineral-surplus-ok?
                (>= live-army-supply (max 4.0 zerg-vs-tp-or-fog-floor)))
            (>= live-army-supply 4.0)))
  (define zerg-drone-batch
       (cond
         [(and (> live-enemy-threat-supply 0) (>= total-workers 24)) 1]
         [(and live-game?
               (>= total-workers 34)
               (memq effective-enemy-race '(Terran Protoss Unknown Random)))
          2]
         [else 4]))
  (define zerg-drone-priority?
       (and (not crisis-freeze-workers?)
            (not zerg-holding-for-aa-spire?)
            (not zerg-holding-for-aa-corruptor?)
            (l2-worker-army-curve-satisfied? ctx)
            (or (not zerg-saving-for-expand?)
                (and (< total-workers 16) (< (l2-ctx-minerals ctx) 250)))
            (not urgent-combat-or-intel-need?)
            (or (< total-workers zerg-ideal-worker-cap)
                (l2-can-spend-by-priority? ctx 'drone 'worker))
            (< total-workers (min 70 (max target-workers zerg-ideal-worker-cap)))
            (or (not live-game?)
                (and (not under-base-attack?) (<= live-enemy-threat-supply 0))
                zerg-3base-interleave-drone-ok?
                (< total-workers 19)
                (not (memq 'spawning-pool ready-bldg-types))
                (>= (length ally-combat-units) 4)
                (>= live-army-supply (* 6 (max 1 (length hatcheries)))))
            (>= (l2-ctx-minerals ctx) (sc2-min-cost 'drone))
            (l2-can-spend-supply? ctx (sc2-supply-cost 'drone))
            (not under-early-cheese?)
            (< (hash-ref pressure-metrics 'threat-pressure 0.0)
               (if zerg-3base-interleave-drone-ok? 2.0 0.75))))
  (when zerg-drone-priority?
       (l2-try-train-unit! ctx 'drone 'larva zerg-drone-batch
                        #:respect-bo-reserve?
                        (and live-game?
                             (or (not zerg-3base-interleave-drone-ok?)
                                 (enemy-tech-observation-requires-anti-air? tech-obs))
                             (or (>= total-workers 24)
                                 (>= total-workers zerg-ideal-worker-cap)
                                 (and (>= total-workers 16)
                                      (> (l2-ctx-bo-reserved-gas ctx) 0)
                                      (>= (l2-ctx-gas ctx) (l2-ctx-bo-reserved-gas ctx))))
                             (not (memq bo-goal-sym '(hatchery nexus command-center drone probe scv))))))
  (when (and live-game?
                zerg-saving-for-expand?
                (>= (length hatcheries) 3)
                (enemy-tech-observation-requires-anti-air? tech-obs)
                (< (l2-unit-count ctx 'corruptor) 4))
       (cond
         [(or (memq 'spire ready-bldg-types) (memq 'greater-spire ready-bldg-types))
          (l2-try-train-unit! ctx 'corruptor 'larva 4 #:respect-bo-reserve? #f)]
         [(memq 'hydralisk-den ready-bldg-types)
          (l2-try-train-unit! ctx 'hydralisk 'larva 4 #:respect-bo-reserve? #f)]))
  (unless zerg-saving-for-expand?
       (when (and (memq 'baneling-nest ready-bldg-types)
                  (< (l2-unit-count ctx 'baneling)
                     (max 4 (quotient (max 1 (l2-unit-count ctx 'zergling)) 2)))
                  (l2-can-spend-by-priority? ctx 'baneling 'combat-unit))
         (l2-emit-unit-morph-verified! ctx 'baneling 'zergling 0))
       (define zerg-needs-queen-or-warren-minerals?
         (and live-game?
              (not under-base-attack?)
              (<= live-enemy-threat-supply 0)
              (>= live-army-supply 4)
              (or (< (l2-unit-count ctx 'queen) (length hatcheries))
                  (and (>= (l2-ctx-gas ctx) 80)
                       (not (l2-building-present-or-pending? ctx 'roach-warren))))))
       ;; Endgame Anti-Tie Corner Hunters: maintain >= 2 flying AA hunters (Corruptor / Mutalisk)
       (when (and endgame-corner-hunt?
                  (or (memq 'spire ready-bldg-types) (memq 'greater-spire ready-bldg-types))
                  (< (+ (l2-unit-count ctx 'mutalisk) (l2-unit-count ctx 'corruptor)) 2))
         (when (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'corruptor))
                    (>= (l2-ctx-gas ctx) (sc2-gas-cost 'corruptor)))
           (l2-try-train-unit! ctx 'corruptor 'larva 4))
         (when (and (< (+ (l2-unit-count ctx 'mutalisk) (l2-unit-count ctx 'corruptor)) 2)
                    (>= (l2-ctx-minerals ctx) (sc2-min-cost 'mutalisk))
                    (>= (l2-ctx-gas ctx) (sc2-gas-cost 'mutalisk)))
           (l2-try-train-unit! ctx 'mutalisk 'larva 4)))
       (define brood-lord-corruptor-target
         (if (or enemy-heavy-ground-siege? (memq 'greater-spire ready-bldg-types)) 5 3))
       ;; T3 Air Siege: Corruptor -> Brood Lord when Greater Spire is ready or morphing (`< 8` cap, `#89` [UNCOVERED-Z3])
       (when (and (or (memq 'greater-spire ready-bldg-types)
                      (l2-building-present-or-pending? ctx 'greater-spire))
                  (< (l2-unit-count ctx 'brood-lord) 8))
         (when (< (l2-unit-count ctx 'corruptor) brood-lord-corruptor-target)
           (l2-try-train-unit! ctx 'corruptor 'larva 4 #:respect-bo-reserve? #t))
         (when (memq 'greater-spire ready-bldg-types)
           (l2-emit-unit-morph-verified! ctx 'brood-lord 'corruptor 2)))
       ;; T3 Hive Caster: Viper (Blinding Cloud / Abduct / Parasitic Bomb)
       (when (and (memq 'hive ready-bldg-types)
                  (< (l2-unit-count ctx 'viper) (if (>= eff-phase-supply 130) 3 2))
                  (or (l2-plan-wants-now? ctx 'viper)
                      enemy-heavy-ground-siege?
                      (and live-game? (>= live-army-supply 34)))
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'viper))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'viper)))
         (l2-try-train-unit! ctx 'viper 'larva 4 #:respect-bo-reserve? #t))
       ;; T3 Frontline: Ultralisk (`ultralisk-cavern` protects `200G` ahead of Hydra drain, `#89` [UNCOVERED-Z3])
       (define hold-ultra-gas?
         (and live-game?
              (not crisis-tech-upgrade-deferral?)
              (memq 'hive ready-bldg-types)
              (memq 'ultralisk-cavern ready-bldg-types)
              (< (l2-unit-count ctx 'ultralisk) 6)
              (not zerg-real-anti-air-threat?)))
       (define zerg-ultra-res-gas
         (if hold-ultra-gas? (sc2-gas-cost 'ultralisk) 0))
       (when (and (memq 'ultralisk-cavern ready-bldg-types)
                  (< (l2-unit-count ctx 'ultralisk) 8)
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'ultralisk))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'ultralisk))
                  (or (l2-can-spend-by-priority? ctx 'ultralisk 'combat-unit)
                      (and live-game? (< (l2-unit-count ctx 'ultralisk) 4))))
         (l2-try-train-unit! ctx 'ultralisk 'larva 4 #:respect-bo-reserve? #t))
       ;; T2/T3 Caster: Infestor
       (when (and (memq 'infestation-pit ready-bldg-types)
                  (< (l2-unit-count ctx 'infestor) 2)
                  (or (l2-plan-wants-now? ctx 'infestor)
                      (and live-game? (>= live-army-supply 50)))
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'infestor))
                  (>= (- (l2-ctx-gas ctx) zerg-ultra-res-gas) (sc2-gas-cost 'infestor)))
         (l2-try-train-unit! ctx 'infestor 'larva 4 #:respect-bo-reserve? #t))
       (define zerg-ground-threats-exist?
         (or (ormap (lambda (e)
                      (and (combat-unit-record? e)
                           (not (fast-unit-is-flying-sym? (unit-type-sym e)))))
                    enemy-units)
             (ormap (lambda (eb)
                      (memq (unit-type-sym eb) '(bunker photon-cannon spine-crawler planetary-fortress)))
                    enemy-bldgs)
             (>= live-enemy-threat-supply 4)
             (and (null? enemy-units) (not zerg-real-anti-air-threat?))))
       (define zergling-heavy-counter?
         (ormap (lambda (e)
                  (memq (unit-type-sym e)
                        '(siege-tank siege-tank-sieged colossus archon planetary-fortress)))
                (append enemy-units enemy-bldgs)))
       (define zergling-standing-cap
         (cond
           [(>= (l2-ctx-minerals ctx) 1500) 999]
           [zergling-heavy-counter? 20]
           [else 32]))
       (define (zergling-under-cap?)
         (or (not live-game?)
             (< (l2-unit-count ctx 'zergling) zergling-standing-cap)))
       (define (try-zerg-roach-core!)
         (when (and (memq 'roach-warren ready-bldg-types)
                    zerg-ground-threats-exist?
                    (>= (l2-ctx-minerals ctx) 300)
                    (>= (- (l2-ctx-gas ctx) zerg-ultra-res-gas) (sc2-gas-cost 'roach))
                    (or (not live-game?) (< (l2-unit-count ctx 'roach) 16))
                    (l2-can-spend-by-priority? ctx 'roach 'combat-unit))
           (l2-try-train-unit! ctx 'roach 'larva 4 #:respect-bo-reserve? #t)))
       (when (and crisis-tech-upgrade-deferral?
                  (not zerg-real-anti-air-threat?)
                  (memq 'roach-warren ready-bldg-types)
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'roach))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'roach)))
         (l2-try-train-unit! ctx 'roach 'larva 4 #:respect-bo-reserve? #f))
       (cond
         [(and (or (memq 'spire ready-bldg-types) (memq 'greater-spire ready-bldg-types))
               (or (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'corruptor))
                        (>= (l2-ctx-gas ctx) (sc2-gas-cost 'corruptor)))
                   (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'mutalisk))
                        (>= (l2-ctx-gas ctx) (sc2-gas-cost 'mutalisk)))))
          (define zerg-anti-air-now? zerg-real-anti-air-threat?)
          (define hold-mutalisk-for-corruptor?
            (and live-game?
                 zerg-anti-air-now?
                 (< (l2-unit-count ctx 'corruptor) 8)
                 (or (< (l2-ctx-minerals ctx) 250) (< (l2-ctx-gas ctx) 200))))
          (when (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'corruptor))
                     (>= (- (l2-ctx-gas ctx) (if zerg-anti-air-now? 0 zerg-ultra-res-gas)) (sc2-gas-cost 'corruptor))
                     (or (not live-game?)
                         (and zerg-anti-air-now? (< (l2-unit-count ctx 'corruptor) 8))
                         (and (or (memq 'greater-spire ready-bldg-types)
                                  (l2-building-present-or-pending? ctx 'greater-spire))
                              (or (not live-game?) (< (l2-unit-count ctx 'corruptor) 6)))
                         (and zerg-anti-air-now?
                              (< (l2-unit-count ctx 'corruptor) 10)
                              (l2-plan-wants-now? ctx 'corruptor))))
            (l2-try-train-unit! ctx 'corruptor 'larva 4 #:respect-bo-reserve? (not zerg-anti-air-now?)))
          (when (and (not hold-mutalisk-for-corruptor?)
                     (< (l2-unit-count ctx 'mutalisk) 10)
                     (>= (- (l2-ctx-gas ctx) zerg-ultra-res-gas) (sc2-gas-cost 'mutalisk))
                     (l2-can-spend-by-priority? ctx 'mutalisk 'combat-unit))
            (l2-try-train-unit! ctx 'mutalisk 'larva 4 #:respect-bo-reserve? #t))
          (when (and (memq 'hydralisk-den ready-bldg-types)
                     (>= (- (l2-ctx-gas ctx) zerg-ultra-res-gas) (sc2-gas-cost 'hydralisk)))
            (l2-try-train-unit! ctx 'hydralisk 'larva 4 #:respect-bo-reserve? #t))
          (try-zerg-roach-core!)
          (when (and (memq 'spawning-pool ready-bldg-types)
                     (zergling-under-cap?)
                     (>= (l2-ctx-minerals ctx) 300)
                     (l2-can-spend-by-priority? ctx 'zergling 'combat-unit))
            (l2-try-train-unit! ctx 'zergling 'larva 4 #:respect-bo-reserve? #t))]
         [(and (memq 'hydralisk-den ready-bldg-types)
               (>= (l2-ctx-minerals ctx) (sc2-min-cost 'hydralisk))
               (>= (- (l2-ctx-gas ctx) zerg-ultra-res-gas) (sc2-gas-cost 'hydralisk)))
          (when (or (not live-game?)
                    (not (memq 'hive ready-bldg-types))
                    (< (l2-unit-count ctx 'hydralisk) 16)
                    (< (l2-ctx-gas ctx) 150))
            (l2-try-train-unit! ctx 'hydralisk 'larva 4 #:respect-bo-reserve? #t))
          (when (and (memq 'roach-warren ready-bldg-types)
                     (or (not live-game?)
                         (and zerg-ground-threats-exist?
                              (or (>= (l2-ctx-minerals ctx) 300) (< (l2-ctx-gas ctx) (sc2-gas-cost 'hydralisk)))
                              (< (l2-unit-count ctx 'roach) 16)))
                     (>= (- (l2-ctx-gas ctx) zerg-ultra-res-gas) (sc2-gas-cost 'roach))
                     (l2-can-spend-by-priority? ctx 'roach 'combat-unit))
            (l2-try-train-unit! ctx 'roach 'larva 4 #:respect-bo-reserve? #t))
          (when (and (memq 'spawning-pool ready-bldg-types)
                     (zergling-under-cap?)
                     (>= (l2-ctx-minerals ctx) 300)
                     (l2-can-spend-by-priority? ctx 'zergling 'combat-unit))
            (l2-try-train-unit! ctx 'zergling 'larva 4 #:respect-bo-reserve? #t))]
         [(and (memq 'roach-warren ready-bldg-types)
               (>= (l2-ctx-minerals ctx) (sc2-min-cost 'roach))
               (>= (- (l2-ctx-gas ctx) zerg-ultra-res-gas) (sc2-gas-cost 'roach)))
          (l2-try-train-unit! ctx 'roach 'larva 4 #:respect-bo-reserve? #t)
          (when (and (memq 'spawning-pool ready-bldg-types)
                     (zergling-under-cap?)
                     (not zerg-needs-queen-or-warren-minerals?)
                     (or (< (l2-ctx-gas ctx) (sc2-gas-cost 'roach)) (>= (l2-ctx-minerals ctx) 200))
                     (l2-can-spend-by-priority? ctx 'zergling 'combat-unit))
            (l2-try-train-unit! ctx 'zergling 'larva 4 #:respect-bo-reserve? #t))]
         [(and (memq 'spawning-pool ready-bldg-types)
               (zergling-under-cap?)
               (or (not zerg-needs-queen-or-warren-minerals?)
                   (>= (l2-ctx-minerals ctx) (+ (sc2-min-cost 'queen) (sc2-min-cost 'zergling))))
               (l2-can-spend-by-priority? ctx 'zergling 'combat-unit)
               (>= (l2-ctx-minerals ctx) (sc2-min-cost 'zergling))
               (or under-early-cheese?
                   urgent-combat-or-intel-need?
                   (>= (hash-ref pressure-metrics 'threat-pressure 0.0) 0.35)
                   (>= total-workers (add1 SC2-PRIORITY-WORKERS-PER-BASE))
                   (< (length ally-combat-units) SC2-ATTACK-WAVE-MIN-COMBAT-UNITS)
                   (>= (l2-ctx-minerals ctx) (sc2-min-cost 'queen))))
          (l2-try-train-unit! ctx 'zergling 'larva 4 #:respect-bo-reserve? #t)]))
  (when (and (not zerg-drone-priority?)
                (not crisis-freeze-workers?)
                (l2-worker-army-curve-satisfied? ctx)
                (not zerg-saving-for-expand?)
                (l2-can-spend-by-priority? ctx 'drone 'worker)
                (< total-workers
                   (if live-game?
                       (min 70 (max target-workers zerg-ideal-worker-cap))
                       target-workers))
                (or (member '(train drone) prio-scheduled-actions)
                    (< (hash-ref pressure-metrics 'threat-pressure 0.0) 1.0)))
       (l2-try-train-unit! ctx 'drone 'larva zerg-drone-batch
                        #:respect-bo-reserve? (and live-game? (>= total-workers 24)))))

(define (l2-protoss-phase1-chrono-wall! ctx)
  (define allow-exact-wall-slot? (l2-ctx-allow-exact-wall-slot? ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define blocked-nat-expanded-early? (l2-ctx-blocked-nat-expanded-early? ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define cortex (l2-ctx-cortex ctx))
  (define crisis-freeze-expand-or-gas? (l2-ctx-crisis-freeze-expand-or-gas? ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define cur-escrow-age-frames (l2-ctx-cur-escrow-age-frames ctx))
  (define desired-bases (l2-ctx-desired-bases ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define endgame-corner-hunt? (l2-ctx-endgame-corner-hunt? ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define forward-proxy-detected? (l2-ctx-forward-proxy-detected? ctx))
  (define frame (l2-ctx-frame ctx))
  (define hard-supply-lockout-reserve-min (l2-ctx-hard-supply-lockout-reserve-min ctx))
  (define in-base-proxy-detected? (l2-ctx-in-base-proxy-detected? ctx))
  (define leases (l2-ctx-leases ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-game-obs? (l2-ctx-live-game-obs? ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define macro-plan (l2-ctx-macro-plan ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define obs (l2-ctx-obs ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define power-placement-failed? (l2-ctx-power-placement-failed? ctx))
  (define protoss-matchup-wall (l2-ctx-protoss-matchup-wall ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define ready-bldgs (l2-ctx-ready-bldgs ctx))
  (define rt (l2-ctx-rt ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define workers (l2-ctx-workers ctx))
  (define nexuses-rev '())
  (define assimilators-rev '())
  (define active-assimilators-rev '())
  (define gateways-rev '())
  (for ([b (in-list ally-bldgs)])
       (define cs (fast-canonical-structure-sym (unit-type-sym b)))
       (cond
         [(eq? cs 'nexus)
          (set! nexuses-rev (cons b nexuses-rev))]
         [(eq? cs 'assimilator)
          (set! assimilators-rev (cons b assimilators-rev))
          (when (l2-active-gas-bldg? ctx b)
            (set! active-assimilators-rev (cons b active-assimilators-rev)))]
         [(memq cs '(gateway warp-gate))
          (set! gateways-rev (cons b gateways-rev))]))
  (define nexuses (reverse nexuses-rev))
  (set-l2-ctx-nexuses! ctx nexuses)
  (define assimilators (reverse assimilators-rev))
  (define active-assimilators (reverse active-assimilators-rev))
  (set-l2-ctx-active-assimilators! ctx active-assimilators)
  (define gateways (reverse gateways-rev))
  (set-l2-ctx-gateways! ctx gateways)
  (define ready-nexuses
       (let ([rev '()])
         (for ([b (in-list ready-bldgs)])
           (when (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'nexus)
             (set! rev (cons b rev))))
         (reverse rev)))
  (define chrono-claimed-ids (mutable-seteqv))
  (define (eligible-live-chrono-target? b)
       (and (hash-ref b 'busy? #f)
            (not (memq 'chrono-boost (hash-ref b 'buffs '())))
            (not (set-member? chrono-claimed-ids (hash-ref b 'id -1)))))
  (define (chrono-prio-score b)
       (define bsym (fast-canonical-structure-sym (unit-type-sym b)))
       (cond
         [(and (or early-survival-crisis? under-base-attack?)
               (memq bsym '(gateway warp-gate robotics-facility stargate)))
          1000.0]
         [(and (< total-workers 38)
               (not early-survival-crisis?)
               (eq? bsym 'nexus))
          900.0]
         [else
          (let loop ([rem PRO-CHRONO-11-STRUCTURES] [idx 0])
            (cond
              [(null? rem) -1.0]
              [(eq? bsym (sc2-canonical-structure-sym (car rem)))
               (- 800.0 (* 10.0 idx))]
              [else (loop (cdr rem) (add1 idx))]))]))
  (if live-game?
         (fast-dispatch-macro-energy!
          ready-nexuses
          ready-bldgs
          frame
          chrono-claimed-ids
          #:min-energy SC2-NEXUS-CHRONO-BOOST-ENERGY
          #:valid-pair?
          (lambda (_nx b)
            (and (eligible-live-chrono-target? b)
                 (> (chrono-prio-score b) 0.0)))
          #:score-pair
          (lambda (_nx b)
            (chrono-prio-score b))
          #:emit-cast!
          (lambda (nx b)
            (define nx-id (hash-ref nx 'id 201))
            (define ct-id (hash-ref b 'id nx-id))
            (l2-emit! ctx (list 'cast-spell nx-id 'chrono-boost ct-id))))
         (for ([nx (in-list ready-nexuses)])
           (when (>= (hash-ref nx 'energy SC2-NEXUS-CHRONO-BOOST-ENERGY) SC2-NEXUS-CHRONO-BOOST-ENERGY)
             (define nx-id (hash-ref nx 'id 201))
             (define chrono-target
               (if (and (< total-workers SC2-EARLY-CHRONO-MAX-WORKERS)
                        (< frame SC2-EARLY-CHRONO-NEXUS-MAX-FRAME)
                        (not early-survival-crisis?))
                   nx
                   (or (and early-survival-crisis?
                            (findf (lambda (b)
                                     (memq (fast-canonical-structure-sym (unit-type-sym b))
                                           '(gateway warp-gate)))
                                   ready-bldgs))
                       (for/or ([prio-type (in-list PRO-CHRONO-11-STRUCTURES)]
                                #:when (not (eq? prio-type 'nexus)))
                         (findf (lambda (b)
                                  (eq? (fast-canonical-structure-sym (unit-type-sym b))
                                       (sc2-canonical-structure-sym prio-type)))
                                ready-bldgs))
                       nx)))
             (when chrono-target
               (define ct-id (hash-ref chrono-target 'id nx-id))
               (set-add! chrono-claimed-ids ct-id)
               (l2-emit! ctx (list 'cast-spell nx-id 'chrono-boost ct-id))))))
  (define wall-pylon-slot (and (hash? protoss-matchup-wall) (hash-ref protoss-matchup-wall 'pylon #f)))
  (define wall-slot-1 (and (hash? protoss-matchup-wall) (hash-ref protoss-matchup-wall 'slot-1 #f)))
  (define wall-slot-2 (and (hash? protoss-matchup-wall) (hash-ref protoss-matchup-wall 'slot-2 #f)))
  (define wall-slot-3 (and (hash? protoss-matchup-wall) (hash-ref protoss-matchup-wall 'slot-3 #f)))
  (set-l2-ctx-wall-slot-3! ctx wall-slot-3)
  (define wall-door-pt (and (hash? protoss-matchup-wall) (hash-ref protoss-matchup-wall 'door #f)))
  (define wall-park-pt (and (hash? protoss-matchup-wall) (hash-ref protoss-matchup-wall 'door-park #f)))
  (define door-guards
       (filter (lambda (u)
                 (and (memq (unit-type-sym u) '(zealot adept stalker))
                      (not (or (eq? (hash-ref u 'is-hallucination #f) #t)
                               (eq? (hash-ref u 'hallucination #f) #t)))))
               ally-units))
  (cond
       [(and (not (null? door-guards))
             (or (hash-ref obs 'door-guard #f)
                 (and (not live-game?)
                      (or (memq 'gateway (l2-ctx-bldg-types ctx)) (memq 'warp-gate (l2-ctx-bldg-types ctx)))
                      (< frame SC2-DOOR-GUARD-MAX-FRAME)
                      (not (null? enemy-units)))))
        (define dg (car door-guards))
        (define dg-id (hash-ref dg 'id 703))
        (acquire-unit-lease! leases dg-id 'door-guard frame 16 #:x nat-x #:y nat-y)
        (l2-emit! ctx (list 'hold-position dg-id nat-x nat-y))
        (l2-emit! ctx (list 'control-group-steal 2 (list dg-id)))
        (cortex-steal-control-group! cortex 2 (list dg-id))]
       [(and live-game?
             (pair? wall-door-pt)
             (not worker-rush-active?)
             (not in-base-proxy-detected?)
             (not (ormap (lambda (e)
                           (and (not (or (eq? (hash-ref e 'is-flying #f) #t)
                                         (eq? (hash-ref e 'flying? #f) #t)))
                                (<= (dist2d base-x base-y
                                            (hash-ref e 'x 9999.0)
                                            (hash-ref e 'y 9999.0))
                                    12.0)
                                (> (dist2d (car wall-door-pt) (cdr wall-door-pt)
                                           (hash-ref e 'x 9999.0)
                                           (hash-ref e 'y 9999.0))
                                   3.5)))
                         enemy-units))
             (not (null? door-guards))
             (or (memq 'gateway (l2-ctx-bldg-types ctx)) (memq 'warp-gate (l2-ctx-bldg-types ctx))))
        (define door-x (safe-coord (car wall-door-pt) nat-x))
        (define door-y (safe-coord (cdr wall-door-pt) nat-y))
        (define park-x (if (pair? wall-park-pt) (safe-coord (car wall-park-pt) base-x) (safe-coord (+ door-x (* 2.5 (/ (- base-x door-x) (max 1.0 (dist2d base-x base-y door-x door-y))))) base-x)))
        (define park-y (if (pair? wall-park-pt) (safe-coord (cdr wall-park-pt) base-y) (safe-coord (+ door-y (* 2.5 (/ (- base-y door-y) (max 1.0 (dist2d base-x base-y door-x door-y))))) base-y)))
        (define door-st (rt-door-state rt))
        (define prev-gid (hash-ref door-st 'guard-id #f))
        (define near-guards
          (filter (lambda (u)
                    (<= (dist2d door-x door-y (hash-ref u 'x base-x) (hash-ref u 'y base-y)) 22.0))
                  door-guards))
        (define chosen-guard
          (or (and prev-gid
                   (findf (lambda (u) (equal? (hash-ref u 'id -1) prev-gid)) near-guards))
              (and (pair? near-guards)
                   (argmin (lambda (u)
                             (+ (if (eq? (unit-type-sym u) 'zealot) 0.0 3.0)
                                (dist2d door-x door-y (hash-ref u 'x door-x) (hash-ref u 'y door-y))))
                           near-guards))))
        (when chosen-guard
          (define gid (hash-ref chosen-guard 'id 703))
          (define gx (hash-ref chosen-guard 'x door-x))
          (define gy (hash-ref chosen-guard 'y door-y))
          (hash-set! door-st 'guard-id gid)
          (acquire-unit-lease! leases gid 'door-guard frame 16 #:x door-x #:y door-y)
          (define nearest-enemy-to-door
            (if (null? enemy-units)
                +inf.0
                (apply min
                       (map (lambda (e)
                              (dist2d door-x door-y (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)))
                            enemy-units))))
          (define townhall-pts
            (if (null? nexuses)
                (list (cons base-x base-y))
                (map (lambda (b)
                       (cons (hash-ref b 'x base-x) (hash-ref b 'y base-y)))
                     nexuses)))
          (define (dist-to-nearest-th wx wy)
            (apply min
                   (map (lambda (pt) (dist2d wx wy (car pt) (cdr pt)))
                        townhall-pts)))
          (define active-scout-id (hash-ref (rt-scout-state rt) 'scout-id #f))
          (define (worker-scout-leased? wid)
            (let ([l (and (hash? leases) (hash-ref leases wid #f))])
              (and (unit-role-lease? l)
                   (> (unit-role-lease-expires-frame l) frame)
                   (eq? (unit-role-lease-role l) 'scout))))
          (define worker-transiting-door?
            (ormap (lambda (w)
                     (define wid (hash-ref w 'id 0))
                     (define wx (hash-ref w 'x base-x))
                     (define wy (hash-ref w 'y base-y))
                     (define dw (dist2d door-x door-y wx wy))
                     (define oc (hash-ref w 'order-count 0))
                     (define oab (hash-ref w 'order-ability-id 0))
                     (and (<= dw 4.0)
                          (or (eq? (hash-ref w 'has-build-order? #f) #t)
                              (order-ledger-unit-has-active-build? oledger wid w)
                              (worker-has-engine-build-order? w)
                              (and active-scout-id (equal? wid active-scout-id))
                              (worker-scout-leased? wid)
                              (and (= oc 0) (<= dw 2.8))
                              (and (> oc 0)
                                   (not (= oab 18))
                                   (<= dw 3.5)
                                   (> (dist-to-nearest-th wx wy) 4.5)))))
                   workers))
          (define base-door-dx (- base-x door-x))
          (define base-door-dy (- base-y door-y))
          (define out-norm (max 1.0 (dist2d base-x base-y door-x door-y)))
          (define out-ux (/ (- door-x base-x) out-norm))
          (define out-uy (/ (- door-y base-y) out-norm))
          (define trapped-idle-army-units
            (filter (lambda (u)
                      (define uid (hash-ref u 'id 0))
                      (define ux (hash-ref u 'x base-x))
                      (define uy (hash-ref u 'y base-y))
                      (define on-main-side?
                        (>= (+ (* (- ux door-x) base-door-dx)
                               (* (- uy door-y) base-door-dy))
                            0.0))
                      (and (not (equal? uid gid))
                           (combat-unit-record? u)
                           (not (or (eq? (hash-ref u 'is-flying #f) #t)
                                    (eq? (hash-ref u 'flying? #f) #t)))
                           (= (hash-ref u 'order-count 0) 0)
                           (<= (dist2d door-x door-y ux uy) 3.2)
                           on-main-side?))
                    ally-units))
          (define transiting-army-near-door
            (count (lambda (u)
                     (define uid (hash-ref u 'id 0))
                     (define ux (hash-ref u 'x base-x))
                     (define uy (hash-ref u 'y base-y))
                     (define on-main-side?
                       (>= (+ (* (- ux door-x) base-door-dx)
                              (* (- uy door-y) base-door-dy))
                           0.0))
                     (and (not (equal? uid gid))
                          (combat-unit-record? u)
                          (not (or (eq? (hash-ref u 'is-flying #f) #t)
                                   (eq? (hash-ref u 'flying? #f) #t)))
                          (<= (dist2d door-x door-y ux uy) 4.0)
                          (or (and (> (hash-ref u 'order-count 0) 0)
                                   (not (= (hash-ref u 'order-ability-id 0) 18)))
                              (and (= (hash-ref u 'order-count 0) 0)
                                   (<= (dist2d door-x door-y ux uy) 3.2)
                                   on-main-side?))))
                   ally-units))
          (define transit-needed?
            (and (or worker-transiting-door? (>= transiting-army-near-door 1))
                 (> nearest-enemy-to-door 6.5)))
          (cond
            [transit-needed?
             (hash-set! door-st 'state 'open)
             (hash-set! door-st 'open-until-frame (+ frame 24))
             (when (or (> (dist2d gx gy park-x park-y) 1.0)
                       (= (hash-ref chosen-guard 'order-ability-id 0) 18))
               (l2-emit! ctx (list 'move gid park-x park-y))
               (order-ledger-record-issued! oledger gid 'move 'door-park park-x park-y frame))
             (define nudge-x (safe-coord (+ door-x (* 4.5 out-ux)) nat-x))
             (define nudge-y (safe-coord (+ door-y (* 4.5 out-uy)) nat-y))
             (for ([tu (in-list trapped-idle-army-units)])
               (define tid (hash-ref tu 'id 0))
               (l2-emit! ctx (list 'move tid nudge-x nudge-y))
               (order-ledger-record-issued! oledger tid 'move 'door-unstick nudge-x nudge-y frame))]
            [else
             (hash-set! door-st 'open-until-frame 0)
             (hash-set! door-st 'state 'closed)
             (when (or (> (dist2d gx gy door-x door-y) 0.85)
                       (not (= (hash-ref chosen-guard 'order-ability-id 0) 18)))
               (l2-emit! ctx (list 'hold-position gid door-x door-y))
               (order-ledger-record-issued! oledger gid 'hold-position 'door-seal door-x door-y frame))]))])
  (define protoss-exp-x #f)
  (define protoss-exp-y #f)
  (when (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'nexus))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'nexus) 'nexus)
                (not blocked-nat-expanded-early?)
                (not under-early-cheese?)
                (not early-survival-crisis?)
                (not crisis-freeze-expand-or-gas?)
                (not under-base-attack?)
                (= (order-ledger-pending-count-for-type oledger 'nexus frame) 0)
                (or (< (length nexuses) SC2-MIN-DESIRED-BASES)
                    (and (= (length nexuses) 2)
                         (>= eff-phase-supply 50)
                         (or (not live-game?) (>= live-army-supply 14))
                         (or (memq 'robotics-facility (l2-ctx-bldg-types ctx))
                             (memq 'twilight-council (l2-ctx-bldg-types ctx))
                             (memq 'stargate (l2-ctx-bldg-types ctx))
                             (l2-plan-wants-now? ctx 'nexus)))
                    (and (< (length nexuses) desired-bases)
                         (or (not (and endgame-corner-hunt?
                                       (< (+ (l2-unit-count ctx 'phoenix) (l2-unit-count ctx 'void-ray)) 2)))
                             (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'nexus)) 150))
                         (>= total-workers (* (length nexuses)
                                              (if (>= (length nexuses) 3) 16 SC2-MIN-WORKERS-PER-BASE-FOR-EXPAND)))
                         (or (not live-game?)
                             (>= live-army-supply (* 9 (length nexuses)))
                             (>= (l2-ctx-minerals ctx) 550))
                         (or (coupled-macro-plan-should-expand? macro-plan)
                             (>= frame SC2-MACRO-EXPAND-FRAME-THRESHOLD))))
                (refractory-ready? cd-tracker '(macro-expand Protoss) frame SC2-EXPANSION-COOLDOWN-FRAMES)
                (let-values ([(cand-ex cand-ey)
                              (l2-select-uncamped-expansion-pad ctx (< (length nexuses) SC2-MIN-DESIRED-BASES))])
                  (and cand-ex cand-ey
                       (begin (set! protoss-exp-x cand-ex)
                              (set! protoss-exp-y cand-ey)
                              #t)))
                (refractory-allow-action?! cd-tracker
                                           '(macro-expand Protoss)
                                           frame
                                           SC2-EXPANSION-COOLDOWN-FRAMES))
       (when (and protoss-exp-x protoss-exp-y)
         (l2-emit! ctx (list 'expand protoss-exp-x protoss-exp-y))
         (order-ledger-record-issued! oledger (+ 810000 (modulo frame 10000)) 'expand 'nexus protoss-exp-x protoss-exp-y frame)
         (l2-spend-resources-and-supply! ctx (sc2-min-cost 'nexus) 0 0)))
  (define protoss-saving-for-expand? (l2-saving-for-expansion-now? ctx (length nexuses)))
  (set-l2-ctx-protoss-saving-for-expand?! ctx protoss-saving-for-expand?)
  (define ready-pylons
       (filter (lambda (b)
                 (and (hash? b)
                      (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'pylon)
                      (>= (hash-ref b 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)))
               ally-bldgs))
  (define first-ready-pylon
       (or (findf (lambda (b)
                    (or (not live-game-obs?)
                        (not (or worker-rush-active? in-base-proxy-detected?))
                        (<= (dist2d base-x base-y
                                    (hash-ref b 'x -999.0)
                                    (hash-ref b 'y -999.0))
                            7.5)))
                  ready-pylons)
           (and (> frame 500)
                (pair? ready-pylons)
                (car ready-pylons))))
  (set-l2-ctx-first-ready-pylon! ctx first-ready-pylon)
  (define inmain-powered-gx
       (if first-ready-pylon
           (safe-coord (+ (hash-ref first-ready-pylon 'x (+ base-x 4.0)) 2.5) (+ base-x 4.0))
           (safe-coord (+ base-x 4.0))))
  (define inmain-powered-gy
       (if first-ready-pylon
           (safe-coord (+ (hash-ref first-ready-pylon 'y (+ base-y 4.0)) 0.5) (+ base-y 4.0))
           (safe-coord (+ base-y 4.0))))
  (define gateway-wall-fallback?
       (let ([tbl (and (refractory-cooldown-tracker? cd-tracker)
                       (refractory-cooldown-tracker-table cd-tracker))])
         (when (and (null? gateways) live-game-obs? (hash? tbl))
           (define lock-entry (hash-ref tbl '(build-issue-lock gateway) #f))
           (when (pair? lock-entry)
             (define last-issue-f (car lock-entry))
             (define last-issue-cnt (cadr lock-entry))
             (define last-wall-f (hash-ref tbl '(build-issue-exact-wall gateway) -9999))
             (define wall-attempt? (= last-wall-f last-issue-f))
             (when (and (> frame last-issue-f)
                        (= (l2-cur-ally-canon-bldg-count ctx 'gateway) last-issue-cnt)
                        (= (order-ledger-pending-count-for-type oledger 'gateway frame) 0)
                        (or (and wall-attempt? power-placement-failed?)
                            (>= (- frame last-issue-f) 16)))
               (hash-remove! tbl '(build-issue-lock gateway))
               (hash-set! tbl '(gateway-wall-fallback gateway) frame))))
         (let ([fb-f (and (hash? tbl) (hash-ref tbl '(gateway-wall-fallback gateway) #f))])
           (and (exact-integer? fb-f)
                (<= 0 (- frame fb-f))
                (< (- frame fb-f) 64)))))
  (when (and (null? gateways)
                (or (not live-game-obs?) (not (not first-ready-pylon)))
                (not (l2-building-present-or-pending? ctx 'gateway))
                (l2-save-cancel-rebuild-ready? ctx 'gateway 60)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'gateway))
                (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'gateway)) hard-supply-lockout-reserve-min))
       (if (and allow-exact-wall-slot?
                (not gateway-wall-fallback?)
                (not worker-rush-active?)
                (not in-base-proxy-detected?)
                (< frame 2200)
                (< cur-escrow-age-frames 64)
                (<= (length nexuses) 2)
                (l2-wall-slot-powered? ctx wall-slot-1))
           (l2-emit-build-verified! ctx 'gateway
                                 (safe-coord (car wall-slot-1) inmain-powered-gx)
                                 (safe-coord (cdr wall-slot-1) inmain-powered-gy)
                                 SC2-BUILD-SITE-MIN-CLEARANCE
                                 #:exact-wall-slot? #t)
           (l2-emit-build-verified! ctx 'gateway inmain-powered-gx inmain-powered-gy)))
  (define protoss-aa-needed?
       (enemy-tech-observation-requires-anti-air? tech-obs))
  (set-l2-ctx-protoss-aa-needed?! ctx protoss-aa-needed?)
  (define enemy-muta-cnt-p
       (count (lambda (e) (eq? (unit-type-sym e) 'mutalisk)) enemy-units))
  (set-l2-ctx-enemy-muta-cnt-p! ctx enemy-muta-cnt-p)
  (define enemy-air-raiders?
       (ormap (lambda (e)
                (memq (fast-canonical-unit-sym (unit-type-sym e))
                      '(mutalisk oracle banshee)))
              enemy-units))
  (set-l2-ctx-enemy-air-raiders?! ctx enemy-air-raiders?)
  (define cur-sb-cnt
       (+ (count (lambda (b) (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'shield-battery)) ally-bldgs)
          (order-ledger-pending-count-for-type oledger 'shield-battery frame)))
  (define desired-sb-cnt
       (cond
         [crisis-tech-upgrade-deferral? 2]
         [(and live-game? (or enemy-air-raiders? protoss-aa-needed?))
          (min 2 (max 1 (length nexuses)))]
         [else 1]))
  (when (and (or early-survival-crisis?
                    under-base-attack?
                    forward-proxy-detected?
                    (and live-game? (or enemy-air-raiders? protoss-aa-needed?))
                    (>= (count (lambda (e) (eq? (unit-type-sym e) 'reaper)) enemy-units) 2))
                (or (not live-game-obs?) (memq 'pylon ready-bldg-types))
                (memq 'cybernetics-core ready-bldg-types)
                (< cur-sb-cnt desired-sb-cnt)
                (= (order-ledger-pending-count-for-type oledger 'shield-battery frame) 0)
                (l2-save-cancel-rebuild-ready? ctx 'shield-battery 60)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'shield-battery))
                (or (and crisis-tech-upgrade-deferral?
                         (or (<= (hash-ref open-prod-slots 'gateway 0) 0)
                             (>= (l2-ctx-minerals ctx) (+ (sc2-min-cost 'shield-battery) 125))))
                    (<= (hash-ref open-prod-slots 'gateway 0) 0)
                    (l2-non-combat-min-ok? ctx (sc2-min-cost 'shield-battery))))
       (define main-has-sb?
         (ormap (lambda (b)
                  (and (hash? b)
                       (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'shield-battery)
                       (<= (dist2d base-x base-y (hash-ref b 'x -999.0) (hash-ref b 'y -999.0)) 12.0)))
                ally-bldgs))
       (define nat-has-sb?
         (ormap (lambda (b)
                  (and (hash? b)
                       (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'shield-battery)
                       (<= (dist2d nat-x nat-y (hash-ref b 'x -999.0) (hash-ref b 'y -999.0)) 12.0)))
                ally-bldgs))
       (define (pick-main-sb-coords)
         (let* ([px (if first-ready-pylon (hash-ref first-ready-pylon 'x (+ base-x 4.5)) (+ base-x 4.5))]
                [py (if first-ready-pylon (hash-ref first-ready-pylon 'y (+ base-y 2.5)) (+ base-y 2.5))]
                [cand (findf (lambda (off)
                               (define cx (+ px (car off)))
                               (define cy (+ py (cdr off)))
                               (and (>= (dist2d cx cy base-x base-y) 4.0)
                                    (andmap (lambda (b)
                                              (>= (dist2d cx cy
                                                          (hash-ref b 'x -999.0)
                                                          (hash-ref b 'y -999.0))
                                                  2.6))
                                            ally-bldgs)))
                             '((-3.0 . 0.0) (0.0 . -3.0) (3.0 . -3.0) (-2.5 . 3.0) (0.0 . 3.5) (3.5 . 2.5)))])
           (if cand
               (values (safe-coord (+ px (car cand))) (safe-coord (+ py (cdr cand))))
               (values (safe-coord (+ base-x 4.5)) (safe-coord (- base-y 3.5))))))
       (define-values (sb-x sb-y)
         (if (or (<= (length nexuses) 1)
                 (and nat-has-sb? (not main-has-sb?)))
             (pick-main-sb-coords)
             (l2-offset-defense-anchor ctx nat-x nat-y 5.5)))
       (l2-emit-build-verified! ctx 'shield-battery sb-x sb-y 2.0))
  (when (and (or (memq 'gateway ready-bldg-types) (memq 'warp-gate ready-bldg-types))
                (not protoss-saving-for-expand?)
                (not (l2-building-present-or-pending? ctx 'cybernetics-core))
                (l2-save-cancel-rebuild-ready? ctx 'cybernetics-core 60)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'cybernetics-core))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'cybernetics-core) 'cybernetics-core))
       (define inmain-cy-x
         (if first-ready-pylon
             (safe-coord (- (hash-ref first-ready-pylon 'x (+ base-x 6.0)) 2.5) (+ base-x 6.0))
             (safe-coord (+ base-x 6.0))))
       (define inmain-cy-y
         (if first-ready-pylon
             (safe-coord (+ (hash-ref first-ready-pylon 'y (+ base-y 4.0)) 2.0) (+ base-y 4.0))
             (safe-coord (+ base-y 4.0))))
       (if (and allow-exact-wall-slot?
                (not worker-rush-active?)
                (not in-base-proxy-detected?)
                (< frame 2200)
                (< cur-escrow-age-frames 64)
                (<= (length nexuses) 2)
                (l2-wall-slot-powered? ctx wall-slot-2))
           (l2-emit-build-verified! ctx 'cybernetics-core
                                 (safe-coord (car wall-slot-2) inmain-cy-x)
                                 (safe-coord (cdr wall-slot-2) inmain-cy-y)
                                 SC2-BUILD-SITE-MIN-CLEARANCE
                                 #:exact-wall-slot? #t)
           (l2-emit-build-verified! ctx 'cybernetics-core inmain-cy-x inmain-cy-y))))

(define (l2-protoss-phase2-tech-expand! ctx)
  (define active-assimilators (l2-ctx-active-assimilators ctx))
  (define active-bases (l2-ctx-active-bases ctx))
  (define allow-exact-wall-slot? (l2-ctx-allow-exact-wall-slot? ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define crisis-freeze-expand-or-gas? (l2-ctx-crisis-freeze-expand-or-gas? ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define cur-escrow-age-frames (l2-ctx-cur-escrow-age-frames ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define endgame-corner-hunt? (l2-ctx-endgame-corner-hunt? ctx))
  (define enemy-air-raiders? (l2-ctx-enemy-air-raiders? ctx))
  (define enemy-heavy-ground-siege? (l2-ctx-enemy-heavy-ground-siege? ctx))
  (define enemy-muta-cnt-p (l2-ctx-enemy-muta-cnt-p ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define escrow-suppressed-active? (l2-ctx-escrow-suppressed-active? ctx))
  (define first-ready-pylon (l2-ctx-first-ready-pylon ctx))
  (define frame (l2-ctx-frame ctx))
  (define gateways (l2-ctx-gateways ctx))
  (define in-base-proxy-detected? (l2-ctx-in-base-proxy-detected? ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define max-escrow-timeout-frames (l2-ctx-max-escrow-timeout-frames ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define natural-blocked? (l2-ctx-natural-blocked? ctx))
  (define nexuses (l2-ctx-nexuses ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define orphaned-prereqs (l2-ctx-orphaned-prereqs ctx))
  (define prio-saving-for-sym (l2-ctx-prio-saving-for-sym ctx))
  (define prio-scheduled-actions (l2-ctx-prio-scheduled-actions ctx))
  (define protoss-aa-needed? (l2-ctx-protoss-aa-needed? ctx))
  (define protoss-saving-for-expand? (l2-ctx-protoss-saving-for-expand? ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define researched-upgs (l2-ctx-researched-upgs ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
  (define wall-slot-3 (l2-ctx-wall-slot-3 ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (define has-nat-nexus-or-pending?
       (or (>= (length nexuses) 2)
           (> (order-ledger-pending-count-for-type oledger 'nexus frame) 0)))
  (define desired-assimilators
       (if (and early-survival-crisis? (null? active-assimilators))
           0
           (min (* SC2-GEYSERS-PER-BASE (length nexuses))
                (if live-game?
                    (cond
                      [(and (>= (length nexuses) 4) (>= total-workers 62) (< (l2-ctx-gas ctx) 600)) 8]
                      [(and (>= (length nexuses) 3) (>= total-workers 50) (< (l2-ctx-gas ctx) 450)) 6]
                      [(and (>= eff-phase-supply 52) (>= total-workers 38) (< (l2-ctx-gas ctx) 350)) 4]
                      [(and (>= eff-phase-supply 38) (>= total-workers 32) (< (l2-ctx-gas ctx) 300)) 3]
                      [(and (l2-building-present-or-pending? ctx 'cybernetics-core)
                            (or has-nat-nexus-or-pending? (>= eff-phase-supply 32))
                            (>= total-workers 19)
                            (< (l2-ctx-gas ctx) 250))
                       2]
                      [else 1])
                    (cond
                      [(>= supply-used 54) 4]
                      [(>= supply-used 40) 3]
                      [(or (memq 'cybernetics-core (l2-ctx-bldg-types ctx)) (>= total-workers SC2-MIN-WORKERS-FOR-SECOND-GAS)) 2]
                      [else 1])))))
  (define reserve-idle-stargate-aa?
       (and live-game?
            protoss-aa-needed?
            (memq 'stargate ready-bldg-types)
            (< (l2-unit-count ctx 'phoenix) 6)
            (> (hash-ref open-prod-slots 'stargate 0) 0)))
  (define (aa-stargate-min-ok? cost)
       (>= (l2-ctx-minerals ctx) (+ cost (if reserve-idle-stargate-aa? (sc2-min-cost 'phoenix) 0))))
  (define (aa-stargate-gas-ok? cost)
       (>= (l2-ctx-gas ctx) (+ cost (if reserve-idle-stargate-aa? (sc2-gas-cost 'phoenix) 0))))
  (define colossus-goal-cap (if (eq? effective-enemy-race 'Terran) 3 2))
  (set-l2-ctx-colossus-goal-cap! ctx colossus-goal-cap)
  (when (and (or (memq 'gateway (l2-ctx-bldg-types ctx)) (memq 'warp-gate (l2-ctx-bldg-types ctx)))
                (not crisis-freeze-expand-or-gas?)
                (l2-save-cancel-rebuild-ready? ctx 'assimilator 60)
                (or (null? active-assimilators) (not protoss-saving-for-expand?))
                (or (< (length active-assimilators) 2)
                    (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'assimilator) 0))
                (< (+ (length active-assimilators) (order-ledger-pending-count-for-type oledger 'assimilator frame))
                   desired-assimilators)
                (aa-stargate-min-ok? (sc2-min-cost 'assimilator))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'assimilator)))
       (l2-emit-gas-build-verified! ctx 'assimilator (safe-coord (+ base-x 4.0)) (safe-coord (+ base-y 4.0))))
  (when (memq 'cybernetics-core ready-bldg-types)
       (when (and (not protoss-saving-for-expand?)
                  (aa-stargate-min-ok? (sc2-min-cost 'warp-gate-research))
                  (aa-stargate-gas-ok? (sc2-gas-cost 'warp-gate-research))
                  (l2-non-combat-min-ok? ctx (sc2-min-cost 'warp-gate-research) 'warp-gate-research)
                  (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'warp-gate-research) 'warp-gate-research)
                  (l2-upgrade-needed? ctx 'warp-gate-research)
                  (l2-upgrade-needed? ctx 'warpgate))
         (l2-emit-research-verified! ctx 'warp-gate-research))
       (when (and (not live-game?)
                  (or (memq 'warpgate researched-upgs)
                      (memq 'warp-gate-research researched-upgs))
                  (memq 'gateway ready-bldg-types))
         (l2-emit! ctx '(morph warp-gate))))
  (define cur-robo-cnt
       (+ (count (lambda (b) (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'robotics-facility))
                 ally-bldgs)
          (order-ledger-pending-count-for-type oledger 'robotics-facility frame)))
  (define desired-robos
       (if (and live-game?
                (memq 'robotics-facility ready-bldg-types)
                (or (>= (length nexuses) 3)
                    (and (>= (l2-ctx-minerals ctx) 550) (>= (l2-ctx-gas ctx) 200)))
                (>= eff-phase-supply 72))
           2
           1))
  (when (and (memq 'cybernetics-core ready-bldg-types)
                (or (not protoss-saving-for-expand?) endgame-corner-hunt?)
                (l2-save-cancel-rebuild-ready? ctx 'robotics-facility 60)
                (< cur-robo-cnt desired-robos)
                (or (= cur-robo-cnt 0)
                    (and (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'robotics-facility) (sc2-gas-cost 'robotics-facility))
                         (or (>= (l2-ctx-minerals ctx) 550)
                             (l2-can-spend-by-priority? ctx 'robotics-facility 'production-scaling))))
                (or (and (= cur-robo-cnt 0)
                         (not (or enemy-air-raiders?
                                  (ormap (lambda (e)
                                           (or (eq? (hash-ref e 'flying? #f) #t)
                                               (eq? (hash-ref e 'is-flying #f) #t)))
                                         enemy-units))))
                    (and (aa-stargate-min-ok? (sc2-min-cost 'robotics-facility))
                         (aa-stargate-gas-ok? (sc2-gas-cost 'robotics-facility))))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'robotics-facility) 'robotics-facility)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'robotics-facility) 'robotics-facility))
       (l2-emit-build-verified! ctx 'robotics-facility
                             (safe-coord (+ base-x 6.0 (* 4.0 cur-robo-cnt)))
                             (safe-coord (+ base-y 6.0 (* 2.0 cur-robo-cnt))))
       (unless live-game?
         (l2-emit! ctx '(morph warp-gate))))
  (when (and (or (not protoss-saving-for-expand?)
                    (and endgame-corner-hunt? (< (l2-unit-count ctx 'observer) 1)))
                (memq 'robotics-facility ready-bldg-types)
                (l2-can-spend-supply? ctx (sc2-supply-cost 'observer)))
       (define desired-observers
         (if (or (enemy-tech-observation-requires-detection? tech-obs)
                 (and live-game? (>= live-army-supply 40)))
             2
             1))
       (when (and (< (l2-unit-count ctx 'observer) desired-observers)
                  (or (< (l2-unit-count ctx 'observer) 1)
                      (enemy-tech-observation-requires-detection? tech-obs)
                      (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'observer) (sc2-gas-cost 'observer)))
                  (or (enemy-tech-observation-requires-detection? tech-obs)
                      (aa-stargate-gas-ok? (sc2-gas-cost 'observer))))
         (l2-try-train-unit! ctx 'observer 'robotics-facility 6))
       (when (or crisis-tech-upgrade-deferral? (not protoss-saving-for-expand?))
         (when (and crisis-tech-upgrade-deferral?
                    (l2-can-spend-supply? ctx (sc2-supply-cost 'immortal)))
           (l2-try-train-unit! ctx 'immortal 'robotics-facility 6 #:respect-bo-reserve? #f))
         (when (and (memq 'robotics-bay ready-bldg-types)
                    (< (l2-unit-count ctx 'colossus) 4)
                    (aa-stargate-min-ok? (sc2-min-cost 'colossus))
                    (aa-stargate-gas-ok? (sc2-gas-cost 'colossus))
                    (l2-can-spend-supply? ctx (sc2-supply-cost 'colossus)))
           (l2-try-train-unit! ctx 'colossus 'robotics-facility 6))
         (when (and (memq 'robotics-bay ready-bldg-types)
                    (< (l2-unit-count ctx 'disruptor) 3)
                    (or (member '(train disruptor) prio-scheduled-actions)
                        (>= (l2-unit-count ctx 'colossus) 1))
                    (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'disruptor) (sc2-gas-cost 'disruptor))
                    (aa-stargate-min-ok? (sc2-min-cost 'disruptor))
                    (aa-stargate-gas-ok? (sc2-gas-cost 'disruptor))
                    (l2-can-spend-supply? ctx (sc2-supply-cost 'disruptor)))
           (l2-try-train-unit! ctx 'disruptor 'robotics-facility 6))
         (when (and (or crisis-tech-upgrade-deferral?
                        (and (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'immortal) (sc2-gas-cost 'immortal))
                             (aa-stargate-min-ok? (sc2-min-cost 'immortal))
                             (aa-stargate-gas-ok? (sc2-gas-cost 'immortal))))
                    (l2-can-spend-supply? ctx (sc2-supply-cost 'immortal)))
           (l2-try-train-unit! ctx 'immortal 'robotics-facility 6 #:respect-bo-reserve? (not crisis-tech-upgrade-deferral?)))
         (when (and (< (l2-unit-count ctx 'warp-prism) 1)
                    (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'warp-prism) (sc2-gas-cost 'warp-prism))
                    (aa-stargate-min-ok? (sc2-min-cost 'warp-prism))
                    (or (l2-plan-wants-now? ctx 'warp-prism)
                        (and live-game? (>= live-army-supply 20) (>= (l2-ctx-minerals ctx) 350)))
                    (l2-can-spend-supply? ctx (sc2-supply-cost 'warp-prism)))
           (l2-try-train-unit! ctx 'warp-prism 'robotics-facility 6 #:respect-bo-reserve? #t))))
  (define protoss-corner-flyers-needed?
       (and endgame-corner-hunt?
            (< (+ (l2-unit-count ctx 'phoenix) (l2-unit-count ctx 'void-ray)) 2)))
  (when (and (or (not protoss-saving-for-expand?)
                    protoss-corner-flyers-needed?
                    protoss-aa-needed?)
                (memq 'stargate ready-bldg-types))
       (when (and (not protoss-saving-for-expand?)
                  (memq 'fleet-beacon ready-bldg-types)
                  (or (l2-plan-wants-now? ctx 'tempest)
                      enemy-heavy-ground-siege?)
                  (< (l2-unit-count ctx 'tempest) 4)
                  (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'tempest) (sc2-gas-cost 'tempest))
                  (l2-can-spend-supply? ctx (sc2-supply-cost 'tempest)))
         (l2-try-train-unit! ctx 'tempest 'stargate 6))
       (when (and (not protoss-saving-for-expand?)
                  (memq 'fleet-beacon ready-bldg-types)
                  (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'carrier) (sc2-gas-cost 'carrier))
                  (l2-can-spend-supply? ctx (sc2-supply-cost 'carrier)))
         (l2-try-train-unit! ctx 'carrier 'stargate 6))
       (define phoenix-cap (if protoss-aa-needed? 10 4))
       ;; When facing light air (Mutalisk / Banshee / Phoenix), train fast Phoenixes BEFORE heavy Void Rays!
       (when (and (or protoss-corner-flyers-needed?
                      protoss-aa-needed?
                      (l2-plan-wants-now? ctx 'phoenix))
                  (< (l2-unit-count ctx 'phoenix) phoenix-cap)
                  (or protoss-corner-flyers-needed?
                      protoss-aa-needed?
                      (and (l2-can-spend-by-priority? ctx 'phoenix 'combat-unit)
                           (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'phoenix) (sc2-gas-cost 'phoenix))))
                  (l2-can-spend-supply? ctx (sc2-supply-cost 'phoenix)))
         (l2-try-train-unit! ctx 'phoenix 'stargate 6
                          #:respect-bo-reserve? (not (or protoss-corner-flyers-needed? protoss-aa-needed?))))
       (when (and (or protoss-corner-flyers-needed?
                      protoss-aa-needed?
                      (l2-plan-wants-now? ctx 'void-ray)
                      (>= (l2-ctx-minerals ctx) 250))
                  (or protoss-corner-flyers-needed?
                      (and (l2-can-spend-by-priority? ctx 'void-ray 'combat-unit)
                           (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'void-ray) (sc2-gas-cost 'void-ray))))
                  (l2-can-spend-supply? ctx (sc2-supply-cost 'void-ray)))
         (l2-try-train-unit! ctx 'void-ray 'stargate 6 #:respect-bo-reserve? (not protoss-corner-flyers-needed?)))
       (when (and (not protoss-saving-for-expand?)
                  (or (not live-game?)
                      (and (not protoss-aa-needed?)
                           (< live-army-supply 30)))
                  (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'oracle) (sc2-gas-cost 'oracle))
                  (or (< (l2-unit-count ctx 'oracle) 1)
                      (and (< (l2-unit-count ctx 'oracle) 2)
                           (>= (l2-ctx-minerals ctx) 200)
                           (>= (l2-ctx-gas ctx) 200)))
                  (l2-can-spend-supply? ctx (sc2-supply-cost 'oracle)))
         (l2-try-train-unit! ctx 'oracle 'stargate 6)))
  (when (and (memq 'cybernetics-core ready-bldg-types)
                (not protoss-saving-for-expand?)
                (l2-building-present-or-pending? ctx 'robotics-facility)
                (not (l2-building-present-or-pending? ctx 'twilight-council))
                (l2-save-cancel-rebuild-ready? ctx 'twilight-council 60)
                (>= eff-phase-supply 28)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'twilight-council))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'twilight-council))
                (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'twilight-council) (sc2-gas-cost 'twilight-council))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'twilight-council) 'twilight-council)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'twilight-council) 'twilight-council))
       (l2-emit-build-verified! ctx 'twilight-council (safe-coord (+ base-x 6.0)) (safe-coord (- base-y 4.0))))
  (when (and (memq 'twilight-council ready-bldg-types)
                (not urgent-combat-or-intel-need?))
       (define blink-first?
         (and live-game?
              (or protoss-aa-needed? (> enemy-muta-cnt-p 0))))
       (cond
         [(and blink-first?
               (l2-upgrade-needed? ctx 'blink)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'blink) (sc2-gas-cost 'blink)))
          (l2-emit-research-verified! ctx 'blink)]
         [(and (l2-upgrade-needed? ctx 'charge)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'charge) (sc2-gas-cost 'charge)))
          (l2-emit-research-verified! ctx 'charge)]
         [(and (l2-upgrade-needed? ctx 'blink)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'blink) (sc2-gas-cost 'blink)))
          (l2-emit-research-verified! ctx 'blink)]
         [(and (or (not live-game?)
                   (l2-plan-wants-now? ctx 'resonating-glaives)
                   (>= (l2-unit-count ctx 'adept) 2))
               (l2-upgrade-needed? ctx 'resonating-glaives)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'resonating-glaives) (sc2-gas-cost 'resonating-glaives)))
          (l2-emit-research-verified! ctx 'resonating-glaives)]))
  (define robo-and-twilight-present?
       (and (l2-building-present-or-pending? ctx 'robotics-facility)
            (l2-building-present-or-pending? ctx 'twilight-council)))
  (when (and (memq 'cybernetics-core ready-bldg-types)
                (or (not protoss-saving-for-expand?) endgame-corner-hunt?)
                (not (l2-building-present-or-pending? ctx 'stargate))
                (l2-save-cancel-rebuild-ready? ctx 'stargate 60)
                (or (and (not (and live-game? robo-and-twilight-present?))
                         (l2-plan-wants-now? ctx 'stargate))
                    (enemy-tech-observation-requires-anti-air? tech-obs)
                    endgame-corner-hunt?
                    (and live-game? (>= (length nexuses) 3) (>= eff-phase-supply 80)))
                (or endgame-corner-hunt?
                    protoss-aa-needed?
                    (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'stargate) (sc2-gas-cost 'stargate)))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'stargate))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'stargate))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'stargate) 'stargate)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'stargate) 'stargate))
       (l2-emit-build-verified! ctx 'stargate (safe-coord (- base-x 5.0)) (safe-coord (+ base-y 5.0))))
  (when (and (memq 'stargate ready-bldg-types)
                (not protoss-saving-for-expand?)
                (not (l2-building-present-or-pending? ctx 'fleet-beacon))
                (l2-save-cancel-rebuild-ready? ctx 'fleet-beacon 60)
                (or (l2-plan-wants-now? ctx 'fleet-beacon)
                    (and live-game? (>= (length nexuses) 3) (>= eff-phase-supply 106)))
                (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'fleet-beacon) (sc2-gas-cost 'fleet-beacon))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'fleet-beacon))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'fleet-beacon))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'fleet-beacon) 'fleet-beacon)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'fleet-beacon) 'fleet-beacon))
       (l2-emit-build-verified! ctx 'fleet-beacon (safe-coord (- base-x 6.0)) (safe-coord (+ base-y 6.0))))
  (define pending-nexus-count
       (order-ledger-pending-count-for-type oledger 'nexus frame))
  (define protoss-nat-reserve
       (if live-game?
           (compute-natural-expansion-mineral-reserve
            #:race 'Protoss
            #:frame frame
            #:active-bases (length nexuses)
            #:pending-bases pending-nexus-count
            #:workers total-workers
            #:under-attack? under-base-attack?
            #:enemy-threat-supply live-enemy-threat-supply
            #:natural-blocked? natural-blocked?
            #:escrow-expired? (or escrow-suppressed-active?
                                  (>= cur-escrow-age-frames max-escrow-timeout-frames)
                                  urgent-combat-or-intel-need?
                                  (not (null? orphaned-prereqs))))
           0))
  (define desired-gateways
       (min SC2-MAX-PRODUCTION-FACILITIES
            (max 1 (cond
                     [(>= (length nexuses) 3)
                      (* SC2-PROTOSS-FACILITIES-PER-BASE (length nexuses))]
                     [(= (length nexuses) 2)
                      (cond
                        [(>= (l2-ctx-minerals ctx) 650) 8]
                        [(>= (l2-ctx-minerals ctx) 450) 6]
                        [(>= total-workers 42) 5]
                        [(>= eff-phase-supply 36) 4]
                        [else 3])]
                     [(and (memq 'cybernetics-core (l2-ctx-bldg-types ctx))
                           (or (not live-game?)
                               (<= protoss-nat-reserve 0)
                               (>= (- (l2-ctx-minerals ctx) protoss-nat-reserve) (sc2-min-cost 'gateway))))
                      (if (>= (l2-ctx-minerals ctx) 650) 3 2)]
                     [else 1]))))
  (define protoss-holding-forge-min?
       (and (memq 'cybernetics-core ready-bldg-types)
            (not (l2-building-present-or-pending? ctx 'forge))
            (or (eq? bo-goal-sym 'forge)
                (eq? prio-saving-for-sym 'forge)
                (and (enemy-tech-observation-requires-detection? tech-obs)
                     (not (l2-building-present-or-pending? ctx 'robotics-facility))))))
  (when (and (not protoss-saving-for-expand?)
                (l2-save-cancel-rebuild-ready? ctx 'gateway 60)
                (or (< (length gateways) 1)
                    (not live-game?)
                    (>= (l2-ctx-minerals ctx) 650)
                    (l2-can-spend-by-priority? ctx 'gateway 'production-scaling))
                (or (< (length gateways) 1)
                    (>= (l2-ctx-minerals ctx) 850)
                    (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'gateway) 0))
                (>= (length gateways) 1)
                (or (not live-game?)
                    (< (length gateways) 3)
                    (< (hash-ref open-prod-slots 'gateway 0) 2)
                    (>= (l2-ctx-minerals ctx) 350))
                (< (+ (length gateways) (order-ledger-pending-count-for-type oledger 'gateway frame))
                   desired-gateways)
                (or (memq 'cybernetics-core (l2-ctx-bldg-types ctx))
                    (>= (l2-ctx-minerals ctx) SC2-SURPLUS-MINERAL-BANK-THRESHOLD))
                (>= (- (l2-ctx-minerals ctx)
                       protoss-nat-reserve
                       (if protoss-holding-forge-min? (sc2-min-cost 'forge) 0))
                    (sc2-min-cost 'gateway))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'gateway)))
       (define gw-idx (length gateways))
       (if (and allow-exact-wall-slot?
                (not worker-rush-active?)
                (not in-base-proxy-detected?)
                (< frame 2600)
                (< cur-escrow-age-frames 64)
                (<= (length nexuses) 2)
                (= gw-idx 1)
                (l2-wall-slot-powered? ctx wall-slot-3))
           (l2-emit-build-verified! ctx 'gateway
                                 (safe-coord (car wall-slot-3) (+ base-x 7.5))
                                 (safe-coord (cdr wall-slot-3) (+ base-y 4.0))
                                 SC2-BUILD-SITE-MIN-CLEARANCE
                                 #:exact-wall-slot? #t)
           (l2-emit-build-verified! ctx 'gateway
                                 (safe-coord (+ base-x 4.0 (* 3.5 (modulo gw-idx 3))))
                                 (safe-coord (+ base-y 4.0 (* 3.5 (quotient gw-idx 3)))))))
  (when (and (or (memq 'robotics-facility ready-bldg-types)
                    (memq 'twilight-council ready-bldg-types)
                    (and (memq 'cybernetics-core ready-bldg-types)
                         (or (enemy-tech-observation-requires-detection? tech-obs)
                             (l2-plan-wants-now? ctx 'forge)
                             (eq? bo-goal-sym 'forge)
                             (eq? prio-saving-for-sym 'forge)
                             (member '(build forge) prio-scheduled-actions)
                             (>= active-bases 2))))
                (or (enemy-tech-observation-requires-detection? tech-obs)
                    (not early-survival-crisis?))
                (not protoss-saving-for-expand?)
                (or (enemy-tech-observation-requires-detection? tech-obs)
                    (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'forge) 0))
                (or (enemy-tech-observation-requires-detection? tech-obs)
                    (l2-plan-wants-now? ctx 'forge)
                    (eq? bo-goal-sym 'forge)
                    (eq? prio-saving-for-sym 'forge)
                    (member '(build forge) prio-scheduled-actions)
                    (l2-can-spend-by-priority? ctx 'forge 'tech-upgrade))
                (not (l2-building-present-or-pending? ctx 'forge))
                (l2-save-cancel-rebuild-ready? ctx 'forge 60)
                (or (enemy-tech-observation-requires-detection? tech-obs)
                    (l2-plan-wants-now? ctx 'forge)
                    (eq? bo-goal-sym 'forge)
                    (eq? prio-saving-for-sym 'forge)
                    (member '(build forge) prio-scheduled-actions)
                    (>= (length nexuses) SC2-MIN-DESIRED-BASES))
                (or (not live-game?)
                    (enemy-tech-observation-requires-detection? tech-obs)
                    (l2-plan-wants-now? ctx 'forge)
                    (eq? bo-goal-sym 'forge)
                    (eq? prio-saving-for-sym 'forge)
                    (member '(build forge) prio-scheduled-actions)
                    (>= eff-phase-supply 46))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'forge))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'forge) 'forge))
       (l2-emit-build-verified! ctx 'forge (safe-coord (+ base-x 5.0)) (safe-coord (- base-y 4.0))))
  (define cur-pc-cnt
       (+ (count (lambda (b) (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'photon-cannon)) ally-bldgs)
          (order-ledger-pending-count-for-type oledger 'photon-cannon frame)))
  (define desired-pc-cnt
       (if (and live-game? (or enemy-air-raiders? protoss-aa-needed?))
           (min 2 (max 1 (length nexuses)))
           1))
  (when (and (memq 'forge ready-bldg-types)
                (or (enemy-tech-observation-requires-detection? tech-obs)
                    (l2-plan-wants-now? ctx 'photon-cannon)
                    (and live-game? (or enemy-air-raiders? protoss-aa-needed?)))
                (< cur-pc-cnt desired-pc-cnt)
                (l2-save-cancel-rebuild-ready? ctx 'photon-cannon 60)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'photon-cannon))
                (refractory-allow-action?! cd-tracker
                                           (list 'static-detector 'photon-cannon)
                                           frame
                                           SC2-STATIC-DETECTOR-COOLDOWN-FRAMES))
       (define main-has-pc?
         (ormap (lambda (b)
                  (and (hash? b)
                       (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'photon-cannon)
                       (<= (dist2d base-x base-y (hash-ref b 'x -999.0) (hash-ref b 'y -999.0)) 12.0)))
                ally-bldgs))
       (define nat-has-pc?
         (ormap (lambda (b)
                  (and (hash? b)
                       (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'photon-cannon)
                       (<= (dist2d nat-x nat-y (hash-ref b 'x -999.0) (hash-ref b 'y -999.0)) 12.0)))
                ally-bldgs))
       (define-values (pc-x pc-y)
         (if (and live-game?
                  (or enemy-air-raiders? protoss-aa-needed?)
                  (not main-has-pc?)
                  (or (<= (length nexuses) 1) nat-has-pc?))
             (let* ([px (if first-ready-pylon (hash-ref first-ready-pylon 'x (+ base-x 4.5)) (+ base-x 4.5))]
                    [py (if first-ready-pylon (hash-ref first-ready-pylon 'y (+ base-y 2.5)) (+ base-y 2.5))])
               (values (safe-coord (+ px 2.5) base-x) (safe-coord (- py 2.5) base-y)))
             (l2-offset-defense-anchor ctx nat-x nat-y 5.5)))
       (l2-emit-build-verified! ctx 'photon-cannon pc-x pc-y 2.0)))

(define (l2-protoss-phase3-upgrades-units! ctx)
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define crisis-freeze-workers? (l2-ctx-crisis-freeze-workers? ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define enemy-muta-cnt-p (l2-ctx-enemy-muta-cnt-p ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define forward-proxy-detected? (l2-ctx-forward-proxy-detected? ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define nexuses (l2-ctx-nexuses ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define pressure-metrics (l2-ctx-pressure-metrics ctx))
  (define prio-saving-for-sym (l2-ctx-prio-saving-for-sym ctx))
  (define prio-scheduled-actions (l2-ctx-prio-scheduled-actions ctx))
  (define protoss-aa-needed? (l2-ctx-protoss-aa-needed? ctx))
  (define protoss-pending-robo-gas-reserve (l2-ctx-protoss-pending-robo-gas-reserve ctx))
  (define protoss-saving-for-expand? (l2-ctx-protoss-saving-for-expand? ctx))
  (define raw-obs (l2-ctx-raw-obs ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define researched-upgs (l2-ctx-researched-upgs ctx))
  (define target-workers (l2-ctx-target-workers ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (when (and (memq 'forge ready-bldg-types)
                (not urgent-combat-or-intel-need?))
       (cond
         [(and (l2-can-spend-by-priority? ctx 'protoss-ground-weapons-1 'tech-upgrade)
               (l2-upgrade-needed? ctx 'protoss-ground-weapons-1)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'protoss-ground-weapons-1) (sc2-gas-cost 'protoss-ground-weapons-1)))
          (l2-emit-research-verified! ctx 'protoss-ground-weapons-1)]
         [(and (l2-upgrade-needed? ctx 'protoss-ground-armor-1)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'protoss-ground-armor-1) (sc2-gas-cost 'protoss-ground-armor-1)))
          (l2-emit-research-verified! ctx 'protoss-ground-armor-1)]
         [(and (memq 'twilight-council ready-bldg-types)
               (l2-upgrade-needed? ctx 'protoss-ground-weapons-2)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'protoss-ground-weapons-2) (sc2-gas-cost 'protoss-ground-weapons-2)))
          (l2-emit-research-verified! ctx 'protoss-ground-weapons-2)]
         [(and (memq 'twilight-council ready-bldg-types)
               (l2-upgrade-needed? ctx 'protoss-ground-armor-2)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'protoss-ground-armor-2) (sc2-gas-cost 'protoss-ground-armor-2)))
          (l2-emit-research-verified! ctx 'protoss-ground-armor-2)]
         [(and (memq 'twilight-council ready-bldg-types)
               (l2-upgrade-needed? ctx 'protoss-ground-weapons-3)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'protoss-ground-weapons-3) (sc2-gas-cost 'protoss-ground-weapons-3)))
          (l2-emit-research-verified! ctx 'protoss-ground-weapons-3)]
         [(and (memq 'twilight-council ready-bldg-types)
               (l2-upgrade-needed? ctx 'protoss-ground-armor-3)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'protoss-ground-armor-3) (sc2-gas-cost 'protoss-ground-armor-3)))
          (l2-emit-research-verified! ctx 'protoss-ground-armor-3)]
         [(and (l2-upgrade-needed? ctx 'protoss-shields-1)
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'protoss-shields-1) (sc2-gas-cost 'protoss-shields-1)))
          (l2-emit-research-verified! ctx 'protoss-shields-1)]))
  (when (and (memq 'twilight-council ready-bldg-types)
                (not protoss-saving-for-expand?)
                (l2-save-cancel-rebuild-ready? ctx 'templar-archive 60)
                (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'templar-archive) (sc2-gas-cost 'templar-archive))
                (or (and (not live-game?)
                         (or (l2-plan-wants-now? ctx 'templar-archive)
                             (l2-can-spend-by-priority? ctx 'templar-archive 'tech-upgrade)))
                    (and live-game?
                         (or (eq? bo-goal-sym 'templar-archive)
                             (>= enemy-muta-cnt-p 3)
                             (and (>= (length nexuses) 3) (>= eff-phase-supply 80)))
                         (or (l2-plan-wants-now? ctx 'templar-archive)
                             (l2-can-spend-by-priority? ctx 'templar-archive 'tech-upgrade)
                             (>= eff-phase-supply 92))))
                (not (l2-building-present-or-pending? ctx 'templar-archive))
                (>= (length nexuses) SC2-MIN-DESIRED-BASES)
                (>= (l2-ctx-gas ctx) 150)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'templar-archive))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'templar-archive)))
       (l2-emit-build-verified! ctx 'templar-archive (safe-coord (+ base-x 6.0)) (safe-coord (- base-y 6.0))))
  (when (and (memq 'twilight-council ready-bldg-types)
                (not protoss-saving-for-expand?)
                (l2-save-cancel-rebuild-ready? ctx 'dark-shrine 60)
                (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'dark-shrine) (sc2-gas-cost 'dark-shrine))
                (not (l2-building-present-or-pending? ctx 'dark-shrine))
                (l2-plan-wants-now? ctx 'dark-shrine)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'dark-shrine))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'dark-shrine))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'dark-shrine) 'dark-shrine)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'dark-shrine) 'dark-shrine))
       (l2-emit-build-verified! ctx 'dark-shrine (safe-coord (- base-x 6.0)) (safe-coord (- base-y 5.0))))
  (when (and (memq 'templar-archive ready-bldg-types)
                (not urgent-combat-or-intel-need?)
                (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'psi-storm) (sc2-gas-cost 'psi-storm))
                (l2-upgrade-needed? ctx 'psi-storm))
       (l2-emit-research-verified! ctx 'psi-storm))
  (when (and (memq 'robotics-facility ready-bldg-types)
                (l2-can-spend-by-priority? ctx 'robotics-bay 'tech-upgrade)
                (not (l2-building-present-or-pending? ctx 'robotics-bay))
                (l2-save-cancel-rebuild-ready? ctx 'robotics-bay 60)
                (or (not live-game?)
                    (not (or protoss-aa-needed? (> enemy-muta-cnt-p 0)))
                    (>= (l2-unit-count ctx 'phoenix) 4)
                    (>= (l2-unit-count ctx 'stalker) 10))
                (or (not (hash-has-key? raw-obs 'mineral-harvesters))
                    (eq? bo-goal-sym 'robotics-bay)
                    (and (eq? effective-enemy-race 'Terran)
                         (>= eff-phase-supply 52)
                         (>= (l2-unit-count ctx 'immortal) 1))
                    (and (>= eff-phase-supply 62)
                         (or (>= (l2-unit-count ctx 'immortal) 2)
                             (>= eff-phase-supply 76))))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'robotics-bay))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'robotics-bay))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'robotics-bay))
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'robotics-bay)))
       (l2-emit-build-verified! ctx 'robotics-bay (safe-coord (+ base-x 7.0)) (safe-coord (+ base-y 7.0)))
       (when (or (not live-game?) (memq 'forge ready-bldg-types))
         (l2-emit-research-verified! ctx 'protoss-ground-weapons-1))
       (when (and (or (not live-game?)
                      (and (memq 'forge ready-bldg-types)
                           (>= (l2-ctx-minerals ctx) (sc2-min-cost 'photon-cannon))))
                  (refractory-allow-action?! cd-tracker
                                             (list 'static-detector 'photon-cannon)
                                             frame
                                             SC2-STATIC-DETECTOR-COOLDOWN-FRAMES))
         (if live-game?
             (let-values ([(pcx pcy) (l2-offset-defense-anchor ctx nat-x nat-y 5.5)])
               (l2-emit-build-verified! ctx 'photon-cannon pcx pcy 2.0))
             (l2-emit! ctx (list 'build 'photon-cannon nat-x nat-y)))))
  (when (and (memq 'robotics-bay ready-bldg-types)
                (not urgent-combat-or-intel-need?))
       (cond
         [(and (or (not live-game?)
                   (>= (l2-unit-count ctx 'colossus) 1))
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'extended-thermal-lance) (sc2-gas-cost 'extended-thermal-lance))
               (l2-upgrade-needed? ctx 'extended-thermal-lance))
          (l2-emit-research-verified! ctx 'extended-thermal-lance)]
         [(and (or (not live-game?)
                   (l2-plan-wants-now? ctx 'gravitic-booster)
                   (>= (l2-unit-count ctx 'observer) 1))
               (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost 'gravitic-booster) (sc2-gas-cost 'gravitic-booster))
               (l2-upgrade-needed? ctx 'gravitic-booster))
          (l2-emit-research-verified! ctx 'gravitic-booster)]))
  (define storm-ready? (memq 'psi-storm researched-upgs))
  (define high-energy-ht-count
       (if (and live-game? storm-ready? (< enemy-muta-cnt-p 3))
           (min 2 (count (lambda (u)
                           (and (eq? (unit-type-sym u) 'high-templar)
                                (>= (hash-ref u 'energy 0) 75)))
                         ally-units))
           0))
  (define avail-ht-slots (max 0 (- (hash-ref open-prod-slots 'high-templar 0) high-energy-ht-count)))
  (define avail-dt-slots (hash-ref open-prod-slots 'dark-templar 0))
  (when (if live-game?
               (>= (+ avail-ht-slots avail-dt-slots) 2)
               (>= (count (lambda (u) (memq (unit-type-sym u) '(high-templar dark-templar))) ally-units) 2))
       (define consume-ht (min 2 avail-ht-slots))
       (define consume-dt (min (- 2 consume-ht) avail-dt-slots))
       (when (> consume-ht 0)
         (hash-set! open-prod-slots 'high-templar
                    (max 0 (- (hash-ref open-prod-slots 'high-templar 0) consume-ht))))
       (when (> consume-dt 0)
         (hash-set! open-prod-slots 'dark-templar (- avail-dt-slots consume-dt)))
       (l2-emit! ctx '(morph archon))
       (order-ledger-record-issued! oledger (+ 865500 (modulo frame 10000) (length (l2-ctx-actions ctx)))
                                    'morph 'archon base-x base-y frame))
  (define protoss-ideal-worker-cap
       (l2-compute-race-ideal-worker-cap ctx nexuses))
  (define protoss-probe-priority?
       (and (or (not protoss-saving-for-expand?)
                (and (< total-workers 19) (< (l2-ctx-minerals ctx) 350)))
            (not crisis-freeze-workers?)
            (l2-worker-army-curve-satisfied? ctx)
            (not urgent-combat-or-intel-need?)
            (or (< total-workers protoss-ideal-worker-cap)
                (l2-can-spend-by-priority? ctx 'probe 'worker))
            (< total-workers (min 70 (max target-workers protoss-ideal-worker-cap)))
            (or (not live-game?)
                (and (not under-base-attack?) (<= live-enemy-threat-supply 0))
                (< total-workers 20)
                (not (or (memq 'gateway ready-bldg-types) (memq 'warp-gate ready-bldg-types)))
                (>= (length ally-combat-units) 3)
                (>= live-army-supply (* 6 (max 1 (length nexuses)))))
            (>= (l2-ctx-minerals ctx)
                (+ (sc2-min-cost 'probe)
                   (if (and live-game?
                            (>= total-workers 18)
                            bo-goal-sym
                            (not (memq bo-goal-sym '(hatchery nexus command-center drone probe scv)))
                            (> (sc2-gas-cost bo-goal-sym) 0)
                            (>= (l2-ctx-gas ctx) (sc2-gas-cost bo-goal-sym)))
                       (sc2-min-cost bo-goal-sym)
                       0)))
            (l2-can-spend-supply? ctx (sc2-supply-cost 'probe))
            (not under-early-cheese?)
            (< (hash-ref pressure-metrics 'threat-pressure 0.0) 0.85)))
  (when protoss-probe-priority?
       (l2-try-train-unit! ctx 'probe 'townhall 4
                        #:respect-bo-reserve?
                        (and live-game?
                             (or (>= total-workers 24)
                                 (>= total-workers protoss-ideal-worker-cap)
                                 (and (>= total-workers 16)
                                      (> (l2-ctx-bo-reserved-gas ctx) 0)
                                      (>= (l2-ctx-gas ctx) (l2-ctx-bo-reserved-gas ctx))))
                             (not (memq bo-goal-sym '(hatchery nexus command-center drone probe scv))))))
  (define (gateway-unit-colossus-ok? u-sym)
       (or crisis-tech-upgrade-deferral?
           (and (or (<= (sc2-gas-cost u-sym) 0)
                    (>= (- (l2-ctx-gas ctx) (sc2-gas-cost u-sym)) protoss-pending-robo-gas-reserve))
                (or urgent-combat-or-intel-need?
                    under-base-attack?
                    (and (eq? u-sym 'zealot) (>= (l2-ctx-minerals ctx) 400))
                    (l2-protoss-colossus-escrow-ok? ctx (sc2-min-cost u-sym) (sc2-gas-cost u-sym))))))
  (when (and (or crisis-tech-upgrade-deferral? (not protoss-saving-for-expand?))
                (l2-can-spend-supply? ctx (sc2-supply-cost 'zealot)))
       (cond
         [(memq 'cybernetics-core ready-bldg-types)
          ;; Dark Templar when Dark Shrine is ready
          (when (and (not crisis-tech-upgrade-deferral?)
                     (memq 'dark-shrine ready-bldg-types)
                     (gateway-unit-colossus-ok? 'dark-templar)
                     (or (l2-plan-wants-now? ctx 'dark-templar)
                         (< (l2-unit-count ctx 'dark-templar) 3))
                     (>= (l2-ctx-gas ctx) (sc2-gas-cost 'dark-templar))
                     (l2-can-spend-by-priority? ctx 'dark-templar 'combat-unit))
            (l2-try-train-unit! ctx 'dark-templar 'gateway 5 #:respect-bo-reserve? #t))
          ;; High Templar -> Psi Storm & Archon when Templar Archives ready
          (when (and (not crisis-tech-upgrade-deferral?)
                     (memq 'templar-archive ready-bldg-types)
                     (gateway-unit-colossus-ok? 'high-templar)
                     (< (l2-unit-count ctx 'high-templar) 6)
                     (>= (l2-ctx-gas ctx) (sc2-gas-cost 'high-templar)))
            (l2-try-train-unit! ctx 'high-templar 'gateway 5 #:respect-bo-reserve? #t))
          ;; Guardian Shield aura + gas sink: maintain 1 Sentry (respecting exact 100G cost & bo=sentry goal!)
          (when (and (not crisis-tech-upgrade-deferral?)
                     (>= (l2-ctx-gas ctx) (sc2-gas-cost 'sentry))
                     (gateway-unit-colossus-ok? 'sentry)
                     (or (eq? bo-goal-sym 'sentry)
                         (l2-plan-wants-now? ctx 'sentry)
                         (>= (length ally-combat-units) 2))
                     (if live-game?
                         (and (< (l2-unit-count ctx 'sentry) 1)
                              (or (eq? bo-goal-sym 'sentry)
                                  (eq? prio-saving-for-sym 'sentry)
                                  (l2-plan-wants-now? ctx 'sentry)
                                  (>= (l2-unit-count ctx 'stalker) 4)
                                  (and (>= (l2-ctx-gas ctx) 120) (>= (length ally-combat-units) 2))))
                         (< (l2-unit-count ctx 'sentry) 2)))
            (l2-try-train-unit! ctx 'sentry 'gateway 5 #:respect-bo-reserve? #t))
          ;; Counter-composition sensors: Zergling/Baneling floods (#5122350) vs Reaper/proxy Terran (#5122354)
          (define enemy-reaper-cnt
            (count (lambda (e) (eq? (unit-type-sym e) 'reaper)) enemy-units))
          (define enemy-light-swarm-cnt
            (count (lambda (e) (memq (unit-type-sym e) '(zergling baneling marine))) enemy-units))
          (define enemy-armored-or-air-cnt
            (count (lambda (e)
                     (memq (unit-type-sym e)
                           '(roach ravager marauder stalker immortal siege-tank siege-tank-sieged
                             thor ultralisk colossus mutalisk void-ray phoenix banshee viking medivac liberator)))
                   enemy-units))
          (define pvz-matchup?
            (and live-game?
                 (or (eq? effective-enemy-race 'Zerg)
                     (ormap (lambda (e)
                              (memq (unit-type-sym e)
                                    '(zergling baneling roach ravager hydralisk lurker
                                      lurker-burrowed lurker-mp-burrowed mutalisk corruptor
                                      ultralisk brood-lord broodlord drone queen overlord)))
                            enemy-units))))
          (define pvz-air-threat?
            (and pvz-matchup?
                 (ormap (lambda (e)
                          (memq (unit-type-sym e) '(mutalisk corruptor brood-lord broodlord)))
                        enemy-units)))
          (define pvz-ling-swarm-mode?
            (and live-game?
                 (>= enemy-light-swarm-cnt 6)
                 (> enemy-light-swarm-cnt (* 2 (max 1 enemy-armored-or-air-cnt)))))
          (define pvz-anti-ground-mode?
            (and pvz-matchup?
                 (not pvz-air-threat?)
                 (or (> enemy-light-swarm-cnt 0)
                     (> enemy-armored-or-air-cnt 0)
                     (< (l2-unit-count ctx 'zealot) (max 4 (* 2 (l2-unit-count ctx 'stalker)))))))
          (define anti-reaper-or-proxy-terran?
            (and live-game?
                 (or (>= enemy-reaper-cnt 1)
                     (and forward-proxy-detected? (eq? effective-enemy-race 'Terran)))))
          (cond
            [pvz-ling-swarm-mode?
             ;; Counter Zergling/Baneling floods (#5122350) with tanky Zealots + Adepts
             ;; instead of overbuilding Stalkers that get surrounded and shredded!
             (when (and (< (l2-unit-count ctx 'adept) 6)
                        (gateway-unit-colossus-ok? 'adept)
                        (or (l2-can-spend-by-priority? ctx 'adept 'combat-unit)
                            (l2-can-spend-by-priority? ctx 'stalker 'combat-unit)))
               (l2-try-train-unit! ctx 'adept 'gateway 5 #:respect-bo-reserve? #t))
             (when (and (gateway-unit-colossus-ok? 'zealot)
                        (or (l2-can-spend-by-priority? ctx 'zealot 'combat-unit)
                            (l2-can-spend-by-priority? ctx 'stalker 'combat-unit)))
               (l2-try-train-unit! ctx 'zealot 'gateway 5 #:respect-bo-reserve? #t))
             (when (and (gateway-unit-colossus-ok? 'stalker)
                        (or pvz-air-threat?
                            (and (not pvz-matchup?) (enemy-tech-observation-requires-anti-air? tech-obs))
                            (< (l2-unit-count ctx 'stalker) 2))
                        (l2-can-spend-by-priority? ctx 'stalker 'combat-unit))
               (l2-try-train-unit! ctx 'stalker 'gateway 5 #:respect-bo-reserve? #t))]
            [pvz-anti-ground-mode?
             ;; In PvZ vs Roach/Ravager/Zergling (`P0-2b`), conserve gas for Immortals/Archons/Colossi
             ;; by training Zealots first and strictly capping low-value Stalkers!
             (when (and (gateway-unit-colossus-ok? 'zealot)
                        (or (l2-can-spend-by-priority? ctx 'zealot 'combat-unit)
                            (>= (l2-ctx-minerals ctx) (sc2-min-cost 'zealot))))
               (l2-try-train-unit! ctx 'zealot 'gateway 5 #:respect-bo-reserve? #t))
             (when (and (< (l2-unit-count ctx 'adept) 3)
                        (< frame 4000)
                        (gateway-unit-colossus-ok? 'adept)
                        (l2-can-spend-by-priority? ctx 'adept 'combat-unit))
               (l2-try-train-unit! ctx 'adept 'gateway 5 #:respect-bo-reserve? #t))
             (when (and (gateway-unit-colossus-ok? 'stalker)
                        (< (l2-unit-count ctx 'stalker) (if (>= (l2-ctx-gas ctx) 225) 5 3))
                        (l2-can-spend-by-priority? ctx 'stalker 'combat-unit))
               (l2-try-train-unit! ctx 'stalker 'gateway 5 #:respect-bo-reserve? #t))]
            [anti-reaper-or-proxy-terran?
             ;; Counter proxy Reapers / proxy Barracks (#5122354) with ranged Stalkers + Adepts first
             (when (and (gateway-unit-colossus-ok? 'stalker)
                        (l2-can-spend-by-priority? ctx 'stalker 'combat-unit))
               (l2-try-train-unit! ctx 'stalker 'gateway 5 #:respect-bo-reserve? #t))
             (when (and (< (l2-unit-count ctx 'adept) 4)
                        (gateway-unit-colossus-ok? 'adept)
                        (or (l2-can-spend-by-priority? ctx 'adept 'combat-unit)
                            (l2-can-spend-by-priority? ctx 'stalker 'combat-unit)))
               (l2-try-train-unit! ctx 'adept 'gateway 5 #:respect-bo-reserve? #t))
             (when (and (gateway-unit-colossus-ok? 'zealot)
                        (l2-can-spend-by-priority? ctx 'zealot 'combat-unit)
                        (or (< (l2-ctx-gas ctx) (sc2-gas-cost 'adept))
                            (>= (l2-ctx-minerals ctx) 225)
                            (memq 'charge researched-upgs)))
               (l2-try-train-unit! ctx 'zealot 'gateway 5 #:respect-bo-reserve? #t))]
            [else
             ;; Early scouting / light-unit Adept when planned
             (when (and (not crisis-tech-upgrade-deferral?)
                        (gateway-unit-colossus-ok? 'adept)
                        (or (l2-plan-wants-now? ctx 'adept)
                            (and live-game? (< frame 3000) (< (l2-unit-count ctx 'adept) 1) (= (l2-unit-count ctx 'stalker) 0)))
                        (l2-can-spend-by-priority? ctx 'adept 'combat-unit))
               (l2-try-train-unit! ctx 'adept 'gateway 5 #:respect-bo-reserve? #t))
             (when (and (gateway-unit-colossus-ok? 'stalker)
                        (or crisis-tech-upgrade-deferral?
                            (l2-can-spend-by-priority? ctx 'stalker 'combat-unit)))
               (l2-try-train-unit! ctx 'stalker 'gateway 5 #:respect-bo-reserve? (not crisis-tech-upgrade-deferral?)))
             (when (and (gateway-unit-colossus-ok? 'zealot)
                        (or crisis-tech-upgrade-deferral?
                            (and (l2-can-spend-by-priority? ctx 'zealot 'combat-unit)
                                 (or (< (l2-ctx-gas ctx) (sc2-gas-cost 'stalker))
                                     (and (> protoss-pending-robo-gas-reserve 0)
                                          (< (- (l2-ctx-gas ctx) protoss-pending-robo-gas-reserve) (sc2-gas-cost 'stalker)))
                                     (>= (l2-ctx-minerals ctx) 225)
                                     (and urgent-combat-or-intel-need? (< (l2-ctx-minerals ctx) (sc2-min-cost 'stalker)))
                                     (and (memq 'charge researched-upgs)
                                          (< (l2-ctx-gas ctx) 200)
                                          (<= (l2-unit-count ctx 'zealot) (l2-unit-count ctx 'stalker)))))))
               (l2-try-train-unit! ctx 'zealot 'gateway 5 #:respect-bo-reserve? (not crisis-tech-upgrade-deferral?)))])]
         [(and (or (memq 'gateway ready-bldg-types) (memq 'warp-gate ready-bldg-types))
               (gateway-unit-colossus-ok? 'zealot)
               (or crisis-tech-upgrade-deferral?
                   (l2-can-spend-by-priority? ctx 'zealot 'combat-unit)))
          (l2-try-train-unit! ctx 'zealot 'gateway 5 #:respect-bo-reserve? (not crisis-tech-upgrade-deferral?))]))
  (when (and (not protoss-probe-priority?)
                (not crisis-freeze-workers?)
                (l2-worker-army-curve-satisfied? ctx)
                (not protoss-saving-for-expand?)
                (l2-can-spend-by-priority? ctx 'probe 'worker)
                (< total-workers
                   (if live-game?
                       (min 70 (max target-workers protoss-ideal-worker-cap))
                       target-workers))
                (or (member '(train probe) prio-scheduled-actions)
                    worker-rush-active?
                    (< total-workers 14)
                    (< (hash-ref pressure-metrics 'threat-pressure 0.0) 1.0)))
       (l2-try-train-unit! ctx 'probe 'townhall 4
                        #:respect-bo-reserve? (and live-game? (>= total-workers 24)))))

(define (l2-terran-phase1-orbital-addon-expand! ctx)
  (define allow-exact-wall-slot? (l2-ctx-allow-exact-wall-slot? ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define blocked-nat-expanded-early? (l2-ctx-blocked-nat-expanded-early? ctx))
  (define bypass-wall-depot1? (l2-ctx-bypass-wall-depot1? ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define crisis-freeze-expand-or-gas? (l2-ctx-crisis-freeze-expand-or-gas? ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define cur-escrow-age-frames (l2-ctx-cur-escrow-age-frames ctx))
  (define desired-bases (l2-ctx-desired-bases ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define endgame-corner-hunt? (l2-ctx-endgame-corner-hunt? ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define escrow-suppressed-active? (l2-ctx-escrow-suppressed-active? ctx))
  (define forward-proxy-detected? (l2-ctx-forward-proxy-detected? ctx))
  (define frame (l2-ctx-frame ctx))
  (define hard-supply-lockout-reserve-min (l2-ctx-hard-supply-lockout-reserve-min ctx))
  (define in-base-proxy-completed-cannon? (l2-ctx-in-base-proxy-completed-cannon? ctx))
  (define intel-confidence (l2-ctx-intel-confidence ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game-obs? (l2-ctx-live-game-obs? ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define macro-plan (l2-ctx-macro-plan ctx))
  (define max-escrow-timeout-frames (l2-ctx-max-escrow-timeout-frames ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define natural-blocked? (l2-ctx-natural-blocked? ctx))
  (define obs (l2-ctx-obs ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define orphaned-prereqs (l2-ctx-orphaned-prereqs ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define rt (l2-ctx-rt ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define terran-ramp-wall (l2-ctx-terran-ramp-wall ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
  (define ccs-rev '())
  (define refineries-rev '())
  (define active-refineries-rev '())
  (define barracks-rev '())
  (define factories-rev '())
  (for ([b (in-list ally-bldgs)])
       (define cs (fast-canonical-structure-sym (unit-type-sym b)))
       (cond
         [(memq cs '(command-center orbital-command planetary-fortress))
          (set! ccs-rev (cons b ccs-rev))]
         [(eq? cs 'refinery)
          (set! refineries-rev (cons b refineries-rev))
          (when (l2-active-gas-bldg? ctx b)
            (set! active-refineries-rev (cons b active-refineries-rev)))]
         [(eq? cs 'barracks)
          (set! barracks-rev (cons b barracks-rev))]
         [(eq? cs 'factory)
          (set! factories-rev (cons b factories-rev))]))
  (define ccs (reverse ccs-rev))
  (set-l2-ctx-ccs! ctx ccs)
  (define refineries (reverse refineries-rev))
  (define active-refineries (reverse active-refineries-rev))
  (set-l2-ctx-active-refineries! ctx active-refineries)
  (define barracks-list (reverse barracks-rev))
  (set-l2-ctx-barracks-list! ctx barracks-list)
  (define factories-list (reverse factories-rev))
  (set-l2-ctx-factories-list! ctx factories-list)
  (define mule-patch-id (hash-ref obs 'mineral-patch-id SC2-SYNTHETIC-MINERAL-PATCH-ID))
  (define raw-mineral-patches
       (let ([mps (hash-ref obs 'mineral-patches '())])
         (if (list? mps) (filter hash? mps) '())))
  (define splash-st (rt-splash-state rt))
  (define scanned-pts '())
  (define claimed-mule-patches (mutable-seteqv))
  (define reserve-scan-energy?
       (and live-game?
            (>= frame 3360)
            (or (enemy-tech-observation-requires-detection? tech-obs)
                endgame-corner-hunt?
                (< intel-confidence 0.55))))
  (for ([cc (in-list ccs)])
       (define raw-ctype (unit-type-sym cc))
       (define cid (hash-ref cc 'id 301))
       (define cenergy (hash-ref cc 'energy SC2-ORBITAL-MULE-ENERGY))
       (cond
         [(and (eq? raw-ctype 'command-center)
               (l2-building-grounded-and-powered? ctx cc)
               (>= (hash-ref cc 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
               (<= (hash-ref cc 'order-count 0) 0)
               (= (hash-ref cc 'order-ability-id 0) 0)
               (memq 'barracks ready-bldg-types)
               (not (order-ledger-facility-busy? oledger cc frame))
               (>= (l2-ctx-minerals ctx) (sc2-min-cost 'orbital-command))
               (l2-non-combat-min-ok? ctx (sc2-min-cost 'orbital-command) 'orbital-command)
               (or (not live-game?)
                   (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                              (list 'morph-cc cid 'orbital-command)
                                              frame
                                              28)))
          (l2-recall-building-group! ctx 4)
          (l2-emit! ctx (list 'morph cid 'orbital-command))
          (order-ledger-record-issued! oledger cid 'morph 'orbital-command base-x base-y frame)
          (set-l2-ctx-morphing-bldg-types! ctx (cons 'orbital-command (l2-ctx-morphing-bldg-types ctx)))
          (when live-game?
            (hash-set! open-prod-slots 'townhall
                       (max 0 (sub1 (hash-ref open-prod-slots 'townhall 0)))))
          (l2-spend-resources-and-supply! ctx (sc2-min-cost 'orbital-command) 0 0)]
         [(and (eq? raw-ctype 'orbital-command)
               (l2-building-grounded-and-powered? ctx cc)
               (>= (hash-ref cc 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS))
          (define last-scan-f (hash-ref splash-st 'last-scan-frame -9999))
          (define scan-ready?
            (and (>= cenergy SC2-ORBITAL-SCAN-ENERGY)
                 (or (not live-game?) (>= (- frame last-scan-f) 44))))
          (define cloaked-enemy
            (and scan-ready?
                 (for/first ([e (in-list enemy-units)]
                             #:when (and (or (hash-ref e 'cloaked #f)
                                             (hash-ref e 'burrowed #f)
                                             (memq (fast-canonical-unit-sym (unit-type-sym e))
                                                   '(lurker dark-templar banshee ghost widow-mine)))
                                         (let ([ex0 (exact->inexact (hash-ref e 'x nat-x))]
                                               [ey0 (exact->inexact (hash-ref e 'y nat-y))])
                                           (not (for/or ([pt (in-list scanned-pts)])
                                                  (define dx (fl- ex0 (exact->inexact (car pt))))
                                                  (define dy (fl- ey0 (exact->inexact (cdr pt))))
                                                  (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 144.0))))))
                   e)))
          (cond
            [cloaked-enemy
             (define sx (safe-coord (hash-ref cloaked-enemy 'x nat-x) nat-x))
             (define sy (safe-coord (hash-ref cloaked-enemy 'y nat-y) nat-y))
             (set! scanned-pts (cons (cons sx sy) scanned-pts))
             (hash-set! splash-st 'last-scan-frame frame)
             (l2-emit! ctx (list 'cast-spell cid 'scanner-sweep sx sy))]
            [(and (or (not live-game?) (not (null? raw-mineral-patches)))
                  (>= cenergy (if endgame-corner-hunt?
                                  150
                                  (if reserve-scan-energy? 100 SC2-ORBITAL-MULE-ENERGY))))
             (define ccx (exact->inexact (hash-ref cc 'x base-x)))
             (define ccy (exact->inexact (hash-ref cc 'y base-y)))
             (define best-patch-id #f)
             (define best-contents -1)
             (for ([mp (in-list raw-mineral-patches)])
               (define pid (hash-ref mp 'id 0))
               (when (and (> pid 0) (not (set-member? claimed-mule-patches pid)))
                 (define dx (fl- ccx (exact->inexact (hash-ref mp 'x ccx))))
                 (define dy (fl- ccy (exact->inexact (hash-ref mp 'y ccy))))
                 (when (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 121.0)
                   (define mc (hash-ref mp 'mineral-contents 1000))
                   (when (or (not best-patch-id) (> mc best-contents))
                     (set! best-patch-id pid)
                     (set! best-contents mc)))))
             (define chosen-patch-id (or best-patch-id mule-patch-id))
             (set-add! claimed-mule-patches chosen-patch-id)
             (l2-emit! ctx (list 'cast-spell cid 'calldown-mule chosen-patch-id))])]))
  (when (and endgame-corner-hunt?
                (memq 'starport ready-bldg-types)
                (< (l2-unit-count ctx 'viking) 2)
                (l2-can-spend-supply? ctx (sc2-supply-cost 'viking)))
       (l2-try-train-unit! ctx 'viking 'starport 6 #:respect-bo-reserve? #f))
  (when (and live-game?
                (not endgame-corner-hunt?)
                (memq 'starport ready-bldg-types)
                (enemy-tech-observation-requires-anti-air? tech-obs)
                (< (l2-unit-count ctx 'viking) 2)
                (l2-can-spend-supply? ctx (sc2-supply-cost 'viking)))
       (l2-try-train-unit! ctx 'viking 'starport 6 #:respect-bo-reserve? #f))
  (when (and live-game?
                (not endgame-corner-hunt?)
                (memq 'starport ready-bldg-types)
                (or (not (enemy-tech-observation-requires-anti-air? tech-obs))
                    (>= (l2-unit-count ctx 'viking) 2))
                (>= (+ (l2-unit-count ctx 'marine) (l2-unit-count ctx 'marauder)) 6)
                (< (l2-unit-count ctx 'medivac) 1)
                (l2-can-spend-supply? ctx (sc2-supply-cost 'medivac)))
       (l2-try-train-unit! ctx 'medivac 'starport 6 #:respect-bo-reserve? #f))
  (when (and live-game?
                (not endgame-corner-hunt?)
                (memq 'starport ready-bldg-types)
                (enemy-tech-observation-requires-anti-air? tech-obs)
                (>= (l2-unit-count ctx 'medivac) 2)
                (< (l2-unit-count ctx 'viking) 8)
                (l2-can-spend-supply? ctx (sc2-supply-cost 'viking)))
       (l2-try-train-unit! ctx 'viking 'starport 6 #:respect-bo-reserve? #f))
  (define unmorphed-ready-cc
       (findf (lambda (cc)
                (and (eq? (unit-type-sym cc) 'command-center)
                     (l2-building-grounded-and-powered? ctx cc)
                     (>= (hash-ref cc 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS)
                     (<= (hash-ref cc 'order-count 0) 0)
                     (= (hash-ref cc 'order-ability-id 0) 0)
                     (not (order-ledger-facility-busy? oledger cc frame))))
              ccs))
  (define terran-saving-for-orbital?
       (and live-game?
            (not (not unmorphed-ready-cc))
            (= (order-ledger-pending-count-for-type oledger 'orbital-command frame) 0)
            (memq 'barracks ready-bldg-types)
            (not under-base-attack?)
            (not under-early-cheese?)
            (not early-survival-crisis?)
            (not urgent-combat-or-intel-need?)
            (not escrow-suppressed-active?)
            (< (l2-ctx-minerals ctx) (sc2-min-cost 'orbital-command))))
  (set-l2-ctx-terran-saving-for-orbital?! ctx terran-saving-for-orbital?)
  (define terran-addon-xs-ys
       (for/fold ([xs '()] [ys '()] #:result (cons xs ys))
                 ([ab (in-list ally-bldgs)]
                  #:when (hash-has-key? TERRAN-ADDON-BLDG-SET (unit-type-sym ab)))
         (values (cons (exact->inexact (hash-ref ab 'x -9999.0)) xs)
                 (cons (exact->inexact (hash-ref ab 'y -9999.0)) ys))))
  (define terran-addon-xs (car terran-addon-xs-ys))
  (set-l2-ctx-terran-addon-xs! ctx terran-addon-xs)
  (define terran-addon-ys (cdr terran-addon-xs-ys))
  (set-l2-ctx-terran-addon-ys! ctx terran-addon-ys)
  (define terran-addon-ox (exact->inexact SC2-TERRAN-ADDON-OFFSET-X))
  (set-l2-ctx-terran-addon-ox! ctx terran-addon-ox)
  (define terran-addon-oy (exact->inexact SC2-TERRAN-ADDON-OFFSET-Y))
  (set-l2-ctx-terran-addon-oy! ctx terran-addon-oy)
  (when (not live-game?)
       (define rax-with-reactor
         (for/first ([b (in-list ally-bldgs)]
                     #:when (let ([bt (unit-type-sym b)])
                              (or (eq? bt 'barracks-reactor)
                                  (and (eq? bt 'barracks)
                                       (l2-building-grounded-and-powered? ctx b)
                                       (eq? (hash-ref b 'addon #f) 'reactor)))))
           b))
       (define fac-needing-addon
         (for/first ([b (in-list ally-bldgs)]
                     #:when (and (eq? (unit-type-sym b) 'factory)
                                 (l2-building-grounded-and-powered? ctx b)
                                 (not (l2-terran-facility-has-addon? ctx b))))
           b))
       (when (and rax-with-reactor fac-needing-addon)
         (l2-emit! ctx (list 'swap-addon
                      (hash-ref rax-with-reactor 'id 704)
                      (hash-ref fac-needing-addon 'id 705)))))
  (define addon-swap-acts (plan-terran-addon-swap obs))
  (set-l2-ctx-addon-swap-acts! ctx addon-swap-acts)
  (for ([swap-act (in-list addon-swap-acts)])
       (l2-emit! ctx swap-act))
  (define claimed-addon-fac-ids (mutable-seteqv))
  (set-l2-ctx-claimed-addon-fac-ids! ctx claimed-addon-fac-ids)
  (define terran-exp-x #f)
  (define terran-exp-y #f)
  (when (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'command-center))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'command-center) 'command-center)
                (not blocked-nat-expanded-early?)
                (not under-early-cheese?)
                (not early-survival-crisis?)
                (not crisis-freeze-expand-or-gas?)
                (not under-base-attack?)
                (< (length ccs) SC2-MAX-ACTIVE-BASES)
                (= (order-ledger-pending-count-for-type oledger 'command-center frame) 0)
                (or (< (length ccs) SC2-MIN-DESIRED-BASES)
                    (and (= (length ccs) 2)
                         (>= eff-phase-supply 42)
                         (or (not live-game?) (>= live-army-supply 10) (>= (l2-ctx-minerals ctx) 550))
                         (or (not live-game?)
                             (memq 'starport ready-bldg-types)
                             (>= (l2-ctx-minerals ctx) 550))
                         (or live-game?
                             (memq 'starport (l2-ctx-bldg-types ctx))
                             (memq 'factory (l2-ctx-bldg-types ctx))
                             (l2-plan-wants-now? ctx 'command-center)))
                    (and (< (length ccs) desired-bases)
                         (or (not (and live-game?
                                       (= (length ccs) 2)
                                       (not (memq 'starport ready-bldg-types))))
                             (>= (l2-ctx-minerals ctx) 550))
                         (or (not (and endgame-corner-hunt?
                                       (< (l2-unit-count ctx 'viking) 2)))
                             (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'command-center)) 150))
                         (>= total-workers (* (length ccs)
                                              (if (>= (length ccs) 3) 16 SC2-MIN-WORKERS-PER-BASE-FOR-EXPAND)))
                         (or (coupled-macro-plan-should-expand? macro-plan)
                             (>= frame SC2-MACRO-EXPAND-FRAME-THRESHOLD))))
                (refractory-ready? cd-tracker '(macro-expand Terran) frame SC2-EXPANSION-COOLDOWN-FRAMES)
                (or (and live-game? (= (length ccs) 1) natural-blocked?)
                    (let-values ([(cand-ex cand-ey)
                                  (l2-select-uncamped-expansion-pad ctx (< (length ccs) SC2-MIN-DESIRED-BASES))])
                      (set! terran-exp-x cand-ex)
                      (set! terran-exp-y cand-ey)
                      (or (and cand-ex cand-ey)
                          (and live-game? (= (length ccs) 2) (>= (l2-ctx-minerals ctx) 550)))))
                (refractory-allow-action?! cd-tracker
                                           '(macro-expand Terran)
                                           frame
                                           SC2-EXPANSION-COOLDOWN-FRAMES))
       (cond
         [(and live-game? (= (length ccs) 1) natural-blocked?)
          (l2-emit-build-verified! ctx 'command-center
                                (safe-coord (+ base-x 4.0))
                                (safe-coord base-y))]
         [(and terran-exp-x terran-exp-y)
          (l2-emit! ctx (list 'expand terran-exp-x terran-exp-y))
          (order-ledger-record-issued! oledger (+ 810000 (modulo frame 10000)) 'expand 'command-center terran-exp-x terran-exp-y frame)
          (l2-spend-resources-and-supply! ctx (sc2-min-cost 'command-center) 0 0)]
         [(and live-game? (= (length ccs) 2) (>= (l2-ctx-minerals ctx) 550))
          (l2-emit-build-verified! ctx 'command-center
                                (safe-coord (+ base-x 4.0))
                                (safe-coord base-y))]))
  (define pending-cc-count
       (order-ledger-pending-count-for-type oledger 'command-center frame))
  (set-l2-ctx-pending-cc-count! ctx pending-cc-count)
  (define reserved-expansion-minerals
       (if live-game?
           (compute-natural-expansion-mineral-reserve
            #:race 'Terran
            #:frame frame
            #:active-bases (length ccs)
            #:pending-bases pending-cc-count
            #:workers total-workers
            #:under-attack? (or under-base-attack? early-survival-crisis?)
            #:enemy-threat-supply live-enemy-threat-supply
            #:natural-blocked? natural-blocked?
            #:escrow-expired? (or escrow-suppressed-active?
                                  early-survival-crisis?
                                  (>= cur-escrow-age-frames max-escrow-timeout-frames)
                                  urgent-combat-or-intel-need?
                                  (not (null? orphaned-prereqs))))
           0))
  (set-l2-ctx-reserved-expansion-minerals! ctx reserved-expansion-minerals)
  (define terran-saving-for-expand?
       (or (l2-saving-for-expansion-now? ctx (length ccs))
           (and (> reserved-expansion-minerals 0) (< (l2-ctx-minerals ctx) reserved-expansion-minerals))
           terran-saving-for-orbital?))
  (set-l2-ctx-terran-saving-for-expand?! ctx terran-saving-for-expand?)
  (define cur-bunker-cnt
       (+ (count (lambda (b) (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'bunker)) ally-bldgs)
          (order-ledger-pending-count-for-type oledger 'bunker frame)))
  (define desired-bunker-cnt
       (if (and crisis-tech-upgrade-deferral?
                (or (>= live-army-supply 4)
                    (>= (l2-ctx-minerals ctx) 200)))
           2
           1))
  (when (and (or early-survival-crisis?
                    under-early-cheese?
                    under-base-attack?
                    forward-proxy-detected?
                    (>= live-enemy-threat-supply 6))
                (memq 'barracks (l2-ctx-bldg-types ctx))
                (< cur-bunker-cnt desired-bunker-cnt)
                (= (order-ledger-pending-count-for-type oledger 'bunker frame) 0)
                (l2-save-cancel-rebuild-ready? ctx 'bunker 60)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'bunker)))
       (define-values (bk-x bk-y)
         (cond
           [(> cur-bunker-cnt 0)
            (l2-offset-defense-anchor ctx (safe-coord (+ nat-x 3.0) nat-x) (safe-coord (- nat-y 3.0) nat-y) 5.5)]
           [(<= (length ccs) 1)
            (values (safe-coord (+ base-x (* 0.25 (- nat-x base-x))) base-x)
                    (safe-coord (+ base-y (* 0.25 (- nat-y base-y))) base-y))]
           [else
            (l2-offset-defense-anchor ctx nat-x nat-y 5.5)]))
       (l2-emit-build-verified! ctx 'bunker bk-x bk-y))
  (when (and (null? barracks-list)
                (or (not live-game-obs?) (memq 'supply-depot ready-bldg-types))
                (not (l2-building-present-or-pending? ctx 'barracks))
                (l2-save-cancel-rebuild-ready? ctx 'barracks 60)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'barracks))
                (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'barracks)) hard-supply-lockout-reserve-min))
       (define wall-rax
         (and allow-exact-wall-slot?
              (not bypass-wall-depot1?)
              (<= (length ccs) 2)
              (hash-ref terran-ramp-wall 'barracks #f)))
       (define rx0 (if (pair? wall-rax) (safe-coord (car wall-rax) (+ base-x 4.0)) (safe-coord (+ base-x 4.0))))
       (define ry0 (if (pair? wall-rax) (safe-coord (cdr wall-rax) (+ base-y 4.0)) (safe-coord (+ base-y 4.0))))
       (l2-emit-build-verified! ctx 'barracks rx0 ry0 SC2-BUILD-SITE-MIN-CLEARANCE
                             #:exact-wall-slot? (and allow-exact-wall-slot? (not bypass-wall-depot1?) (<= (length ccs) 2) (pair? wall-rax))))
  (define terran-cannon-breakout-mode?
       (and live-game?
            in-base-proxy-completed-cannon?
            (< (l2-unit-count ctx 'siege-tank) 2)))
  (set-l2-ctx-terran-cannon-breakout-mode?! ctx terran-cannon-breakout-mode?)
  (define desired-refineries
       (if (and early-survival-crisis?
                (not terran-cannon-breakout-mode?)
                (null? active-refineries))
           0
           (min (* SC2-GEYSERS-PER-BASE (length ccs))
                (if live-game?
                    (cond
                      [(and (>= (length ccs) 4) (>= total-workers 62) (< (l2-ctx-gas ctx) 600)) 8]
                      [(and (>= (length ccs) 3) (>= total-workers 50) (< (l2-ctx-gas ctx) 450)) 6]
                      [(and (>= eff-phase-supply 56) (>= total-workers 42) (< (l2-ctx-gas ctx) 350)) 4]
                      [(and (>= eff-phase-supply 44) (>= total-workers 34) (< (l2-ctx-gas ctx) 300)) 3]
                      [(and (or (memq 'factory (l2-ctx-bldg-types ctx)) (>= eff-phase-supply 22))
                            (>= total-workers 21)
                            (< (l2-ctx-gas ctx) 250))
                       2]
                      [else 1])
                    (cond
                      [(>= supply-used 56) 4]
                      [(>= supply-used 44) 3]
                      [(or (memq 'factory (l2-ctx-bldg-types ctx)) (>= supply-used 22)) 2]
                      [else 1])))))
  (when (and (memq 'barracks (l2-ctx-bldg-types ctx))
                (or terran-cannon-breakout-mode? (not crisis-freeze-expand-or-gas?))
                (l2-save-cancel-rebuild-ready? ctx 'refinery 60)
                (or (null? active-refineries) (not terran-saving-for-expand?) terran-cannon-breakout-mode?)
                (< (+ (length active-refineries) (order-ledger-pending-count-for-type oledger 'refinery frame))
                   desired-refineries)
                (or (< (length active-refineries) 2)
                    (l2-starport-escrow-ok? ctx (sc2-min-cost 'refinery) 0))
                (or (not live-game?)
                    (< (length active-refineries) 2)
                    (< (l2-ctx-gas ctx) 150)
                    (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'refinery)) (l2-ctx-bo-reserved-min ctx)))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'refinery))
                (or terran-cannon-breakout-mode? (l2-non-combat-min-ok? ctx (sc2-min-cost 'refinery))))
       (l2-emit-gas-build-verified! ctx 'refinery (safe-coord (+ base-x 3.0)) (safe-coord (+ base-y 5.0)))))

(define (l2-terran-phase2-tech-starport! ctx)
  (define active-refineries (l2-ctx-active-refineries ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define barracks-list (l2-ctx-barracks-list ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define ccs (l2-ctx-ccs ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define claimed-addon-fac-ids (l2-ctx-claimed-addon-fac-ids ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define early-survival-crisis? (l2-ctx-early-survival-crisis? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define endgame-corner-hunt? (l2-ctx-endgame-corner-hunt? ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define factories-list (l2-ctx-factories-list ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define pending-cc-count (l2-ctx-pending-cc-count ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define reserved-expansion-minerals (l2-ctx-reserved-expansion-minerals ctx))
  (define rt (l2-ctx-rt ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define terran-cannon-breakout-mode? (l2-ctx-terran-cannon-breakout-mode? ctx))
  (define terran-saving-for-expand? (l2-ctx-terran-saving-for-expand? ctx))
  (define terran-saving-for-orbital? (l2-ctx-terran-saving-for-orbital? ctx))
  (define total-bldg-counts (l2-ctx-total-bldg-counts ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
  (define cur-rax-techlab-cnt
       (+ (count (lambda (t) (memq t '(barracks-techlab tech-lab))) (l2-ctx-bldg-types ctx))
          (order-ledger-pending-count-for-type oledger 'barracks-techlab frame)))
  (define desired-rax-techlabs
       (if (and live-game?
                (or (memq effective-enemy-race '(Protoss Zerg Terran))
                    (ormap (lambda (e)
                             (memq (unit-type-sym e)
                                   '(stalker immortal marauder roach ravager siege-tank siege-tank-sieged thor colossus ultralisk)))
                           enemy-units)))
           (cond
             [(>= (length barracks-list) 5) 3]
             [(>= (length barracks-list) 3) 2]
             [else 1])
           1))
  (define has-rax-techlab?
       (or (>= cur-rax-techlab-cnt desired-rax-techlabs)
           (and (= desired-rax-techlabs 1)
                (l2-building-present-or-pending? ctx 'barracks-techlab #t))))
  (define addon-threat-enemies
       (if live-game?
           (filter combat-unit-record? enemy-units)
           '()))
  (define (facility-safe-for-addon? fac)
       (or (not live-game?)
           (let ([fx (exact->inexact (hash-ref fac 'x base-x))]
                 [fy (exact->inexact (hash-ref fac 'y base-y))])
             (and (not (eq? (hash-ref fac 'under-attack #f) #t))
                  (not (for/or ([e (in-list addon-threat-enemies)])
                         (define dx (- fx (exact->inexact (hash-ref e 'x 9999.0))))
                         (define dy (- fy (exact->inexact (hash-ref e 'y 9999.0))))
                         (<= (+ (* dx dx) (* dy dy)) 100.0)))))))
  (define bare-rax-for-tl (l2-grounded-bare-facility ctx 'barracks))
  (when (and bare-rax-for-tl
                (not terran-saving-for-expand?)
                (not has-rax-techlab?)
                (or (= cur-rax-techlab-cnt 0)
                    (l2-starport-escrow-ok? ctx (sc2-min-cost 'barracks-techlab) (sc2-gas-cost 'barracks-techlab)))
                (or (not live-game?)
                    (and (> (hash-ref open-prod-slots 'barracks 0) 0)
                         (or (not urgent-combat-or-intel-need?)
                             (not (null? ally-combat-units))
                             (> (hash-ref open-prod-slots 'barracks 0) 1))))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'barracks-techlab))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'barracks-techlab))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'barracks-techlab) 'barracks-techlab)
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'barracks-techlab) 'barracks-techlab)
                (facility-safe-for-addon? bare-rax-for-tl)
                (or (not live-game?)
                    (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                               (list 'terran-addon-emit (hash-ref bare-rax-for-tl 'id 303) 'barracks-techlab)
                                               frame
                                               36)))
       (define rbx (safe-coord (+ (hash-ref bare-rax-for-tl 'x (+ base-x 4.0)) SC2-TERRAN-ADDON-OFFSET-X) (+ base-x 6.5)))
       (define rby (safe-coord (+ (hash-ref bare-rax-for-tl 'y (+ base-y 4.0)) SC2-TERRAN-ADDON-OFFSET-Y) (+ base-y 3.5)))
       (l2-recall-building-group! ctx 5)
       (l2-emit! ctx (list 'build 'barracks-techlab rbx rby))
       (set-add! claimed-addon-fac-ids (hash-ref bare-rax-for-tl 'id 303))
       (order-ledger-record-issued! oledger (hash-ref bare-rax-for-tl 'id 303) 'build 'barracks-techlab rbx rby frame)
       (set-l2-ctx-bldg-types! ctx (cons 'barracks-techlab (l2-ctx-bldg-types ctx)))
       (set! cur-rax-techlab-cnt (add1 cur-rax-techlab-cnt))
       (set! has-rax-techlab? (>= cur-rax-techlab-cnt desired-rax-techlabs))
       (when live-game?
         (hash-set! open-prod-slots 'barracks (max 0 (sub1 (hash-ref open-prod-slots 'barracks 0)))))
       (l2-spend-resources-and-supply! ctx (sc2-min-cost 'barracks-techlab) (sc2-gas-cost 'barracks-techlab) 0))
  (when (and (memq 'barracks-techlab ready-bldg-types)
                (not urgent-combat-or-intel-need?))
       (cond
         [(l2-upgrade-needed? ctx 'stimpack)
          (when (and (>= (l2-ctx-minerals ctx) (sc2-min-cost 'stimpack))
                     (>= (l2-ctx-gas ctx) (sc2-gas-cost 'stimpack)))
            (l2-emit-research-verified! ctx 'stimpack))]
         [(l2-upgrade-needed? ctx 'combat-shield)
          (when (and (l2-starport-escrow-ok? ctx (sc2-min-cost 'combat-shield) (sc2-gas-cost 'combat-shield))
                     (>= (l2-ctx-minerals ctx) (sc2-min-cost 'combat-shield))
                     (>= (l2-ctx-gas ctx) (sc2-gas-cost 'combat-shield)))
            (l2-emit-research-verified! ctx 'combat-shield))]
         [(and (l2-upgrade-needed? ctx 'concussive-shells)
               (l2-starport-escrow-ok? ctx (sc2-min-cost 'concussive-shells) (sc2-gas-cost 'concussive-shells))
               (or (not live-game?)
                   (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'concussive-shells)) (l2-ctx-bo-reserved-min ctx)))
               (>= (l2-ctx-minerals ctx) (sc2-min-cost 'concussive-shells))
               (>= (l2-ctx-gas ctx) (sc2-gas-cost 'concussive-shells)))
          (l2-emit-research-verified! ctx 'concussive-shells)]))
  (define desired-factories
       (cond
         [(not live-game?) 1]
         [(and (memq effective-enemy-race '(Terran Protoss))
               (>= (length ccs) 2)
               (>= eff-phase-supply 68)
               (>= (l2-ctx-gas ctx) 100))
          2]
         [(and (>= (length ccs) 3) (>= eff-phase-supply 106) (>= (l2-ctx-gas ctx) 200))
          2]
         [else 1]))
  (define rush-factory-vs-proxy-cannon?
       (and terran-cannon-breakout-mode?
            (null? factories-list)))
  (when (and (memq 'barracks ready-bldg-types)
                (or (not terran-saving-for-expand?) rush-factory-vs-proxy-cannon?)
                (l2-save-cancel-rebuild-ready? ctx 'factory 60)
                (< (+ (length factories-list) (order-ledger-pending-count-for-type oledger 'factory frame))
                   desired-factories)
                (or (null? factories-list)
                    (l2-can-spend-by-priority? ctx 'factory 'production-scaling)
                    (and (memq effective-enemy-race '(Terran Protoss))
                         (>= (length ccs) 2)
                         (>= eff-phase-supply 68)
                         (>= (l2-ctx-minerals ctx) (sc2-min-cost 'factory))
                         (>= (l2-ctx-gas ctx) (sc2-gas-cost 'factory)))
                    (>= (l2-ctx-minerals ctx) 400))
                (or rush-factory-vs-proxy-cannon?
                    (>= (- (l2-ctx-minerals ctx) reserved-expansion-minerals) (sc2-min-cost 'factory)))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'factory))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'factory))
                (or rush-factory-vs-proxy-cannon?
                    (and (l2-non-combat-min-ok? ctx (sc2-min-cost 'factory) 'factory)
                         (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'factory) 'factory))))
       (define fac-idx (length factories-list))
       (l2-emit-build-verified! ctx 'factory
                             (safe-coord (+ base-x (* (add1 fac-idx) SC2-TERRAN-FACILITY-STEP-X)))
                             (safe-coord (+ base-y SC2-TERRAN-FACILITY-STEP-Y))))
  (when (and (or (not terran-saving-for-expand?) endgame-corner-hunt?)
                (memq 'factory ready-bldg-types)
                (not (l2-building-present-or-pending? ctx 'starport))
                (l2-save-cancel-rebuild-ready? ctx 'starport 60)
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'starport))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'starport))
                (or endgame-corner-hunt?
                    (and (l2-non-combat-min-ok? ctx (sc2-min-cost 'starport) 'starport)
                         (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'starport) 'starport))))
       (l2-emit-build-verified! ctx 'starport
                             (safe-coord (+ base-x SC2-TERRAN-FACILITY-STEP-X))
                             (safe-coord (+ base-y (* 2.0 SC2-TERRAN-FACILITY-STEP-Y)))))
  (define terran-ideal-worker-cap
       (l2-compute-race-ideal-worker-cap ctx ccs))
  (set-l2-ctx-terran-ideal-worker-cap! ctx terran-ideal-worker-cap)
  (define terran-worker-min-floor
       (if (and live-game?
                (>= (length ccs) 2)
                (< total-workers (* 18 (length ccs)))
                (< (l2-ctx-gas ctx) 200)
                (> (hash-ref open-prod-slots 'townhall 0) 0)
                (not under-base-attack?)
                (<= live-enemy-threat-supply 0)
                (not under-early-cheese?)
                (not terran-saving-for-orbital?))
           (sc2-min-cost 'scv)
           0))
  (define raw-desired-barracks
       (min SC2-MAX-PRODUCTION-FACILITIES
            (max 1 (if (>= (+ (length ccs) pending-cc-count) SC2-MIN-DESIRED-BASES)
                       (* SC2-TERRAN-FACILITIES-PER-BASE (max (length ccs) (+ (length ccs) pending-cc-count)))
                       (if (and (memq 'factory (l2-ctx-bldg-types ctx))
                                (or (not live-game?)
                                    (<= reserved-expansion-minerals 0)
                                    (>= (- (l2-ctx-minerals ctx) reserved-expansion-minerals) (sc2-min-cost 'barracks))))
                           2
                           1)))))
  (define desired-barracks
       (cond
         [(not live-game?) raw-desired-barracks]
         [(and (not (memq 'factory (l2-ctx-bldg-types ctx)))
               (not (and (< (length active-refineries) 1) (>= (l2-ctx-minerals ctx) 450))))
          (min 2 raw-desired-barracks)]
         [(and (not (memq 'starport (l2-ctx-bldg-types ctx)))
               (< (l2-ctx-minerals ctx) 500))
          (min 2 raw-desired-barracks)]
         [(< (l2-ctx-minerals ctx) 1000)
          (min 8 raw-desired-barracks)]
         [else raw-desired-barracks]))
  (define cur-rax-total
       (+ (length barracks-list) (order-ledger-pending-count-for-type oledger 'barracks frame)))
  (when (and (not terran-saving-for-expand?)
                (l2-save-cancel-rebuild-ready? ctx 'barracks 60)
                (l2-can-spend-by-priority? ctx 'barracks 'production-scaling)
                (>= (length barracks-list) 1)
                (or (< cur-rax-total 2)
                    (l2-starport-escrow-ok? ctx (sc2-min-cost 'barracks) 0))
                (or (not live-game?)
                    (< (length barracks-list) 2)
                    (< (hash-ref open-prod-slots 'barracks 0) 2)
                    (>= (l2-ctx-minerals ctx) 350))
                (< cur-rax-total desired-barracks)
                (or (memq 'factory (l2-ctx-bldg-types ctx))
                    (< (l2-ctx-gas ctx) (sc2-gas-cost 'factory))
                    (>= (l2-ctx-minerals ctx) SC2-SURPLUS-MINERAL-BANK-THRESHOLD))
                (>= (- (l2-ctx-minerals ctx) (+ reserved-expansion-minerals terran-worker-min-floor)) (sc2-min-cost 'barracks))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'barracks)))
       (define rax-idx (length barracks-list))
       (l2-emit-build-verified! ctx 'barracks
                             (safe-coord (+ base-x 4.0 (* SC2-TERRAN-FACILITY-STEP-X (modulo rax-idx 2))))
                             (safe-coord (+ base-y 4.0 (* SC2-TERRAN-FACILITY-STEP-Y (quotient rax-idx 2))))))
  (define bare-rax-for-rx (l2-grounded-bare-facility ctx 'barracks))
  (define cur-rax-reactor-cnt
       (+ (count (lambda (t) (memq t '(barracks-reactor reactor))) (l2-ctx-bldg-types ctx))
          (order-ledger-pending-count-for-type oledger 'barracks-reactor frame)))
  (when (and (not terran-saving-for-expand?)
                (>= (length barracks-list) 2)
                bare-rax-for-rx
                (l2-starport-escrow-ok? ctx (sc2-min-cost 'barracks-reactor) (sc2-gas-cost 'barracks-reactor))
                (if (and live-game? (memq 'factory (l2-ctx-bldg-types ctx)) (>= (length barracks-list) 3))
                    (< cur-rax-reactor-cnt (max 1 (- (length barracks-list) desired-rax-techlabs)))
                    (not (l2-building-present-or-pending? ctx 'barracks-reactor #t)))
                (or (not live-game?) (> (hash-ref open-prod-slots 'barracks 0) 0))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'barracks-reactor))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'barracks-reactor))
                (l2-non-combat-min-ok? ctx (sc2-min-cost 'barracks-reactor))
                (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'barracks-reactor))
                (facility-safe-for-addon? bare-rax-for-rx)
                (or (not live-game?)
                    (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                               (list 'terran-addon-emit (hash-ref bare-rax-for-rx 'id 304) 'barracks-reactor)
                                               frame
                                               36)))
       (define rrx (safe-coord (+ (hash-ref bare-rax-for-rx 'x (+ base-x 8.5)) SC2-TERRAN-ADDON-OFFSET-X) (+ base-x 11.0)))
       (define rry (safe-coord (+ (hash-ref bare-rax-for-rx 'y (+ base-y 4.0)) SC2-TERRAN-ADDON-OFFSET-Y) (+ base-y 3.5)))
       (l2-recall-building-group! ctx 5)
       (l2-emit! ctx (list 'build 'barracks-reactor rrx rry))
       (set-add! claimed-addon-fac-ids (hash-ref bare-rax-for-rx 'id 304))
       (order-ledger-record-issued! oledger (hash-ref bare-rax-for-rx 'id 304) 'build 'barracks-reactor rrx rry frame)
       (set-l2-ctx-bldg-types! ctx (cons 'barracks-reactor (l2-ctx-bldg-types ctx)))
       (when live-game?
         (hash-set! open-prod-slots 'barracks (max 0 (sub1 (hash-ref open-prod-slots 'barracks 0)))))
       (l2-spend-resources-and-supply! ctx (sc2-min-cost 'barracks-reactor) (sc2-gas-cost 'barracks-reactor) 0))
  (define has-fac-techlab-any?
       (l2-building-present-or-pending? ctx 'factory-techlab #t))
  (define bare-fac-for-tl (l2-grounded-bare-facility ctx 'factory))
  (when (and (or (not terran-saving-for-expand?) terran-cannon-breakout-mode?)
                bare-fac-for-tl
                (or terran-cannon-breakout-mode?
                    (l2-starport-escrow-ok? ctx (sc2-min-cost 'factory-techlab) (sc2-gas-cost 'factory-techlab)))
                (or (not has-fac-techlab-any?) (>= (length factories-list) 2))
                (or (not live-game?) (> (hash-ref open-prod-slots 'factory 0) 0))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'factory-techlab))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'factory-techlab))
                (or terran-cannon-breakout-mode?
                    (and (l2-non-combat-min-ok? ctx (sc2-min-cost 'factory-techlab))
                         (l2-non-combat-gas-ok? ctx (sc2-gas-cost 'factory-techlab))))
                (facility-safe-for-addon? bare-fac-for-tl)
                (or (not live-game?)
                    (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                               (list 'terran-addon-emit (hash-ref bare-fac-for-tl 'id 305) 'factory-techlab)
                                               frame
                                               36)))
       (define ftx (safe-coord (+ (hash-ref bare-fac-for-tl 'x (+ base-x 6.0)) SC2-TERRAN-ADDON-OFFSET-X) (+ base-x 8.5)))
       (define fty (safe-coord (+ (hash-ref bare-fac-for-tl 'y (+ base-y 3.5)) SC2-TERRAN-ADDON-OFFSET-Y) (+ base-y 3.0)))
       (l2-recall-building-group! ctx 6)
       (l2-emit! ctx (list 'build 'factory-techlab ftx fty))
       (set-add! claimed-addon-fac-ids (hash-ref bare-fac-for-tl 'id 305))
       (order-ledger-record-issued! oledger (hash-ref bare-fac-for-tl 'id 305) 'build 'factory-techlab ftx fty frame)
       (set-l2-ctx-bldg-types! ctx (cons 'factory-techlab (l2-ctx-bldg-types ctx)))
       (set! has-fac-techlab-any? #t)
       (when live-game?
         (hash-set! open-prod-slots 'factory (max 0 (sub1 (hash-ref open-prod-slots 'factory 0)))))
       (l2-spend-resources-and-supply! ctx (sc2-min-cost 'factory-techlab) (sc2-gas-cost 'factory-techlab) 0))
  (define bare-fac-for-rx (l2-grounded-bare-facility ctx 'factory))
  (when (and (not terran-saving-for-expand?)
                bare-fac-for-rx
                has-fac-techlab-any?
                (l2-plan-wants-now? ctx 'factory-reactor)
                (not (l2-building-present-or-pending? ctx 'factory-reactor #t))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'factory-reactor))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'factory-reactor))
                (facility-safe-for-addon? bare-fac-for-rx)
                (or (not live-game?)
                    (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                               (list 'terran-addon-emit (hash-ref bare-fac-for-rx 'id 307) 'factory-reactor)
                                               frame
                                               36)))
       (define frx (safe-coord (+ (hash-ref bare-fac-for-rx 'x (+ base-x 6.0)) SC2-TERRAN-ADDON-OFFSET-X) (+ base-x 8.5)))
       (define fry (safe-coord (+ (hash-ref bare-fac-for-rx 'y (+ base-y 3.5)) SC2-TERRAN-ADDON-OFFSET-Y) (+ base-y 3.0)))
       (l2-recall-building-group! ctx 6)
       (l2-emit! ctx (list 'build 'factory-reactor frx fry))
       (set-add! claimed-addon-fac-ids (hash-ref bare-fac-for-rx 'id 307))
       (order-ledger-record-issued! oledger (hash-ref bare-fac-for-rx 'id 307) 'build 'factory-reactor frx fry frame)
       (set-l2-ctx-bldg-types! ctx (cons 'factory-reactor (l2-ctx-bldg-types ctx)))
       (l2-spend-resources-and-supply! ctx (sc2-min-cost 'factory-reactor) (sc2-gas-cost 'factory-reactor) 0))
  (define enemy-capital-air?
       (ormap (lambda (e)
                (memq (unit-type-sym e) THOR-CAPITAL-AIR-SYMS))
              enemy-units))
  (set-l2-ctx-enemy-capital-air?! ctx enemy-capital-air?)
  (when (and (or (not terran-saving-for-expand?) endgame-corner-hunt? enemy-capital-air?)
                (not (and crisis-tech-upgrade-deferral? (not enemy-capital-air?)))
                (or (not urgent-combat-or-intel-need?) endgame-corner-hunt? enemy-capital-air? (>= (l2-ctx-minerals ctx) 400))
                (memq 'factory ready-bldg-types))
       (when (and (not (l2-building-present-or-pending? ctx 'armory))
                  (l2-save-cancel-rebuild-ready? ctx 'armory 60)
                  (or enemy-capital-air?
                      (l2-starport-escrow-ok? ctx (sc2-min-cost 'armory) (sc2-gas-cost 'armory)))
                  (or (not live-game?)
                      enemy-capital-air?
                      (and (memq 'engineering-bay (l2-ctx-bldg-types ctx))
                           (>= live-army-supply 18)))
                  (or enemy-capital-air? (l2-plan-wants-now? ctx 'armory) (>= eff-phase-supply 52))
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'armory))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'armory)))
         (l2-emit-build-verified! ctx 'armory (safe-coord (- base-x 4.0)) (safe-coord (+ base-y 4.0))))
       ;; In SC2 LotV, Drilling Claws requires BOTH Factory TechLab AND Armory!
       (when (and (not crisis-tech-upgrade-deferral?)
                  (if live-game?
                      (and (memq 'factory-techlab ready-bldg-types)
                           (memq 'armory ready-bldg-types)
                           (>= (l2-unit-count ctx 'widow-mine) 2))
                      #t)
                  (l2-upgrade-needed? ctx 'drilling-claws))
         (l2-emit-research-verified! ctx 'drilling-claws)))
  (define need-emergency-ebay-or-turret?
       (or (enemy-tech-observation-requires-detection? tech-obs)
           (enemy-tech-observation-requires-anti-air? tech-obs)))
  (when (and (not terran-saving-for-expand?)
                (or (not urgent-combat-or-intel-need?)
                    need-emergency-ebay-or-turret?
                    (and (l2-non-combat-min-ok? ctx (sc2-min-cost 'engineering-bay) 'engineering-bay)
                         (>= (l2-ctx-minerals ctx) 250)))
                (or need-emergency-ebay-or-turret?
                    (l2-plan-wants-now? ctx 'engineering-bay)
                    (l2-plan-wants-now? ctx 'missile-turret)
                    (memq 'starport ready-bldg-types)
                    (and live-game?
                         (>= (length ccs) 2)
                         (memq 'factory ready-bldg-types)
                         (>= eff-phase-supply 40)))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'engineering-bay)))
       (when (and (not (l2-building-present-or-pending? ctx 'engineering-bay))
                  (l2-save-cancel-rebuild-ready? ctx 'engineering-bay 60)
                  (>= (- (l2-ctx-minerals ctx) (if need-emergency-ebay-or-turret? 0 terran-worker-min-floor))
                      (sc2-min-cost 'engineering-bay)))
         (l2-emit-build-verified! ctx 'engineering-bay (safe-coord (+ base-x 5.0)) (safe-coord (- base-y 4.0))))
       (define cur-turret-cnt
         (+ (count (lambda (t) (eq? t 'missile-turret)) (l2-ctx-bldg-types ctx))
            (order-ledger-pending-count-for-type oledger 'missile-turret frame)))
       (define desired-turrets
         (if (and live-game? need-emergency-ebay-or-turret?) 2 1))
       (when (and (or (not live-game?)
                      (and (memq 'engineering-bay ready-bldg-types)
                           (< cur-turret-cnt desired-turrets)
                           (or need-emergency-ebay-or-turret?
                               (l2-plan-wants-now? ctx 'missile-turret)
                               (>= eff-phase-supply 60))))
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'missile-turret))
                  (refractory-allow-action?! cd-tracker
                                             (list 'static-detector 'missile-turret)
                                             frame
                                             SC2-STATIC-DETECTOR-COOLDOWN-FRAMES))
         (define-values (tx ty)
           (if (and live-game? (> cur-turret-cnt 0) (>= (length ccs) 2))
               (l2-offset-defense-anchor ctx nat-x nat-y 4.5)
               (values (safe-coord (+ base-x 3.0)) (safe-coord (+ base-y 3.0)))))
         (if live-game?
             (l2-emit-build-verified! ctx 'missile-turret tx ty)
             (l2-emit! ctx (list 'build 'missile-turret tx ty)))))
  (define terran-air-fleet-count
       (+ (l2-unit-count ctx 'viking)
          (l2-unit-count ctx 'liberator)
          (l2-unit-count ctx 'battlecruiser)))
  (when (and (or (not terran-saving-for-expand?)
                    (and (>= (length ccs) 2) (>= terran-air-fleet-count 4)))
                (not crisis-tech-upgrade-deferral?)
                (memq 'armory ready-bldg-types)
                (or (>= terran-air-fleet-count 4)
                    (l2-plan-wants-now? ctx 'terran-ship-weapons-1)))
       (cond
         [(l2-upgrade-needed? ctx 'terran-ship-weapons-1)
          (l2-emit-research-verified! ctx 'terran-ship-weapons-1)]
         [(and (>= terran-air-fleet-count 6)
               (l2-upgrade-needed? ctx 'terran-ship-weapons-2))
          (l2-emit-research-verified! ctx 'terran-ship-weapons-2)]
         [(and (>= terran-air-fleet-count 8)
               (l2-upgrade-needed? ctx 'terran-ship-weapons-3))
          (l2-emit-research-verified! ctx 'terran-ship-weapons-3)]))
  (when (and (not terran-saving-for-expand?)
                (not crisis-tech-upgrade-deferral?)
                (or (not urgent-combat-or-intel-need?) (>= (l2-ctx-minerals ctx) 300)))
       (when (memq 'engineering-bay ready-bldg-types)
         (cond
           [(l2-upgrade-needed? ctx 'terran-infantry-weapons-1)
            (l2-emit-research-verified! ctx 'terran-infantry-weapons-1)]
           [(l2-upgrade-needed? ctx 'terran-infantry-armor-1)
            (l2-emit-research-verified! ctx 'terran-infantry-armor-1)]
           [(and (memq 'armory ready-bldg-types)
                 (l2-upgrade-needed? ctx 'terran-infantry-weapons-2))
            (l2-emit-research-verified! ctx 'terran-infantry-weapons-2)]
           [(and (memq 'armory ready-bldg-types)
                 (l2-upgrade-needed? ctx 'terran-infantry-armor-2))
            (l2-emit-research-verified! ctx 'terran-infantry-armor-2)]
           [(and (memq 'armory ready-bldg-types)
                 (l2-upgrade-needed? ctx 'terran-infantry-weapons-3))
            (l2-emit-research-verified! ctx 'terran-infantry-weapons-3)]
           [(and (memq 'armory ready-bldg-types)
                 (l2-upgrade-needed? ctx 'terran-infantry-armor-3))
            (l2-emit-research-verified! ctx 'terran-infantry-armor-3)]))
       (when (memq 'armory ready-bldg-types)
         (cond
           [(and (or (>= terran-air-fleet-count 4)
                     (l2-plan-wants-now? ctx 'terran-ship-weapons-1))
                 (l2-upgrade-needed? ctx 'terran-ship-weapons-1))
            (l2-emit-research-verified! ctx 'terran-ship-weapons-1)]
           [(l2-upgrade-needed? ctx 'terran-vehicle-weapons-1)
            (l2-emit-research-verified! ctx 'terran-vehicle-weapons-1)]
           [(l2-upgrade-needed? ctx 'terran-vehicle-and-ship-plating-1)
            (l2-emit-research-verified! ctx 'terran-vehicle-and-ship-plating-1)])))
  (define bare-sp-for-addon (l2-grounded-bare-facility ctx 'starport))
  (when (and (or (not terran-saving-for-expand?) endgame-corner-hunt?)
                (or (not urgent-combat-or-intel-need?) endgame-corner-hunt? (>= (l2-ctx-minerals ctx) 300))
                (memq 'starport ready-bldg-types))
       (define has-local-terran-detection?
         (or (memq 'orbital-command ready-bldg-types)
             (> (hash-ref total-bldg-counts 'missile-turret 0) 0)))
       (define want-starport-techlab-now?
         (or (not live-game?)
             (>= (l2-unit-count ctx 'banshee) 1)
             (>= (l2-unit-count ctx 'raven) 1)
             (l2-plan-wants-now? ctx 'raven)
             (l2-plan-wants-now? ctx 'banshee)
             (l2-plan-wants-now? ctx 'battlecruiser)
             (and endgame-corner-hunt? (>= (l2-unit-count ctx 'viking) 2) (= (l2-unit-count ctx 'raven) 0))
             (and (enemy-tech-observation-requires-detection? tech-obs)
                  (not has-local-terran-detection?))))
       (cond
         [(and bare-sp-for-addon
               live-game?
               (not want-starport-techlab-now?)
               (> (hash-ref open-prod-slots 'starport 0) 0)
               (or (l2-plan-wants-now? ctx 'starport-reactor)
                   (>= eff-phase-supply 34)
                   (>= (length ccs) 2))
               (not (l2-building-present-or-pending? ctx 'starport-reactor #t))
               (not (l2-building-present-or-pending? ctx 'starport-techlab #f))
               (>= (l2-ctx-minerals ctx) (sc2-min-cost 'starport-reactor))
               (>= (l2-ctx-gas ctx) (sc2-gas-cost 'starport-reactor))
               (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                          (list 'terran-addon-emit (hash-ref bare-sp-for-addon 'id 308) 'starport-reactor)
                                          frame
                                          36))
          (define sp-id (hash-ref bare-sp-for-addon 'id 308))
          (define srx (safe-coord (+ (hash-ref bare-sp-for-addon 'x (+ base-x 6.0)) SC2-TERRAN-ADDON-OFFSET-X) (+ base-x 8.5)))
          (define sry (safe-coord (+ (hash-ref bare-sp-for-addon 'y (+ base-y 7.0)) SC2-TERRAN-ADDON-OFFSET-Y) (+ base-y 6.5)))
          (l2-recall-building-group! ctx 6)
          (l2-emit! ctx (list 'build 'starport-reactor srx sry))
          (set-add! claimed-addon-fac-ids sp-id)
          (order-ledger-record-issued! oledger sp-id 'build 'starport-reactor srx sry frame)
          (set-l2-ctx-bldg-types! ctx (cons 'starport-reactor (l2-ctx-bldg-types ctx)))
          (hash-set! open-prod-slots 'starport (max 0 (sub1 (hash-ref open-prod-slots 'starport 0))))
          (l2-spend-resources-and-supply! ctx (sc2-min-cost 'starport-reactor) (sc2-gas-cost 'starport-reactor) 0)]
         [(and bare-sp-for-addon
               (or (not live-game?) (> (hash-ref open-prod-slots 'starport 0) 0))
               (or want-starport-techlab-now?
                   (and (>= (hash-ref total-bldg-counts 'starport-reactor 0) 1)
                        (l2-plan-wants-now? ctx 'starport-techlab)))
               (not (l2-building-present-or-pending? ctx 'starport-techlab #t))
               (not (and live-game?
                         (l2-building-present-or-pending? ctx 'starport-reactor #f)
                         (< (count (lambda (b) (eq? (unit-type-sym b) 'starport)) ally-bldgs) 2)))
               (>= (l2-ctx-minerals ctx) (sc2-min-cost 'starport-techlab))
               (>= (l2-ctx-gas ctx) (sc2-gas-cost 'starport-techlab))
               (or (not live-game?)
                   (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                              (list 'terran-addon-emit (hash-ref bare-sp-for-addon 'id 306) 'starport-techlab)
                                              frame
                                              36)))
          (define sp-id (hash-ref bare-sp-for-addon 'id 306))
          (define stx (safe-coord (+ (hash-ref bare-sp-for-addon 'x (+ base-x 6.0)) SC2-TERRAN-ADDON-OFFSET-X) (+ base-x 8.5)))
          (define sty (safe-coord (+ (hash-ref bare-sp-for-addon 'y (+ base-y 7.0)) SC2-TERRAN-ADDON-OFFSET-Y) (+ base-y 6.5)))
          (l2-recall-building-group! ctx 6)
          (l2-emit! ctx (list 'build 'starport-techlab stx sty))
          (set-add! claimed-addon-fac-ids sp-id)
          (order-ledger-record-issued! oledger sp-id 'build 'starport-techlab stx sty frame)
          (set-l2-ctx-bldg-types! ctx (cons 'starport-techlab (l2-ctx-bldg-types ctx)))
          (hash-set! open-prod-slots 'starport (max 0 (sub1 (hash-ref open-prod-slots 'starport 0))))
          (l2-spend-resources-and-supply! ctx (sc2-min-cost 'starport-techlab) (sc2-gas-cost 'starport-techlab) 0)]
         [(and bare-sp-for-addon
               live-game?
               (> (hash-ref open-prod-slots 'starport 0) 0)
               (or (l2-plan-wants-now? ctx 'starport-reactor)
                   (>= eff-phase-supply 34)
                   (and (>= (length ccs) 2) (>= eff-phase-supply 52)))
               (not (l2-building-present-or-pending? ctx 'starport-reactor #t))
               (not (l2-building-present-or-pending? ctx 'starport-techlab #f))
               (>= (l2-ctx-minerals ctx) (sc2-min-cost 'starport-reactor))
               (>= (l2-ctx-gas ctx) (sc2-gas-cost 'starport-reactor))
               (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                          (list 'terran-addon-emit (hash-ref bare-sp-for-addon 'id 308) 'starport-reactor)
                                          frame
                                          36))
          (define sp-id (hash-ref bare-sp-for-addon 'id 308))
          (define srx (safe-coord (+ (hash-ref bare-sp-for-addon 'x (+ base-x 6.0)) SC2-TERRAN-ADDON-OFFSET-X) (+ base-x 8.5)))
          (define sry (safe-coord (+ (hash-ref bare-sp-for-addon 'y (+ base-y 7.0)) SC2-TERRAN-ADDON-OFFSET-Y) (+ base-y 6.5)))
          (l2-recall-building-group! ctx 6)
          (l2-emit! ctx (list 'build 'starport-reactor srx sry))
          (set-add! claimed-addon-fac-ids sp-id)
          (order-ledger-record-issued! oledger sp-id 'build 'starport-reactor srx sry frame)
          (set-l2-ctx-bldg-types! ctx (cons 'starport-reactor (l2-ctx-bldg-types ctx)))
          (hash-set! open-prod-slots 'starport (max 0 (sub1 (hash-ref open-prod-slots 'starport 0))))
          (l2-spend-resources-and-supply! ctx (sc2-min-cost 'starport-reactor) (sc2-gas-cost 'starport-reactor) 0)])
       (when (and (not crisis-tech-upgrade-deferral?)
                  (memq 'starport-techlab ready-bldg-types)
                  (or (not live-game?)
                      (and (>= (l2-unit-count ctx 'banshee) 1)
                           (l2-can-spend-by-priority? ctx 'banshee-cloak 'tech-upgrade)))
                  (l2-upgrade-needed? ctx 'banshee-cloak))
         (l2-emit-research-verified! ctx 'banshee-cloak))
       (when (and (not crisis-tech-upgrade-deferral?)
                  (not (l2-building-present-or-pending? ctx 'ghost-academy))
                  (l2-save-cancel-rebuild-ready? ctx 'ghost-academy 60)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'ghost-academy)
                      (and (>= (length ccs) 3) (>= live-army-supply 34) (>= eff-phase-supply 92)))
                  (>= eff-phase-supply 56)
                  (>= (l2-ctx-minerals ctx) (sc2-min-cost 'ghost-academy))
                  (>= (l2-ctx-gas ctx) (sc2-gas-cost 'ghost-academy)))
         (l2-emit-build-verified! ctx 'ghost-academy (safe-coord (- base-x 4.0)) (safe-coord (- base-y 4.0))))
       (when (and (not crisis-tech-upgrade-deferral?)
                  (memq 'ghost-academy ready-bldg-types)
                  (or (not live-game?)
                      (l2-plan-wants-now? ctx 'personal-cloaking)
                      (>= (l2-unit-count ctx 'ghost) 1))
                  (l2-upgrade-needed? ctx 'personal-cloaking))
         (l2-emit-research-verified! ctx 'personal-cloaking)))
  (when (and (memq 'starport ready-bldg-types)
                (not crisis-tech-upgrade-deferral?)
                (not early-survival-crisis?)
                (not terran-saving-for-expand?)
                (not (l2-building-present-or-pending? ctx 'fusion-core))
                (l2-save-cancel-rebuild-ready? ctx 'fusion-core 60)
                (or (l2-plan-wants-now? ctx 'fusion-core)
                    (and live-game? (>= (length ccs) 3) (>= eff-phase-supply 118) (>= (l2-ctx-gas ctx) 250)))
                (or (not live-game?) (l2-can-spend-by-priority? ctx 'fusion-core 'tech-bldg) (>= (l2-ctx-minerals ctx) 350))
                (>= (l2-ctx-minerals ctx) (sc2-min-cost 'fusion-core))
                (>= (l2-ctx-gas ctx) (sc2-gas-cost 'fusion-core)))
       (l2-emit-build-verified! ctx 'fusion-core (safe-coord (- base-x 5.0)) (safe-coord (+ base-y 5.0)))))

(define (l2-terran-phase3-units-depots! ctx)
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-combat-units (l2-ctx-ally-combat-units ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bo-goal-sym (l2-ctx-bo-goal-sym ctx))
  (define ccs (l2-ctx-ccs ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define crisis-freeze-workers? (l2-ctx-crisis-freeze-workers? ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define eff-phase-supply (l2-ctx-eff-phase-supply ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define endgame-corner-hunt? (l2-ctx-endgame-corner-hunt? ctx))
  (define enemy-capital-air? (l2-ctx-enemy-capital-air? ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define frame (l2-ctx-frame ctx))
  (define live-army-supply (l2-ctx-live-army-supply ctx))
  (define live-enemy-threat-supply (l2-ctx-live-enemy-threat-supply ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define oledger (l2-ctx-oledger ctx))
  (define open-prod-slots (l2-ctx-open-prod-slots ctx))
  (define pressure-metrics (l2-ctx-pressure-metrics ctx))
  (define prio-scheduled-actions (l2-ctx-prio-scheduled-actions ctx))
  (define race (l2-ctx-race ctx))
  (define raw-obs (l2-ctx-raw-obs ctx))
  (define ready-bldg-types (l2-ctx-ready-bldg-types ctx))
  (define rt (l2-ctx-rt ctx))
  (define target-workers (l2-ctx-target-workers ctx))
  (define tech-obs (l2-ctx-tech-obs ctx))
  (define terran-cannon-breakout-mode? (l2-ctx-terran-cannon-breakout-mode? ctx))
  (define terran-ideal-worker-cap (l2-ctx-terran-ideal-worker-cap ctx))
  (define terran-ramp-wall (l2-ctx-terran-ramp-wall ctx))
  (define terran-saving-for-expand? (l2-ctx-terran-saving-for-expand? ctx))
  (define terran-saving-for-orbital? (l2-ctx-terran-saving-for-orbital? ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define under-early-cheese? (l2-ctx-under-early-cheese? ctx))
  (define urgent-combat-or-intel-need? (l2-ctx-urgent-combat-or-intel-need? ctx))
  (define worker-rush-active? (l2-ctx-worker-rush-active? ctx))
  (when (and (memq 'fusion-core ready-bldg-types)
                (not crisis-tech-upgrade-deferral?)
                (not urgent-combat-or-intel-need?))
       (cond
         [(and (>= (l2-unit-count ctx 'battlecruiser) 1)
               (l2-upgrade-needed? ctx 'weapon-refit))
          (l2-emit-research-verified! ctx 'weapon-refit)]
         [(and (>= (l2-unit-count ctx 'liberator) 2)
               (l2-upgrade-needed? ctx 'advanced-ballistics))
          (l2-emit-research-verified! ctx 'advanced-ballistics)]))
  (define has-fac-tl?
       (or (memq 'factory-techlab ready-bldg-types)
           (ormap (lambda (b)
                    (and (hash? b)
                         (eq? (fast-canonical-structure-sym (unit-type-sym b)) 'factory)
                         (>= (hash-ref b 'build-progress 1.0) 1.0)
                         (or (memq (hash-ref b 'addon #f) '(techlab factory-techlab))
                             (memq (hash-ref b 'addon-type #f) '(techlab factory-techlab))
                             (let* ([atag (hash-ref b 'add-on-tag 0)]
                                    [addon-rec (and (> atag 0)
                                                    (findf (lambda (ab)
                                                             (and (hash? ab)
                                                                  (= (hash-ref ab 'id -1) atag)))
                                                           ally-bldgs))])
                               (and (> atag 0)
                                    (if addon-rec
                                        (and (>= (hash-ref addon-rec 'build-progress 1.0) 1.0)
                                             (memq (unit-type-sym addon-rec) '(factory-techlab techlab)))
                                        #t))))))
                  ally-bldgs)
           (not (hash-has-key? raw-obs 'mineral-harvesters))))
  (define terran-scv-priority?
       (and (or (not terran-saving-for-expand?)
                (and (not terran-saving-for-orbital?) (< total-workers 19) (< (l2-ctx-minerals ctx) 350)))
            (not crisis-freeze-workers?)
            (l2-worker-army-curve-satisfied? ctx)
            (not terran-saving-for-orbital?)
            (not urgent-combat-or-intel-need?)
            (or (< total-workers terran-ideal-worker-cap)
                (l2-can-spend-by-priority? ctx 'scv 'worker))
            (< total-workers (min 70 (max target-workers terran-ideal-worker-cap)))
            (or (not live-game?)
                (and (not under-base-attack?) (<= live-enemy-threat-supply 0))
                (< total-workers 20)
                (not (memq 'barracks ready-bldg-types))
                (>= (length ally-combat-units) 3)
                (>= live-army-supply (* 6 (max 1 (length ccs)))))
            (>= (l2-ctx-minerals ctx) (sc2-min-cost 'scv))
            (l2-can-spend-supply? ctx (sc2-supply-cost 'scv))
            (not under-early-cheese?)
            (< (hash-ref pressure-metrics 'threat-pressure 0.0) 0.85)))
  (when terran-scv-priority?
       (l2-try-train-unit! ctx 'scv 'townhall 4
                        #:respect-bo-reserve?
                        (and live-game?
                             (or (>= total-workers 24)
                                 (>= total-workers terran-ideal-worker-cap)
                                 (and (>= total-workers 16)
                                      (> (l2-ctx-bo-reserved-gas ctx) 0)
                                      (>= (l2-ctx-gas ctx) (l2-ctx-bo-reserved-gas ctx))))
                             (or (<= (l2-ctx-bo-reserved-gas ctx) 0)
                                 (>= (l2-ctx-gas ctx) (- (l2-ctx-bo-reserved-gas ctx) 25)))
                             (not (memq bo-goal-sym '(hatchery nexus command-center drone probe scv))))))
  (when (and (or (not terran-saving-for-expand?)
                    crisis-tech-upgrade-deferral?
                    enemy-capital-air?
                    (and endgame-corner-hunt? (< (l2-unit-count ctx 'viking) 2)))
                (or crisis-tech-upgrade-deferral?
                    (not terran-saving-for-orbital?)
                    (>= (- (l2-ctx-minerals ctx) (sc2-min-cost 'marine)) (sc2-min-cost 'orbital-command)))
                (l2-can-spend-supply? ctx (sc2-supply-cost 'marine)))
       ;; Priority corner-hunter air-to-air: ensure >= 2 Vikings before Medivacs/tanks consume Starport/gas!
       (when (and endgame-corner-hunt?
                  (memq 'starport ready-bldg-types)
                  (< (l2-unit-count ctx 'viking) 2))
         (l2-try-train-unit! ctx 'viking 'starport 6 #:respect-bo-reserve? #f))
       ;; Priority vs-Air Vikings: ensure >= 2 Vikings BEFORE Medivacs/tanks consume gas!
       (when (and live-game?
                  (not endgame-corner-hunt?)
                  (or (not terran-saving-for-expand?) crisis-tech-upgrade-deferral?)
                  (memq 'starport ready-bldg-types)
                  (enemy-tech-observation-requires-anti-air? tech-obs)
                  (< (l2-unit-count ctx 'viking) 2))
         (l2-try-train-unit! ctx 'viking 'starport 6 #:respect-bo-reserve? #f))
       ;; Priority bio sustain (#5122349): ensure first 2 Medivacs before Factory drains 125G/tank
       ;; (vs air, co-produce Medivacs once >= 2 Vikings are active)!
       (when (and live-game?
                  (not crisis-tech-upgrade-deferral?)
                  (not terran-saving-for-expand?)
                  (memq 'starport ready-bldg-types)
                  (or (not (enemy-tech-observation-requires-anti-air? tech-obs))
                      (>= (l2-unit-count ctx 'viking) 2))
                  (>= (+ (l2-unit-count ctx 'marine) (l2-unit-count ctx 'marauder)) 6)
                  (< (l2-unit-count ctx 'medivac) 2)
                  (l2-can-spend-supply? ctx (sc2-supply-cost 'medivac)))
         (l2-try-train-unit! ctx 'medivac 'starport 6 #:respect-bo-reserve? #f))
       ;; Factory production first (Group 6): Siege Tank / Thor on Factory-TechLab
       (when (and (or (not terran-saving-for-expand?)
                      terran-cannon-breakout-mode?
                      crisis-tech-upgrade-deferral?
                      enemy-capital-air?)
                  (memq 'factory ready-bldg-types))
         (when (and has-fac-tl?
                    (memq 'armory ready-bldg-types)
                    (or enemy-capital-air?
                        (l2-starport-escrow-ok? ctx (sc2-min-cost 'thor) (sc2-gas-cost 'thor)))
                    (or (l2-plan-wants-now? ctx 'thor)
                        (and enemy-capital-air?
                             (< (l2-unit-count ctx 'thor) 5)
                             (>= (l2-ctx-minerals ctx) (sc2-min-cost 'thor))
                             (>= (l2-ctx-gas ctx) (sc2-gas-cost 'thor)))
                        (and (or (enemy-tech-observation-requires-anti-air? tech-obs)
                                 (and (not crisis-tech-upgrade-deferral?)
                                      (>= (l2-unit-count ctx 'siege-tank) 4)))
                             (< (l2-unit-count ctx 'thor) 4)
                             (>= (l2-ctx-minerals ctx) (sc2-min-cost 'thor))
                             (>= (l2-ctx-gas ctx) (sc2-gas-cost 'thor))))
                    (or enemy-capital-air?
                        (l2-can-spend-by-priority? ctx 'thor 'combat-unit)))
           (l2-try-train-unit! ctx 'thor 'factory 6 #:respect-bo-reserve? (not enemy-capital-air?)))
         (if has-fac-tl?
             (when (or terran-cannon-breakout-mode?
                       crisis-tech-upgrade-deferral?
                       (l2-starport-escrow-ok? ctx (sc2-min-cost 'siege-tank) (sc2-gas-cost 'siege-tank)))
               (l2-try-train-unit! ctx 'siege-tank 'factory 6 #:respect-bo-reserve? #f))
             (when (or crisis-tech-upgrade-deferral?
                       (l2-starport-escrow-ok? ctx (sc2-min-cost 'widow-mine) (sc2-gas-cost 'widow-mine)))
               (l2-try-train-unit! ctx 'widow-mine 'factory 6)))
         (when (and (or crisis-tech-upgrade-deferral?
                        (l2-starport-escrow-ok? ctx (sc2-min-cost 'hellion) (sc2-gas-cost 'hellion)))
                    (if live-game?
                        (and (or (not has-fac-tl?) (and (>= (l2-ctx-minerals ctx) 400) (< (l2-ctx-gas ctx) 50)))
                             (< (l2-unit-count ctx 'hellion) 4))
                        (or (< (l2-ctx-gas ctx) (sc2-gas-cost 'siege-tank)) (>= (l2-ctx-minerals ctx) 250))))
           (l2-try-train-unit! ctx 'hellion 'factory 6)))
       ;; Starport production (Group 6): Battlecruiser -> Raven -> 2 Vikings (AA) -> Medivac (1-2 AA / 4 normal) -> up to 8-10 Vikings (AA) -> Liberator
       (when (and (not terran-saving-for-expand?)
                  (memq 'starport ready-bldg-types))
         (when (and (memq 'fusion-core ready-bldg-types)
                    (memq 'starport-techlab ready-bldg-types)
                    (< (l2-unit-count ctx 'battlecruiser) 4)
                    (or (l2-plan-wants-now? ctx 'battlecruiser)
                        (and (>= (l2-ctx-minerals ctx) 450) (>= (l2-ctx-gas ctx) 350)))
                    (l2-can-spend-supply? ctx (sc2-supply-cost 'battlecruiser)))
           (l2-try-train-unit! ctx 'battlecruiser 'starport 6 #:respect-bo-reserve? #t))
         (when (and (memq 'starport-techlab ready-bldg-types)
                    (< (l2-unit-count ctx 'raven)
                       (if (enemy-tech-observation-requires-detection? tech-obs) 2 1))
                    (or (enemy-tech-observation-requires-detection? tech-obs)
                        endgame-corner-hunt?
                        (l2-plan-wants-now? ctx 'raven)
                        (and live-game? (>= live-army-supply 30))))
           (l2-try-train-unit! ctx 'raven 'starport 6))
         (when (and live-game?
                    (enemy-tech-observation-requires-anti-air? tech-obs)
                    (< (l2-unit-count ctx 'viking) 2))
           (l2-try-train-unit! ctx 'viking 'starport 6 #:respect-bo-reserve? #f))
         (define desired-medivac-cap
           (cond
             [(enemy-tech-observation-requires-anti-air? tech-obs)
              (if (>= (l2-unit-count ctx 'viking) 8) 4 2)]
             [(or (>= (length ccs) 4) (>= eff-phase-supply 130)) 6]
             [else 4]))
         (when (and (or (not live-game?)
                        (not (enemy-tech-observation-requires-anti-air? tech-obs))
                        (>= (l2-unit-count ctx 'viking) 2))
                    (or (not live-game?)
                        (and (< (l2-unit-count ctx 'medivac) desired-medivac-cap)
                             (or (< (l2-unit-count ctx 'medivac)
                                    (if (enemy-tech-observation-requires-anti-air? tech-obs) 2 4))
                                 (l2-can-spend-by-priority? ctx 'medivac 'combat-unit)))))
           (l2-try-train-unit! ctx 'medivac 'starport 6 #:respect-bo-reserve? #t))
         (when (and live-game?
                    (enemy-tech-observation-requires-anti-air? tech-obs)
                    (< (l2-unit-count ctx 'viking) 8))
           (l2-try-train-unit! ctx 'viking 'starport 6 #:respect-bo-reserve? #f))
         (define enemy-ground-siege-for-lib?
           (ormap (lambda (e)
                    (memq (unit-type-sym e)
                          '(siege-tank siege-tank-sieged lurker lurker-burrowed ultralisk)))
                  enemy-units))
         (define desired-liberator-cap
           (cond
             [(>= (length ccs) 4) 8]
             [enemy-ground-siege-for-lib? 6]
             [else 4]))
         (when (or (not live-game?)
                   (and (enemy-tech-observation-requires-anti-air? tech-obs)
                        (< (l2-unit-count ctx 'viking) 10))
                   (and endgame-corner-hunt?
                        (< (l2-unit-count ctx 'viking) 10))
                   (and (< (l2-unit-count ctx 'viking) 10)
                        (>= (l2-unit-count ctx 'medivac) 2)
                        (or (l2-plan-wants-now? ctx 'viking)
                            (>= (l2-unit-count ctx 'liberator) desired-liberator-cap))
                        (l2-can-spend-by-priority? ctx 'viking 'combat-unit)))
           (l2-try-train-unit! ctx 'viking 'starport 6 #:respect-bo-reserve? #t))
         (when (and (< (l2-unit-count ctx 'liberator) desired-liberator-cap)
                    (or (l2-plan-wants-now? ctx 'liberator)
                        (and live-game?
                             (>= eff-phase-supply 80)
                             (>= (l2-unit-count ctx 'medivac) (if enemy-ground-siege-for-lib? 1 2))))
                    (l2-can-spend-by-priority? ctx 'liberator 'combat-unit))
           (l2-try-train-unit! ctx 'liberator 'starport 6 #:respect-bo-reserve? #t)))
       ;; Barracks production (Group 5)
       (when (memq 'barracks ready-bldg-types)
         (define has-rax-tl-ready?
           (or (memq 'barracks-techlab ready-bldg-types)
               (not (hash-has-key? raw-obs 'mineral-harvesters))))
         (define rax-tl-open-now (hash-ref open-prod-slots 'barracks-techlab-open 0))
         (define rax-basic-open-now (hash-ref open-prod-slots 'barracks-basic-open 0))
         (define tvp-or-armored-marauder?
           (and live-game?
                (or (memq effective-enemy-race '(Protoss Terran))
                    (ormap (lambda (e)
                             (memq (unit-type-sym e)
                                   '(stalker immortal colossus marauder roach ravager
                                     siege-tank siege-tank-sieged thor ultralisk)))
                           enemy-units))))
         (define desired-marauder-target
           (max 4 (quotient (* 2 (max 3 (l2-unit-count ctx 'marine))) 3)))
         (when (and live-game?
                    (< frame 2600)
                    (= (l2-unit-count ctx 'reaper) 0)
                    (= (length ally-combat-units) 0)
                    (>= (l2-ctx-gas ctx) (sc2-gas-cost 'reaper))
                    (not under-base-attack?)
                    (not under-early-cheese?))
           (when (l2-try-train-unit! ctx 'reaper 'barracks 5)
             (when (> rax-basic-open-now 0)
               (set! rax-basic-open-now (sub1 rax-basic-open-now)))))
         (define enemy-high-value-ghost-tgts?
           (ormap (lambda (e)
                    (memq (unit-type-sym e)
                          '(infestor infestor-burrowed viper ultralisk lurker lurker-burrowed
                            high-templar archon)))
                  enemy-units))
         (define desired-ghost-cap
           (if enemy-high-value-ghost-tgts? 10 6))
         (when (and has-rax-tl-ready?
                    (not crisis-tech-upgrade-deferral?)
                    (memq 'ghost-academy ready-bldg-types)
                    (< (l2-unit-count ctx 'ghost) desired-ghost-cap)
                    (>= (l2-ctx-gas ctx) (sc2-gas-cost 'ghost))
                    (or (l2-plan-wants-now? ctx 'ghost)
                        (memq effective-enemy-race '(Protoss Zerg))))
           (when (l2-try-train-unit! ctx 'ghost 'barracks 5 #:respect-bo-reserve? #t)
             (when (> rax-tl-open-now 0)
               (set! rax-tl-open-now (max 0 (sub1 rax-tl-open-now)))
               (hash-set! open-prod-slots 'barracks-techlab-open rax-tl-open-now))))
         (when (and has-rax-tl-ready?
                    (or urgent-combat-or-intel-need?
                        crisis-tech-upgrade-deferral?
                        (and tvp-or-armored-marauder? (< (l2-unit-count ctx 'marauder) (max 6 desired-marauder-target)))
                        (l2-starport-escrow-ok? ctx (sc2-min-cost 'marauder) (sc2-gas-cost 'marauder)))
                    (or crisis-tech-upgrade-deferral?
                        (l2-can-spend-by-priority? ctx 'marauder 'combat-unit)))
           (define pre-slots (hash-ref open-prod-slots 'barracks 0))
           (when (and live-game? (> rax-tl-open-now 0) (< rax-tl-open-now pre-slots))
             (hash-set! open-prod-slots 'barracks rax-tl-open-now))
           (define trained-mar?
             (l2-try-train-unit! ctx 'marauder 'barracks 5
                              #:respect-bo-reserve? (and (not tvp-or-armored-marauder?)
                                                         (not crisis-tech-upgrade-deferral?))))
           (define post-slots (hash-ref open-prod-slots 'barracks 0))
           (define consumed (max 0 (- (if (and live-game? (> rax-tl-open-now 0) (< rax-tl-open-now pre-slots))
                                          rax-tl-open-now
                                          pre-slots)
                                      post-slots)))
           (when (and live-game? (> rax-tl-open-now 0) (< rax-tl-open-now pre-slots))
             (hash-set! open-prod-slots 'barracks (max 0 (- pre-slots consumed))))
           (when trained-mar?
             (set! rax-tl-open-now (max 0 (- rax-tl-open-now consumed)))
             (hash-set! open-prod-slots 'barracks-techlab-open rax-tl-open-now)))
         ;; Reserve open TechLab Barracks slots from Marine training when Marauders are wanted & gas >= 15
         ;; so 50M Marines do not starve 100M/25G Marauders (`#5124059`), targeting ~35-40% Bio ratio (`#89` [UNCOVERED-T1]).
         (define reserve-tl-for-marauder?
           (and live-game?
                has-rax-tl-ready?
                (> rax-tl-open-now 0)
                (>= (l2-ctx-gas ctx) 15)
                (or (and tvp-or-armored-marauder?
                         (< (l2-unit-count ctx 'marauder) desired-marauder-target))
                    (< (l2-unit-count ctx 'marauder) (max 2 (quotient (l2-unit-count ctx 'marine) 3))))
                (not (and under-early-cheese? (= (length ally-combat-units) 0) (< (l2-ctx-minerals ctx) 95)))))
         (when (and (or urgent-combat-or-intel-need?
                        crisis-tech-upgrade-deferral?
                        (< (+ (l2-unit-count ctx 'marine) (l2-unit-count ctx 'marauder)) 4)
                        (l2-starport-escrow-ok? ctx (sc2-min-cost 'marine) 0))
                    (or (not reserve-tl-for-marauder?) (> rax-basic-open-now 0))
                    (or crisis-tech-upgrade-deferral?
                        (l2-can-spend-by-priority? ctx 'marine 'combat-unit)))
           (define full-rax-slots (hash-ref open-prod-slots 'barracks 0))
           (when reserve-tl-for-marauder?
             (hash-set! open-prod-slots 'barracks rax-basic-open-now))
           (l2-try-train-unit! ctx 'marine 'barracks 5 #:respect-bo-reserve? (not crisis-tech-upgrade-deferral?))
           (when reserve-tl-for-marauder?
             (define used-basic (max 0 (- rax-basic-open-now (hash-ref open-prod-slots 'barracks 0))))
             (hash-set! open-prod-slots 'barracks (max 0 (- full-rax-slots used-basic)))))))
  (when (and (not terran-scv-priority?)
                (not crisis-freeze-workers?)
                (l2-worker-army-curve-satisfied? ctx)
                (not terran-saving-for-expand?)
                (not terran-saving-for-orbital?)
                (l2-can-spend-by-priority? ctx 'scv 'worker)
                (< total-workers
                   (if live-game?
                       (min 70 (max target-workers terran-ideal-worker-cap))
                       target-workers))
                (or (member '(train scv) prio-scheduled-actions)
                    worker-rush-active?
                    (< total-workers 14)
                    (< (hash-ref pressure-metrics 'threat-pressure 0.0) 1.0)))
       (l2-try-train-unit! ctx 'scv 'townhall 4
                        #:respect-bo-reserve? (and live-game? (>= total-workers 24))))
  (define depot-bldgs
       (if (or (eq? race 'Terran)
               (memq 'supply-depot (l2-ctx-bldg-types ctx))
               (memq 'supply-depot-lowered (l2-ctx-bldg-types ctx)))
           (for/list ([b (in-list ally-bldgs)]
                      #:when (memq (unit-type-sym b) '(supply-depot supply-depot-lowered)))
             b)
           '()))
  (when (not (null? depot-bldgs))
       (define door-st (rt-door-state rt))
       (define stuck-tbl (hash-ref! door-st 'terran-stuck-counts (lambda () (make-hasheqv))))
       (define wall-dep1 (and (hash? terran-ramp-wall) (hash-ref terran-ramp-wall 'depot-1 #f)))
       (define wall-dep2 (and (hash? terran-ramp-wall) (hash-ref terran-ramp-wall 'depot-2 #f)))
       (define has-wall-coords? (or (pair? wall-dep1) (pair? wall-dep2)))
       (define front-depots
         (if (not has-wall-coords?)
             depot-bldgs
             (let ([wd (for/list ([d (in-list depot-bldgs)]
                                  #:when (let ([dx (hash-ref d 'x base-x)]
                                               [dy (hash-ref d 'y base-y)])
                                           (or (and (pair? wall-dep1) (<= (fast-dist2d dx dy (car wall-dep1) (cdr wall-dep1)) 6.0))
                                               (and (pair? wall-dep2) (<= (fast-dist2d dx dy (car wall-dep2) (cdr wall-dep2)) 6.0)))))
                         d)])
               (if (null? wd) depot-bldgs wd))))
       (define-values (raised-depots lowered-depots)
         (for/fold ([r-rev '()] [l-rev '()]
                    #:result (values (reverse r-rev) (reverse l-rev)))
                   ([d (in-list front-depots)])
           (if (eq? (unit-type-sym d) 'supply-depot)
               (values (cons d r-rev) l-rev)
               (values r-rev (cons d l-rev)))))
       (define ground-enemy-pts-cache #f)
       (define (get-ground-enemy-pts)
         (unless ground-enemy-pts-cache
           (set! ground-enemy-pts-cache
                 (for/list ([e (in-list enemy-units)]
                            #:when (let ([et (unit-type-sym e)])
                                     (and (not (or (eq? (hash-ref e 'is-flying #f) #t)
                                                   (eq? (hash-ref e 'flying? #f) #t)))
                                          (not (hash-ref NON-COMBAT-AND-SCOUT-ENEMY-HT et #f)))))
                   (define et (unit-type-sym e))
                   (define ex (hash-ref e 'x 9999.0))
                   (define ey (hash-ref e 'y 9999.0))
                   (define fast? (not (not (memq et '(zergling baneling reaper adept hellion hellbat cyclone)))))
                   (vector (if (real? ex) (exact->inexact ex) 9999.0)
                           (if (real? ey) (exact->inexact ey) 9999.0)
                           (if fast? 256.0 196.0)
                           (if fast? 289.0 225.0)))))
         ground-enemy-pts-cache)
       (define raised-enemy-near-ht (pooled-hasheq! (rt-l2-scratch rt) 'door-raised-enemy-near))
       (define (raised-depot-enemy-near? d dx dy)
         (define cached (hash-ref raised-enemy-near-ht d 'miss))
         (if (eq? cached 'miss)
             (let ([res
                    (for/or ([ep (in-list (get-ground-enemy-pts))])
                      (define ddx (fl- dx (vector-ref ep 0)))
                      (define ddy (fl- dy (vector-ref ep 1)))
                      (fl<= (fl+ (fl* ddx ddx) (fl* ddy ddy)) (vector-ref ep 3)))])
               (hash-set! raised-enemy-near-ht d res)
               res)
             cached))
       (define base-x-fl (exact->inexact base-x))
       (define base-y-fl (exact->inexact base-y))
       (define nat-x-fl (exact->inexact nat-x))
       (define nat-y-fl (exact->inexact nat-y))
       (define front-depot-xs (for/list ([fd (in-list front-depots)]) (exact->inexact (hash-ref fd 'x base-x))))
       (define front-depot-ys (for/list ([fd (in-list front-depots)]) (exact->inexact (hash-ref fd 'y base-y))))
       (define raised-depot-xs (for/list ([rd (in-list raised-depots)]) (exact->inexact (hash-ref rd 'x base-x))))
       (define raised-depot-ys (for/list ([rd (in-list raised-depots)]) (exact->inexact (hash-ref rd 'y base-y))))
       (define has-front? (pair? front-depots))
       (define has-raised? (pair? raised-depots))
       (define active-stuck-tags (pooled-mutable-seteqv! (rt-l2-scratch rt) 'door-active-stuck-tags))
       (define seen-transiting-ht (pooled-hasheqv! (rt-l2-scratch rt) 'door-seen-transiting))
       (define transiting-tags-rev '())
       (when (or has-front? has-raised?)
         (for ([u (in-list ally-units)])
           (define uid (hash-ref u 'id #f))
           (when (and (exact-integer? uid)
                      (> uid 0)
                      (not (eq? (hash-ref u 'is-flying #f) #t))
                      (not (eq? (hash-ref u 'flying? #f) #t)))
             (define ux-raw (hash-ref u 'x base-x))
             (define uy-raw (hash-ref u 'y base-y))
             (define ux (if (flonum? ux-raw) ux-raw (exact->inexact ux-raw)))
             (define uy (if (flonum? uy-raw) uy-raw (exact->inexact uy-raw)))
             (when (and has-front?
                        (not (hash-ref seen-transiting-ht uid #f))
                        (for/or ([fx (in-list front-depot-xs)]
                                 [fy (in-list front-depot-ys)])
                          (define ddx (fl- ux fx))
                          (define ddy (fl- uy fy))
                          (fl<= (fl+ (fl* ddx ddx) (fl* ddy ddy)) 17.64)))
               (hash-set! seen-transiting-ht uid #t)
               (set! transiting-tags-rev (cons uid transiting-tags-rev)))
             (when (and has-raised?
                        (not (= (hash-ref u 'order-ability-id 0) 18)))
               (define near-raised #f)
               (define near-dx 0.0)
               (define near-dy 0.0)
               (for ([rd (in-list raised-depots)]
                     [dx (in-list raised-depot-xs)]
                     [dy (in-list raised-depot-ys)]
                     #:break near-raised)
                 (define ddx (fl- ux dx))
                 (define ddy (fl- uy dy))
                 (when (fl<= (fl+ (fl* ddx ddx) (fl* ddy ddy)) 12.25)
                   (set! near-raised rd)
                   (set! near-dx dx)
                   (set! near-dy dy)))
               (when near-raised
               (unless (raised-depot-enemy-near? near-raised near-dx near-dy)
                 (set-add! active-stuck-tags uid)
                 (define cnt (add1 (hash-ref stuck-tbl uid 0)))
                 (hash-set! stuck-tbl uid cnt)
                 (when (>= cnt 2)
                   (define on-base-side?
                     (let ([udx (fl- ux base-x-fl)]
                           [udy (fl- uy base-y-fl)]
                           [ddx (fl- near-dx base-x-fl)]
                           [ddy (fl- near-dy base-y-fl)])
                       (fl<= (fl+ (fl* udx udx) (fl* udy udy))
                             (fl+ (fl* ddx ddx) (fl* ddy ddy)))))
                   (define-values (tx ty)
                     (if on-base-side?
                         (let* ([vx (fl- nat-x-fl near-dx)]
                                [vy (fl- nat-y-fl near-dy)]
                                [vn (flmax 1.0 (flsqrt (fl+ (fl* vx vx) (fl* vy vy))))])
                           (values (safe-coord (fl+ near-dx (fl* 4.5 (fl/ vx vn))) nat-x)
                                   (safe-coord (fl+ near-dy (fl* 4.5 (fl/ vy vn))) nat-y)))
                         (let* ([vx (fl- base-x-fl near-dx)]
                                [vy (fl- base-y-fl near-dy)]
                                [vn (flmax 1.0 (flsqrt (fl+ (fl* vx vx) (fl* vy vy))))])
                           (values (safe-coord (fl+ near-dx (fl* 4.5 (fl/ vx vn))) base-x)
                                   (safe-coord (fl+ near-dy (fl* 4.5 (fl/ vy vn))) base-y)))))
                   (l2-emit! ctx (list 'move uid tx ty))
                   (order-ledger-record-issued! oledger uid 'move 'depot-unstick tx ty frame))))))))
       (define transiting-tags (reverse transiting-tags-rev))
       ;; Raise lowered depots early (<= 14.0 tiles, or <= 16.0 vs fast speedlings/reapers/adepts/hellions)
       (for ([d (in-list lowered-depots)]
             #:when (>= (hash-ref d 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS))
         (define did (hash-ref d 'id 0))
         (define dx (exact->inexact (hash-ref d 'x base-x)))
         (define dy (exact->inexact (hash-ref d 'y base-y)))
         (define breach-threat?
           (for/or ([ep (in-list (get-ground-enemy-pts))])
             (define ddx (fl- dx (vector-ref ep 0)))
             (define ddy (fl- dy (vector-ref ep 1)))
             (fl<= (fl+ (fl* ddx ddx) (fl* ddy ddy)) (vector-ref ep 2))))
         (when breach-threat?
           (define vdx (fl- (exact->inexact base-x) dx))
           (define vdy (fl- (exact->inexact base-y) dy))
           (define vd (flmax 1.0 (flsqrt (fl+ (fl* vdx vdx) (fl* vdy vdy)))))
           (define move-tx (safe-coord (+ dx (* 3.5 (/ vdx vd))) base-x))
           (define move-ty (safe-coord (+ dy (* 3.5 (/ vdy vd))) base-y))
           (define any-blocking? #f)
           (for ([u (in-list ally-units)])
             (define uid (hash-ref u 'id #f))
             (when (and (exact-integer? uid)
                        (> uid 0)
                        (not (or (eq? (hash-ref u 'is-flying #f) #t)
                                 (eq? (hash-ref u 'flying? #f) #t))))
               (define ddx (fl- (exact->inexact (hash-ref u 'x base-x)) dx))
               (define ddy (fl- (exact->inexact (hash-ref u 'y base-y)) dy))
               (when (fl<= (fl+ (fl* ddx ddx) (fl* ddy ddy)) 2.4025)
                 (set! any-blocking? #t)
                 (l2-emit! ctx (list 'move uid move-tx move-ty)))))
           (when (and (not any-blocking?)
                      (> did 0)
                      (refractory-allow-action?! cd-tracker (list 'depot-raise did) frame 12))
             (l2-emit! ctx (list 'cast-spell did 'morph-supply-depot-raise)))))
       ;; Lower raised depots ONLY when friendly units need transit and NO ground enemy is within 15.0 (17.0 vs fast)
       (when (not (null? transiting-tags))
         (for ([rd (in-list raised-depots)]
               #:when (>= (hash-ref rd 'build-progress 1.0) SC2-BUILD-COMPLETE-PROGRESS))
           (define did (hash-ref rd 'id 0))
           (define dx (hash-ref rd 'x base-x))
           (define dy (hash-ref rd 'y base-y))
           (define enemy-within-safe-door? (raised-depot-enemy-near? rd dx dy))
           (when (and (not enemy-within-safe-door?)
                      (> did 0)
                      (refractory-allow-action?! cd-tracker (list 'depot-lower did) frame 24))
             (l2-emit! ctx (list 'cast-spell did 'morph-supply-depot-lower)))))
       (when (positive? (hash-count stuck-tbl))
         (for ([k (in-list (hash-keys stuck-tbl))])
           (unless (set-member? active-stuck-tags k)
             (hash-remove! stuck-tbl k))))
       (hash-set! door-st 'transiting-tags transiting-tags)
       (hash-set! door-st 'state
                  (cond
                    [(and (not (null? lowered-depots)) (null? raised-depots)) 'open]
                    [(and (not (null? lowered-depots)) (= (set-count active-stuck-tags) 0)) 'open]
                    [else 'closed])))
  (void))

(define (l2-phase9-post-race-telemetry! ctx)
  (define active-bases (l2-ctx-active-bases ctx))
  (define active-escrow-sym (l2-ctx-active-escrow-sym ctx))
  (define active-intel-method (l2-ctx-active-intel-method ctx))
  (define ally-bldgs (l2-ctx-ally-bldgs ctx))
  (define ally-units (l2-ctx-ally-units ctx))
  (define bank-target (l2-ctx-bank-target ctx))
  (define base-x (l2-ctx-base-x ctx))
  (define base-y (l2-ctx-base-y ctx))
  (define bo-active-goal (l2-ctx-bo-active-goal ctx))
  (define bo-eval (l2-ctx-bo-eval ctx))
  (define cd-tracker (l2-ctx-cd-tracker ctx))
  (define cortex (l2-ctx-cortex ctx))
  (define crisis-tech-upgrade-deferral? (l2-ctx-crisis-tech-upgrade-deferral? ctx))
  (define cur-escrow-age-frames (l2-ctx-cur-escrow-age-frames ctx))
  (define cur-escrow-peak-min (l2-ctx-cur-escrow-peak-min ctx))
  (define cur-escrow-start-frame (l2-ctx-cur-escrow-start-frame ctx))
  (define cur-exp-streak-start (l2-ctx-cur-exp-streak-start ctx))
  (define cur-peak-supply (l2-ctx-cur-peak-supply ctx))
  (define cur-th-total-cnt (l2-ctx-cur-th-total-cnt ctx))
  (define dyn-plan (l2-ctx-dyn-plan ctx))
  (define effective-enemy-race (l2-ctx-effective-enemy-race ctx))
  (define enemy-u-counts (l2-ctx-enemy-u-counts ctx))
  (define enemy-units (l2-ctx-enemy-units ctx))
  (define enemy-x (l2-ctx-enemy-x ctx))
  (define enemy-y (l2-ctx-enemy-y ctx))
  (define escrow-suppressed-goal (l2-ctx-escrow-suppressed-goal ctx))
  (define escrow-suppressed-until-frame (l2-ctx-escrow-suppressed-until-frame ctx))
  (define escrow-timed-out-now? (l2-ctx-escrow-timed-out-now? ctx))
  (define exp-goal-sym-this-step (l2-ctx-exp-goal-sym-this-step ctx))
  (define frame (l2-ctx-frame ctx))
  (define goal-stream-alloc (l2-ctx-goal-stream-alloc ctx))
  (define intel-confidence (l2-ctx-intel-confidence ctx))
  (define intel-coverage (l2-ctx-intel-coverage ctx))
  (define intel-deficit (l2-ctx-intel-deficit ctx))
  (define intel-freshness (l2-ctx-intel-freshness ctx))
  (define intel-priority-sector (l2-ctx-intel-priority-sector ctx))
  (define intel-staleness-frames (l2-ctx-intel-staleness-frames ctx))
  (define intel-target-goal (l2-ctx-intel-target-goal ctx))
  (define last-enemy-seen-frame (l2-ctx-last-enemy-seen-frame ctx))
  (define last-seen-army-frame (l2-ctx-last-seen-army-frame ctx))
  (define last-seen-main-frame (l2-ctx-last-seen-main-frame ctx))
  (define last-seen-natural-frame (l2-ctx-last-seen-natural-frame ctx))
  (define last-seen-third-frame (l2-ctx-last-seen-third-frame ctx))
  (define live-game? (l2-ctx-live-game? ctx))
  (define nat-x (l2-ctx-nat-x ctx))
  (define nat-y (l2-ctx-nat-y ctx))
  (define next-exp-timeout-cnt (l2-ctx-next-exp-timeout-cnt ctx))
  (define obs (l2-ctx-obs ctx))
  (define obs-minerals (l2-ctx-obs-minerals ctx))
  (define pressure-metrics (l2-ctx-pressure-metrics ctx))
  (define prev-exp-last-f (l2-ctx-prev-exp-last-f ctx))
  (define prio-log-line (l2-ctx-prio-log-line ctx))
  (define prio-summary (l2-ctx-prio-summary ctx))
  (define race (l2-ctx-race ctx))
  (define remembered-enemy-threat-frame (l2-ctx-remembered-enemy-threat-frame ctx))
  (define remembered-enemy-threat-supply (l2-ctx-remembered-enemy-threat-supply ctx))
  (define repaired-prereqs (l2-ctx-repaired-prereqs ctx))
  (define researched-upgs (l2-ctx-researched-upgs ctx))
  (define rt (l2-ctx-rt ctx))
  (define scout-worker-id (l2-ctx-scout-worker-id ctx))
  (define stream-spendable-ht (l2-ctx-stream-spendable-ht ctx))
  (define supply-cap (l2-ctx-supply-cap ctx))
  (define supply-used (l2-ctx-supply-used ctx))
  (define target-workers (l2-ctx-target-workers ctx))
  (define third-x (l2-ctx-third-x ctx))
  (define third-y (l2-ctx-third-y ctx))
  (define total-workers (l2-ctx-total-workers ctx))
  (define under-base-attack? (l2-ctx-under-base-attack? ctx))
  (define max-sup-plan
    (evaluate-max-supply-manager
     #:race race
     #:minerals (l2-ctx-minerals ctx)
     #:gas (l2-ctx-gas ctx)
     #:supply-used supply-used
     #:supply-cap supply-cap
     #:workers total-workers
     #:active-bases active-bases
     #:ally-units ally-units
     #:ally-buildings ally-bldgs
     #:base-x base-x
     #:base-y base-y
     #:nat-x nat-x
     #:nat-y nat-y
     #:third-x third-x
     #:third-y third-y
     #:enemy-x (hash-ref obs 'enemy-x SC2-DEFAULT-ENEMY-BASE-X)
     #:enemy-y (hash-ref obs 'enemy-y SC2-DEFAULT-ENEMY-BASE-Y)))
  (when (and (max-supply-plan-active? max-sup-plan)
             (refractory-allow-action?! cd-tracker
                                        (list 'max-supply-manager race)
                                        frame
                                        48))
    (for ([ms-act (in-list (max-supply-plan-combined-actions max-sup-plan))])
      (l2-emit! ctx ms-act)))
  (define cam-bmark-save-acts
    (cortex-sync-camera-bookmarks! cortex obs))
  (for ([ca (in-list cam-bmark-save-acts)])
    (l2-emit! ctx ca))
  (unless (live-bot-runtime-bookmarks-initialized? rt)
    (set-live-bot-runtime-bookmarks-initialized?! rt #t)
    (when (null? cam-bmark-save-acts)
      (cortex-save-camera-bookmark! cortex 1 base-x base-y)
      (l2-emit! ctx (list 'camera-bookmark-save 1 base-x base-y))))
  (define exp-entry
    (or (unbox (rt-experiment-box rt))
        (let* ([seed-pos
                (inexact->exact
                 (abs (+ (* 17 (round base-x))
                         (* 31 (round base-y))
                         (* 7 (round enemy-x))
                         (* 13 (round enemy-y)))))]
               [sel (select-match-experiment race effective-enemy-race seed-pos)]
               [sx-sy (let-values ([(sx sy) (resolve-experiment-spot-coord sel base-x base-y enemy-x enemy-y)])
                        (cons sx sy))]
               [tag (format-experiment-log-tag sel)]
               [entry (vector sel (car sx-sy) (cdr sx-sy) tag)])
          (set-box! (rt-experiment-box rt) entry)
          entry)))
  (define match-exp-sel (vector-ref exp-entry 0))
  (define exp-spot-x (vector-ref exp-entry 1))
  (define exp-spot-y (vector-ref exp-entry 2))
  (define exp-log-tag (vector-ref exp-entry 3))
  (define enemy-cnt-now (length enemy-units))
  (define cached-sit-vec (unbox (rt-sit-plan-cache rt)))
  (define refresh-sit?
    (or (not cached-sit-vec)
        (not live-game?)
        (>= (- frame (vector-ref cached-sit-vec 0))
            (if (= (modulo frame 16) 8) 20 16))
        (not (= enemy-cnt-now (vector-ref cached-sit-vec 1)))
        (not (eq? effective-enemy-race (vector-ref cached-sit-vec 2)))))
  (define sit-plan
    (if refresh-sit?
        (let ([plan (evaluate-situational-counter-plan obs race effective-enemy-race frame)])
          (set-box! (rt-sit-plan-cache rt)
                    (vector frame enemy-cnt-now effective-enemy-race plan))
          plan)
        (vector-ref cached-sit-vec 3)))
  (define sit-primary (situational-counter-plan-primary-situation sit-plan))
  (when (and refresh-sit?
             live-game?
             (not under-base-attack?)
             (not crisis-tech-upgrade-deferral?)
             (or (>= (l2-ctx-minerals ctx) 150) (>= (l2-ctx-gas ctx) 100))
             (refractory-allow-action?! cd-tracker 'situational-upgrade frame 32))
    (define enemy-comp-syms (hash-keys enemy-u-counts))
    (define sit-upgs
      (select-situational-upgrades
       race sit-primary enemy-comp-syms
       researched-upgs (l2-ctx-pending-upgs ctx) (l2-ctx-bldg-types ctx) (l2-ctx-minerals ctx) (l2-ctx-gas ctx)))
    (for/first ([su (in-list sit-upgs)]
                #:when (let ([before (length (l2-ctx-actions ctx))])
                         (l2-emit-research-verified! ctx su)
                         (> (length (l2-ctx-actions ctx)) before)))
      #t))
  (define prev-tel (live-bot-runtime-last-telemetry rt))
  (set-live-bot-runtime-last-telemetry!
   rt
   (hash-set* (if (hash? prev-tel) prev-tel (hash))
              'priority-summary prio-summary
              'priority-log-line prio-log-line
              'effective-enemy-race effective-enemy-race
              'pad-camped-posterior (l2-pad-camped-posterior ctx nat-x nat-y 11.5)
              'bo-active-goal bo-active-goal
              'target-workers target-workers
              'target-army-supply (pro-bo-eval-result-target-army-supply bo-eval)
              'bank-target bank-target
              'goal-stream-allocation goal-stream-alloc
              'decoupled-stream-spendable stream-spendable-ht
              'goal-streams DEC-GOAL-STREAMS
              'max-supply-plan max-sup-plan
              'dynamic-plan dyn-plan
              'dynamic-plan-next-actions
              (if (dynamic-macro-plan? dyn-plan)
                  (map plan-goal-node-next-action-sym (dynamic-macro-plan-actionable-goals dyn-plan))
                  '())
              'dynamic-plan-in-progress
              (if (dynamic-macro-plan? dyn-plan)
                  (dynamic-macro-plan-in-progress-syms dyn-plan)
                  '())
              'peak-supply-reached cur-peak-supply
              'repaired-prereqs repaired-prereqs
              'priority-repaired-prereqs repaired-prereqs
              'scout-worker-id scout-worker-id
              'last-enemy-seen-frame last-enemy-seen-frame
              'last-seen-main-frame last-seen-main-frame
              'last-seen-natural-frame last-seen-natural-frame
              'last-seen-third-frame last-seen-third-frame
              'last-seen-army-frame last-seen-army-frame
              'intel-staleness-frames intel-staleness-frames
              'intel-freshness intel-freshness
              'intel-coverage intel-coverage
              'intel-confidence intel-confidence
              'intel-deficit intel-deficit
              'intel-priority-sector intel-priority-sector
              'intel-target-goal intel-target-goal
              'intel-pressure (hash-ref pressure-metrics 'intel-pressure 0.0)
              'intel-gathering-method active-intel-method
              'remembered-enemy-threat-supply remembered-enemy-threat-supply
              'remembered-enemy-threat-frame remembered-enemy-threat-frame
              'escrow-goal-sym active-escrow-sym
              'escrow-age-frames (if escrow-timed-out-now? 0 cur-escrow-age-frames)
              'escrow-peak-min (if escrow-timed-out-now? obs-minerals cur-escrow-peak-min)
              'escrow-prev-min obs-minerals
              'escrow-start-frame (if escrow-timed-out-now? frame cur-escrow-start-frame)
              'escrow-last-frame frame
              'escrow-suppressed-goal escrow-suppressed-goal
              'escrow-suppressed-until-frame escrow-suppressed-until-frame
              'exp-goal-streak-start (if escrow-timed-out-now? #f cur-exp-streak-start)
              'exp-goal-th-count cur-th-total-cnt
              'exp-goal-last-frame (if exp-goal-sym-this-step frame prev-exp-last-f)
              'exp-timeout-count next-exp-timeout-cnt
              'experiment-id (MatchExperimentSelection-experiment-id match-exp-sel)
              'experiment-spot-idx (MatchExperimentSelection-spot-idx match-exp-sel)
              'spot-label (MatchExperimentSelection-spot-label match-exp-sel)
              'experiment-spot-label (MatchExperimentSelection-spot-label match-exp-sel)
              'experiment-tag exp-log-tag
              'experiment-spot-x exp-spot-x
              'experiment-spot-y exp-spot-y
              'experiment match-exp-sel
              'situational-plan sit-plan
              'primary-situation sit-primary
              'rush-fighting-worker-ids (l2-ctx-cur-rush-fighting-wids ctx)))
  (reverse (l2-ctx-actions ctx))
  (reverse (l2-ctx-actions ctx)))

(define (step-layer2-economy! rt raw-obs #:raw-obs [orig-raw-obs #f] #:sanitized? [sanitized? #f])
  (define ctx (rt-l2-ctx rt))
  (l2-phase1-setup! ctx rt raw-obs orig-raw-obs sanitized?)
  (l2-phase2-worker-rush! ctx)
  (l2-phase3-recall-cancel-scout! ctx)
  (l2-phase4-expansion-pads! ctx)
  (l2-phase5-threat-proxy! ctx)
  (l2-phase6-crisis-supply! ctx)
  (l2-phase7-wall-counts! ctx)
  (l2-phase8-macro-escrow! ctx)
  (case (l2-ctx-race ctx)
    [(Zerg)
     (l2-zerg-phase1-inject-creep! ctx)
     (l2-zerg-phase2-expand-tech-def! ctx)
     (l2-zerg-phase3-units-drones! ctx)]
    [(Protoss)
     (l2-protoss-phase1-chrono-wall! ctx)
     (l2-protoss-phase2-tech-expand! ctx)
     (l2-protoss-phase3-upgrades-units! ctx)]
    [(Terran)
     (l2-terran-phase1-orbital-addon-expand! ctx)
     (l2-terran-phase2-tech-starport! ctx)
     (l2-terran-phase3-units-depots! ctx)])
  (define out-acts (l2-phase9-post-race-telemetry! ctx))
  (l2-clear-ctx-refs! ctx)
  out-acts)


;; =============================================================================
;; Layer 3 & 4: Squad Split (Monoidal Finger Tree), Tactical Micro, Spells,
;;              Transport Juggle & Adversarial Anti-ForceField / Anti-Kite Leash
;; =============================================================================

;; Select the best targetable enemy unit for `attacker-type` within weapon domain
;; (filters out untargetable projectiles/larva/eggs, enforces air/ground weapon
;; domain matching, de-prioritizes passive scouts/decoys/interceptors/broodlings
;; when real threats exist, and prioritizes Light/Bio clumps for Banelings).
(define PREP-LIGHT-XS (make-flvector 256))
(define PREP-LIGHT-YS (make-flvector 256))

(define (prep-enemy-target-descriptors enemy-units include-nearby-light?)
  (define-values (light-xs light-ys light-cnt)
    (if include-nearby-light?
        (let* ([n (length enemy-units)]
               [cap (flvector-length PREP-LIGHT-XS)]
               [xs (if (<= n cap) PREP-LIGHT-XS (make-flvector n))]
               [ys (if (<= n cap) PREP-LIGHT-YS (make-flvector n))])
          (let loop ([rem enemy-units] [cnt 0])
            (if (null? rem)
                (values xs ys cnt)
                (let ([o (car rem)])
                  (if (bitwise-bit-set? (fast-enemy-sym-flags (unit-type-sym o)) 6)
                      (let ([ox-raw (hash-ref o 'x 0.0)]
                            [oy-raw (hash-ref o 'y 0.0)])
                        (flvector-set! xs cnt (if (flonum? ox-raw) ox-raw (exact->inexact ox-raw)))
                        (flvector-set! ys cnt (if (flonum? oy-raw) oy-raw (exact->inexact oy-raw)))
                        (loop (cdr rem) (add1 cnt)))
                      (loop (cdr rem) cnt))))))
        (values #f #f 0)))
  (let loop ([rem enemy-units] [rev '()])
    (if (null? rem)
        (reverse rev)
        (let* ([e (car rem)]
               [et (unit-type-sym e)]
               [flags (fast-enemy-sym-flags et)])
          (if (or (bitwise-bit-set? flags 0)
                  (eq? (hash-ref e 'hallucination #f) #t))
              (loop (cdr rem) rev)
              (let* ([ex-raw (hash-ref e 'x 9999.0)]
                     [ey-raw (hash-ref e 'y 9999.0)]
                     [ex (if (flonum? ex-raw) ex-raw (exact->inexact ex-raw))]
                     [ey (if (flonum? ey-raw) ey-raw (exact->inexact ey-raw))]
                     [eflying?
                      (or (bitwise-bit-set? flags 8)
                          (eq? (hash-ref e 'is-flying #f) #t)
                          (eq? (hash-ref e 'flying? #f) #t)
                          (eq? (hash-ref e 'flying #f) #t))]
                     [hp-raw (hash-ref e 'hp 100.0)]
                     [hp
                      (cond
                        [(and (flonum? hp-raw) (fl= (fl- hp-raw hp-raw) 0.0)) hp-raw]
                        [(exact-integer? hp-raw) (->fl hp-raw)]
                        [else (exact->inexact (fast-finite-real hp-raw 100.0))])]
                     [changeling?
                      (or (bitwise-bit-set? flags 1)
                          (eq? (hash-ref e 'changeling? #f) #t))]
                     [mobile-det? (bitwise-bit-set? flags 2)]
                     [static-det? (bitwise-bit-set? flags 3)]
                     [passive? (bitwise-bit-set? flags 4)]
                     [struct? (bitwise-bit-set? flags 5)]
                     [light-bio? (bitwise-bit-set? flags 6)]
                     [armored? (bitwise-bit-set? flags 7)]
                     [base-adj
                      (fl+ (if changeling? -220.0 0.0)
                           (if struct? 30.0 0.0))]
                     [adj-plain
                      (if passive? (fl+ base-adj 250.0) base-adj)]
                     [adj-stealth
                      (fl+ base-adj
                           (fl+ (if (or mobile-det? static-det?) -180.0 0.0)
                                (if (and passive? (not mobile-det?)) 250.0 0.0)))]
                     [bane-light-bonus
                      (if (and include-nearby-light? light-bio?)
                          (let jloop ([j 0] [cnt 0])
                            (if (= j light-cnt)
                                (fl- -45.0 (fl* 12.0 (->fl cnt)))
                                (let ([dx (fl- ex (flvector-ref light-xs j))]
                                      [dy (fl- ey (flvector-ref light-ys j))])
                                  (jloop (add1 j)
                                         (if (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 4.84)
                                             (add1 cnt)
                                             cnt)))))
                          (if (or armored? struct?) 80.0 0.0))])
                (loop (cdr rem)
                      (cons (vector e ex ey eflying? hp adj-plain adj-stealth bane-light-bonus) rev))))))))

(define (select-target-enemy-from-prepped ux uy prepped [attacker-type 'marine] [ally-has-stealth? #f])
  (define baneling-attacker? (eq? attacker-type 'baneling))
  (define stealth-active?
    (or ally-has-stealth?
        (hash-ref RUNTIME-STEALTH-SET attacker-type #f)))
  (define can-air? (fast-can-attack-air? attacker-type))
  (define can-gnd? (fast-can-attack-ground? attacker-type))
  (define fx (if (flonum? ux) ux (exact->inexact ux)))
  (define fy (if (flonum? uy) uy (exact->inexact uy)))
  (define focus-r (if (flonum? SC2-ENGAGEMENT-FOCUS-FIRE-RADIUS)
                      SC2-ENGAGEMENT-FOCUS-FIRE-RADIUS
                      (exact->inexact SC2-ENGAGEMENT-FOCUS-FIRE-RADIUS)))
  (define focus-r2 (fl* focus-r focus-r))
  (let loop ([rem prepped]
             [best-valid #f]
             [best-valid-sc +inf.0]
             [best-any #f]
             [best-any-sc +inf.0])
    (if (null? rem)
        (if best-valid
            (values best-valid #t)
            (values best-any #f))
        (let* ([v (car rem)]
               [eflying? (vector-ref v 3)]
               [valid? (if eflying? can-air? can-gnd?)])
          (if (or valid? (not best-valid))
              (let* ([ex (vector-ref v 1)]
                     [ey (vector-ref v 2)]
                     [dx (fl- ex fx)]
                     [dy (fl- ey fy)]
                     [d2 (fl+ (fl* dx dx) (fl* dy dy))]
                     [adj-base (if stealth-active? (vector-ref v 6) (vector-ref v 5))]
                     [adj (if baneling-attacker? (fl+ adj-base (vector-ref v 7)) adj-base)]
                     [cur-best (if valid? best-valid-sc best-any-sc)]
                     [hp (vector-ref v 4)]
                     [pruned?
                      (and (fl< cur-best +inf.0)
                           (if (fl> d2 focus-r2)
                               (let ([margin (fl- cur-best (fl+ adj (fl+ 100.0 (fl* 0.02 hp))))])
                                 (or (fl<= margin 0.0)
                                     (fl> (fl* 16.0 d2) (fl* margin margin))))
                               (let ([margin (fl- cur-best (fl+ adj (fl* 0.05 hp)))])
                                 (or (fl<= margin 0.0)
                                     (fl> (fl* 4.0 d2) (fl* margin margin))))))])
                (if pruned?
                    (loop (cdr rem) best-valid best-valid-sc best-any best-any-sc)
                    (let* ([e (vector-ref v 0)]
                           [d (flsqrt d2)]
                           [sc (fl+ adj
                                    (if (fl<= d focus-r)
                                        (fl+ (fl* 2.0 d) (fl* 0.05 hp))
                                        (fl+ 100.0 (fl+ (fl* 4.0 d) (fl* 0.02 hp)))))])
                      (if valid?
                          (if (fl< sc best-valid-sc)
                              (loop (cdr rem) e sc best-any best-any-sc)
                              (loop (cdr rem) best-valid best-valid-sc best-any best-any-sc))
                          (if (fl< sc best-any-sc)
                              (loop (cdr rem) best-valid best-valid-sc e sc)
                              (loop (cdr rem) best-valid best-valid-sc best-any best-any-sc))))))
              (loop (cdr rem) best-valid best-valid-sc best-any best-any-sc))))))

(define (select-target-enemy-for-unit ux uy enemy-units [attacker-type 'marine] [ally-has-stealth? #f])
  (define baneling-attacker? (eq? attacker-type 'baneling))
  (define prepped (prep-enemy-target-descriptors enemy-units baneling-attacker?))
  (define-values (tgt _valid?)
    (select-target-enemy-from-prepped ux uy prepped attacker-type ally-has-stealth?))
  tgt)


;; Pooled mutable context & top-level phases for step-layer3-and-4-tactics!
(struct l34-ctx
  (rt
   raw-obs
   fap-score
   obs
   frame
   oledger
   researched-upgs
   live-upgrades-tracked?
   wave3-preserved-set
   live-tactics-obs?
   actions
   bo-tplan-box
   door-st-tactics
   under-tactics-base-attack?
   ally-units
   ally-bldgs
   enemy-units
   enemy-bldgs
   pending-upgs
   base-x
   base-y
   nat-x
   nat-y
   enemy-x
   enemy-y
   enemy-exp-x
   enemy-exp-y
   enemy-third-x
   enemy-third-y
   effects
   engagement-enemies
   ally-siege-supporters
   enemy-pf-list
   enemy-sieged-tanks-near
   fbase-x
   fbase-y
   fnat-x
   fnat-y
   fthird-x
   fthird-y
   combat-th-limit?
   enemy-territory-cache
   territory-miss
   ground-eng-enemy-recs-cache
   caster-leash-x
   caster-leash-y
   fcaster-leash-x
   fcaster-leash-y
   bo-rally-override?
   bo-rally-tx
   bo-rally-ty
   fbo-rally-tx
   fbo-rally-ty
   live-obs?
   dead-tags-rt
   immobile-bile-targets
   tbrain
   tbrain-committed-tags
   sum-eb-y
   weighted-combat-units
   enemy-stasis-traps
   wave3-marauder-target-tags
   l34-sc
   splash-evading-tags
   wave3-handled-tags
   enemy-disruptor-units
   disruptor-directive-set
   has-enemy-map-elem-or-recall?
   has-enemy-burrow-or-sh-counter?
   tbrain-unit-actions
   ravager-cast-tags
   sum-eb-x
   enemy-widow-mines
   enemy-banelings
   any-ally-baneling?
   ally-zerg-burrow-candidate?
   disruptor-handled-tags
   has-ally-queen?
   has-ally-zergling?
   oracle-cast-tags
   enemy-air-or-colossus
   has-enemy-changeling?
   has-non-overlord-spotter?
   live-combat-supply
   creep-ally-slice-rev
   queen-cast-tags
   mode-candidates
   local-val-ratio
   enemy-massive-air-or-colossus
   enemy-mutalisks
   has-ally-queen-or-tumor?
   enemy-z-early
   have-heavy-or-siege-breaker?
   has-ally-dropperlord?
   enemy-changelings
   splash-thor-dwell-ht
   splash-bc-yamato-ht
   splash-bc-jump-ht
   enemy-near-home?
   eff-wave-commit?
   splash-lib-dwell-ht
   splash-wm-dwell-ht
   splash-vik-dwell-ht
   ally-has-detector?
   transport-tr
   ft
   splash-tank-dwell-ht
   unit-mode-tr
   bo-fork-active?
   ally-has-stealth?
   has-ally-swarm-host-or-locust?
   bo-contain-active?
   any-pro-caster?
   linear-splash-enemies
   our-z-early
   has-ally-roach?
   splash-wm-disarmed-ht
   bo-micro-dirs
   snipe-locked-tags
   bo-sy
   has-ally-wall-block-bldg?
   splash-mode-dwell-ht
   bo-prepos-active?
   armory-ready-bldgs?
   bstates
   live-owned-townhalls
   prelim-army-cy
   prelim-army-cx
   has-ally-harass-sym?
   has-enemy-swarm-host-or-locust?
   has-ally-unwalled-punish-unit?
   has-enemy-creep-tumor?
   third-y
   can-break-siege-line?
   sum-eu-x
   has-ally-map-elem-or-recall?
   has-ally-static-def-or-nydus?
   sum-eu-y
   has-enemy-static-det?
   leases
   bo-sx
   ground-army-cx
   has-ally-changeling-or-overseer?
   has-enemy-harass-sym?
   has-enemy-static-def-or-nydus?
   ground-army-cy
   third-x
   has-enemy-dropperlord?
   has-enemy-overseer?
   spell-claims-rt
   ally-infestors
   ally-overseers
   vanguard-count
   tank-lurker-hazards
   combat-units
   live-attack-wave-min
   visible-enemy-combat-supply
   wave3-thor-morphed-tags
   fbo-py
   ally-disruptor-units
   splash-st
   stasis-frozen-tags
   enemy-unit-shimmer?
   fbo-px
   reserve-count
   ally-sentries
   creep-enemy-slice-rev
   wave3-viking-morphed-tags
   siege-line-hold?)
  #:mutable)

(define (make-l34-ctx)
  (l34-ctx #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f #f))

(define-rt-weak-state rt-l34-ctx (make-l34-ctx))

(define (l34-clear-ctx-refs! ctx)
  (set-l34-ctx-rt! ctx #f)
  (set-l34-ctx-raw-obs! ctx #f)
  (set-l34-ctx-obs! ctx #f)
  (set-l34-ctx-ally-units! ctx '())
  (set-l34-ctx-ally-bldgs! ctx '())
  (set-l34-ctx-enemy-units! ctx '())
  (set-l34-ctx-enemy-bldgs! ctx '())
  (set-l34-ctx-effects! ctx '())
  (set-l34-ctx-combat-units! ctx '())
  (set-l34-ctx-ft! ctx #f)
  (set-l34-ctx-engagement-enemies! ctx '())
  (set-l34-ctx-actions! ctx '())
  (set-l34-ctx-bo-tplan-box! ctx #f)
  (set-l34-ctx-enemy-territory-cache! ctx #f)
  (set-l34-ctx-ground-eng-enemy-recs-cache! ctx #f))

(define (l34-has-upgrade? ctx upg-sym)
  (or (not (l34-ctx-live-upgrades-tracked? ctx))
      (and (memq upg-sym (l34-ctx-researched-upgs ctx)) #t)))

(define (l34-emit! ctx act)
  (order-ledger-record-issued! (l34-ctx-oledger ctx) (l34-ctx-frame ctx) act)
  (set-l34-ctx-actions! ctx (cons act (l34-ctx-actions ctx))))

(define (l34-emit-preserved! ctx act)
  (set-add! (l34-ctx-wave3-preserved-set ctx) act)
  (l34-emit! ctx act))

(define (l34-quantize-cell-2.5 ctx v fallback)
  (geo:quantize-cell-2.5 v (if (real? fallback) fallback 32.5) (l34-ctx-live-tactics-obs? ctx)))

(define (l34-stealth-unit-or-bldg? e)
  (define et (unit-type-sym e))
  (or (memq et '(widow-mine-burrowed lurker-burrowed dark-templar banshee ghost
                 roach-burrowed infestor-burrowed oracle-stasis-trap stasis-ward))
      (eq? (hash-ref e 'cloaked #f) #t)
      (eq? (hash-ref e 'burrowed #f) #t)
      (= (hash-ref e 'display-type 1) 2)))

(define (l34-get-bo-tplan ctx)
  (or (l34-ctx-bo-tplan-box ctx)
      (let ()
        (define rt (l34-ctx-rt ctx))
        (define obs (l34-ctx-obs ctx))
        (define raw-obs (l34-ctx-raw-obs ctx))
        (define frame (l34-ctx-frame ctx))
        (define under-tactics-base-attack? (l34-ctx-under-tactics-base-attack? ctx))
        (define ally-units (l34-ctx-ally-units ctx))
        (define ally-bldgs (l34-ctx-ally-bldgs ctx))
        (define enemy-units (l34-ctx-enemy-units ctx))
        (define enemy-bldgs (l34-ctx-enemy-bldgs ctx))
        (define researched-upgs (l34-ctx-researched-upgs ctx))
        (define pending-upgs (l34-ctx-pending-upgs ctx))
        (define live-tactics-obs? (l34-ctx-live-tactics-obs? ctx))
        (define door-st-tactics (l34-ctx-door-st-tactics ctx))
        (define base-x (l34-ctx-base-x ctx))
        (define base-y (l34-ctx-base-y ctx))
        (define nat-x (l34-ctx-nat-x ctx))
        (define nat-y (l34-ctx-nat-y ctx))
        (define enemy-x (l34-ctx-enemy-x ctx))
        (define enemy-y (l34-ctx-enemy-y ctx))
        (define enemy-exp-x (l34-ctx-enemy-exp-x ctx))
        (define enemy-exp-y (l34-ctx-enemy-exp-y ctx))
        (define enemy-third-x (l34-ctx-enemy-third-x ctx))
        (define enemy-third-y (l34-ctx-enemy-third-y ctx))
          (begin
        (let* ([t-our-race
                (let ([r (live-bot-runtime-actual-race rt)])
                  (if (and (symbol? r) (not (eq? r 'Unknown)))
                      r
                      (hash-ref obs 'race 'Zerg)))]
               [prev-tel (live-bot-runtime-last-telemetry rt)]
               [t-enemy-race
                (if (hash? prev-tel)
                    (hash-ref prev-tel 'effective-enemy-race (hash-ref obs 'enemy-race 'Unknown))
                    (hash-ref obs 'enemy-race 'Unknown))]
               [ua-flag (or under-tactics-base-attack? (eq? (hash-ref raw-obs 'under-attack #f) #t))]
               [len-au (length ally-units)]
               [len-ab (length ally-bldgs)]
               [len-eu (length enemy-units)]
               [len-eb (length enemy-bldgs)]
               [ru-len (length researched-upgs)]
               [pu-len (length pending-upgs)]
               [cached (and live-tactics-obs? (hash-ref door-st-tactics 'bo-tactical-cache #f))]
               [plan
                (if (and (vector? cached)
                         (>= frame (vector-ref cached 0))
                         (< (- frame (vector-ref cached 0))
                            (if (= (modulo frame 16) 8) 12 8))
                         (eq? t-our-race (vector-ref cached 1))
                         (eq? t-enemy-race (vector-ref cached 2))
                         (= len-au (vector-ref cached 3))
                         (= len-ab (vector-ref cached 4))
                         (= len-eu (vector-ref cached 5))
                         (= len-eb (vector-ref cached 6))
                         (eq? ua-flag (vector-ref cached 7))
                         (= ru-len (vector-ref cached 8))
                         (= pu-len (vector-ref cached 9)))
                    (vector-ref cached 10)
                    (let ()
                      (define raw-uc (hash-ref raw-obs 'unit-counts #f))
                      (define raw-euc (hash-ref raw-obs 'enemy-unit-counts #f))
                      (define raw-ebc (hash-ref raw-obs 'enemy-building-counts #f))
                      (define raw-sup (hash-ref raw-obs 'supply-used #f))
                      (define raw-prog (hash-ref raw-obs 'in-progress-upgrade-progress #f))
                      (define raw-lr (hash-ref raw-obs 'lanchester-ratio #f))
                      (define need-ally-scan?
                        (or (not (and (hash? raw-uc) (not (hash-empty? raw-uc))))
                            (not (exact-integer? raw-sup))
                            (not (real? raw-lr))))
                      (define u-counts (if (and (hash? raw-uc) (not (hash-empty? raw-uc))) raw-uc (make-hasheq)))
                      (define sup-sum 0.0)
                      (define ally-val 0)
                      (define max-bldg-prog 0.0)
                      (when need-ally-scan?
                        (define add-u? (not (and (hash? raw-uc) (not (hash-empty? raw-uc)))))
                        (for ([u (in-list ally-units)])
                          (define ut (unit-type-sym u))
                          (when add-u?
                            (hash-set! u-counts ut (+ 1 (hash-ref u-counts ut 0))))
                          (set! sup-sum (+ sup-sum (unit-supply-cost ut)))
                          (when (combat-unit-record? u)
                            (set! ally-val (+ ally-val (fast-res-cost-50 ut)))))
                        (for ([b (in-list ally-bldgs)])
                          (define bt (unit-type-sym b))
                          (when add-u?
                            (hash-set! u-counts bt (+ 1 (hash-ref u-counts bt 0))))
                          (when (and (not (real? raw-prog)) (hash? b))
                            (define op (hash-ref b 'order-progress #f))
                            (when (real? op)
                              (set! max-bldg-prog (max max-bldg-prog (exact->inexact op)))))))
                      (define need-eu-scan?
                        (or (not (and (hash? raw-euc) (not (hash-empty? raw-euc))))
                            (not (real? raw-lr))))
                      (define eu-counts (if (and (hash? raw-euc) (not (hash-empty? raw-euc))) raw-euc (make-hasheq)))
                      (define enemy-val 0)
                      (when need-eu-scan?
                        (define add-eu? (not (and (hash? raw-euc) (not (hash-empty? raw-euc)))))
                        (for ([e (in-list enemy-units)])
                          (define et (unit-type-sym e))
                          (when add-eu?
                            (hash-set! eu-counts et (+ 1 (hash-ref eu-counts et 0))))
                          (unless (combat-unit-excluded-sym? et)
                            (set! enemy-val (+ enemy-val (fast-res-cost-50 et))))))
                      (define need-eb-scan?
                        (or (not (and (hash? raw-ebc) (not (hash-empty? raw-ebc))))
                            (not (real? raw-lr))))
                      (define eb-counts (if (and (hash? raw-ebc) (not (hash-empty? raw-ebc))) raw-ebc (make-hasheq)))
                      (when need-eb-scan?
                        (define add-eb? (not (and (hash? raw-ebc) (not (hash-empty? raw-ebc)))))
                        (for ([eb (in-list enemy-bldgs)])
                          (define bt (unit-type-sym eb))
                          (when add-eb?
                            (hash-set! eb-counts bt (+ 1 (hash-ref eb-counts bt 0))))
                          (when (hash-ref RUNTIME-STATIC-DEFVAL-SET bt #f)
                            (set! enemy-val (+ enemy-val (fast-res-cost-100 bt))))))
                      (define eff-sup
                        (if (exact-integer? raw-sup)
                            raw-sup
                            (max 12 (inexact->exact (round sup-sum)))))
                      (define eff-prog
                        (if (real? raw-prog)
                            (safe-finite-real raw-prog 0.0)
                            max-bldg-prog))
                      (define eff-lr
                        (if (real? raw-lr)
                            (safe-finite-real raw-lr 1.0)
                            (if (and (null? enemy-units) (null? enemy-bldgs))
                                (if (>= ally-val 200) 1.05 0.95)
                                (/ (exact->inexact (max 50 ally-val))
                                   (exact->inexact (max 50 enemy-val))))))
                      (define fresh-plan
                        (evaluate-build-order-tactical-plan
                         #:race t-our-race
                         #:enemy-race t-enemy-race
                         #:frame frame
                         #:supply-used eff-sup
                         #:unit-counts u-counts
                         #:researched-upgrades researched-upgs
                         #:pending-upgrades pending-upgs
                         #:in-progress-upgrade-progress eff-prog
                         #:enemy-unit-counts eu-counts
                         #:enemy-building-counts eb-counts
                         #:lanchester-ratio eff-lr
                         #:under-attack? ua-flag
                         #:base-x base-x #:base-y base-y
                         #:nat-x nat-x #:nat-y nat-y
                         #:enemy-main-x enemy-x #:enemy-main-y enemy-y
                         #:enemy-nat-x enemy-exp-x #:enemy-nat-y enemy-exp-y
                         #:enemy-third-x enemy-third-x #:enemy-third-y enemy-third-y))
                      (when live-tactics-obs?
                        (hash-set! door-st-tactics 'bo-tactical-cache
                                   (vector frame t-our-race t-enemy-race len-au len-ab len-eu len-eb
                                           ua-flag ru-len pu-len fresh-plan)))
                      fresh-plan))])
          (set-l34-ctx-bo-tplan-box! ctx plan)
          (hash-set! door-st-tactics 'bo-tactical-plan plan)
          (hash-set! door-st-tactics 'bo-tactical-disposition (bo-active-tactical-plan-disposition plan))
          (hash-set! door-st-tactics 'bo-tactical-phase (bo-active-tactical-plan-phase-id plan))
          (hash-set! door-st-tactics 'bo-micro-directives (bo-active-tactical-plan-micro-directives plan))
          (hash-set! door-st-tactics 'bo-active-tactics (bo-active-tactical-plan-active-tactics plan))
          plan)))))

(define (l34-bo-fork-coords ctx)
  (define enemy-x (l34-ctx-enemy-x ctx))
  (define enemy-y (l34-ctx-enemy-y ctx))
  (define enemy-exp-x (l34-ctx-enemy-exp-x ctx))
  (define enemy-exp-y (l34-ctx-enemy-exp-y ctx))
    (define p (l34-get-bo-tplan ctx))
    (define d (bo-active-tactical-plan-disposition p))
    (define px (safe-coord (bo-active-tactical-plan-primary-target-x p) enemy-x))
    (define py (safe-coord (bo-active-tactical-plan-primary-target-y p) enemy-y))
    (define sx (safe-coord (bo-active-tactical-plan-secondary-fork-x p) enemy-exp-x))
    (define sy (safe-coord (bo-active-tactical-plan-secondary-fork-y p) enemy-exp-y))
    (define dx (- sx px))
    (define dy (- sy py))
    (define fork-on?
      (and (memq d '(execute-timing-bypass-harass-fork execute-timing-attack-commit))
           (or (eq? d 'execute-timing-bypass-harass-fork)
               (> (+ (* dx dx) (* dy dy)) 4.0))))
    (values fork-on? sx sy))

(define (l34-safe-coord-dist2 x1 y1 x2 y2)
  (if (and (flonum? x1) (flonum? y1) (flonum? x2) (flonum? y2)
           (fl= (fl- x1 x1) 0.0) (fl= (fl- y1 y1) 0.0)
           (fl= (fl- x2 x2) 0.0) (fl= (fl- y2 y2) 0.0))
      (let ([dx (fl- x1 x2)] [dy (fl- y1 y2)])
        (fl+ (fl* dx dx) (fl* dy dy)))
      (if (and (real? x1) (= (- x1 x1) 0)
               (real? y1) (= (- y1 y1) 0)
               (real? x2) (= (- x2 x2) 0)
               (real? y2) (= (- y2 y2) 0))
          (let ([dx (fl- (exact->inexact x1) (exact->inexact x2))]
                [dy (fl- (exact->inexact y1) (exact->inexact y2))])
            (fl+ (fl* dx dx) (fl* dy dy)))
          (let ([d (dist2d x1 y1 x2 y2)])
            (* d d)))))
(define (l34-within-r2? x1 y1 x2 y2 r2 r)
  (if (and (flonum? x1) (flonum? y1) (flonum? x2) (flonum? y2)
           (fl= (fl- x1 x1) 0.0) (fl= (fl- y1 y1) 0.0)
           (fl= (fl- x2 x2) 0.0) (fl= (fl- y2 y2) 0.0))
      (let ([dx (fl- x1 x2)] [dy (fl- y1 y2)])
        (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2))
      (if (and (real? x1) (= (- x1 x1) 0)
               (real? y1) (= (- y1 y1) 0)
               (real? x2) (= (- x2 x2) 0)
               (real? y2) (= (- y2 y2) 0))
          (let ([dx (fl- (exact->inexact x1) (exact->inexact x2))]
                [dy (fl- (exact->inexact y1) (exact->inexact y2))])
            (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2))
          (<= (dist2d x1 y1 x2 y2) r))))
(define (l34-fast-enemy-near-territory? ctx e ex ey)
  (define enemy-territory-cache (l34-ctx-enemy-territory-cache ctx))
  (define territory-miss (l34-ctx-territory-miss ctx))
  (define fbase-x (l34-ctx-fbase-x ctx))
  (define fbase-y (l34-ctx-fbase-y ctx))
  (define fnat-x (l34-ctx-fnat-x ctx))
  (define fnat-y (l34-ctx-fnat-y ctx))
  (define fthird-x (l34-ctx-fthird-x ctx))
  (define fthird-y (l34-ctx-fthird-y ctx))
  (define combat-th-limit? (l34-ctx-combat-th-limit? ctx))
  (define hit (if enemy-territory-cache (hash-ref enemy-territory-cache e territory-miss) territory-miss))
  (if (eq? hit territory-miss)
      (let ([res (or (l34-within-r2? ex ey fbase-x fbase-y 1296.0 36.0)
                     (l34-within-r2? ex ey fnat-x fnat-y 1296.0 36.0)
                     (and combat-th-limit?
                          (l34-within-r2? ex ey fthird-x fthird-y 1296.0 36.0)))])
        (when enemy-territory-cache (hash-set! enemy-territory-cache e res))
        res)
      hit))
(define (l34-get-ground-eng-enemy-recs ctx)
  (or (l34-ctx-ground-eng-enemy-recs-cache ctx)
      (let ([res (for/list ([e (in-list (l34-ctx-engagement-enemies ctx))]
                            #:when (not (fast-unit-is-flying-sym? (unit-type-sym e))))
                   (vector e (hash-ref e 'x #f) (hash-ref e 'y #f)))])
        (set-l34-ctx-ground-eng-enemy-recs-cache! ctx res)
        res)))
(define (l34-any-ally-siege-near? ctx ex ey ux uy)
  (define ally-siege-supporters (l34-ctx-ally-siege-supporters ctx))
  (let loop ([rem ally-siege-supporters])
    (and (pair? rem)
         (let ([tk (car rem)])
           (or (l34-within-r2? ex ey (hash-ref tk 'x ux) (hash-ref tk 'y uy) 240.25 15.5)
               (loop (cdr rem)))))))
(define (l34-find-pf-holding-off ctx etype ex ey ux uy)
  (define enemy-pf-list (l34-ctx-enemy-pf-list ctx))
  (let loop ([rem enemy-pf-list])
    (and (pair? rem)
         (let ([eb (car rem)])
           (if (or (eq? etype 'planetary-fortress)
                   (l34-within-r2? ex ey (hash-ref eb 'x 9999.0) (hash-ref eb 'y 9999.0) 110.25 10.5)
                   (l34-within-r2? ux uy (hash-ref eb 'x 9999.0) (hash-ref eb 'y 9999.0) 110.25 10.5))
               eb
               (loop (cdr rem)))))))
(define (l34-find-sieged-tank-holding-off ctx ex ey ux uy)
  (define enemy-sieged-tanks-near (l34-ctx-enemy-sieged-tanks-near ctx))
  (let loop ([rem enemy-sieged-tanks-near])
    (and (pair? rem)
         (let ([st (car rem)])
           (if (or (l34-within-r2? ex ey (hash-ref st 'x 9999.0) (hash-ref st 'y 9999.0) 196.0 14.0)
                   (l34-within-r2? ux uy (hash-ref st 'x 9999.0) (hash-ref st 'y 9999.0) 240.25 15.5))
               st
               (loop (cdr rem)))))))
(define (l34-find-nearest-sieged-tank ctx ux uy)
  (define enemy-sieged-tanks-near (l34-ctx-enemy-sieged-tanks-near ctx))
  (let loop ([rem enemy-sieged-tanks-near])
    (and (pair? rem)
         (let ([st (car rem)])
           (if (l34-within-r2? ux uy (hash-ref st 'x 9999.0) (hash-ref st 'y 9999.0) 240.25 15.5)
               st
               (loop (cdr rem)))))))
(define (l34-emit-caster-rear-leash! ctx uid ux uy)
  (define fcaster-leash-x (l34-ctx-fcaster-leash-x ctx))
  (define fcaster-leash-y (l34-ctx-fcaster-leash-y ctx))
  (define caster-leash-x (l34-ctx-caster-leash-x ctx))
  (define caster-leash-y (l34-ctx-caster-leash-y ctx))
  (when (not (l34-within-r2? ux uy fcaster-leash-x fcaster-leash-y 4.84 2.2))
    (l34-emit! ctx (list 'move uid caster-leash-x caster-leash-y))))
(define (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid
                               nearest-enemy-tank
                               zergling-hold-off-pf-siege?
                               tank-supporting-vs-static?
                               unit-should-engage-target?)
  (define bo-rally-override? (l34-ctx-bo-rally-override? ctx))
  (define fbo-rally-tx (l34-ctx-fbo-rally-tx ctx))
  (define fbo-rally-ty (l34-ctx-fbo-rally-ty ctx))
  (define bo-rally-tx (l34-ctx-bo-rally-tx ctx))
  (define bo-rally-ty (l34-ctx-bo-rally-ty ctx))
  (define fnat-x (l34-ctx-fnat-x ctx))
  (define fnat-y (l34-ctx-fnat-y ctx))
  (define nat-x (l34-ctx-nat-x ctx))
  (define nat-y (l34-ctx-nat-y ctx))
  (cond
    [nearest-enemy-tank
     (define-values (kx ky)
       (compute-kite-vector ux uy
                            (hash-ref nearest-enemy-tank 'x ex)
                            (hash-ref nearest-enemy-tank 'y ey)
                            3.0))
     (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy)))]
    [zergling-hold-off-pf-siege?
     (define-values (kx ky)
       (compute-kite-vector ux uy
                            (hash-ref zergling-hold-off-pf-siege? 'x ex)
                            (hash-ref zergling-hold-off-pf-siege? 'y ey)
                            3.0))
     (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy)))]
    [tank-supporting-vs-static?
     (define-values (kx ky) (compute-kite-vector ux uy ex ey 2.5))
     (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy)))]
    [(and unit-should-engage-target? eid)
     (l34-emit! ctx (list 'attack-unit uid eid))]
    [bo-rally-override?
     (when (not (l34-within-r2? ux uy fbo-rally-tx fbo-rally-ty 36.0 6.0))
       (l34-emit! ctx (list 'attack-pos uid bo-rally-tx bo-rally-ty)))]
    [(not (l34-within-r2? ux uy fnat-x fnat-y 100.0 10.0))
     (l34-emit! ctx (list 'attack-pos uid nat-x nat-y))]))
(define (l34-lurker-min-ground-dist2 recs ux uy ex ey)
  (let loop ([rem recs] [best +inf.0])
    (if (null? rem)
        best
        (let* ([r (car rem)]
               [ex2 (or (vector-ref r 1) ex)]
               [ey2 (or (vector-ref r 2) ey)]
               [d2 (l34-safe-coord-dist2 ux uy ex2 ey2)])
          (loop (cdr rem) (min best d2))))))
(define (l34-min-eng-fast-dist2d ctx ux uy ex ey)
  (define engagement-enemies (l34-ctx-engagement-enemies ctx))
  (let loop ([rem engagement-enemies] [best +inf.0])
    (if (null? rem)
        best
        (let ([e (car rem)])
          (loop (cdr rem) (min best (fast-dist2d ux uy (hash-ref e 'x ex) (hash-ref e 'y ey))))))))
(define (l34-min-eng-dist2d ctx ux uy ex ey)
  (define engagement-enemies (l34-ctx-engagement-enemies ctx))
  (let loop ([rem engagement-enemies] [best +inf.0])
    (if (null? rem)
        best
        (let ([e (car rem)])
          (loop (cdr rem) (min best (dist2d ux uy (hash-ref e 'x ex) (hash-ref e 'y ey))))))))
(define (l34-wm-best-cluster-enemy ctx ux uy ex ey target-enemy)
  (define engagement-enemies (l34-ctx-engagement-enemies ctx))
  (let loop ([rem engagement-enemies] [best-e target-enemy] [best-cnt -1])
    (if (null? rem)
        best-e
        (let* ([e (car rem)]
               [et2 (unit-type-sym e)]
               [ex2 (hash-ref e 'x ex)]
               [ey2 (hash-ref e 'y ey)]
               [d2 (fast-dist2d ux uy ex2 ey2)])
          (if (and (<= d2 5.0)
                   (not (memq et2 SC2-PASSIVE-SCOUT-OR-DECOY-UNIT-SYMS)))
              (let cloop ([orem engagement-enemies] [cnt 0])
                (if (null? orem)
                    (if (> cnt best-cnt)
                        (loop (cdr rem) e cnt)
                        (loop (cdr rem) best-e best-cnt))
                    (let ([o (car orem)])
                      (cloop (cdr orem)
                             (if (<= (fast-dist2d ex2 ey2 (hash-ref o 'x ex2) (hash-ref o 'y ey2)) 1.75)
                                 (add1 cnt)
                                 cnt)))))
              (loop (cdr rem) best-e best-cnt))))))
(define (l34-viking-aa-screen-unit? e ux uy ex ey)
  (and (memq (unit-type-sym e) VIKING-SCREEN-AA-SYMS)
       (let ([sx (hash-ref e 'x 9999.0)]
             [sy (hash-ref e 'y 9999.0)])
         (or (<= (dist2d ux uy sx sy) 7.5)
             (<= (dist2d ex ey sx sy) 7.5)))))
(define (l34-viking-screen-aa-count ctx ux uy ex ey)
  (define engagement-enemies (l34-ctx-engagement-enemies ctx))
  (define live-obs? (l34-ctx-live-obs? ctx))
  (define enemy-bldgs (l34-ctx-enemy-bldgs ctx))
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define eng-cnt
    (let loop ([rem engagement-enemies] [cnt 0])
      (if (null? rem)
          cnt
          (loop (cdr rem) (if (l34-viking-aa-screen-unit? (car rem) ux uy ex ey) (add1 cnt) cnt)))))
  (if live-obs?
      eng-cnt
      (+ eng-cnt
         (let bloop ([rem enemy-bldgs] [cnt 0])
           (if (null? rem)
               cnt
               (let ([eb (car rem)])
                 (if (and (l34-viking-aa-screen-unit? eb ux uy ex ey)
                          (let ([bid (hash-ref eb 'id #f)])
                            (or (not bid)
                                (let uloop ([eu enemy-units])
                                  (or (null? eu)
                                      (and (not (equal? (hash-ref (car eu) 'id #f) bid))
                                           (uloop (cdr eu))))))))
                     (bloop (cdr rem) (add1 cnt))
                     (bloop (cdr rem) cnt))))))))
(define (l34-viper-find-consume-bldg ctx ux uy)
  (define ally-bldgs (l34-ctx-ally-bldgs ctx))
  (define base-x (l34-ctx-base-x ctx))
  (define base-y (l34-ctx-base-y ctx))
  (let loop ([rem ally-bldgs])
    (and (pair? rem)
         (let ([b (car rem)])
           (if (and (>= (hash-ref b 'hp 0) 350)
                    (<= (dist2d ux uy (hash-ref b 'x base-x) (hash-ref b 'y base-y)) 14.0))
               b
               (loop (cdr rem)))))))
(define (l34-viper-find-air-clump ctx ux uy)
  (define enemy-units (l34-ctx-enemy-units ctx))
  (let loop ([rem enemy-units])
    (and (pair? rem)
         (let ([e (car rem)])
           (if (and (fast-unit-is-flying-sym? (unit-type-sym e))
                    (<= (fast-dist2d ux uy (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 9.0)
                    (>= (let ([ex2 (hash-ref e 'x 0.0)] [ey2 (hash-ref e 'y 0.0)])
                          (let oloop ([orem enemy-units] [cnt 0])
                            (if (or (null? orem) (>= cnt 3))
                                cnt
                                (let ([o (car orem)])
                                  (oloop (cdr orem)
                                         (if (and (fast-unit-is-flying-sym? (unit-type-sym o))
                                                  (<= (fast-dist2d ex2 ey2
                                                                   (hash-ref o 'x 9999.0) (hash-ref o 'y 9999.0))
                                                      3.5))
                                             (add1 cnt)
                                             cnt))))))
                        3))
               e
               (loop (cdr rem)))))))
(define (l34-viper-find-cloud-tgt ctx ux uy)
  (define enemy-units (l34-ctx-enemy-units ctx))
  (let loop ([rem enemy-units])
    (and (pair? rem)
         (let* ([e (car rem)]
                [et2 (unit-type-sym e)])
           (if (and (not (fast-unit-is-flying-sym? et2))
                    (<= (fast-dist2d ux uy (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 11.0)
                    (or (eq? et2 'siege-tank-sieged)
                        (>= (let ([ex2 (hash-ref e 'x 0.0)] [ey2 (hash-ref e 'y 0.0)])
                              (let oloop ([orem enemy-units] [cnt 0])
                                (if (or (null? orem) (>= cnt 4))
                                    cnt
                                    (let ([o (car orem)])
                                      (oloop (cdr orem)
                                             (if (<= (fast-dist2d ex2 ey2
                                                                  (hash-ref o 'x 9999.0) (hash-ref o 'y 9999.0))
                                                     2.5)
                                                 (add1 cnt)
                                                 cnt))))))
                            4)))
               e
               (loop (cdr rem)))))))
(define (l34-viper-find-abduct-tgt ctx ux uy)
  (define enemy-units (l34-ctx-enemy-units ctx))
  (let loop ([rem enemy-units])
    (and (pair? rem)
         (let ([e (car rem)])
           (if (and (memq (unit-type-sym e)
                          '(siege-tank siege-tank-sieged colossus thor thor-ap
                            carrier tempest immortal battlecruiser brood-lord lurker-burrowed))
                    (<= (dist2d ux uy (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 9.5))
               e
               (loop (cdr rem)))))))
(define (l34-infestor-find-fungal-tgt ctx ux uy)
  (define enemy-units (l34-ctx-enemy-units ctx))
  (let loop ([rem enemy-units])
    (and (pair? rem)
         (let ([e (car rem)])
           (if (and (<= (dist2d ux uy (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 10.0)
                    (>= (let ([ex2 (hash-ref e 'x 0.0)] [ey2 (hash-ref e 'y 0.0)])
                          (let oloop ([orem enemy-units] [cnt 0])
                            (if (or (null? orem) (>= cnt 3))
                                cnt
                                (let ([o (car orem)])
                                  (oloop (cdr orem)
                                         (if (<= (dist2d ex2 ey2
                                                         (hash-ref o 'x 9999.0) (hash-ref o 'y 9999.0))
                                                 2.5)
                                             (add1 cnt)
                                             cnt))))))
                        3))
               e
               (loop (cdr rem)))))))
(define (l34-ht-find-storm-tgt ctx ux uy)
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define effects (l34-ctx-effects ctx))
  (let loop ([rem enemy-units])
    (and (pair? rem)
         (let* ([e (car rem)]
                [ex2 (hash-ref e 'x 9999.0)]
                [ey2 (hash-ref e 'y 9999.0)])
           (if (and (<= (dist2d ux uy ex2 ey2) 9.0)
                    (not (let eloop ([efrem effects])
                           (and (pair? efrem)
                                (let ([eff (car efrem)])
                                  (or (and (memq (hash-ref eff 'type 'none) '(psi-storm psionic-storm))
                                           (<= (dist2d ex2 ey2
                                                       (hash-ref eff 'x 9999.0)
                                                       (hash-ref eff 'y 9999.0))
                                               2.0))
                                      (eloop (cdr efrem)))))))
                    (or (eq? (unit-type-sym e) 'siege-tank-sieged)
                        (>= (let oloop ([orem enemy-units] [cnt 0])
                              (if (or (null? orem) (>= cnt 3))
                                  cnt
                                  (let ([o (car orem)])
                                    (oloop (cdr orem)
                                           (if (<= (dist2d ex2 ey2
                                                           (hash-ref o 'x 9999.0) (hash-ref o 'y 9999.0))
                                                   2.0)
                                               (add1 cnt)
                                               cnt)))))
                            3)))
               e
               (loop (cdr rem)))))))
(define (l34-ht-find-feedback-tgt ctx ux uy)
  (define enemy-units (l34-ctx-enemy-units ctx))
  (let loop ([rem enemy-units])
    (and (pair? rem)
         (let ([e (car rem)])
           (if (and (>= (hash-ref e 'energy 0) 75)
                    (<= (dist2d ux uy (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 10.0))
               e
               (loop (cdr rem)))))))
(define (l34-bc-find-yamato-tgt ctx ux uy)
  (define engagement-enemies (l34-ctx-engagement-enemies ctx))
  (let loop ([rem engagement-enemies])
    (and (pair? rem)
         (let ([e (car rem)])
           (if (and (>= (+ (hash-ref e 'hp 0) (hash-ref e 'shield 0)) 125)
                    (<= (dist2d ux uy (hash-ref e 'x 9999.0) (hash-ref e 'y 9999.0)) 10.0))
               e
               (loop (cdr rem)))))))

(define (l34-phase1-setup! ctx rt raw-obs fap-score sanitized?)
  (set-l34-ctx-actions! ctx '())
  (set-l34-ctx-bo-tplan-box! ctx #f)
  (define obs (if sanitized? raw-obs (sanitize-obs-hash raw-obs)))
  (define frame (hash-ref obs 'frame 0))
  (define oledger (live-bot-runtime-order-ledger rt))
  (define tbrain (live-bot-runtime-tactical-brain rt))
  (define ally-units (hash-ref obs 'ally-units '()))
  (define ally-bldgs (hash-ref obs 'ally-buildings '()))
  (define enemy-units (hash-ref obs 'enemy-units '()))
  (define enemy-bldgs (hash-ref obs 'enemy-buildings '()))
  (define effects (hash-ref obs 'effects '()))
  (define live-upgrades-tracked? (hash-has-key? raw-obs 'researched-upgrades))
  (define researched-upgs (hash-ref obs 'researched-upgrades '()))
  (define base-x (hash-ref obs 'base-x SC2-DEFAULT-HOME-BASE-X))
  (define base-y (hash-ref obs 'base-y SC2-DEFAULT-HOME-BASE-Y))
  (define nat-x (hash-ref obs 'natural-x SC2-DEFAULT-NATURAL-X))
  (define nat-y (hash-ref obs 'natural-y SC2-DEFAULT-NATURAL-Y))
  (define third-x (hash-ref obs 'third-x SC2-DEFAULT-THIRD-X))
  (define third-y (hash-ref obs 'third-y SC2-DEFAULT-THIRD-Y))
  (define enemy-x (hash-ref obs 'enemy-x SC2-DEFAULT-ENEMY-BASE-X))
  (define enemy-y (hash-ref obs 'enemy-y SC2-DEFAULT-ENEMY-BASE-Y))
  (define enemy-exp-x (hash-ref obs 'enemy-expand-x SC2-DEFAULT-ENEMY-EXPAND-X))
  (define enemy-exp-y (hash-ref obs 'enemy-expand-y SC2-DEFAULT-ENEMY-EXPAND-Y))
  (define enemy-third-x
    (let ([v (hash-ref raw-obs 'enemy-third-x #f)])
      (if (finite-real? v)
          (safe-coord v 132.0)
          (safe-coord (* 0.72 enemy-x) 132.0))))
  (define enemy-third-y
    (let ([v (hash-ref raw-obs 'enemy-third-y #f)])
      (if (finite-real? v)
          (safe-coord v 132.0)
          (safe-coord (* 0.72 enemy-y) 132.0))))
  (define pending-upgs (hash-ref obs 'pending-upgrades '()))

  (define leases (rt-role-leases rt))
  (define bstates (rt-bistable-states rt))
  (define splash-st (rt-splash-state rt))
  (define spotter-ht (rt-spotter-lings rt))
  (define live-tactics-obs? (hash-has-key? raw-obs 'mineral-harvesters))
  (define wave3-frame-box (rt-wave3-frame-box rt))
  (define splash-wm-disarmed-ht (hash-ref! splash-st 'wm-disarmed-ht make-hasheqv))
  (define splash-mode-dwell-ht (hash-ref! splash-st 'mode-dwell-ht make-hasheqv))
  (define splash-wm-dwell-ht (hash-ref! splash-st 'wm-dwell-ht make-hasheqv))
  (define splash-lib-dwell-ht (hash-ref! splash-st 'lib-dwell-ht make-hasheqv))
  (define splash-vik-dwell-ht (hash-ref! splash-st 'vik-dwell-ht make-hasheqv))
  (define splash-thor-dwell-ht (hash-ref! splash-st 'thor-dwell-ht make-hasheqv))
  (define splash-bc-jump-ht (hash-ref! splash-st 'bc-jump-ready-ht make-hasheqv))
  (define splash-bc-yamato-ht (hash-ref! splash-st 'bc-yamato-ready-ht make-hasheqv))
  (define splash-tank-dwell-ht (hash-ref! splash-st 'tank-dwell-ht make-hasheqv))
  (define prev-wave3-frame (unbox wave3-frame-box))
  (when (and (>= prev-wave3-frame 0) (< frame prev-wave3-frame))
    (reset-wave3-tactical-state! rt))
  (set-box! wave3-frame-box frame)
  (define spell-claims-rt (rt-spell-claims rt))
  (define unit-mode-tr (rt-unit-mode-tracker rt))
  (define transport-tr (rt-transport-tracker rt))
  (define l34-sc (rt-l34-scratch rt))
  (define wave3-handled-tags (pooled-mutable-seteqv! l34-sc 'wave3-handled-tags))
  (define snipe-locked-tags (pooled-mutable-seteqv! l34-sc 'snipe-locked-tags))
  (define wave3-preserved-set (pooled-mutable-set! l34-sc 'wave3-preserved-set))

  ;; ---------------------------------------------------------------------------
  ;; Zerg Zergling Spotter Scouts (Up to 3 Map Watch Posts, 0-APM Hold Until Needed)
  ;; ---------------------------------------------------------------------------
  (define under-tactics-base-attack?
    (let ([bx (if (flonum? base-x) base-x (exact->inexact base-x))]
          [by (if (flonum? base-y) base-y (exact->inexact base-y))]
          [nx (if (flonum? nat-x) nat-x (exact->inexact nat-x))]
          [ny (if (flonum? nat-y) nat-y (exact->inexact nat-y))])
      (for/or ([e (in-list enemy-units)])
        (define rx (hash-ref e 'x 9999.0))
        (define ry (hash-ref e 'y 9999.0))
        (define ex (if (flonum? rx) rx (exact->inexact rx)))
        (define ey (if (flonum? ry) ry (exact->inexact ry)))
        (define dx1 (fl- bx ex))
        (define dy1 (fl- by ey))
        (define dx2 (fl- nx ex))
        (define dy2 (fl- ny ey))
        (or (fl<= (fl+ (fl* dx1 dx1) (fl* dy1 dy1)) 676.0)
            (fl<= (fl+ (fl* dx2 dx2) (fl* dy2 dy2)) 676.0)))))
  (define door-st-tactics (rt-door-state rt))
  (set-l34-ctx-rt! ctx rt)
  (set-l34-ctx-raw-obs! ctx raw-obs)
  (set-l34-ctx-fap-score! ctx fap-score)
  (set-l34-ctx-obs! ctx obs)
  (set-l34-ctx-frame! ctx frame)
  (set-l34-ctx-oledger! ctx oledger)
  (set-l34-ctx-ally-units! ctx ally-units)
  (set-l34-ctx-ally-bldgs! ctx ally-bldgs)
  (set-l34-ctx-enemy-units! ctx enemy-units)
  (set-l34-ctx-enemy-bldgs! ctx enemy-bldgs)
  (set-l34-ctx-effects! ctx effects)
  (set-l34-ctx-live-upgrades-tracked?! ctx live-upgrades-tracked?)
  (set-l34-ctx-researched-upgs! ctx researched-upgs)
  (set-l34-ctx-base-x! ctx base-x)
  (set-l34-ctx-base-y! ctx base-y)
  (set-l34-ctx-nat-x! ctx nat-x)
  (set-l34-ctx-nat-y! ctx nat-y)
  (set-l34-ctx-third-x! ctx third-x)
  (set-l34-ctx-third-y! ctx third-y)
  (set-l34-ctx-enemy-x! ctx enemy-x)
  (set-l34-ctx-enemy-y! ctx enemy-y)
  (set-l34-ctx-enemy-exp-x! ctx enemy-exp-x)
  (set-l34-ctx-enemy-exp-y! ctx enemy-exp-y)
  (set-l34-ctx-enemy-third-x! ctx enemy-third-x)
  (set-l34-ctx-enemy-third-y! ctx enemy-third-y)
  (set-l34-ctx-pending-upgs! ctx pending-upgs)
  (set-l34-ctx-leases! ctx leases)
  (set-l34-ctx-bstates! ctx bstates)
  (set-l34-ctx-splash-st! ctx splash-st)
  (set-l34-ctx-live-tactics-obs?! ctx live-tactics-obs?)
  (set-l34-ctx-splash-wm-disarmed-ht! ctx splash-wm-disarmed-ht)
  (set-l34-ctx-splash-mode-dwell-ht! ctx splash-mode-dwell-ht)
  (set-l34-ctx-splash-wm-dwell-ht! ctx splash-wm-dwell-ht)
  (set-l34-ctx-splash-lib-dwell-ht! ctx splash-lib-dwell-ht)
  (set-l34-ctx-splash-vik-dwell-ht! ctx splash-vik-dwell-ht)
  (set-l34-ctx-splash-thor-dwell-ht! ctx splash-thor-dwell-ht)
  (set-l34-ctx-splash-bc-jump-ht! ctx splash-bc-jump-ht)
  (set-l34-ctx-splash-bc-yamato-ht! ctx splash-bc-yamato-ht)
  (set-l34-ctx-splash-tank-dwell-ht! ctx splash-tank-dwell-ht)
  (set-l34-ctx-spell-claims-rt! ctx spell-claims-rt)
  (set-l34-ctx-unit-mode-tr! ctx unit-mode-tr)
  (set-l34-ctx-transport-tr! ctx transport-tr)
  (set-l34-ctx-l34-sc! ctx l34-sc)
  (set-l34-ctx-wave3-handled-tags! ctx wave3-handled-tags)
  (set-l34-ctx-snipe-locked-tags! ctx snipe-locked-tags)
  (set-l34-ctx-wave3-preserved-set! ctx wave3-preserved-set)
  (set-l34-ctx-under-tactics-base-attack?! ctx under-tactics-base-attack?)
  (set-l34-ctx-door-st-tactics! ctx door-st-tactics)
  (when (and live-tactics-obs?
             (eq? (live-bot-runtime-actual-race rt) 'Zerg)
             (not under-tactics-base-attack?))
    (define map-dx (- enemy-x base-x))
    (define map-dy (- enemy-y base-y))
    (define map-d (max 1.0 (sqrt (+ (* map-dx map-dx) (* map-dy map-dy)))))
    (define map-px (/ (- map-dy) map-d))
    (define map-py (/ map-dx map-d))
    (define spotter-posts
      (list (list 'enemy-front
                  (safe-coord (+ enemy-exp-x (* 0.28 (- nat-x enemy-exp-x))) enemy-exp-x)
                  (safe-coord (+ enemy-exp-y (* 0.28 (- nat-y enemy-exp-y))) enemy-exp-y))
            (list 'enemy-third
                  (safe-coord (+ enemy-exp-x (* 14.0 map-px)) enemy-exp-x)
                  (safe-coord (+ enemy-exp-y (* 14.0 map-py)) enemy-exp-y))
            (list 'enemy-fourth
                  (safe-coord (+ (* 0.5 (+ nat-x enemy-exp-x)) (* -14.0 map-px)) nat-x)
                  (safe-coord (+ (* 0.5 (+ nat-y enemy-exp-y)) (* -14.0 map-py)) nat-y))))
    (define all-live-lings
      (for/list ([u (in-list ally-units)]
                 #:when (and (eq? (unit-type-sym u) 'zergling)
                             (not (or (eq? (hash-ref u 'is-hallucination #f) #t)
                                      (eq? (hash-ref u 'hallucination #f) #t)))))
        u))
    (for ([post (in-list spotter-posts)])
      (define pkey (first post))
      (define px (second post))
      (define py (third post))
      (define prev-entry (hash-ref spotter-ht pkey #f))
      (define prev-tag (and (hash? prev-entry) (hash-ref prev-entry 'tag #f)))
      (define cd-until (if (hash? prev-entry) (hash-ref prev-entry 'cooldown-until 0) 0))
      (define repost-after (if (hash? prev-entry) (hash-ref prev-entry 'repost-after 0) 0))
      (define live-spotter
        (and prev-tag
             (for/first ([u (in-list all-live-lings)]
                         #:when (equal? (hash-ref u 'id -1) prev-tag))
               u)))
      (cond
        [(and prev-tag (not live-spotter))
         (hash-set! spotter-ht pkey
                    (hash 'tag #f
                          'cooldown-until (max cd-until (+ frame 672))
                          'repost-after (+ frame 672)))]
        [(and (not live-spotter)
              (>= frame cd-until)
              (>= (length all-live-lings) 6))
         (define fpx (exact->inexact px))
         (define fpy (exact->inexact py))
         (define chosen #f)
         (define best-d2 +inf.0)
         (for ([u (in-list all-live-lings)])
           (unless (unit-leased-above? leases (hash-ref u 'id 0) 'army frame)
             (define dx (fl- fpx (exact->inexact (hash-ref u 'x px))))
             (define dy (fl- fpy (exact->inexact (hash-ref u 'y py))))
             (define d2 (fl+ (fl* dx dx) (fl* dy dy)))
             (when (fl< d2 best-d2)
               (set! chosen u)
               (set! best-d2 d2))))
         (when chosen
           (define sid (hash-ref chosen 'id 0))
           (acquire-unit-lease! leases sid 'spotter frame 32 #:x px #:y py)
           (hash-set! spotter-ht pkey
                      (hash 'tag sid 'cooldown-until 0 'repost-after 0))
           (when (fl> best-d2 6.25)
             (l34-emit! ctx (list 'move sid px py))))]
        [live-spotter
         (define sid (hash-ref live-spotter 'id 0))
         (define sx (hash-ref live-spotter 'x px))
         (define sy (hash-ref live-spotter 'y py))
         (acquire-unit-lease! leases sid 'spotter frame 32 #:x px #:y py)
         (define fsx (if (flonum? sx) sx (exact->inexact sx)))
         (define fsy (if (flonum? sy) sy (exact->inexact sy)))
         (define threat-near
           (for/first ([e (in-list enemy-units)]
                       #:when (let* ([rx (hash-ref e 'x 9999.0)]
                                     [ry (hash-ref e 'y 9999.0)]
                                     [dx (fl- fsx (if (flonum? rx) rx (exact->inexact rx)))]
                                     [dy (fl- fsy (if (flonum? ry) ry (exact->inexact ry)))])
                                (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 81.0)))
             e))
         (cond
           [threat-near
            (define-values (rx ry)
              (compute-kite-vector sx sy
                                   (hash-ref threat-near 'x sx)
                                   (hash-ref threat-near 'y sy)
                                   6.0))
            (hash-set! spotter-ht pkey
                       (hash 'tag sid 'cooldown-until cd-until 'repost-after (+ frame 180)))
            (when (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                             (list 'spotter-evade sid)
                                             frame
                                             16)
              (l34-emit! ctx (list 'move sid (safe-coord rx nat-x) (safe-coord ry nat-y))))]
           [(< frame repost-after)
            (void)]
           [(<= (dist2d sx sy px py) 2.0)
            (void)]
           [(and (> (dist2d sx sy px py) 2.5)
                 (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                            (list 'spotter-move sid)
                                            frame
                                            28))
            (l34-emit! ctx (list 'move sid px py))])])))

  (define-values (combat-units ground-combat-units live-overseers stasis-frozen-tags
                  cu-cnt cu-sum-x cu-sum-y gcu-cnt gcu-sum-x gcu-sum-y)
    (let loop ([rem ally-units]
               [cu-rev '()] [gcu-rev '()] [ov-rev '()] [sf-ids '()]
               [cc 0] [cx 0.0] [cy 0.0]
               [gc 0] [gx 0.0] [gy 0.0])
      (if (null? rem)
          (values (reverse cu-rev) (reverse gcu-rev) (reverse ov-rev) sf-ids cc cx cy gc gx gy)
          (let* ([u (car rem)]
                 [ut (unit-type-sym u)]
                 [n-ov-rev
                  (if (and (or (eq? ut 'overseer) (eq? ut 'overseer-siege-mode))
                           (not (eq? (hash-ref u 'is-hallucination #f) #t))
                           (not (eq? (hash-ref u 'hallucination #f) #t)))
                      (cons u ov-rev)
                      ov-rev)]
                 [stasis-frozen?
                  (let ([b (hash-ref u 'buffs #f)])
                    (and (list? b)
                         (or (memq 'oracle-stasis-trap-target b)
                             (memq 'stasis-ward-target b))))]
                 [n-sf-ids
                  (if stasis-frozen?
                      (let ([sid (hash-ref u 'id (hash-ref u 'tag -1))])
                        (if (and (exact-integer? sid) (> sid 0))
                            (cons sid sf-ids)
                            sf-ids))
                      sf-ids)]
                 [combat?
                  (and (not stasis-frozen?)
                       (combat-unit-record? u)
                       (not (unit-leased-above? leases (hash-ref u 'id 0) 'army frame)))])
            (if (not combat?)
                (loop (cdr rem) cu-rev gcu-rev n-ov-rev n-sf-ids cc cx cy gc gx gy)
                (let* ([ux-raw (safe-finite-real (hash-ref u 'x nat-x) nat-x)]
                       [uy-raw (safe-finite-real (hash-ref u 'y nat-y) nat-y)]
                       [ux (if (flonum? ux-raw) ux-raw (exact->inexact ux-raw))]
                       [uy (if (flonum? uy-raw) uy-raw (exact->inexact uy-raw))]
                       [ncx (fl+ cx ux)]
                       [ncy (fl+ cy uy)])
                  (if (fast-unit-is-flying-sym? ut)
                      (loop (cdr rem) (cons u cu-rev) gcu-rev n-ov-rev n-sf-ids
                            (add1 cc) ncx ncy gc gx gy)
                      (loop (cdr rem) (cons u cu-rev) (cons u gcu-rev) n-ov-rev n-sf-ids
                            (add1 cc) ncx ncy (add1 gc) (fl+ gx ux) (fl+ gy uy)))))))))
  (define ft (perception-grid-squad-finger-tree (live-bot-runtime-perception rt)))
  (define total-dps (combat-measure-dps (ft-measure ft)))
  (define-values (vanguard-ft reserve-ft)
    (split-by-dps ft (exact-ceiling (* 0.70 total-dps))))
  (define vanguard-count (combat-measure-count (ft-measure vanguard-ft)))
  (define reserve-count (combat-measure-count (ft-measure reserve-ft)))

  ;; Compute primary army centroid early for Overseer escort & siege-line positioning
  (define prelim-army-cx
    (if (= cu-cnt 0)
        nat-x
        (safe-coord (fl/ cu-sum-x (exact->inexact cu-cnt)) nat-x)))
  (define prelim-army-cy
    (if (= cu-cnt 0)
        nat-y
        (safe-coord (fl/ cu-sum-y (exact->inexact cu-cnt)) nat-y)))
  (define ground-army-cx
    (if (= gcu-cnt 0)
        nat-x
        (safe-coord (fl/ gcu-sum-x (exact->inexact gcu-cnt)) nat-x)))
  (define ground-army-cy
    (if (= gcu-cnt 0)
        nat-y
        (safe-coord (fl/ gcu-sum-y (exact->inexact gcu-cnt)) nat-y)))
  (define first-stealth-threat-near-army
    (and (pair? live-overseers)
         (or (for/or ([e (in-list enemy-units)]) (l34-stealth-unit-or-bldg? e))
             (for/or ([e (in-list enemy-bldgs)]) (l34-stealth-unit-or-bldg? e)))
         (let ()
           (define cu-xs
             (for/list ([cu (in-list combat-units)]) (exact->inexact (hash-ref cu 'x base-x))))
           (define cu-ys
             (for/list ([cu (in-list combat-units)]) (exact->inexact (hash-ref cu 'y base-y))))
           (define (near-3-combat? e)
             (and (l34-stealth-unit-or-bldg? e)
                  (let ([ex0 (exact->inexact (hash-ref e 'x 9999.0))]
                        [ey0 (exact->inexact (hash-ref e 'y 9999.0))])
                    (let loop ([xs cu-xs] [ys cu-ys] [hits 0])
                      (cond
                        [(>= hits 3) #t]
                        [(null? xs) #f]
                        [else
                         (define dx (fl- ex0 (car xs)))
                         (define dy (fl- ey0 (car ys)))
                         (loop (cdr xs) (cdr ys)
                               (if (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 196.0)
                                   (add1 hits)
                                   hits))])))))
           (or (for/first ([e (in-list enemy-units)] #:when (near-3-combat? e)) e)
               (for/first ([e (in-list enemy-bldgs)] #:when (near-3-combat? e)) e)))))
  (define reveal-assigned-ov-id
    (and first-stealth-threat-near-army
         (let ([ftx (exact->inexact (hash-ref first-stealth-threat-near-army 'x prelim-army-cx))]
               [fty (exact->inexact (hash-ref first-stealth-threat-near-army 'y prelim-army-cy))]
               [best-ov #f]
               [best-d2 +inf.0])
           (for ([ov (in-list live-overseers)])
             (define dx (fl- ftx (exact->inexact (hash-ref ov 'x base-x))))
             (define dy (fl- fty (exact->inexact (hash-ref ov 'y base-y))))
             (define d2 (fl+ (fl* dx dx) (fl* dy dy)))
             (when (fl< d2 best-d2)
               (set! best-ov ov)
               (set! best-d2 d2)))
           (and best-ov (hash-ref best-ov 'id #f)))))
  (define stealth-threats-near-army
    (if first-stealth-threat-near-army (list first-stealth-threat-near-army) '()))
  (for ([ov (in-list live-overseers)])
    (define ov-id (hash-ref ov 'id 0))
    (define ovx (hash-ref ov 'x base-x))
    (define ovy (hash-ref ov 'y base-y))
    (acquire-unit-lease! leases ov-id 'detector-escort frame 24
                         #:x prelim-army-cx #:y prelim-army-cy)
    (define fovx (if (flonum? ovx) ovx (exact->inexact ovx)))
    (define fovy (if (flonum? ovy) ovy (exact->inexact ovy)))
    (define allies-near-ov
      (let loop ([rem combat-units] [cnt 0])
        (cond
          [(or (>= cnt 3) (null? rem)) cnt]
          [else
           (define cu (car rem))
           (define cux (hash-ref cu 'x base-x))
           (define cuy (hash-ref cu 'y base-y))
           (define dx (fl- fovx (if (flonum? cux) cux (exact->inexact cux))))
           (define dy (fl- fovy (if (flonum? cuy) cuy (exact->inexact cuy))))
           (loop (cdr rem) (if (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 144.0) (add1 cnt) cnt))])))
    (define (aa-near-ov? e)
      (define et (unit-type-sym e))
      (and (fast-can-attack-air? et)
           (let* ([rx (hash-ref e 'x 9999.0)]
                  [ry (hash-ref e 'y 9999.0)]
                  [dx (fl- fovx (if (flonum? rx) rx (exact->inexact rx)))]
                  [dy (fl- fovy (if (flonum? ry) ry (exact->inexact ry)))])
             (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 132.25))))
    (define aa-threat-near-ov
      (and (< allies-near-ov 3)
           (or (for/first ([e (in-list enemy-units)] #:when (aa-near-ov? e)) e)
               (for/first ([e (in-list enemy-bldgs)] #:when (aa-near-ov? e)) e))))
    (cond
      [(and reveal-assigned-ov-id (equal? ov-id reveal-assigned-ov-id))
       (define thr (car stealth-threats-near-army))
       (define tx0 (hash-ref thr 'x prelim-army-cx))
       (define ty0 (hash-ref thr 'y prelim-army-cy))
       (define d-back (max 1.0 (dist2d tx0 ty0 prelim-army-cx prelim-army-cy)))
       (define stand-x (safe-coord (+ tx0 (* 8.5 (/ (- prelim-army-cx tx0) d-back))) prelim-army-cx))
       (define stand-y (safe-coord (+ ty0 (* 8.5 (/ (- prelim-army-cy ty0) d-back))) prelim-army-cy))
       (when (and (> (dist2d ovx ovy stand-x stand-y) 2.0)
                  (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                             (list 'ov-reveal ov-id)
                                             frame
                                             16))
         (l34-emit! ctx (list 'move ov-id stand-x stand-y)))]
      [(and (< allies-near-ov 3) aa-threat-near-ov)
       (define d-home (max 1.0 (dist2d ovx ovy base-x base-y)))
       (define rx (safe-coord (+ ovx (* 6.0 (/ (- base-x ovx) d-home))) base-x))
       (define ry (safe-coord (+ ovy (* 6.0 (/ (- base-y ovy) d-home))) base-y))
       (when (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                        (list 'ov-retreat ov-id)
                                        frame
                                        16)
         (l34-emit! ctx (list 'move ov-id rx ry)))]
      [(not (null? combat-units))
       (define d-home (max 1.0 (dist2d prelim-army-cx prelim-army-cy base-x base-y)))
       (define leash-x (safe-coord (+ prelim-army-cx (* 2.5 (/ (- base-x prelim-army-cx) d-home))) prelim-army-cx))
       (define leash-y (safe-coord (+ prelim-army-cy (* 2.5 (/ (- base-y prelim-army-cy) d-home))) prelim-army-cy))
       (when (and (> (dist2d ovx ovy leash-x leash-y) 2.2)
                  (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                             (list 'ov-escort ov-id)
                                             frame
                                             20))
         (l34-emit! ctx (list 'move ov-id leash-x leash-y)))]))

  (set-l34-ctx-combat-units! ctx combat-units)
  (set-l34-ctx-ft! ctx ft)
  (set-l34-ctx-ground-army-cx! ctx ground-army-cx)
  (set-l34-ctx-ground-army-cy! ctx ground-army-cy)
  (set-l34-ctx-prelim-army-cx! ctx prelim-army-cx)
  (set-l34-ctx-prelim-army-cy! ctx prelim-army-cy)
  (set-l34-ctx-reserve-count! ctx reserve-count)
  (set-l34-ctx-stasis-frozen-tags! ctx stasis-frozen-tags)
  (set-l34-ctx-tbrain! ctx tbrain)
  (set-l34-ctx-vanguard-count! ctx vanguard-count)
)

(define (l34-phase2-tbrain-drops! ctx)
  (define ally-bldgs (l34-ctx-ally-bldgs ctx))
  (define ally-units (l34-ctx-ally-units ctx))
  (define base-x (l34-ctx-base-x ctx))
  (define base-y (l34-ctx-base-y ctx))
  (define combat-units (l34-ctx-combat-units ctx))
  (define effects (l34-ctx-effects ctx))
  (define enemy-bldgs (l34-ctx-enemy-bldgs ctx))
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define enemy-x (l34-ctx-enemy-x ctx))
  (define enemy-y (l34-ctx-enemy-y ctx))
  (define frame (l34-ctx-frame ctx))
  (define l34-sc (l34-ctx-l34-sc ctx))
  (define live-tactics-obs? (l34-ctx-live-tactics-obs? ctx))
  (define nat-x (l34-ctx-nat-x ctx))
  (define nat-y (l34-ctx-nat-y ctx))
  (define obs (l34-ctx-obs ctx))
  (define oledger (l34-ctx-oledger ctx))
  (define prelim-army-cx (l34-ctx-prelim-army-cx ctx))
  (define prelim-army-cy (l34-ctx-prelim-army-cy ctx))
  (define rt (l34-ctx-rt ctx))
  (define tbrain (l34-ctx-tbrain ctx))
  (define transport-tr (l34-ctx-transport-tr ctx))
  (define wave3-handled-tags (l34-ctx-wave3-handled-tags ctx))
  ;; ---------------------------------------------------------------------------
  ;; Multi-Depth Mirrored Tactical Micro Brain (0.5s, 2.0s, 5.0s Horizons)
  ;; ---------------------------------------------------------------------------
  (define-values (tbrain-actions tbrain-committed-tags _tbrain-decisions)
    (if (and (not (null? combat-units)) (not (null? enemy-units)))
        (step-tactical-mirror-brain! tbrain oledger obs #:record-ledger? #f)
        (values '() (set) '())))
  (define tbrain-unit-actions (pooled-hasheqv! l34-sc 'tbrain-unit-actions))
  (for ([ta (in-list tbrain-actions)])
    (when (and (pair? ta) (>= (length ta) 2) (exact-integer? (second ta)))
      (define uid (second ta))
      (hash-set! tbrain-unit-actions uid
                 (append (hash-ref tbrain-unit-actions uid '()) (list ta)))))

  ;; ---------------------------------------------------------------------------
  ;; Scenario 9: Nuclear Strike / Nuke Calldown Alert Evasion (10.0 tiles)
  ;; ---------------------------------------------------------------------------
  (define nuke-alert (hash-ref obs 'nuke-alert #f))
  (when nuke-alert
    (define nx (if (pair? nuke-alert) (car nuke-alert) nat-x))
    (define ny (if (pair? nuke-alert) (cdr nuke-alert) nat-y))
    (for ([u (in-list ally-units)])
      (when (<= (dist2d nx ny (hash-ref u 'x nx) (hash-ref u 'y ny)) SC2-NUKE-EVASION-RADIUS)
        (l34-emit! ctx (list 'kite (hash-ref u 'id 101) base-x base-y)))))

  ;; ---------------------------------------------------------------------------
  ;; Scenario 4: Hidden / Corner Flying Building Search when Enemy Base Cleared
  ;; ---------------------------------------------------------------------------
  (when (and (hash-ref obs 'enemy-main-cleared #f)
             (null? enemy-units)
             (null? enemy-bldgs)
             (not (null? combat-units)))
    (define corners '((16.0 . 16.0) (16.0 . 240.0) (240.0 . 16.0) (240.0 . 240.0)))
    (for ([u (in-list combat-units)]
          [idx (in-naturals)])
      (define c (list-ref corners (modulo idx (length corners))))
      (l34-emit! ctx (list 'attack-pos (hash-ref u 'id 101) (car c) (cdr c)))))

  ;; ---------------------------------------------------------------------------
  ;; Pro Mechanic #4: Active Transport Juggling (Load/Unload, 10.0 tiles) & Multi-Prong Drop
  ;; ---------------------------------------------------------------------------
  (define-values (transports has-overlord?)
    (for/fold ([tr-rev '()] [ov? #f] #:result (values (reverse tr-rev) ov?))
              ([u (in-list ally-units)])
      (define ut (unit-type-sym u))
      (values (if (or (eq? ut 'warp-prism)
                      (eq? ut 'warp-prism-phasing)
                      (eq? ut 'medivac)
                      (eq? ut 'overlord-transport))
                  (cons u tr-rev)
                  tr-rev)
              (or ov? (eq? ut 'overlord)))))
  (define dead-tags-rt
    (let ([dt (hash-ref obs 'dead-tags '())])
      (if (null? dt)
          '()
          (for/list ([x (in-list dt)] #:when (exact-integer? x)) x))))
  (cond
    [live-tactics-obs?
     (define lair-or-hive-ok?
       (and has-overlord?
            (for/or ([b (in-list ally-bldgs)])
              (and (hash? b)
                   (let ([bt (unit-type-sym b)])
                     (or (eq? bt 'lair) (eq? bt 'hive)))
                   (>= (hash-ref b 'build-progress 1.0) 1.0)))))
     (define tr-dirs
       (cond
         [(and (null? transports)
               (or (not lair-or-hive-ok?)
                   (and (hash-has-key? obs 'mineral-harvesters)
                        (not (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                                        'zerg-ov-morph-check
                                                        frame
                                                        128)))))
          '()]
         [else
          (define transport-combat-supply
            (for/sum ([u (in-list combat-units)])
              (unit-supply-cost (unit-type-sym u))))
          (define any-cargo?
            (ormap (lambda (tr)
                     (or (pair? (hash-ref tr 'passengers '()))
                         (> (hash-ref tr 'cargo-space-taken 0) 0)))
                   transports))
          (define tr-pts
            (for/list ([tr (in-list transports)])
              (cons (exact->inexact (hash-ref tr 'x base-x))
                    (exact->inexact (hash-ref tr 'y base-y)))))
          (define effect-pts
            (for/list ([ef (in-list effects)]
                       #:when (hash? ef))
              (cons (exact->inexact (hash-ref ef 'x base-x))
                    (exact->inexact (hash-ref ef 'y base-y)))))
          (define (near-pts? pts x y r2)
            (for/or ([pt (in-list pts)])
              (define dx (fl- x (car pt)))
              (define dy (fl- y (cdr pt)))
              (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2)))
          (define tr-ally-slice
            (if (null? transports)
                (for/list ([u (in-list ally-units)]
                           #:when (eq? (unit-type-sym u) 'overlord))
                  u)
                (let ([passenger-id-ht (make-hasheqv)]
                      [nearby-ground '()])
                  (for ([tr (in-list transports)])
                    (for ([p (in-list (hash-ref tr 'passengers '()))])
                      (define pid (if (hash? p) (hash-ref p 'tag (hash-ref p 'id #f)) p))
                      (when (exact-integer? pid) (hash-set! passenger-id-ht pid #t))))
                  (define tr-core
                    (for/fold ([acc '()] #:result (reverse acc))
                              ([u (in-list ally-units)])
                      (define ut (unit-type-sym u))
                      (define uid (hash-ref u 'id -1))
                      (cond
                        [(or (memq ut '(warp-prism warp-prism-phasing medivac overlord-transport))
                             (and lair-or-hive-ok? (eq? ut 'overlord))
                             (hash-ref passenger-id-ht uid #f))
                         (cons u acc)]
                        [(and (not (hash-ref RUNTIME-WORKER-SET ut #f))
                              (not (fast-unit-is-flying-sym? ut))
                              (not (hash-ref RUNTIME-STRUCT-SYM-SET ut #f)))
                         (define ux (exact->inexact (hash-ref u 'x base-x)))
                         (define uy (exact->inexact (hash-ref u 'y base-y)))
                         (define in-eff? (and (pair? effect-pts) (near-pts? effect-pts ux uy 36.0)))
                         (when (or in-eff? (near-pts? tr-pts ux uy (if any-cargo? 625.0 156.25)))
                           (define hp-pct (/ (exact->inexact (unit-total-hp-and-shield u))
                                             (max 1.0 (exact->inexact (hash-ref u 'max-hp 50)))))
                           (set! nearby-ground (cons (cons (if in-eff? (- hp-pct 2.0) hp-pct) u) nearby-ground)))
                         acc]
                        [else acc])))
                  (if (null? nearby-ground)
                      tr-core
                      (let ([capped-ground
                             (map cdr
                                  (take (sort nearby-ground < #:key car)
                                        (min (if any-cargo? 24 16) (length nearby-ground))))])
                        (append tr-core capped-ground))))))
          (define tr-enemy-slice
            (cond
              [(null? transports)
               (define ovi-pts
                 (for/list ([o (in-list tr-ally-slice)])
                   (cons (exact->inexact (hash-ref o 'x base-x))
                         (exact->inexact (hash-ref o 'y base-y)))))
               (if (null? ovi-pts)
                   '()
                   (for/list ([e (in-list enemy-units)]
                              #:when (near-pts? ovi-pts
                                                (exact->inexact (hash-ref e 'x 9999.0))
                                                (exact->inexact (hash-ref e 'y 9999.0))
                                                625.0))
                     e))]
              [any-cargo?
               (define ex-tgt (exact->inexact enemy-x))
               (define ey-tgt (exact->inexact enemy-y))
               (define scored
                 (for/fold ([acc '()])
                           ([e (in-list enemy-units)])
                   (define ex0 (exact->inexact (hash-ref e 'x 9999.0)))
                   (define ey0 (exact->inexact (hash-ref e 'y 9999.0)))
                   (define dt (for/fold ([m +inf.0]) ([pt (in-list tr-pts)])
                                (define dx (- ex0 (car pt)))
                                (define dy (- ey0 (cdr pt)))
                                (min m (+ (* dx dx) (* dy dy)))))
                   (define dx-e (- ex0 ex-tgt))
                   (define dy-e (- ey0 ey-tgt))
                   (define de (+ (* dx-e dx-e) (* dy-e dy-e)))
                   (define dmin (min dt de))
                   (if (<= dmin 625.0)
                       (cons (cons dmin e) acc)
                       acc)))
               (map cdr (take (sort scored < #:key car) (min 24 (length scored))))]
              [else
               (define near
                 (for/list ([e (in-list enemy-units)]
                            #:when (near-pts? tr-pts
                                              (exact->inexact (hash-ref e 'x 9999.0))
                                              (exact->inexact (hash-ref e 'y 9999.0))
                                              361.0))
                   e))
               (take near (min 24 (length near)))]))
          (sync-transport-tracker! transport-tr transports frame #:dead-tags dead-tags-rt)
          (plan-transport-fleet-micro tr-ally-slice tr-enemy-slice
                                      #:tracker transport-tr
                                      #:current-frame frame
                                      #:home-x (exact->inexact base-x)
                                      #:home-y (exact->inexact base-y)
                                      #:effects effects
                                      #:warp-in-complete? (and (hash-ref obs 'warp-in-complete? #f) #t)
                                      #:warp-in-requested? (if (hash-has-key? obs 'warp-in-requested?)
                                                               (and (hash-ref obs 'warp-in-requested? #f) #t)
                                                               #t)
                                      #:lair-or-hive-ready? lair-or-hive-ok?
                                      #:combat-supply transport-combat-supply)]))
     (define transport-acted-tags (pooled-mutable-seteqv! l34-sc 'transport-acted-tags))
     (for ([td (in-list tr-dirs)])
       (define ttag (transport-directive-transport-tag td))
       (define act-kind (transport-directive-action td))
       (define ab-sym (transport-directive-ability td))
       (define sx (safe-coord (transport-directive-tx td) base-x))
       (define sy (safe-coord (transport-directive-ty td) base-y))
       (define translated
         (cond
           [(eq? act-kind 'transport-drop-moving)
            (list 'transport-juggle ttag (list ttag) sx sy)]
           [(and (eq? act-kind 'cast-spell) (eq? ab-sym 'morph-overlord-transport))
            (list 'morph ttag 'overlord-transport)]
           [(eq? act-kind 'load-unit)
            (define ptags
              (filter (lambda (p) (and (exact-integer? p) (> p 0) (not (= p ttag))))
                      (transport-directive-passenger-tags td)))
            (and (pair? ptags)
                 (list 'transport-juggle ttag ptags sx sy))]
           [(eq? act-kind 'transport-drop-point)
            (list 'transport-juggle ttag sx sy)]
           [(memq act-kind '(approach-save-pickup hold-and-reposition move-to-drop))
            (list 'move ttag sx sy)]
           [(memq act-kind '(medivac-boost morph-warp-prism-phasing morph-warp-prism-transport cast-spell))
            (list 'cast-spell ttag (or ab-sym 'unknown) ttag)]
           [else
            (list 'move ttag sx sy)]))
       (when translated
         (set-add! transport-acted-tags ttag)
         (set-add! wave3-handled-tags ttag)
         (l34-emit-preserved! ctx translated)))
     (for ([tr (in-list transports)]
           #:when (not (set-member? transport-acted-tags (hash-ref tr 'id 706))))
       (define tr-id (hash-ref tr 'id 706))
       (define tx (hash-ref tr 'x base-x))
       (define ty (hash-ref tr 'y base-y))
       (define tr-ut (unit-type-sym tr))
       (define-values (tr-fork-on? tr-fork-x tr-fork-y)
         (if (or (pair? (hash-ref tr 'passengers '()))
                 (> (hash-ref tr 'cargo-space-taken 0) 0)
                 (memq tr-ut '(warp-prism warp-prism-phasing)))
             (l34-bo-fork-coords ctx)
             (values #f enemy-x enemy-y)))
       (cond
         [(and tr-fork-on?
               (> (dist2d tx ty tr-fork-x tr-fork-y) 6.0)
               (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                          (list 'transport-escort tr-id)
                                          frame
                                          28))
          (l34-emit! ctx (list 'multi-prong-drop tr-id tr-fork-x tr-fork-y))]
         [(not (null? combat-units))
          (define escort-x prelim-army-cx)
          (define escort-y prelim-army-cy)
          (when (and (> (dist2d tx ty escort-x escort-y) 6.0)
                     (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                                (list 'transport-escort tr-id)
                                                frame
                                                20))
            (l34-emit! ctx (list 'attack-pos tr-id escort-x escort-y)))]
         [(and (> (dist2d tx ty nat-x nat-y) 8.0)
               (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                          (list 'transport-escort tr-id)
                                          frame
                                          20))
          (l34-emit! ctx (list 'attack-pos tr-id nat-x nat-y))]))]
    [else
     (define-values (tr-fork-on? tr-fork-x tr-fork-y)
       (if (pair? transports) (l34-bo-fork-coords ctx) (values #f enemy-x enemy-y)))
     (for ([tr (in-list transports)])
       (define tr-id (hash-ref tr 'id 706))
       (define tx (hash-ref tr 'x base-x))
       (define ty (hash-ref tr 'y base-y))
       (define wounded-passenger
         (findf (lambda (u)
                  (and (combat-unit-record? u)
                       (<= (dist2d tx ty (hash-ref u 'x tx) (hash-ref u 'y ty)) SC2-TRANSPORT-JUGGLE-RADIUS)
                       (or (< (hash-ref u 'hp 100) SC2-WOUNDED-PASSENGER-MIN-HP)
                           (< (/ (exact->inexact (hash-ref u 'hp 100))
                                 (max 1 (hash-ref u 'max-hp 100)))
                              SC2-WOUNDED-PASSENGER-HP-PCT))))
                combat-units))
       (cond
         [wounded-passenger
          (l34-emit! ctx (list 'transport-juggle tr-id (hash-ref wounded-passenger 'id 707) base-x base-y))]
         [else
          (l34-emit! ctx (list 'multi-prong-drop tr-id
                       (if tr-fork-on? tr-fork-x enemy-x)
                       (if tr-fork-on? tr-fork-y enemy-y)))]))])

  (set-l34-ctx-dead-tags-rt! ctx dead-tags-rt)
  (set-l34-ctx-tbrain-committed-tags! ctx tbrain-committed-tags)
  (set-l34-ctx-tbrain-unit-actions! ctx tbrain-unit-actions)
)

(define (l34-phase3-classify! ctx)
  (define ally-bldgs (l34-ctx-ally-bldgs ctx))
  (define ally-units (l34-ctx-ally-units ctx))
  (define base-x (l34-ctx-base-x ctx))
  (define base-y (l34-ctx-base-y ctx))
  (define combat-units (l34-ctx-combat-units ctx))
  (define effects (l34-ctx-effects ctx))
  (define enemy-bldgs (l34-ctx-enemy-bldgs ctx))
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define enemy-x (l34-ctx-enemy-x ctx))
  (define enemy-y (l34-ctx-enemy-y ctx))
  (define l34-sc (l34-ctx-l34-sc ctx))
  (define live-tactics-obs? (l34-ctx-live-tactics-obs? ctx))
  (define nat-x (l34-ctx-nat-x ctx))
  (define nat-y (l34-ctx-nat-y ctx))
  (define obs (l34-ctx-obs ctx))
  (define prelim-army-cx (l34-ctx-prelim-army-cx ctx))
  (define prelim-army-cy (l34-ctx-prelim-army-cy ctx))
  ;; ---------------------------------------------------------------------------
  ;; Adversarial Countermeasure #5: Ramp Force-Field Corrosive-Bile Breaker
  ;; ---------------------------------------------------------------------------
  (define ravager-cast-tags (pooled-mutable-seteqv! l34-sc 'ravager-cast-tags))
  (define force-fields
    (let ([eff-ffs (if (null? effects)
                       '()
                       (for/list ([eff (in-list effects)]
                                  #:when (eq? (hash-ref eff 'type 'none) 'force-field))
                         eff))]
          [unit-ffs (for/list ([e (in-list enemy-units)]
                               #:when (eq? (unit-type-sym e) 'force-field))
                      e)])
      (cond
        [(null? eff-ffs) unit-ffs]
        [(null? unit-ffs) eff-ffs]
        [else (append eff-ffs unit-ffs)])))
  (when (not (null? force-fields))
    (define ff (car force-fields))
    (define ffx (hash-ref ff 'x nat-x))
    (define ffy (hash-ref ff 'y nat-y))
    (define ravagers (for/list ([u (in-list combat-units)] #:when (eq? (unit-type-sym u) 'ravager)) u))
    (for ([rav (in-list (take ravagers (min 2 (length ravagers))))])
      (define rid (hash-ref rav 'id 140))
      (set-add! ravager-cast-tags rid)
      (l34-emit! ctx (list 'cast-spell rid 'corrosive-bile ffx ffy)))
    (for ([u (in-list combat-units)])
      (define ux (hash-ref u 'x base-x))
      (define uy (hash-ref u 'y base-y))
      (when (and (not (eq? (unit-type-sym u) 'ravager))
                 (<= (dist2d ffx ffy ux uy) SC2-FORCE-FIELD-STEPBACK-RADIUS))
        (l34-emit! ctx (list 'kite (hash-ref u 'id 101) base-x base-y)))))

  ;; ---------------------------------------------------------------------------
  ;; Adversarial Countermeasure #5b: Anti-Kite Defensive Leash (16.0 tiles)
  ;; ---------------------------------------------------------------------------
  (define lone-kiter?
    (and (= (length enemy-units) 1)
         (memq (unit-type-sym (car enemy-units))
               '(reaper hellion adept stalker oracle phoenix mutalisk))
         (< (length combat-units) SC2-LONE-KITER-MAX-DEFENDERS)))
  (when lone-kiter?
    (for ([u (in-list combat-units)])
      (when (and (memq (unit-type-sym u) '(zealot zergling roach immortal))
                 (> (dist2d base-x base-y (hash-ref u 'x base-x) (hash-ref u 'y base-y))
                    SC2-ANTI-KITE-LEASH-RADIUS))
        (l34-emit! ctx (list 'kite (hash-ref u 'id 101) nat-x nat-y)))))

  ;; ---------------------------------------------------------------------------
  ;; Pro Splash & Micro Countermeasures:
  ;;   1. Coalesced Hostile Ground Effects (`psi-storm`, `corrosive-bile`, `blinding-cloud`) &
  ;;      Enemy `disruptor-phased` (Purification Nova) Lateral Wing Evasion
  ;;   2. Enemy `widow-mine` / `widow-mine-burrowed` Out-Range Snipe, Lock Pull-Back & Bait
  ;;   3. Enemy `baneling` Light-Unit Radial Pre-Split (2.5x2.5 Bucketed)
  ;;   4. Enemy `hellion` & `lurker-burrowed` Collinear Lateral Scatter (+/- n-hat)
  ;;   5. Enemy `siege-tank-sieged` Line Discipline, Ravager Bile Stagger & 3-Flank Break
  ;; ---------------------------------------------------------------------------
  (define splash-evading-tags (pooled-mutable-seteqv! l34-sc 'splash-evading-tags))
  (define disruptor-handled-tags (pooled-mutable-seteqv! l34-sc 'disruptor-handled-tags))
  (define disruptor-directive-set (pooled-mutable-set! l34-sc 'disruptor-directive-set))
  (define fprelim-cx (exact->inexact prelim-army-cx))
  (define fprelim-cy (exact->inexact prelim-army-cy))
  (define (prelim-dist2-le? obj r2)
    (define ox (hash-ref obj 'x 9999.0))
    (define oy (hash-ref obj 'y 9999.0))
    (if (and (real? ox) (real? oy) (= (- ox ox) 0) (= (- oy oy) 0))
        (let ([dx (- fprelim-cx (exact->inexact ox))]
              [dy (- fprelim-cy (exact->inexact oy))])
          (<= (+ (* dx dx) (* dy dy)) r2))
        (<= (dist2d prelim-army-cx prelim-army-cy ox oy) (sqrt r2))))

  ;; Single-pass classification over ally-units, ally-bldgs, enemy-units, enemy-bldgs, combat-units
  (define ally-disruptor-units-rev '())
  (define ally-sentries-rev '())
  (define ally-overseers-rev '())
  (define ally-infestors-rev '())
  (define mode-candidates-rev '())
  (define ally-zerg-burrow-candidate? #f)
  (define ally-acc-mask 0)
  (define creep-ally-slice-rev '())
  (define creep-queen-xs '())
  (define creep-queen-ys '())
  (for ([u (in-list ally-units)])
    (define ut (unit-type-sym u))
    (define af (fast-ally-sym-flags ut))
    (set! ally-acc-mask (bitwise-ior ally-acc-mask af))
    (unless (zero? (bitwise-and af #x40489E))
      (when (bitwise-bit-set? af 1)
        (set! ally-disruptor-units-rev (cons u ally-disruptor-units-rev)))
      (when (bitwise-bit-set? af 2)
        (set! ally-sentries-rev (cons u ally-sentries-rev)))
      (when (bitwise-bit-set? af 3)
        (set! ally-overseers-rev (cons u ally-overseers-rev)))
      (when (bitwise-bit-set? af 4)
        (set! ally-infestors-rev (cons u ally-infestors-rev)))
      (when (bitwise-bit-set? af 7)
        (set! mode-candidates-rev (cons u mode-candidates-rev)))
      (when (and (not ally-zerg-burrow-candidate?)
                 (bitwise-bit-set? af 11)
                 (hash? u)
                 (or (hash-ref u 'burrowed #f)
                     (hash-ref u 'is-burrowed? #f)
                     (let* ([hp-raw (or (hash-ref u 'hp #f) (hash-ref u 'health #f) 100.0)]
                            [hp (exact->inexact (fast-finite-real hp-raw 100.0))]
                            [mhp-raw (or (hash-ref u 'max-hp #f) (hash-ref u 'health-max #f) hp)]
                            [mhp (max 1.0 (exact->inexact (fast-finite-real mhp-raw hp)))])
                       (<= hp (* 0.999 mhp)))))
        (set! ally-zerg-burrow-candidate? #t))
      (when (bitwise-bit-set? af 14)
        (set! creep-ally-slice-rev (cons u creep-ally-slice-rev))
        (define qx (hash-ref u 'x base-x))
        (define qy (hash-ref u 'y base-y))
        (set! creep-queen-xs (cons (if (flonum? qx) qx (exact->inexact qx)) creep-queen-xs))
        (set! creep-queen-ys (cons (if (flonum? qy) qy (exact->inexact qy)) creep-queen-ys)))
      (when (bitwise-bit-set? af 22)
        (set! creep-ally-slice-rev (cons u creep-ally-slice-rev)))))
  (define ally-unit-det? (bitwise-bit-set? ally-acc-mask 0))
  (define has-non-overlord-spotter? (bitwise-bit-set? ally-acc-mask 5))
  (define any-pro-caster? (bitwise-bit-set? ally-acc-mask 6))
  (define has-ally-roach? (bitwise-bit-set? ally-acc-mask 8))
  (define has-ally-ravager? (bitwise-bit-set? ally-acc-mask 9))
  (when (bitwise-bit-set? ally-acc-mask 10)
    (set! ally-zerg-burrow-candidate? #t))
  (define has-ally-swarm-host-or-locust? (bitwise-bit-set? ally-acc-mask 12))
  (define has-ally-zergling? (bitwise-bit-set? ally-acc-mask 13))
  (define has-ally-queen? (bitwise-bit-set? ally-acc-mask 14))
  (define has-ally-queen-or-tumor? (not (zero? (bitwise-and ally-acc-mask 49152))))
  (define has-ally-changeling-or-overseer? (bitwise-bit-set? ally-acc-mask 16))
  (define has-ally-dropperlord? (bitwise-bit-set? ally-acc-mask 17))
  (define has-ally-unwalled-punish-unit? (bitwise-bit-set? ally-acc-mask 18))
  (define has-ally-harass-sym? (bitwise-bit-set? ally-acc-mask 19))
  (define has-ally-static-def-or-nydus? (bitwise-bit-set? ally-acc-mask 20))
  (define has-ally-map-elem-or-recall? (bitwise-bit-set? ally-acc-mask 21))
  (define ally-disruptor-units (reverse ally-disruptor-units-rev))
  (define ally-sentries (reverse ally-sentries-rev))
  (define ally-overseers (reverse ally-overseers-rev))
  (define ally-infestors (reverse ally-infestors-rev))
  (define mode-candidates (reverse mode-candidates-rev))

  (define ally-bldg-acc 0)
  (define armory-ready-bldgs? #f)
  (define live-owned-townhalls 0)
  (for ([b (in-list ally-bldgs)])
    (define bt (unit-type-sym b))
    (define bf (fast-ally-bldg-flags bt))
    (set! ally-bldg-acc (bitwise-ior ally-bldg-acc bf))
    (when (bitwise-bit-set? bf 2)
      (set! live-owned-townhalls (add1 live-owned-townhalls)))
    (when (and (not armory-ready-bldgs?)
               (bitwise-bit-set? bf 1)
               (hash? b)
               (>= (hash-ref b 'build-progress 1.0) 1.0))
      (set! armory-ready-bldgs? #t)))
  (define ally-bldg-det? (bitwise-bit-set? ally-bldg-acc 0))
  (when (bitwise-bit-set? ally-bldg-acc 3)
    (set! has-ally-queen-or-tumor? #t))
  (define has-ally-wall-block-bldg? (bitwise-bit-set? ally-bldg-acc 4))
  (define has-ally-lowered-depot? (bitwise-bit-set? ally-bldg-acc 5))
  (when (bitwise-bit-set? ally-bldg-acc 6)
    (set! has-ally-static-def-or-nydus? #t))
  (when (bitwise-bit-set? ally-bldg-acc 7)
    (set! has-ally-map-elem-or-recall? #t))
  (define ally-has-detector? (or ally-unit-det? ally-bldg-det?))

  (define bx-fl (exact->inexact base-x))
  (define by-fl (exact->inexact base-y))
  (define nx-fl (exact->inexact nat-x))
  (define ny-fl (exact->inexact nat-y))
  (define enemy-near-home? #f)
  (define enemy-acc-mask 0)
  (define enemy-disruptor-units-rev '())
  (define enemy-widow-mines-rev '())
  (define enemy-banelings-rev '())
  (define linear-splash-enemies-rev '())
  (define enemy-stasis-eu-rev '())
  (define immobile-bile-eu-rev '())
  (define enemy-sieged-tanks-near-rev '())
  (define tank-lurker-hazards-rev '())
  (define enemy-air-or-colossus-rev '())
  (define enemy-massive-air-or-colossus-rev '())
  (define enemy-mutalisks-rev '())
  (define enemy-changelings-rev '())
  (define creep-enemy-slice-rev '())
  (define has-creep-queens? (pair? creep-queen-xs))
  (define visible-enemy-combat-supply 0.0)
  (define local-enemy-unit-val 0)
  (define enemy-unit-shimmer? #f)
  (define sum-eu-x 0.0)
  (define sum-eu-y 0.0)
  (for ([e (in-list enemy-units)])
    (define et (unit-type-sym e))
    (define einfo (fast-enemy-u-info et))
    (define ef (vector-ref einfo 0))
    (set! enemy-acc-mask (bitwise-ior enemy-acc-mask ef))
    (define ex-raw (hash-ref e 'x #f))
    (define ey-raw (hash-ref e 'y #f))
    (define fex-opt
      (cond
        [(flonum? ex-raw) (and (fl= (fl- ex-raw ex-raw) 0.0) ex-raw)]
        [(exact-integer? ex-raw) (->fl ex-raw)]
        [(and (real? ex-raw) (= (- ex-raw ex-raw) 0)) (exact->inexact ex-raw)]
        [else #f]))
    (define fey-opt
      (cond
        [(flonum? ey-raw) (and (fl= (fl- ey-raw ey-raw) 0.0) ey-raw)]
        [(exact-integer? ey-raw) (->fl ey-raw)]
        [(and (real? ey-raw) (= (- ey-raw ey-raw) 0)) (exact->inexact ey-raw)]
        [else #f]))
    (define coords-ok? (and fex-opt fey-opt))
    (define fex (or fex-opt 9999.0))
    (define fey (or fey-opt 9999.0))
    (define d2
      (if coords-ok?
          (let ([dx (fl- fprelim-cx fex)]
                [dy (fl- fprelim-cy fey)])
            (fl+ (fl* dx dx) (fl* dy dy)))
          (let ([d (dist2d prelim-army-cx prelim-army-cy
                           (or ex-raw 9999.0) (or ey-raw 9999.0))])
            (define fd (if (flonum? d) d (exact->inexact d)))
            (fl* fd fd))))
    (unless enemy-near-home?
      (let ([dx1 (fl- fex bx-fl)] [dy1 (fl- fey by-fl)]
            [dx2 (fl- fex nx-fl)] [dy2 (fl- fey ny-fl)])
        (when (or (fl<= (fl+ (fl* dx1 dx1) (fl* dy1 dy1)) 256.0)
                  (fl<= (fl+ (fl* dx2 dx2) (fl* dy2 dy2)) 256.0))
          (set! enemy-near-home? #t))))
    (unless (zero? (bitwise-and ef #x3FFF))
      (when (bitwise-bit-set? ef 0)
        (set! enemy-disruptor-units-rev (cons e enemy-disruptor-units-rev)))
      (when (bitwise-bit-set? ef 1)
        (set! enemy-widow-mines-rev (cons e enemy-widow-mines-rev)))
      (when (bitwise-bit-set? ef 2)
        (set! enemy-banelings-rev (cons e enemy-banelings-rev)))
      (when (or (bitwise-bit-set? ef 3)
                (and (bitwise-bit-set? ef 4)
                     (or (hash-ref e 'burrowed #f) (hash-ref e 'burrowed? #f))))
        (set! linear-splash-enemies-rev (cons e linear-splash-enemies-rev)))
      (when (or (bitwise-bit-set? ef 5)
                (and (bitwise-bit-set? ef 6)
                     (or (hash-ref e 'sieged #f) (hash-ref e 'is-sieged? #f)))
                (and (or (bitwise-bit-set? ef 4) (bitwise-bit-set? ef 7))
                     (or (hash-ref e 'burrowed #f)
                         (hash-ref e 'burrowed? #f)
                         (hash-ref e 'is-burrowed? #f)
                         (hash-ref e 'burrow-intent? #f)
                         (hash-ref e 'burrow-intent #f)
                         (hash-ref e 'burrowing? #f)
                         (hash-ref e 'is-burrowing? #f)
                         (hash-ref e 'preparing-burrow? #f))))
        (set! tank-lurker-hazards-rev (cons e tank-lurker-hazards-rev)))
      (when (bitwise-bit-set? ef 8)
        (set! enemy-stasis-eu-rev (cons e enemy-stasis-eu-rev)))
      (when (bitwise-bit-set? ef 9)
        (set! immobile-bile-eu-rev (cons e immobile-bile-eu-rev)))
      (when (and (bitwise-bit-set? ef 10) (fl<= d2 306.25))
        (set! enemy-sieged-tanks-near-rev (cons e enemy-sieged-tanks-near-rev)))
      (when (bitwise-bit-set? ef 11)
        (set! enemy-air-or-colossus-rev (cons e enemy-air-or-colossus-rev)))
      (when (bitwise-bit-set? ef 12)
        (set! enemy-massive-air-or-colossus-rev (cons e enemy-massive-air-or-colossus-rev)))
      (when (bitwise-bit-set? ef 13)
        (set! enemy-mutalisks-rev (cons e enemy-mutalisks-rev))))
    (when (or (bitwise-bit-set? ef 14)
              (eq? (hash-ref e 'changeling? #f) #t))
      (set! enemy-changelings-rev (cons e enemy-changelings-rev)))
    (when (and (bitwise-bit-set? ef 23)
               (not (eq? (hash-ref e 'is-hallucination #f) #t))
               (not (eq? (hash-ref e 'hallucination #f) #t))
               (not (eq? (hash-ref e 'hallucination? #f) #t)))
      (set! visible-enemy-combat-supply (+ visible-enemy-combat-supply (vector-ref einfo 1))))
    (when (fl<= d2 361.0)
      (set! local-enemy-unit-val (+ local-enemy-unit-val (vector-ref einfo 2))))
    (when (and (hash? e)
               (or (hash-ref e 'is-shimmer? #f)
                   (hash-ref e 'cloaked #f)
                   (hash-ref e 'is-cloaked? #f)
                   (hash-ref e 'burrowed #f)
                   (hash-ref e 'is-burrowed? #f)
                   (let ([dt (hash-ref e 'display-type 1)])
                     (or (eq? dt 2) (not (exact-integer? dt))))
                   (let ([cs (hash-ref e 'cloak-state 0)])
                     (or (eq? cs 2) (not (exact-integer? cs))))
                   (let ([ck (hash-ref e 'cloak 0)])
                     (or (eq? ck 1) (eq? ck 2)))))
      (set! enemy-unit-shimmer? #t))
    (when (and has-creep-queens? (bitwise-bit-set? ef 25))
      (when (for/or ([qx (in-list creep-queen-xs)]
                     [qy (in-list creep-queen-ys)])
              (define dx (fl- fex qx))
              (define dy (fl- fey qy))
              (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 49.0))
        (set! creep-enemy-slice-rev (cons e creep-enemy-slice-rev))))
    (if coords-ok?
        (begin
          (set! sum-eu-x (fl+ sum-eu-x fex))
          (set! sum-eu-y (fl+ sum-eu-y fey)))
        (begin
          (set! sum-eu-x (fl+ sum-eu-x (exact->inexact (fast-finite-real ex-raw enemy-x))))
          (set! sum-eu-y (fl+ sum-eu-y (exact->inexact (fast-finite-real ey-raw enemy-y)))))))
  (define has-enemy-static-det? (bitwise-bit-set? enemy-acc-mask 15))
  (define has-enemy-swarm-host-or-locust? (bitwise-bit-set? enemy-acc-mask 16))
  (define has-enemy-creep-tumor? (bitwise-bit-set? enemy-acc-mask 17))
  (define has-enemy-dropperlord? (bitwise-bit-set? enemy-acc-mask 18))
  (define has-enemy-overseer? (bitwise-bit-set? enemy-acc-mask 19))
  (define has-enemy-harass-sym? (bitwise-bit-set? enemy-acc-mask 20))
  (define has-enemy-static-def-or-nydus? (bitwise-bit-set? enemy-acc-mask 21))
  (define has-enemy-map-elem-or-recall? (bitwise-bit-set? enemy-acc-mask 22))
  (define has-enemy-burrow-or-sh-counter?
    (or enemy-unit-shimmer? (bitwise-bit-set? enemy-acc-mask 24)))
  (define enemy-disruptor-units (reverse enemy-disruptor-units-rev))
  (define enemy-widow-mines (reverse enemy-widow-mines-rev))
  (define enemy-banelings (reverse enemy-banelings-rev))
  (define linear-splash-enemies (reverse linear-splash-enemies-rev))
  (define enemy-sieged-tanks-near (reverse enemy-sieged-tanks-near-rev))
  (define tank-lurker-hazards (reverse tank-lurker-hazards-rev))
  (define enemy-air-or-colossus (reverse enemy-air-or-colossus-rev))
  (define enemy-massive-air-or-colossus (reverse enemy-massive-air-or-colossus-rev))
  (define enemy-mutalisks (reverse enemy-mutalisks-rev))
  (define enemy-changelings (reverse enemy-changelings-rev))
  (define has-enemy-changeling? (pair? enemy-changelings))

  (define enemy-stasis-eb-rev '())
  (define immobile-bile-eb-rev '())
  (define enemy-pfs-near-rev '())
  (define enemy-pf-list-rev '())
  (define local-enemy-bldg-val 0)
  (define sum-eb-x 0.0)
  (define sum-eb-y 0.0)
  (define enemy-bldg-acc 0)
  (for ([eb (in-list enemy-bldgs)])
    (define bt (unit-type-sym eb))
    (define binfo (fast-enemy-b-info bt))
    (define bf (vector-ref binfo 0))
    (set! enemy-bldg-acc (bitwise-ior enemy-bldg-acc bf))
    (define ex-raw (hash-ref eb 'x #f))
    (define ey-raw (hash-ref eb 'y #f))
    (define fex-opt
      (cond
        [(flonum? ex-raw) (and (fl= (fl- ex-raw ex-raw) 0.0) ex-raw)]
        [(exact-integer? ex-raw) (->fl ex-raw)]
        [(and (real? ex-raw) (= (- ex-raw ex-raw) 0)) (exact->inexact ex-raw)]
        [else #f]))
    (define fey-opt
      (cond
        [(flonum? ey-raw) (and (fl= (fl- ey-raw ey-raw) 0.0) ey-raw)]
        [(exact-integer? ey-raw) (->fl ey-raw)]
        [(and (real? ey-raw) (= (- ey-raw ey-raw) 0)) (exact->inexact ey-raw)]
        [else #f]))
    (define coords-ok? (and fex-opt fey-opt))
    (define fex (or fex-opt 9999.0))
    (define fey (or fey-opt 9999.0))
    (unless enemy-near-home?
      (let ([dx1 (fl- fex bx-fl)] [dy1 (fl- fey by-fl)]
            [dx2 (fl- fex nx-fl)] [dy2 (fl- fey ny-fl)])
        (when (or (fl<= (fl+ (fl* dx1 dx1) (fl* dy1 dy1)) 324.0)
                  (fl<= (fl+ (fl* dx2 dx2) (fl* dy2 dy2)) 324.0))
          (set! enemy-near-home? #t))))
    (unless (zero? (bitwise-and bf 120))
      (when (bitwise-bit-set? bf 3)
        (set! enemy-stasis-eb-rev (cons eb enemy-stasis-eb-rev)))
      (when (bitwise-bit-set? bf 4)
        (set! immobile-bile-eb-rev (cons eb immobile-bile-eb-rev)))
      (when (not (zero? (bitwise-and bf 96)))
        (define d2
          (if coords-ok?
              (let ([dx (fl- fprelim-cx fex)]
                    [dy (fl- fprelim-cy fey)])
                (fl+ (fl* dx dx) (fl* dy dy)))
              (let ([d (dist2d prelim-army-cx prelim-army-cy
                               (or ex-raw 9999.0) (or ey-raw 9999.0))])
                (define fd (if (flonum? d) d (exact->inexact d)))
                (fl* fd fd))))
        (when (bitwise-bit-set? bf 5)
          (set! enemy-pf-list-rev (cons eb enemy-pf-list-rev))
          (when (fl<= d2 306.25)
            (set! enemy-pfs-near-rev (cons eb enemy-pfs-near-rev))))
        (when (and (bitwise-bit-set? bf 6) (fl<= d2 361.0))
          (set! local-enemy-bldg-val (+ local-enemy-bldg-val (vector-ref binfo 1))))))
    (if coords-ok?
        (begin
          (set! sum-eb-x (fl+ sum-eb-x fex))
          (set! sum-eb-y (fl+ sum-eb-y fey)))
        (begin
          (set! sum-eb-x (fl+ sum-eb-x (exact->inexact (fast-finite-real ex-raw enemy-x))))
          (set! sum-eb-y (fl+ sum-eb-y (exact->inexact (fast-finite-real ey-raw enemy-y)))))))
  (when (and (not has-enemy-static-det?) (bitwise-bit-set? enemy-bldg-acc 0))
    (set! has-enemy-static-det? #t))
  (when (and (not has-enemy-creep-tumor?) (bitwise-bit-set? enemy-bldg-acc 1))
    (set! has-enemy-creep-tumor? #t))
  (when (and (not has-enemy-static-def-or-nydus?) (bitwise-bit-set? enemy-bldg-acc 2))
    (set! has-enemy-static-def-or-nydus? #t))
  (define enemy-stasis-traps
    (if (and (null? enemy-stasis-eu-rev) (null? enemy-stasis-eb-rev))
        '()
        (append (reverse enemy-stasis-eu-rev) (reverse enemy-stasis-eb-rev))))
  (define immobile-bile-targets
    (if (and live-tactics-obs?
             has-ally-ravager?
             (or (pair? immobile-bile-eu-rev) (pair? immobile-bile-eb-rev)))
        (append (reverse immobile-bile-eu-rev) (reverse immobile-bile-eb-rev))
        '()))
  (define enemy-pfs-near (reverse enemy-pfs-near-rev))
  (define enemy-pf-list (reverse enemy-pf-list-rev))

  (define have-siege-breaker-unit? #f)
  (define have-heavy-or-siege-breaker-unit? #f)
  (define local-ally-val 0)
  (define live-combat-supply 0.0)
  (define weighted-combat-units 0.0)
  (define ally-siege-tanks-rev '())
  (define ally-siege-supporters-rev '())
  (define ally-has-stealth? #f)
  (define any-ally-baneling? #f)
  (for ([u (in-list combat-units)])
    (define ut (unit-type-sym u))
    (unless have-siege-breaker-unit?
      (when (hash-ref RUNTIME-SIEGE-BREAKER-SET ut #f)
        (set! have-siege-breaker-unit? #t)))
    (unless have-heavy-or-siege-breaker-unit?
      (when (hash-ref RUNTIME-HEAVY-SB-SET ut #f)
        (set! have-heavy-or-siege-breaker-unit? #t)))
    (set! local-ally-val (+ local-ally-val (fast-res-cost-50 ut)))
    (set! live-combat-supply (+ live-combat-supply (unit-supply-cost ut)))
    (set! weighted-combat-units (+ weighted-combat-units (if (eq? ut 'zergling) 0.5 1.0)))
    (when (or (eq? ut 'siege-tank) (eq? ut 'siege-tank-sieged))
      (set! ally-siege-tanks-rev (cons u ally-siege-tanks-rev)))
    (when (hash-ref RUNTIME-SIEGE-SUPP-SET ut #f)
      (set! ally-siege-supporters-rev (cons u ally-siege-supporters-rev)))
    (unless ally-has-stealth?
      (when (or (hash-ref RUNTIME-STEALTH-SET ut #f)
                (hash-ref u 'cloaked #f)
                (hash-ref u 'burrowed #f))
        (set! ally-has-stealth? #t)))
    (unless any-ally-baneling?
      (when (eq? ut 'baneling) (set! any-ally-baneling? #t))))
  (define ally-siege-tanks (reverse ally-siege-tanks-rev))
  (define ally-siege-supporters (reverse ally-siege-supporters-rev))
  (define our-z-early
    (hash-ref obs 'our-terrain-z
              (if (not (null? combat-units)) (hash-ref (car combat-units) 'z 10.0) 10.0)))
  (define enemy-z-early
    (hash-ref obs 'enemy-terrain-z
              (if (not (null? enemy-units)) (hash-ref (car enemy-units) 'z 10.0) 10.0)))
  (define siege-uphill? (>= (- (exact->inexact enemy-z-early) (exact->inexact our-z-early)) 0.75))
  (define have-siege-breaker?
    (or have-siege-breaker-unit?
        (ormap (lambda (eff) (eq? (hash-ref eff 'type 'none) 'blinding-cloud)) effects)))
  (define have-heavy-or-siege-breaker?
    (or have-siege-breaker?
        have-heavy-or-siege-breaker-unit?))
  (define local-enemy-val
    (max 100 (+ local-enemy-unit-val local-enemy-bldg-val)))
  (define local-val-ratio (/ (exact->inexact local-ally-val) (exact->inexact local-enemy-val)))
  (define can-break-siege-line?
    (or (>= local-val-ratio (if siege-uphill? 1.55 1.40))
        (and (>= (hash-ref obs 'supply-used 0) 180)
             (or have-heavy-or-siege-breaker?
                 (>= local-val-ratio 1.25)))
        have-siege-breaker?))
  (define siege-shelling-friendly-structure?
    (and (pair? enemy-sieged-tanks-near)
         (ormap (lambda (st)
                  (define stx (hash-ref st 'x 9999.0))
                  (define sty (hash-ref st 'y 9999.0))
                  (ormap (lambda (b)
                           (<= (dist2d stx sty (hash-ref b 'x base-x) (hash-ref b 'y base-y)) 15.5))
                         ally-bldgs))
                enemy-sieged-tanks-near)))
  (define siege-line-hold?
    (and live-tactics-obs?
         (or (>= (length enemy-sieged-tanks-near) 2)
             (and (>= (length enemy-sieged-tanks-near) 1)
                  (not (null? enemy-pfs-near))))
         (not siege-shelling-friendly-structure?)
         (not can-break-siege-line?)))
  (set-l34-ctx-ally-disruptor-units! ctx ally-disruptor-units)
  (set-l34-ctx-ally-has-detector?! ctx ally-has-detector?)
  (set-l34-ctx-ally-has-stealth?! ctx ally-has-stealth?)
  (set-l34-ctx-ally-infestors! ctx ally-infestors)
  (set-l34-ctx-ally-overseers! ctx ally-overseers)
  (set-l34-ctx-ally-sentries! ctx ally-sentries)
  (set-l34-ctx-ally-siege-supporters! ctx ally-siege-supporters)
  (set-l34-ctx-ally-zerg-burrow-candidate?! ctx ally-zerg-burrow-candidate?)
  (set-l34-ctx-any-ally-baneling?! ctx any-ally-baneling?)
  (set-l34-ctx-any-pro-caster?! ctx any-pro-caster?)
  (set-l34-ctx-armory-ready-bldgs?! ctx armory-ready-bldgs?)
  (set-l34-ctx-can-break-siege-line?! ctx can-break-siege-line?)
  (set-l34-ctx-creep-ally-slice-rev! ctx creep-ally-slice-rev)
  (set-l34-ctx-creep-enemy-slice-rev! ctx creep-enemy-slice-rev)
  (set-l34-ctx-disruptor-directive-set! ctx disruptor-directive-set)
  (set-l34-ctx-disruptor-handled-tags! ctx disruptor-handled-tags)
  (set-l34-ctx-enemy-air-or-colossus! ctx enemy-air-or-colossus)
  (set-l34-ctx-enemy-banelings! ctx enemy-banelings)
  (set-l34-ctx-enemy-changelings! ctx enemy-changelings)
  (set-l34-ctx-enemy-disruptor-units! ctx enemy-disruptor-units)
  (set-l34-ctx-enemy-massive-air-or-colossus! ctx enemy-massive-air-or-colossus)
  (set-l34-ctx-enemy-mutalisks! ctx enemy-mutalisks)
  (set-l34-ctx-enemy-near-home?! ctx enemy-near-home?)
  (set-l34-ctx-enemy-pf-list! ctx enemy-pf-list)
  (set-l34-ctx-enemy-sieged-tanks-near! ctx enemy-sieged-tanks-near)
  (set-l34-ctx-enemy-stasis-traps! ctx enemy-stasis-traps)
  (set-l34-ctx-enemy-unit-shimmer?! ctx enemy-unit-shimmer?)
  (set-l34-ctx-enemy-widow-mines! ctx enemy-widow-mines)
  (set-l34-ctx-enemy-z-early! ctx enemy-z-early)
  (set-l34-ctx-has-ally-changeling-or-overseer?! ctx has-ally-changeling-or-overseer?)
  (set-l34-ctx-has-ally-dropperlord?! ctx has-ally-dropperlord?)
  (set-l34-ctx-has-ally-harass-sym?! ctx has-ally-harass-sym?)
  (set-l34-ctx-has-ally-map-elem-or-recall?! ctx has-ally-map-elem-or-recall?)
  (set-l34-ctx-has-ally-queen-or-tumor?! ctx has-ally-queen-or-tumor?)
  (set-l34-ctx-has-ally-queen?! ctx has-ally-queen?)
  (set-l34-ctx-has-ally-roach?! ctx has-ally-roach?)
  (set-l34-ctx-has-ally-static-def-or-nydus?! ctx has-ally-static-def-or-nydus?)
  (set-l34-ctx-has-ally-swarm-host-or-locust?! ctx has-ally-swarm-host-or-locust?)
  (set-l34-ctx-has-ally-unwalled-punish-unit?! ctx has-ally-unwalled-punish-unit?)
  (set-l34-ctx-has-ally-wall-block-bldg?! ctx has-ally-wall-block-bldg?)
  (set-l34-ctx-has-ally-zergling?! ctx has-ally-zergling?)
  (set-l34-ctx-has-enemy-burrow-or-sh-counter?! ctx has-enemy-burrow-or-sh-counter?)
  (set-l34-ctx-has-enemy-changeling?! ctx has-enemy-changeling?)
  (set-l34-ctx-has-enemy-creep-tumor?! ctx has-enemy-creep-tumor?)
  (set-l34-ctx-has-enemy-dropperlord?! ctx has-enemy-dropperlord?)
  (set-l34-ctx-has-enemy-harass-sym?! ctx has-enemy-harass-sym?)
  (set-l34-ctx-has-enemy-map-elem-or-recall?! ctx has-enemy-map-elem-or-recall?)
  (set-l34-ctx-has-enemy-overseer?! ctx has-enemy-overseer?)
  (set-l34-ctx-has-enemy-static-def-or-nydus?! ctx has-enemy-static-def-or-nydus?)
  (set-l34-ctx-has-enemy-static-det?! ctx has-enemy-static-det?)
  (set-l34-ctx-has-enemy-swarm-host-or-locust?! ctx has-enemy-swarm-host-or-locust?)
  (set-l34-ctx-has-non-overlord-spotter?! ctx has-non-overlord-spotter?)
  (set-l34-ctx-have-heavy-or-siege-breaker?! ctx have-heavy-or-siege-breaker?)
  (set-l34-ctx-immobile-bile-targets! ctx immobile-bile-targets)
  (set-l34-ctx-linear-splash-enemies! ctx linear-splash-enemies)
  (set-l34-ctx-live-combat-supply! ctx live-combat-supply)
  (set-l34-ctx-live-owned-townhalls! ctx live-owned-townhalls)
  (set-l34-ctx-local-val-ratio! ctx local-val-ratio)
  (set-l34-ctx-mode-candidates! ctx mode-candidates)
  (set-l34-ctx-our-z-early! ctx our-z-early)
  (set-l34-ctx-ravager-cast-tags! ctx ravager-cast-tags)
  (set-l34-ctx-siege-line-hold?! ctx siege-line-hold?)
  (set-l34-ctx-splash-evading-tags! ctx splash-evading-tags)
  (set-l34-ctx-sum-eb-x! ctx sum-eb-x)
  (set-l34-ctx-sum-eb-y! ctx sum-eb-y)
  (set-l34-ctx-sum-eu-x! ctx sum-eu-x)
  (set-l34-ctx-sum-eu-y! ctx sum-eu-y)
  (set-l34-ctx-tank-lurker-hazards! ctx tank-lurker-hazards)
  (set-l34-ctx-visible-enemy-combat-supply! ctx visible-enemy-combat-supply)
  (set-l34-ctx-weighted-combat-units! ctx weighted-combat-units)
)

(define (l34-phase4a-hazards-wm! ctx)
  (define ally-disruptor-units (l34-ctx-ally-disruptor-units ctx))
  (define ally-has-detector? (l34-ctx-ally-has-detector? ctx))
  (define ally-units (l34-ctx-ally-units ctx))
  (define base-x (l34-ctx-base-x ctx))
  (define base-y (l34-ctx-base-y ctx))
  (define can-break-siege-line? (l34-ctx-can-break-siege-line? ctx))
  (define combat-units (l34-ctx-combat-units ctx))
  (define disruptor-directive-set (l34-ctx-disruptor-directive-set ctx))
  (define disruptor-handled-tags (l34-ctx-disruptor-handled-tags ctx))
  (define effects (l34-ctx-effects ctx))
  (define enemy-disruptor-units (l34-ctx-enemy-disruptor-units ctx))
  (define enemy-sieged-tanks-near (l34-ctx-enemy-sieged-tanks-near ctx))
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define enemy-widow-mines (l34-ctx-enemy-widow-mines ctx))
  (define frame (l34-ctx-frame ctx))
  (define live-tactics-obs? (l34-ctx-live-tactics-obs? ctx))
  (define nat-x (l34-ctx-nat-x ctx))
  (define nat-y (l34-ctx-nat-y ctx))
  (define obs (l34-ctx-obs ctx))
  (define oledger (l34-ctx-oledger ctx))
  (define prelim-army-cx (l34-ctx-prelim-army-cx ctx))
  (define prelim-army-cy (l34-ctx-prelim-army-cy ctx))
  (define rt (l34-ctx-rt ctx))
  (define siege-line-hold? (l34-ctx-siege-line-hold? ctx))
  (define spell-claims-rt (l34-ctx-spell-claims-rt ctx))
  (define splash-evading-tags (l34-ctx-splash-evading-tags ctx))
  (define splash-st (l34-ctx-splash-st ctx))
  (define splash-wm-disarmed-ht (l34-ctx-splash-wm-disarmed-ht ctx))
  (define tank-lurker-hazards (l34-ctx-tank-lurker-hazards ctx))
  (define any-disruptor-or-nova?
    (or (not (null? ally-disruptor-units))
        (not (null? enemy-disruptor-units))))
  (when any-disruptor-or-nova?
    (define (augment-disruptor-orders u)
      (if (not (hash? u))
          u
          (let* ([ords (hash-ref u 'orders #f)]
                 [ab-id (hash-ref u 'order-ability-id 0)]
                 [ox (hash-ref u 'order-target-x #f)]
                 [oy (hash-ref u 'order-target-y #f)])
            (if (or (list? ords) (not (and (exact-integer? ab-id) (> ab-id 0))))
                u
                (hash-set u 'orders
                          (list (hash 'ability_id ab-id
                                      'tx (or ox (hash-ref u 'x base-x))
                                      'ty (or oy (hash-ref u 'y base-y))
                                      'target_x (or ox (hash-ref u 'x base-x))
                                      'target_y (or oy (hash-ref u 'y base-y)))))))))
    (define enemy-dis-pts
      (for/list ([e (in-list enemy-disruptor-units)])
        (cons (exact->inexact (hash-ref e 'x 9999.0))
              (exact->inexact (hash-ref e 'y 9999.0)))))
    (define ally-dis-pts
      (for/list ([u (in-list ally-disruptor-units)])
        (cons (exact->inexact (hash-ref u 'x base-x))
              (exact->inexact (hash-ref u 'y base-y)))))
    (define (near-any-pt? pts x y r2)
      (and (pair? pts)
           (let ([xf (if (flonum? x) x (exact->inexact x))]
                 [yf (if (flonum? y) y (exact->inexact y))]
                 [r2f (if (flonum? r2) r2 (exact->inexact r2))])
             (for/or ([pt (in-list pts)])
               (define dx (fl- xf (car pt)))
               (define dy (fl- yf (cdr pt)))
               (fl<= (fl+ (fl* dx dx) (fl* dy dy)) r2f)))))
    (define has-live-nova?
      (or (for/or ([e (in-list enemy-units)])
            (eq? (unit-type-sym e) 'disruptor-phased))
          (for/or ([ef (in-list (hash-ref obs 'effects '()))])
            (define et (and (hash? ef) (hash-ref ef 'type #f)))
            (or (eq? et 'purification-nova)
                (eq? et 'disruptor-nova)
                (eq? et 'purification-nova-explosion)))))
    (define micro-allies
      (if (and (null? ally-dis-pts) (null? enemy-dis-pts) (not has-live-nova?))
          '()
          (for/list ([u (in-list ally-units)]
                     #:when (let ([ut (unit-type-sym u)])
                              (or (eq? ut 'disruptor)
                                  (eq? ut 'disruptor-phased)
                                  (and (or (pair? enemy-dis-pts) has-live-nova?)
                                       (or has-live-nova?
                                           (not (memq ut '(scv probe drone mule larva egg overlord observer))))
                                       (let ([rx (hash-ref u 'x base-x)]
                                             [ry (hash-ref u 'y base-y)])
                                         (or has-live-nova?
                                             (near-any-pt? enemy-dis-pts rx ry 225.0)))))))
            (let ([ut (unit-type-sym u)])
              (if (or (eq? ut 'disruptor) (eq? ut 'disruptor-phased))
                  (augment-disruptor-orders u)
                  u)))))
    (define micro-enemies
      (for/list ([e (in-list enemy-units)]
                 #:when (let ([et (unit-type-sym e)])
                          (or (eq? et 'disruptor)
                              (eq? et 'disruptor-phased)
                              (and (pair? ally-dis-pts)
                                   (let ([rx (hash-ref e 'x 9999.0)]
                                         [ry (hash-ref e 'y 9999.0)])
                                     (near-any-pt? ally-dis-pts rx ry 361.0))))))
        (augment-disruptor-orders e)))
    (define d-acts
      (step-disruptor-tactical-micro! micro-allies
                                      micro-enemies
                                      #:tracker (rt-disruptor-tracker rt)
                                      #:current-frame frame
                                      #:blink-researched? (l34-has-upgrade? ctx 'blink)
                                      #:home-x base-x
                                      #:home-y base-y))
    (define ally-by-id
      (and (pair? d-acts)
           (let ([ht (make-hasheqv)])
             (for ([u (in-list ally-units)]
                   #:when (hash? u))
               (define uid0 (hash-ref u 'id #f))
               (when (exact-integer? uid0) (hash-set! ht uid0 u)))
             ht)))
    (for ([da (in-list d-acts)]
          #:when (and (pair? da) (>= (length da) 3) (exact-integer? (second da))))
      (define raw-uid (second da))
      (define head (car da))
      (define u-rec (hash-ref ally-by-id raw-uid #f))
      (define u-ab-id (if u-rec (hash-ref u-rec 'order-ability-id 0) 0))
      (define u-prot (and live-tactics-obs? (> u-ab-id 0) (fast-order-protection-class u-ab-id)))
      (define hold-cast-walk? (memq u-prot '(morph channel cast-walk)))
      (define nova-stagger-ok?
        (or (not (eq? head 'purification-nova))
            (not live-tactics-obs?)
            (disruptor-nova-stagger-ready? spell-claims-rt
                                           frame
                                           DISRUPTOR-NOVA-STAGGER-DEFAULT-FRAMES
                                           #:commit? #t)))
      (when nova-stagger-ok?
        (set-add! disruptor-handled-tags raw-uid)
        (unless (and hold-cast-walk? (not (eq? head 'blink)))
          (define translated
            (case head
              [(purification-nova)
               (list 'cast-spell raw-uid 'purification-nova (third da) (fourth da))]
              [(blink)
               (list 'cast-spell raw-uid 'blink (third da) (fourth da))]
              [(move kite)
               (list head raw-uid (third da) (fourth da))]
              [(attack-unit)
               (list 'attack-unit raw-uid (third da))]
              [else da]))
          (when (memq head '(purification-nova blink move kite))
            (set-add! splash-evading-tags raw-uid))
          (set-add! disruptor-directive-set translated)
          (l34-emit! ctx translated)))))
  (hash-set! splash-st 'disruptor-directive-frame frame)
  (hash-set! splash-st 'disruptor-directive-set disruptor-directive-set)

  ;; 1. Emergency Ground-Effect & Purification Nova (`disruptor-phased`) Evasion
  (define hazard-zones
    (append
     (for/list ([eff (in-list effects)]
                #:when (and (hash? eff)
                            (memq (hash-ref eff 'type 'none)
                                  '(psi-storm psionic-storm corrosive-bile blinding-cloud nuke-persistent))))
       (list (hash-ref eff 'x nat-x)
             (hash-ref eff 'y nat-y)
             (safe-finite-real (hash-ref eff 'radius 3.0) 3.0)))
     (if (or any-disruptor-or-nova? (null? enemy-disruptor-units))
         '()
         (for/list ([e (in-list enemy-disruptor-units)]
                    #:when (eq? (unit-type-sym e) 'disruptor-phased))
           (list (hash-ref e 'x nat-x)
                 (hash-ref e 'y nat-y)
                 4.5)))))
  (define base-fx (if (flonum? base-x) base-x (exact->inexact base-x)))
  (define base-fy (if (flonum? base-y) base-y (exact->inexact base-y)))
  (for ([hz (in-list hazard-zones)])
    (define hx (first hz))
    (define hy (second hz))
    (define hrad (third hz))
    (define fhx (if (flonum? hx) hx (if (real? hx) (exact->inexact hx) +nan.0)))
    (define fhy (if (flonum? hy) hy (if (real? hy) (exact->inexact hy) +nan.0)))
    (define fhrad (if (flonum? hrad) hrad (exact->inexact hrad)))
    (define fhrad2 (if (fl>= fhrad 0.0) (fl* fhrad fhrad) -1.0))
    (define affected
      (if (fl< fhrad2 0.0)
          '()
          (let ([rev '()])
            (for ([u (in-list combat-units)])
              (define ux-raw (hash-ref u 'x base-fx))
              (define uy-raw (hash-ref u 'y base-fy))
              (define fux (if (flonum? ux-raw) ux-raw (if (real? ux-raw) (exact->inexact ux-raw) +nan.0)))
              (define fuy (if (flonum? uy-raw) uy-raw (if (real? uy-raw) (exact->inexact uy-raw) +nan.0)))
              (define dx (fl- fux fhx))
              (define dy (fl- fuy fhy))
              (when (fl<= (fl+ (fl* dx dx) (fl* dy dy)) fhrad2)
                (define uid (hash-ref u 'id 101))
                (unless (set-member? splash-evading-tags uid)
                  (define ab-id (hash-ref u 'order-ability-id 0))
                  (define prot (and live-tactics-obs? (> ab-id 0) (fast-order-protection-class ab-id)))
                  (when (and (not (and live-tactics-obs?
                                       (or (memq prot '(morph channel cast-walk))
                                           (snipe-channel-locked? spell-claims-rt uid frame))))
                             (not (order-ledger-unit-in-attack-swing? oledger u)))
                    (set! rev (cons u rev))))))
            (reverse rev))))
    (cond
      [(and live-tactics-obs? (>= (length affected) 4))
       (define hdx (- prelim-army-cx hx))
       (define hdy (- prelim-army-cy hy))
       (define hd (max 1.0 (sqrt (+ (* hdx hdx) (* hdy hdy)))))
       (define hnx (/ (- hdy) hd))
       (define hny (/ hdx hd))
       (define left-ids
         (for/list ([u (in-list affected)] #:when (even? (hash-ref u 'id 0)))
           (define uid (hash-ref u 'id 0))
           (set-add! splash-evading-tags uid)
           uid))
       (define right-ids
         (for/list ([u (in-list affected)] #:when (odd? (hash-ref u 'id 0)))
           (define uid (hash-ref u 'id 0))
           (set-add! splash-evading-tags uid)
           uid))
       (when (not (null? left-ids))
         (l34-emit! ctx (list 'kite left-ids
                      (l34-quantize-cell-2.5 ctx (+ hx (* 4.5 hnx) (* 2.0 (/ hdx hd))) base-x)
                      (l34-quantize-cell-2.5 ctx (+ hy (* 4.5 hny) (* 2.0 (/ hdy hd))) base-y))))
       (when (not (null? right-ids))
         (l34-emit! ctx (list 'kite right-ids
                      (l34-quantize-cell-2.5 ctx (+ hx (* -4.5 hnx) (* 2.0 (/ hdx hd))) base-x)
                      (l34-quantize-cell-2.5 ctx (+ hy (* -4.5 hny) (* 2.0 (/ hdy hd))) base-y))))]
      [else
       (for ([u (in-list affected)])
         (define uid (hash-ref u 'id 101))
         (define ux (hash-ref u 'x base-x))
         (define uy (hash-ref u 'y base-y))
         (define-values (kx ky) (compute-kite-vector ux uy hx hy 3.5))
         (set-add! splash-evading-tags uid)
         (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy))))]))

  ;; 1b. Enemy Siege Tank Deadzone Dive / Radial Split & Lurker Spine Avoidance
  (define lurker-spine-effects
    (if (null? effects)
        '()
        (for/list ([eff (in-list effects)]
                   #:when (and (hash? eff)
                               (memq (or (hash-ref eff 'type #f)
                                         (hash-ref eff 'spell #f)
                                         (hash-ref eff 'kind #f)
                                         (hash-ref eff 'ability #f)
                                         (hash-ref eff 'name 'none))
                                     '(lurker-spines lurker-spine lurker-mp-spines))))
          eff)))
  (define suppress-tank-split?
    (or siege-line-hold?
        (and live-tactics-obs?
             (>= (length enemy-sieged-tanks-near) 2)
             can-break-siege-line?
             (>= (length combat-units) 6))))
  (define eff-tank-lurker-hazards
    (if (and suppress-tank-split? (pair? tank-lurker-hazards))
        (filter (lambda (e) (not (memq (unit-type-sym e) '(siege-tank-sieged siege-tank))))
                tank-lurker-hazards)
        tank-lurker-hazards))
  (when (or (pair? eff-tank-lurker-hazards) (pair? lurker-spine-effects))
    (define ground-splash-cands
      (for/list ([u (in-list combat-units)]
                 #:when (let* ([uid (hash-ref u 'id 101)]
                               [ut (unit-type-sym u)]
                               [ab-id (hash-ref u 'order-ability-id 0)]
                               [prot (and live-tactics-obs? (> ab-id 0) (fast-order-protection-class ab-id))])
                          (and (not (fast-unit-is-flying-sym? ut))
                               (not (and (eq? ut 'ghost)
                                         (null? lurker-spine-effects)
                                         (let ([en (hash-ref u 'energy 0)])
                                           (and (real? en) (>= en 50)))))
                               (not (set-member? splash-evading-tags uid))
                               (not (and live-tactics-obs?
                                         (or (memq prot '(morph channel cast-walk))
                                             (snipe-channel-locked? spell-claims-rt uid frame))))
                               (not (order-ledger-unit-in-attack-swing? oledger u)))))
        u))
    (when (pair? ground-splash-cands)
      (define tank-lurker-cmds
        (plan-avoid-siege-tank-and-lurker-splash-zones ground-splash-cands
                                                       eff-tank-lurker-hazards
                                                       #:effects lurker-spine-effects
                                                       #:home-x base-fx
                                                       #:home-y base-fy))
      (for ([cmd (in-list tank-lurker-cmds)])
        (define uid (hash-ref cmd 'unit-id #f))
        (define tx (hash-ref cmd 'target-x #f))
        (define ty (hash-ref cmd 'target-y #f))
        (when (and uid (real? tx) (real? ty))
          (set-add! splash-evading-tags uid)
          (l34-emit! ctx (list 'move uid (safe-coord tx base-x) (safe-coord ty base-y)))))))

  ;; 2. Enemy Widow Mine Out-Range Snipe, Lock Pull-Back, Bait & Cooldown Tracking
  (for ([wm (in-list enemy-widow-mines)])
    (define wm-id (hash-ref wm 'id 901))
    (define wmx (hash-ref wm 'x nat-x))
    (define wmy (hash-ref wm 'y nat-y))
    (define wm-burrowed?
      (or (eq? (unit-type-sym wm) 'widow-mine-burrowed)
          (eq? (hash-ref wm 'burrowed #f) #t)))
    (define wm-cloaked? (eq? (hash-ref wm 'cloaked #f) #t))
    (define wm-targetable?
      (or (not wm-burrowed?)
          (not wm-cloaked?)
          ally-has-detector?
          (not live-tactics-obs?)))
    (define disarmed-until (hash-ref splash-wm-disarmed-ht wm-id -1))
    (define engaged-tag (hash-ref wm 'engaged-target-tag 0))
    (define explicit-target-id
      (cond
        [(and (exact-integer? engaged-tag) (> engaged-tag 0)) engaged-tag]
        [else (hash-ref wm 'target-id #f)]))
    (define (unit-eff-ground-range u)
      (define ut (unit-type-sym u))
      (define base-gr
        (exact->inexact
         (hash-ref u 'ground-range
                   (hash-ref (fast-unit-combat-stats ut) 'ground-range 0.0))))
      (+ base-gr
         (cond
           [(and (eq? ut 'hydralisk) (l34-has-upgrade? ctx 'grooved-spines)) 1.0]
           [(and (eq? ut 'colossus) (l34-has-upgrade? ctx 'extended-thermal-lance)) 2.0]
           [else 0.0])))
    (when (>= frame disarmed-until)
      (define wm-snipers
        (filter (lambda (u)
                  (define gr (unit-eff-ground-range u))
                  (and (>= gr 6.0)
                       (not (set-member? splash-evading-tags (hash-ref u 'id 0)))
                       (<= (fast-dist2d wmx wmy (hash-ref u 'x base-x) (hash-ref u 'y base-y)) 11.5)))
                combat-units))
      (define targeted-ally
        (or (and explicit-target-id
                 (findf (lambda (u) (equal? (hash-ref u 'id -1) explicit-target-id)) ally-units))
            (let loop ([rem ally-units] [best-u #f] [best-d 5.3])
              (if (null? rem)
                  best-u
                  (let* ([u (car rem)]
                         [d (fast-dist2d wmx wmy (hash-ref u 'x base-x) (hash-ref u 'y base-y))])
                    (if (< d best-d)
                        (loop (cdr rem) u d)
                        (loop (cdr rem) best-u best-d)))))))
      (cond
        [(and wm-targetable? (not (null? wm-snipers)))
         (for ([r (in-list wm-snipers)])
           (define rid (hash-ref r 'id 101))
           (set-add! splash-evading-tags rid)
           (l34-emit! ctx (list 'attack-unit rid wm-id)))
         (for ([u (in-list combat-units)])
           (define uid (hash-ref u 'id 101))
           (define ut (unit-type-sym u))
           (define gr (unit-eff-ground-range u))
           (define ux (hash-ref u 'x base-x))
           (define uy (hash-ref u 'y base-y))
           (when (and (< gr 5.5)
                      (not (fast-unit-is-flying-sym? ut))
                      (not (set-member? splash-evading-tags uid))
                      (<= (fast-dist2d wmx wmy ux uy) 6.8))
             (define-values (kx ky) (compute-kite-vector ux uy wmx wmy 3.5))
             (set-add! splash-evading-tags uid)
             (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy)))))]
        [(and live-tactics-obs? wm-burrowed? (not wm-targetable?))
         (define nearby-pack
           (filter (lambda (u)
                     (<= (dist2d wmx wmy (hash-ref u 'x base-x) (hash-ref u 'y base-y)) 9.5))
                   combat-units))
         (when (>= (length nearby-pack) 2)
           (define cheap-pool
             (filter (lambda (u) (memq (unit-type-sym u) '(zergling zealot marine adept)))
                     nearby-pack))
           (define bait-u
             (argmin (lambda (u) (hash-ref u 'hp 100))
                     (if (not (null? cheap-pool)) cheap-pool nearby-pack)))
           (define bait-id (hash-ref bait-u 'id 101))
           (set-add! splash-evading-tags bait-id)
           (hash-set! splash-wm-disarmed-ht wm-id (+ frame 620))
           (l34-emit! ctx (list 'move bait-id (safe-coord wmx base-x) (safe-coord wmy base-y)))
           (for ([u (in-list nearby-pack)]
                 #:when (not (equal? (hash-ref u 'id -1) bait-id)))
             (define uid (hash-ref u 'id 101))
             (define ux (hash-ref u 'x base-x))
             (define uy (hash-ref u 'y base-y))
             (when (and (not (set-member? splash-evading-tags uid))
                        (<= (dist2d wmx wmy ux uy) 7.5))
               (define-values (kx ky) (compute-kite-vector ux uy wmx wmy 4.5))
               (set-add! splash-evading-tags uid)
               (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy))))))]
        [targeted-ally
         (define tid (hash-ref targeted-ally 'id 101))
         (define tx (hash-ref targeted-ally 'x base-x))
         (define ty (hash-ref targeted-ally 'y base-y))
         (when explicit-target-id
           (hash-set! splash-wm-disarmed-ht wm-id (+ frame 620)))
         (unless (set-member? splash-evading-tags tid)
           (define-values (kx ky) (compute-kite-vector tx ty wmx wmy 3.5))
           (set-add! splash-evading-tags tid)
           (l34-emit! ctx (list 'kite tid (l34-quantize-cell-2.5 ctx kx tx) (l34-quantize-cell-2.5 ctx ky ty))))
         (for ([ally (in-list combat-units)])
           (define aid (hash-ref ally 'id 101))
           (define ax (hash-ref ally 'x base-x))
           (define ay (hash-ref ally 'y base-y))
           (when (and (not (equal? aid tid))
                      (not (set-member? splash-evading-tags aid))
                      (<= (dist2d tx ty ax ay) 2.2))
             (define-values (sx sy) (compute-kite-vector ax ay tx ty 2.8))
             (set-add! splash-evading-tags aid)
             (l34-emit! ctx (list 'kite aid (l34-quantize-cell-2.5 ctx sx ax) (l34-quantize-cell-2.5 ctx sy ay)))))])))

)

(define (l34-phase4b-baneling-oracle! ctx)
  (define ally-bldgs (l34-ctx-ally-bldgs ctx))
  (define ally-has-detector? (l34-ctx-ally-has-detector? ctx))
  (define ally-units (l34-ctx-ally-units ctx))
  (define base-x (l34-ctx-base-x ctx))
  (define base-y (l34-ctx-base-y ctx))
  (define can-break-siege-line? (l34-ctx-can-break-siege-line? ctx))
  (define combat-units (l34-ctx-combat-units ctx))
  (define enemy-banelings (l34-ctx-enemy-banelings ctx))
  (define enemy-bldgs (l34-ctx-enemy-bldgs ctx))
  (define enemy-exp-x (l34-ctx-enemy-exp-x ctx))
  (define enemy-exp-y (l34-ctx-enemy-exp-y ctx))
  (define enemy-sieged-tanks-near (l34-ctx-enemy-sieged-tanks-near ctx))
  (define enemy-stasis-traps (l34-ctx-enemy-stasis-traps ctx))
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define enemy-x (l34-ctx-enemy-x ctx))
  (define enemy-y (l34-ctx-enemy-y ctx))
  (define frame (l34-ctx-frame ctx))
  (define ft (l34-ctx-ft ctx))
  (define immobile-bile-targets (l34-ctx-immobile-bile-targets ctx))
  (define l34-sc (l34-ctx-l34-sc ctx))
  (define linear-splash-enemies (l34-ctx-linear-splash-enemies ctx))
  (define live-tactics-obs? (l34-ctx-live-tactics-obs? ctx))
  (define nat-x (l34-ctx-nat-x ctx))
  (define nat-y (l34-ctx-nat-y ctx))
  (define oledger (l34-ctx-oledger ctx))
  (define prelim-army-cx (l34-ctx-prelim-army-cx ctx))
  (define prelim-army-cy (l34-ctx-prelim-army-cy ctx))
  (define ravager-cast-tags (l34-ctx-ravager-cast-tags ctx))
  (define rt (l34-ctx-rt ctx))
  (define splash-evading-tags (l34-ctx-splash-evading-tags ctx))
  ;; 3. Enemy Baneling Light-Unit Radial Pre-Split (Armored units hold & focus-fire)
  (define light-split-syms
    '(marine zergling zealot adept hydralisk reaper ghost sentry high-templar))
  (when (not (null? enemy-banelings))
    (for ([u (in-list combat-units)])
      (define uid (hash-ref u 'id 101))
      (define ut (unit-type-sym u))
      (define ux (hash-ref u 'x base-x))
      (define uy (hash-ref u 'y base-y))
      (when (and (memq ut light-split-syms)
                 (not (set-member? splash-evading-tags uid))
                 (not (order-ledger-unit-in-attack-swing? oledger u)))
        (define closest-bane
          (let loop ([rem enemy-banelings] [best-b #f] [best-d 4.5])
            (if (null? rem)
                best-b
                (let* ([b (car rem)]
                       [d (dist2d ux uy (hash-ref b 'x nat-x) (hash-ref b 'y nat-y))])
                  (if (<= d best-d)
                      (loop (cdr rem) b d)
                      (loop (cdr rem) best-b best-d))))))
        (when closest-bane
          (define bx (hash-ref closest-bane 'x nat-x))
          (define by (hash-ref closest-bane 'y nat-y))
          (define-values (kx ky) (compute-kite-vector ux uy bx by 3.0))
          (set-add! splash-evading-tags uid)
          (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy)))))))

  ;; 4. Enemy Hellion & Burrowed Lurker Linear Splash Lateral Scatter (+/- perpendicular n-hat)
  (when (and (not (null? linear-splash-enemies)) (>= (length combat-units) 2))
    (for ([u (in-list combat-units)])
      (define uid (hash-ref u 'id 101))
      (define ux (hash-ref u 'x base-x))
      (define uy (hash-ref u 'y base-y))
      (when (and (not (fast-unit-is-flying-sym? (unit-type-sym u)))
                 (not (set-member? splash-evading-tags uid))
                 (not (order-ledger-unit-in-attack-swing? oledger u)))
        (for ([le (in-list linear-splash-enemies)]
              #:unless (set-member? splash-evading-tags uid))
          (define lex (hash-ref le 'x nat-x))
          (define ley (hash-ref le 'y nat-y))
          (define max-line-range (if (eq? (unit-type-sym le) 'hellion) 6.5 9.5))
          (define d (fast-dist2d ux uy lex ley))
          (when (and (> d 0.25) (<= d max-line-range))
            (define vx (/ (- ux lex) d))
            (define vy (/ (- uy ley) d))
            (define collinear-ally?
              (for/or ([o (in-list combat-units)]
                       #:when (not (equal? (hash-ref o 'id -1) uid)))
                (define ox (hash-ref o 'x base-x))
                (define oy (hash-ref o 'y base-y))
                (define odx (- ox lex))
                (define ody (- oy ley))
                (define proj (+ (* odx vx) (* ody vy)))
                (define perp (abs (- (* odx vy) (* ody vx))))
                (and (> proj 0.5) (<= proj (+ max-line-range 1.0)) (<= perp 1.1))))
            (when collinear-ally?
              (define sign (if (even? uid) 1.0 -1.0))
              (define nx (* sign (- vy)))
              (define ny (* sign vx))
              (define lx (+ ux (* 2.5 nx)))
              (define ly (+ uy (* 2.5 ny)))
              (set-add! splash-evading-tags uid)
              (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx lx ux) (l34-quantize-cell-2.5 ctx ly uy)))))))))

  ;; 5. Counter-Micro vs. Enemy `oracle-stasis-trap` / `stasis-ward`
  (for ([trap (in-list enemy-stasis-traps)])
    (define trap-id (hash-ref trap 'id 9001))
    (define tx (hash-ref trap 'x nat-x))
    (define ty (hash-ref trap 'y nat-y))
    (define trap-prog (exact->inexact (hash-ref trap 'build-progress 1.0)))
    (define trap-cloaked? (eq? (hash-ref trap 'cloaked #f) #t))
    (define trap-targetable?
      (or (< trap-prog 1.0)
          (not trap-cloaked?)
          ally-has-detector?))
    (define ranged-snipers
      (filter (lambda (u)
                (define ut (unit-type-sym u))
                (define gr (exact->inexact
                            (hash-ref u 'ground-range
                                      (hash-ref (fast-unit-combat-stats ut) 'ground-range 0.0))))
                (and (>= gr 4.5)
                     (<= (fast-dist2d tx ty (hash-ref u 'x base-x) (hash-ref u 'y base-y)) 11.0)))
              combat-units))
    (cond
      [(and trap-targetable? (not (null? ranged-snipers)))
       (for ([r (in-list ranged-snipers)])
         (define rid (hash-ref r 'id 101))
         (set-add! splash-evading-tags rid)
         (l34-emit! ctx (list 'attack-unit rid trap-id)))
       (for ([u (in-list combat-units)])
         (define uid (hash-ref u 'id 101))
         (define ut (unit-type-sym u))
         (define gr (exact->inexact
                     (hash-ref u 'ground-range
                               (hash-ref (fast-unit-combat-stats ut) 'ground-range 0.0))))
         (define ux (hash-ref u 'x base-x))
         (define uy (hash-ref u 'y base-y))
         (when (and (< gr 4.5)
                    (not (fast-unit-is-flying-sym? ut))
                    (<= (fast-dist2d tx ty ux uy) 6.0))
           (define-values (kx ky) (compute-kite-vector ux uy tx ty 6.8))
           (set-add! splash-evading-tags uid)
           (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx base-x) (l34-quantize-cell-2.5 ctx ky base-y)))))]
      [(>= trap-prog 1.0)
       (define nearby-ground
         (filter (lambda (u)
                   (and (not (fast-unit-is-flying-sym? (unit-type-sym u)))
                        (<= (fast-dist2d tx ty (hash-ref u 'x base-x) (hash-ref u 'y base-y)) 12.0)))
                 combat-units))
       (when (not (null? nearby-ground))
         (define cheap-cands
           (filter (lambda (u) (memq (unit-type-sym u) '(zergling marine zealot adept)))
                   nearby-ground))
         (define sac-unit
           (argmin (lambda (u) (hash-ref u 'hp 100))
                   (if (not (null? cheap-cands)) cheap-cands nearby-ground)))
         (define sac-id (hash-ref sac-unit 'id 101))
         (set-add! splash-evading-tags sac-id)
         (l34-emit! ctx (list 'trigger-stasis-ward-single-unit
                      sac-id trap-id (exact-round tx) (exact-round ty)))
         (l34-emit! ctx (list 'move sac-id (exact-round tx) (exact-round ty)))
         (for ([u (in-list nearby-ground)]
               #:when (not (equal? (hash-ref u 'id -1) sac-id)))
           (define uid (hash-ref u 'id 101))
           (define ux (hash-ref u 'x base-x))
           (define uy (hash-ref u 'y base-y))
           (when (<= (dist2d tx ty ux uy) 6.5)
             (define-values (kx ky) (compute-kite-vector ux uy tx ty 6.8))
             (set-add! splash-evading-tags uid)
             (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx base-x) (l34-quantize-cell-2.5 ctx ky base-y))))))]))

  ;; 6. Anti-Siege-Tank-Sieged Line Discipline, Staggered Ravager Bile & 3-Flank Break
  (when (and live-tactics-obs? (not (null? immobile-bile-targets)))
    (define free-ravagers
      (filter (lambda (u)
                (and (eq? (unit-type-sym u) 'ravager)
                     (not (set-member? ravager-cast-tags (hash-ref u 'id 0)))))
              combat-units))
    (for ([tgt (in-list immobile-bile-targets)])
      (define tx0 (hash-ref tgt 'x nat-x))
      (define ty0 (hash-ref tgt 'y nat-y))
      (define in-range-ravs
        (filter (lambda (r)
                  (and (not (set-member? ravager-cast-tags (hash-ref r 'id 0)))
                       (<= (dist2d tx0 ty0 (hash-ref r 'x base-x) (hash-ref r 'y base-y)) 9.5)))
                free-ravagers))
      (for ([r (in-list (take in-range-ravs (min 3 (length in-range-ravs))))]
            [bidx (in-naturals)])
        (define rid (hash-ref r 'id 140))
        (define off-x (* 0.35 (- bidx 1)))
        (define off-y (* 0.35 (if (= bidx 1) 1 0)))
        (set-add! ravager-cast-tags rid)
        (set-add! splash-evading-tags rid)
        (l34-emit! ctx (list 'cast-spell rid 'corrosive-bile
                     (safe-coord (+ tx0 off-x) tx0)
                     (safe-coord (+ ty0 off-y) ty0))))))

  (when (and live-tactics-obs?
             (>= (length enemy-sieged-tanks-near) 2)
             can-break-siege-line?
             (>= (length combat-units) 6)
             (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                        '(siege-flank-wings)
                                        frame
                                        24))
    (define st0 (car enemy-sieged-tanks-near))
    (define stx (hash-ref st0 'x enemy-x))
    (define sty (hash-ref st0 'y enemy-y))
    (define sdx (- stx prelim-army-cx))
    (define sdy (- sty prelim-army-cy))
    (define sd (max 1.0 (sqrt (+ (* sdx sdx) (* sdy sdy)))))
    (define snx (/ (- sdy) sd))
    (define sny (/ sdx sd))
    (define flank-units
      (sort (filter (lambda (u)
                      (not (set-member? splash-evading-tags (hash-ref u 'id 0))))
                    combat-units)
            <
            #:key (lambda (u)
                    (+ (* (- (hash-ref u 'x prelim-army-cx) prelim-army-cx) snx)
                       (* (- (hash-ref u 'y prelim-army-cy) prelim-army-cy) sny)))))
    (define n-flank (length flank-units))
    (define cut1 (quotient n-flank 3))
    (define cut2 (quotient (* 2 n-flank) 3))
    (define spatial-wings
      (if (>= n-flank 3)
          (list (take flank-units cut1)
                (take (drop flank-units cut1) (- cut2 cut1))
                (drop flank-units cut2))
          (list flank-units '() '())))
    (for ([wing-us (in-list spatial-wings)]
          [lat (in-list '(-5.0 0.0 5.0))])
      (define wing-ids (map (lambda (u) (hash-ref u 'id 0)) wing-us))
      (when (not (null? wing-ids))
        (for ([wid (in-list wing-ids)])
          (set-add! splash-evading-tags wid))
        (l34-emit! ctx (list 'attack-pos wing-ids
                     (safe-coord (+ stx (* lat snx)) stx)
                     (safe-coord (+ sty (* lat sny)) sty))))))

  ;; ---------------------------------------------------------------------------
  ;; Friendly Oracle Spell Micro (`stasis-ward` & `pulsar-beam`) - Legacy Synthetic Path
  ;; ---------------------------------------------------------------------------
  (define live-obs? live-tactics-obs?)
  (define oracle-cast-tags (pooled-mutable-seteqv! l34-sc 'oracle-cast-tags))
  (define queen-cast-tags (pooled-mutable-seteqv! l34-sc 'queen-cast-tags))
  (define wave3-thor-morphed-tags (pooled-mutable-seteqv! l34-sc 'wave3-thor-morphed-tags))
  (define wave3-viking-morphed-tags (pooled-mutable-seteqv! l34-sc 'wave3-viking-morphed-tags))
  (define wave3-marauder-target-tags (pooled-mutable-seteqv! l34-sc 'wave3-marauder-target-tags))
  (unless live-obs?
    (define friendly-stasis-traps
      (filter (lambda (u) (memq (unit-type-sym u) '(oracle-stasis-trap stasis-ward)))
              (append ally-units ally-bldgs)))
    (define enemy-townhalls
      (filter (lambda (eb)
                (memq (unit-type-sym eb)
                      '(hatchery lair hive nexus command-center orbital-command planetary-fortress)))
              enemy-bldgs))
    (for ([u (in-list combat-units)]
          #:when (eq? (unit-type-sym u) 'oracle))
      (define uid (hash-ref u 'id 101))
      (define ux (hash-ref u 'x base-x))
      (define uy (hash-ref u 'y base-y))
      (define u-energy (hash-ref u 'energy 0))
      (define u-buffs (hash-ref u 'buffs '()))
      (define nearby-enemy-workers
        (filter (lambda (e)
                  (and (memq (unit-type-sym e) '(drone scv probe))
                       (<= (dist2d ux uy (hash-ref e 'x 9999) (hash-ref e 'y 9999)) 10.0)))
                enemy-units))
      (define nearby-enemy-th
        (findf (lambda (th)
                 (<= (dist2d ux uy (hash-ref th 'x 9999) (hash-ref th 'y 9999)) 10.0))
               enemy-townhalls))
      (define close-enemy-workers
        (filter (lambda (ew)
                  (<= (dist2d ux uy (hash-ref ew 'x 9999) (hash-ref ew 'y 9999)) 5.0))
                nearby-enemy-workers))
      (when (>= u-energy 50)
        (cond
          [(or (>= (length nearby-enemy-workers) 2) nearby-enemy-th)
           (define-values (wx wy)
             (if (not (null? nearby-enemy-workers))
                 (let ([n (length nearby-enemy-workers)])
                   (values (exact-round (/ (for/sum ([w (in-list nearby-enemy-workers)])
                                             (hash-ref w 'x ux))
                                           n))
                           (exact-round (/ (for/sum ([w (in-list nearby-enemy-workers)])
                                             (hash-ref w 'y uy))
                                           n))))
                 (values (exact-round (hash-ref nearby-enemy-th 'x ux))
                         (exact-round (hash-ref nearby-enemy-th 'y uy)))))
           (set-add! oracle-cast-tags uid)
           (l34-emit! ctx (list 'cast-spell uid 'stasis-ward wx wy))
           (when (not (null? close-enemy-workers))
             (define nearest-ew
               (argmin (lambda (ew) (dist2d ux uy (hash-ref ew 'x ux) (hash-ref ew 'y uy)))
                       close-enemy-workers))
             (l34-emit! ctx (list 'cast-spell uid 'pulsar-beam (hash-ref nearest-ew 'id 0))))]
          [(and (<= (dist2d ux uy enemy-exp-x enemy-exp-y) 15.0)
                (not (ormap (lambda (th)
                              (<= (dist2d enemy-exp-x enemy-exp-y
                                          (hash-ref th 'x 9999) (hash-ref th 'y 9999))
                                  5.0))
                            enemy-townhalls))
                (not (ormap (lambda (ft)
                              (<= (dist2d enemy-exp-x enemy-exp-y
                                          (hash-ref ft 'x 9999) (hash-ref ft 'y 9999))
                                  5.0))
                            friendly-stasis-traps)))
           (set-add! oracle-cast-tags uid)
           (l34-emit! ctx (list 'cast-spell uid 'stasis-ward enemy-exp-x enemy-exp-y))]
          [(and (<= (dist2d ux uy nat-x nat-y) 15.0)
                (not (ormap (lambda (ft)
                              (<= (dist2d nat-x nat-y
                                          (hash-ref ft 'x 9999) (hash-ref ft 'y 9999))
                                  5.0))
                            friendly-stasis-traps))
                (or (>= u-energy 75)
                    (ormap (lambda (e)
                             (<= (dist2d ux uy (hash-ref e 'x 9999) (hash-ref e 'y 9999)) 18.0))
                           enemy-units)))
           (set-add! oracle-cast-tags uid)
           (l34-emit! ctx (list 'cast-spell uid 'stasis-ward nat-x nat-y))]))
      (when (and (list? u-buffs)
                 (or (memq 'pulsar-beam u-buffs) (memq 'oracle-weapon u-buffs))
                 (not (ormap (lambda (e)
                               (<= (dist2d ux uy (hash-ref e 'x 9999) (hash-ref e 'y 9999)) 6.5))
                             enemy-units)))
        (l34-emit! ctx (list 'cast-spell uid 'pulsar-beam-off uid)))))

  (set-l34-ctx-live-obs?! ctx live-obs?)
  (set-l34-ctx-oracle-cast-tags! ctx oracle-cast-tags)
  (set-l34-ctx-queen-cast-tags! ctx queen-cast-tags)
  (set-l34-ctx-wave3-marauder-target-tags! ctx wave3-marauder-target-tags)
  (set-l34-ctx-wave3-thor-morphed-tags! ctx wave3-thor-morphed-tags)
  (set-l34-ctx-wave3-viking-morphed-tags! ctx wave3-viking-morphed-tags)
)

(define (l34-phase5a-wave-casters! ctx)
  (define ally-bldgs (l34-ctx-ally-bldgs ctx))
  (define ally-units (l34-ctx-ally-units ctx))
  (define any-pro-caster? (l34-ctx-any-pro-caster? ctx))
  (define armory-ready-bldgs? (l34-ctx-armory-ready-bldgs? ctx))
  (define base-x (l34-ctx-base-x ctx))
  (define base-y (l34-ctx-base-y ctx))
  (define bstates (l34-ctx-bstates ctx))
  (define combat-units (l34-ctx-combat-units ctx))
  (define dead-tags-rt (l34-ctx-dead-tags-rt ctx))
  (define disruptor-handled-tags (l34-ctx-disruptor-handled-tags ctx))
  (define effects (l34-ctx-effects ctx))
  (define enemy-bldgs (l34-ctx-enemy-bldgs ctx))
  (define enemy-exp-x (l34-ctx-enemy-exp-x ctx))
  (define enemy-exp-y (l34-ctx-enemy-exp-y ctx))
  (define enemy-sieged-tanks-near (l34-ctx-enemy-sieged-tanks-near ctx))
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define enemy-x (l34-ctx-enemy-x ctx))
  (define enemy-y (l34-ctx-enemy-y ctx))
  (define frame (l34-ctx-frame ctx))
  (define leases (l34-ctx-leases ctx))
  (define live-combat-supply (l34-ctx-live-combat-supply ctx))
  (define live-obs? (l34-ctx-live-obs? ctx))
  (define mode-candidates (l34-ctx-mode-candidates ctx))
  (define nat-x (l34-ctx-nat-x ctx))
  (define nat-y (l34-ctx-nat-y ctx))
  (define obs (l34-ctx-obs ctx))
  (define oracle-cast-tags (l34-ctx-oracle-cast-tags ctx))
  (define queen-cast-tags (l34-ctx-queen-cast-tags ctx))
  (define ravager-cast-tags (l34-ctx-ravager-cast-tags ctx))
  (define researched-upgs (l34-ctx-researched-upgs ctx))
  (define siege-line-hold? (l34-ctx-siege-line-hold? ctx))
  (define snipe-locked-tags (l34-ctx-snipe-locked-tags ctx))
  (define spell-claims-rt (l34-ctx-spell-claims-rt ctx))
  (define splash-evading-tags (l34-ctx-splash-evading-tags ctx))
  (define splash-thor-dwell-ht (l34-ctx-splash-thor-dwell-ht ctx))
  (define splash-vik-dwell-ht (l34-ctx-splash-vik-dwell-ht ctx))
  (define under-tactics-base-attack? (l34-ctx-under-tactics-base-attack? ctx))
  (define unit-mode-tr (l34-ctx-unit-mode-tr ctx))
  (define visible-enemy-combat-supply (l34-ctx-visible-enemy-combat-supply ctx))
  (define wave3-handled-tags (l34-ctx-wave3-handled-tags ctx))
  (define wave3-marauder-target-tags (l34-ctx-wave3-marauder-target-tags ctx))
  (define wave3-thor-morphed-tags (l34-ctx-wave3-thor-morphed-tags ctx))
  (define wave3-viking-morphed-tags (l34-ctx-wave3-viking-morphed-tags ctx))
  (define weighted-combat-units (l34-ctx-weighted-combat-units ctx))
  ;; ---------------------------------------------------------------------------
  ;; Active Combat Spells, Bistable Wave Hysteresis & Mutually Exclusive Micro
  ;; ---------------------------------------------------------------------------
  (define lanchester-force-ratio
    (/ (exact->inexact live-combat-supply)
       (max 8.0 (exact->inexact visible-enemy-combat-supply))))
  (define live-attack-wave-min
    (if live-obs?
        22
        SC2-ATTACK-WAVE-MIN-COMBAT-UNITS))
  (define wave-commit-active?
    (if live-obs?
        (bistable-hysteresis-step
         bstates
         'army-attack-wave
         frame
         #:enter? (or (and (>= live-combat-supply 26) (>= lanchester-force-ratio 1.35))
                      (>= live-combat-supply 42)
                      (>= weighted-combat-units live-attack-wave-min))
         #:exit? (and (< live-combat-supply 16)
                      (< lanchester-force-ratio 0.85))
         #:min-dwell-loops 112
         #:cooldown-loops 44)
        #t))
  (define bo-tplan (l34-get-bo-tplan ctx))
  (define bo-disp (bo-active-tactical-plan-disposition bo-tplan))
  (define bo-px (safe-coord (bo-active-tactical-plan-primary-target-x bo-tplan) enemy-x))
  (define bo-py (safe-coord (bo-active-tactical-plan-primary-target-y bo-tplan) enemy-y))
  (define bo-sx (safe-coord (bo-active-tactical-plan-secondary-fork-x bo-tplan) enemy-exp-x))
  (define bo-sy (safe-coord (bo-active-tactical-plan-secondary-fork-y bo-tplan) enemy-exp-y))
  (define bo-micro-dirs (bo-active-tactical-plan-micro-directives bo-tplan))
  (define bo-act-tactics (bo-active-tactical-plan-active-tactics bo-tplan))
  (define-values (bo-stage-x bo-stage-y)
    (let* ([sdx (- base-x bo-px)]
           [sdy (- base-y bo-py)]
           [sd (max 1.0 (sqrt (+ (* sdx sdx) (* sdy sdy))))])
      (values (safe-coord (+ bo-px (* 14.0 (/ sdx sd))) nat-x)
              (safe-coord (+ bo-py (* 14.0 (/ sdy sd))) nat-y))))
  (define bo-prepos-active?
    (and (eq? bo-disp 'pre-position-march-out)
         (not under-tactics-base-attack?)))
  (define bo-contain-active?
    (and (eq? bo-disp 'contain-and-deny-third)
         (not under-tactics-base-attack?)))
  (define bo-commit-active?
    (and (memq bo-disp '(execute-timing-attack-commit execute-timing-bypass-harass-fork))
         (not under-tactics-base-attack?)))
  (define bo-fork-active?
    (and bo-commit-active?
         (or (eq? bo-disp 'execute-timing-bypass-harass-fork)
             (> (+ (* (- bo-sx bo-px) (- bo-sx bo-px))
                   (* (- bo-sy bo-py) (- bo-sy bo-py)))
                4.0))))
  (define bo-rally-override?
    (or bo-prepos-active? bo-contain-active? bo-commit-active?))
  (define-values (bo-rally-tx bo-rally-ty)
    (cond
      [bo-prepos-active? (values bo-stage-x bo-stage-y)]
      [(or bo-contain-active? bo-commit-active?) (values bo-px bo-py)]
      [else (values nat-x nat-y)]))
  (define eff-wave-commit? (or wave-commit-active? bo-commit-active?))
  (define fbo-px (exact->inexact bo-px))
  (define fbo-py (exact->inexact bo-py))
  (define fbo-rally-tx (exact->inexact bo-rally-tx))
  (define fbo-rally-ty (exact->inexact bo-rally-ty))
  (define engagement-enemies
    (if live-obs?
        (append enemy-units enemy-bldgs)
        enemy-units))
  (define static-defense-syms
    '(spine-crawler photon-cannon bunker planetary-fortress))
  (define short-range-bio-syms
    '(marine marauder zergling roach hydralisk zealot stalker adept))

  ;; Wave 3: Pro Spellcaster Micro & Dedicated Terran Unit Mode/Lock-On Micro
  (when live-obs?
    (define sp-dirs
      (cond
        [(not any-pro-caster?) '()]
        [else
         (define inject-q-tags
           (for/list ([u (in-list ally-units)]
                      #:when (and (hash? u)
                                  (eq? (unit-type-sym u) 'queen)
                                  (exact-integer? (hash-ref u 'id #f))
                                  (unit-leased-above? leases (hash-ref u 'id) 'inject-queen frame)
                                  (not (unit-leased-above? leases (hash-ref u 'id) 'creep-queen frame))))
             (hash-ref u 'id)))
         (define spell-excl-tags
           (let ([seen (make-hasheqv)]
                 [acc-rev '()])
             (define (add-tag! id)
               (when (and (exact-integer? id) (not (hash-has-key? seen id)))
                 (hash-set! seen id #t)
                 (set! acc-rev (cons id acc-rev))))
             (for ([id (in-set splash-evading-tags)]) (add-tag! id))
             (for ([id (in-set disruptor-handled-tags)]) (add-tag! id))
             (for ([id (in-set ravager-cast-tags)]) (add-tag! id))
             (for ([id (in-set wave3-handled-tags)]) (add-tag! id))
             (for ([u (in-list ally-units)]
                   #:when (and (hash? u)
                               (eq? (unit-type-sym u) 'queen)))
               (define qid (hash-ref u 'id #f))
               (when (and (exact-integer? qid)
                          (unit-leased-above? leases qid 'creep-queen frame))
                 (add-tag! qid)))
             (reverse acc-rev)))
         (step-pro-spellcaster-micro!
          ally-units
          enemy-units
          #:claims spell-claims-rt
          #:current-frame frame
          #:ally-buildings ally-bldgs
          #:enemy-buildings enemy-bldgs
          #:effects effects
          #:researched-upgrades researched-upgs
          #:psi-storm-researched? (l34-has-upgrade? ctx 'psi-storm)
          #:yamato-researched? (l34-has-upgrade? ctx 'weapon-refit)
          #:home-x (exact->inexact base-x)
          #:home-y (exact->inexact base-y)
          #:natural-x (exact->inexact nat-x)
          #:natural-y (exact->inexact nat-y)
          #:enemy-base-x (exact->inexact enemy-x)
          #:enemy-base-y (exact->inexact enemy-y)
          #:inject-queen-tags inject-q-tags
          #:choke-points (list (cons nat-x nat-y) (cons enemy-exp-x enemy-exp-y))
          #:exclude-tags spell-excl-tags)]))
    (for ([sd (in-list sp-dirs)])
      (define cid (spell-directive-caster-tag sd))
      (define tid (spell-directive-target-tag sd))
      (define sexp (spell-directive->sexp sd))
      (set-add! wave3-handled-tags cid)
      (when (and (eq? (spell-directive-target-mode sd) 'pair) (exact-integer? tid) (> tid 0))
        (set-add! wave3-handled-tags tid))
      (when (eq? (spell-directive-ability sd) 'corrosive-bile)
        (set-add! ravager-cast-tags cid))
      (when (eq? (spell-directive-caster-type sd) 'queen)
        (set-add! queen-cast-tags cid))
      (when (eq? (spell-directive-caster-type sd) 'oracle)
        (set-add! oracle-cast-tags cid))
      (l34-emit-preserved! ctx sexp))
    (for ([u (in-list combat-units)]
          #:when (eq? (unit-type-sym u) 'ghost))
      (define uid (hash-ref u 'id -1))
      (when (and (exact-integer? uid)
                 (> uid 0)
                 (or (snipe-channel-locked? spell-claims-rt uid frame)
                     (spellcaster-channel-protected? u)))
        (set-add! snipe-locked-tags uid)
        (set-add! wave3-handled-tags uid)))

    (when (not (null? mode-candidates))
      (sync-unit-mode-tracker! unit-mode-tr ally-units enemy-units frame
                               #:dead-tags dead-tags-rt
                               #:track-air-memory? #t)
      (define armory-ready-rt?
        (or (and (hash-ref obs 'armory-ready? #f) #t)
            armory-ready-bldgs?))
      (define (um-eligible? u)
        (define uid (and (hash? u) (hash-ref u 'id -1)))
        (define ab-id (if (hash? u) (hash-ref u 'order-ability-id 0) 0))
        (define prot (and (> ab-id 0) (fast-order-protection-class ab-id)))
        (and (exact-integer? uid)
             (> uid 0)
             (not (memq prot '(morph channel)))
             (not (set-member? splash-evading-tags uid))
             (not (set-member? disruptor-handled-tags uid))
             (not (set-member? wave3-handled-tags uid))))
      (define-values (has-thor? has-hellion? has-viking? has-cyclone?)
        (for/fold ([th? #f] [he? #f] [vi? #f] [cy? #f])
                  ([u (in-list mode-candidates)]
                   #:when (um-eligible? u))
          (define ut (unit-type-sym u))
          (values (or th? (eq? ut 'thor) (eq? ut 'thor-ap))
                  (or he? (eq? ut 'hellion) (eq? ut 'hellbat))
                  (or vi? (eq? ut 'viking) (eq? ut 'viking-fighter) (eq? ut 'viking-assault))
                  (or cy? (eq? ut 'cyclone)))))
      (define um-allies
        (if (or has-thor? has-hellion? has-viking? has-cyclone?)
            (for/list ([u (in-list ally-units)] #:when (um-eligible? u)) u)
            '()))
      (when has-thor?
        (for ([td (in-list (plan-thor-modes um-allies enemy-units #:tracker unit-mode-tr #:current-frame frame))])
          (define uid (unit-mode-directive-unit-tag td))
          (hash-set! splash-thor-dwell-ht uid frame)
          (set-add! wave3-thor-morphed-tags uid)
          (set-add! wave3-handled-tags uid)
          (l34-emit-preserved! ctx (unit-mode-directive->sexp td))))
      (when has-hellion?
        (for ([hd (in-list (plan-hellion-modes um-allies enemy-units
                                               #:tracker unit-mode-tr
                                               #:current-frame frame
                                               #:armory-ready? armory-ready-rt?))])
          (set-add! wave3-handled-tags (unit-mode-directive-unit-tag hd))
          (l34-emit-preserved! ctx (unit-mode-directive->sexp hd))))
      (when has-viking?
        (for ([vd (in-list (plan-viking-modes um-allies enemy-units
                                              #:tracker unit-mode-tr
                                              #:current-frame frame
                                              #:home-x (exact->inexact base-x)
                                              #:home-y (exact->inexact base-y)))])
          (define uid (unit-mode-directive-unit-tag vd))
          (hash-set! splash-vik-dwell-ht uid frame)
          (set-add! wave3-viking-morphed-tags uid)
          (set-add! wave3-handled-tags uid)
          (l34-emit-preserved! ctx (unit-mode-directive->sexp vd))))
      (when has-cyclone?
        (for ([cd (in-list (plan-cyclone-micro um-allies enemy-units
                                               #:tracker unit-mode-tr
                                               #:current-frame frame
                                               #:home-x (exact->inexact base-x)
                                               #:home-y (exact->inexact base-y)))])
          (set-add! wave3-handled-tags (unit-mode-directive-unit-tag cd))
          (l34-emit-preserved! ctx (unit-mode-directive->sexp cd))))))

  (set-l34-ctx-bo-contain-active?! ctx bo-contain-active?)
  (set-l34-ctx-bo-fork-active?! ctx bo-fork-active?)
  (set-l34-ctx-bo-micro-dirs! ctx bo-micro-dirs)
  (set-l34-ctx-bo-prepos-active?! ctx bo-prepos-active?)
  (set-l34-ctx-bo-rally-override?! ctx bo-rally-override?)
  (set-l34-ctx-bo-rally-tx! ctx bo-rally-tx)
  (set-l34-ctx-bo-rally-ty! ctx bo-rally-ty)
  (set-l34-ctx-bo-sx! ctx bo-sx)
  (set-l34-ctx-bo-sy! ctx bo-sy)
  (set-l34-ctx-eff-wave-commit?! ctx eff-wave-commit?)
  (set-l34-ctx-engagement-enemies! ctx engagement-enemies)
  (set-l34-ctx-fbo-px! ctx fbo-px)
  (set-l34-ctx-fbo-py! ctx fbo-py)
  (set-l34-ctx-fbo-rally-tx! ctx fbo-rally-tx)
  (set-l34-ctx-fbo-rally-ty! ctx fbo-rally-ty)
  (set-l34-ctx-live-attack-wave-min! ctx live-attack-wave-min)
  (when (not (null? engagement-enemies))
    (when (not live-obs?)
      (define transfusion-queens
        (filter (lambda (u)
                  (and (eq? (unit-type-sym u) 'queen)
                       (not (unit-leased-above? leases (hash-ref u 'id 0) 'creep-queen frame))))
                ally-units))
      (define transfusion-targets
        (filter (lambda (u)
                  (define max-hp (hash-ref u 'max-hp 150))
                  (define cur-hp (hash-ref u 'hp max-hp))
                  (define buffs (hash-ref u 'buffs '()))
                  (define ut (unit-type-sym u))
                  (and (>= max-hp 120)
                       (not (memq ut '(zergling baneling broodling changeling)))
                       (>= (- max-hp cur-hp) 1)
                       (not (and (list? buffs) (memq 'transfusion buffs)))))
                combat-units))
      (fast-dispatch-macro-energy!
       transfusion-queens
       transfusion-targets
       frame
       (mutable-seteqv)
       #:min-energy SC2-QUEEN-TRANSFUSION-ENERGY
       #:valid-pair? (lambda (q tgt) #t)
       #:score-pair (lambda (q tgt)
                      (- (- (hash-ref tgt 'max-hp 150) (hash-ref tgt 'hp 100))
                         (* 2.0 (dist2d (hash-ref q 'x base-x) (hash-ref q 'y base-y)
                                        (hash-ref tgt 'x base-x) (hash-ref tgt 'y base-y)))))
       #:emit-cast! (lambda (q tgt)
                      (define qid (hash-ref q 'id 120))
                      (set-add! queen-cast-tags qid)
                      (l34-emit! ctx (list 'cast-spell qid 'transfusion (hash-ref tgt 'id 141))))))

    (when live-obs?
      (define marauder-allies
        (filter (lambda (u)
                  (and (eq? (unit-type-sym u) 'marauder)
                       (let ([uid (hash-ref u 'id -1)]
                             [ux (hash-ref u 'x base-x)]
                             [uy (hash-ref u 'y base-y)])
                         (and (exact-integer? uid)
                              (> uid 0)
                              (not (memq (fast-order-protection-class (hash-ref u 'order-ability-id 0))
                                         '(morph channel cast-walk)))
                              (not (set-member? splash-evading-tags uid))
                              (not (set-member? disruptor-handled-tags uid))
                              (not (set-member? wave3-handled-tags uid))
                              (not (and siege-line-hold?
                                        (ormap (lambda (st)
                                                 (<= (dist2d ux uy
                                                             (hash-ref st 'x 9999.0)
                                                             (hash-ref st 'y 9999.0))
                                                     15.5))
                                               enemy-sieged-tanks-near)))))))
                combat-units))
      (when (not (null? marauder-allies))
        (define concussive-ok? (l34-has-upgrade? ctx 'concussive-shells))
        (define marauder-orders
          (plan-marauder-concussive-targets marauder-allies enemy-units
                                            #:tracker unit-mode-tr
                                            #:current-frame frame
                                            #:concussive-shells-researched? concussive-ok?))
        (for ([mo (in-list marauder-orders)])
          (set-add! wave3-marauder-target-tags (marauder-target-order-unit-tag mo))
          (l34-emit-preserved! ctx (marauder-order->sexp mo)))))

  )
)

(define (l34-phase5b-engage! ctx)
  (when (pair? (l34-ctx-engagement-enemies ctx))
    (define ally-has-stealth? (l34-ctx-ally-has-stealth? ctx))
    (define ally-siege-supporters (l34-ctx-ally-siege-supporters ctx))
    (define any-ally-baneling? (l34-ctx-any-ally-baneling? ctx))
    (define base-x (l34-ctx-base-x ctx))
    (define base-y (l34-ctx-base-y ctx))
    (define bo-contain-active? (l34-ctx-bo-contain-active? ctx))
    (define bo-fork-active? (l34-ctx-bo-fork-active? ctx))
    (define bo-prepos-active? (l34-ctx-bo-prepos-active? ctx))
    (define bo-sx (l34-ctx-bo-sx ctx))
    (define bo-sy (l34-ctx-bo-sy ctx))
    (define can-break-siege-line? (l34-ctx-can-break-siege-line? ctx))
    (define combat-units (l34-ctx-combat-units ctx))
    (define disruptor-handled-tags (l34-ctx-disruptor-handled-tags ctx))
    (define eff-wave-commit? (l34-ctx-eff-wave-commit? ctx))
    (define enemy-air-or-colossus (l34-ctx-enemy-air-or-colossus ctx))
    (define enemy-massive-air-or-colossus (l34-ctx-enemy-massive-air-or-colossus ctx))
    (define enemy-mutalisks (l34-ctx-enemy-mutalisks ctx))
    (define enemy-pf-list (l34-ctx-enemy-pf-list ctx))
    (define enemy-sieged-tanks-near (l34-ctx-enemy-sieged-tanks-near ctx))
    (define enemy-units (l34-ctx-enemy-units ctx))
    (define engagement-enemies (l34-ctx-engagement-enemies ctx))
    (define fbo-px (l34-ctx-fbo-px ctx))
    (define fbo-py (l34-ctx-fbo-py ctx))
    (define frame (l34-ctx-frame ctx))
    (define ground-army-cx (l34-ctx-ground-army-cx ctx))
    (define ground-army-cy (l34-ctx-ground-army-cy ctx))
    (define have-heavy-or-siege-breaker? (l34-ctx-have-heavy-or-siege-breaker? ctx))
    (define l34-sc (l34-ctx-l34-sc ctx))
    (define live-obs? (l34-ctx-live-obs? ctx))
    (define live-owned-townhalls (l34-ctx-live-owned-townhalls ctx))
    (define live-tactics-obs? (l34-ctx-live-tactics-obs? ctx))
    (define live-upgrades-tracked? (l34-ctx-live-upgrades-tracked? ctx))
    (define local-val-ratio (l34-ctx-local-val-ratio ctx))
    (define nat-x (l34-ctx-nat-x ctx))
    (define nat-y (l34-ctx-nat-y ctx))
    (define oledger (l34-ctx-oledger ctx))
    (define prelim-army-cx (l34-ctx-prelim-army-cx ctx))
    (define prelim-army-cy (l34-ctx-prelim-army-cy ctx))
    (define oracle-cast-tags (l34-ctx-oracle-cast-tags ctx))
    (define queen-cast-tags (l34-ctx-queen-cast-tags ctx))
    (define ravager-cast-tags (l34-ctx-ravager-cast-tags ctx))
    (define rt (l34-ctx-rt ctx))
    (define siege-line-hold? (l34-ctx-siege-line-hold? ctx))
    (define snipe-locked-tags (l34-ctx-snipe-locked-tags ctx))
    (define splash-bc-jump-ht (l34-ctx-splash-bc-jump-ht ctx))
    (define splash-bc-yamato-ht (l34-ctx-splash-bc-yamato-ht ctx))
    (define splash-evading-tags (l34-ctx-splash-evading-tags ctx))
    (define splash-lib-dwell-ht (l34-ctx-splash-lib-dwell-ht ctx))
    (define splash-mode-dwell-ht (l34-ctx-splash-mode-dwell-ht ctx))
    (define splash-tank-dwell-ht (l34-ctx-splash-tank-dwell-ht ctx))
    (define splash-thor-dwell-ht (l34-ctx-splash-thor-dwell-ht ctx))
    (define splash-vik-dwell-ht (l34-ctx-splash-vik-dwell-ht ctx))
    (define splash-wm-dwell-ht (l34-ctx-splash-wm-dwell-ht ctx))
    (define tbrain-unit-actions (l34-ctx-tbrain-unit-actions ctx))
    (define third-x (l34-ctx-third-x ctx))
    (define third-y (l34-ctx-third-y ctx))
    (define under-tactics-base-attack? (l34-ctx-under-tactics-base-attack? ctx))
    (define wave3-handled-tags (l34-ctx-wave3-handled-tags ctx))
    (define wave3-marauder-target-tags (l34-ctx-wave3-marauder-target-tags ctx))
    (define wave3-thor-morphed-tags (l34-ctx-wave3-thor-morphed-tags ctx))
    (define prepped-eng-enemies
      (prep-enemy-target-descriptors engagement-enemies any-ally-baneling?))
    (define has-siege-supporters? (not (null? ally-siege-supporters)))
    (define combat-th-limit? (>= live-owned-townhalls 3))

    (define has-combat-skip-tags?
      (not (and (zero? (set-count disruptor-handled-tags))
                (zero? (set-count splash-evading-tags))
                (zero? (set-count wave3-handled-tags))
                (zero? (set-count snipe-locked-tags))
                (zero? (set-count queen-cast-tags))
                (zero? (set-count ravager-cast-tags))
                (zero? (set-count oracle-cast-tags)))))
    (define combat-skip-tags
      (and has-combat-skip-tags?
           (let ([ht (make-hasheqv)])
             (unless (zero? (set-count disruptor-handled-tags))
               (for ([id (in-set disruptor-handled-tags)]) (hash-set! ht id #t)))
             (unless (zero? (set-count splash-evading-tags))
               (for ([id (in-set splash-evading-tags)]) (hash-set! ht id #t)))
             (unless (zero? (set-count wave3-handled-tags))
               (for ([id (in-set wave3-handled-tags)]) (hash-set! ht id #t)))
             (unless (zero? (set-count snipe-locked-tags))
               (for ([id (in-set snipe-locked-tags)]) (hash-set! ht id #t)))
             (unless (zero? (set-count queen-cast-tags))
               (for ([id (in-set queen-cast-tags)]) (hash-set! ht id #t)))
             (unless (zero? (set-count ravager-cast-tags))
               (for ([id (in-set ravager-cast-tags)]) (hash-set! ht id #t)))
             (unless (zero? (set-count oracle-cast-tags))
               (for ([id (in-set oracle-cast-tags)]) (hash-set! ht id #t)))
             ht)))
    (define enemy-territory-cache (and (pair? combat-units) (pair? engagement-enemies) (pooled-hasheq! l34-sc 'enemy-territory-cache)))
    (define territory-miss (gensym 'terr-miss))
    (define fbase-x (exact->inexact base-x))
    (define fbase-y (exact->inexact base-y))
    (define fnat-x (exact->inexact nat-x))
    (define fnat-y (exact->inexact nat-y))
    (define fthird-x (exact->inexact third-x))
    (define fthird-y (exact->inexact third-y))
    (define d-home-leash (max 1.0 (dist2d prelim-army-cx prelim-army-cy base-x base-y)))
    (define caster-leash-x (safe-coord (+ prelim-army-cx (* 3.0 (/ (- base-x prelim-army-cx) d-home-leash))) base-x))
    (define caster-leash-y (safe-coord (+ prelim-army-cy (* 3.0 (/ (- base-y prelim-army-cy) d-home-leash))) base-y))
    (define fcaster-leash-x (exact->inexact caster-leash-x))
    (define fcaster-leash-y (exact->inexact caster-leash-y))
    (define ground-eng-enemy-recs-cache #f)
    (set-l34-ctx-combat-th-limit?! ctx combat-th-limit?)
    (set-l34-ctx-enemy-territory-cache! ctx enemy-territory-cache)
    (set-l34-ctx-territory-miss! ctx territory-miss)
    (set-l34-ctx-fbase-x! ctx fbase-x)
    (set-l34-ctx-fbase-y! ctx fbase-y)
    (set-l34-ctx-fnat-x! ctx fnat-x)
    (set-l34-ctx-fnat-y! ctx fnat-y)
    (set-l34-ctx-fthird-x! ctx fthird-x)
    (set-l34-ctx-fthird-y! ctx fthird-y)
    (set-l34-ctx-ground-eng-enemy-recs-cache! ctx ground-eng-enemy-recs-cache)
    (set-l34-ctx-caster-leash-x! ctx caster-leash-x)
    (set-l34-ctx-caster-leash-y! ctx caster-leash-y)
    (set-l34-ctx-fcaster-leash-x! ctx fcaster-leash-x)
    (set-l34-ctx-fcaster-leash-y! ctx fcaster-leash-y)
    (define has-tbrain-acts? (> (hash-count tbrain-unit-actions) 0))

    (for ([u (in-list combat-units)])
      (define uid (hash-ref u 'id 101))
      (define u-ab-id (if live-obs? (hash-ref u 'order-ability-id 0) 0))
      (define protected-class (and (> u-ab-id 0) (fast-order-protection-class u-ab-id)))
      (define skip?
        (or (and has-combat-skip-tags? (hash-has-key? combat-skip-tags uid))
            (and live-obs? (memq protected-class '(morph channel cast-walk)))
            (order-ledger-unit-in-attack-swing? oledger u)))
      (define-values (ux uy ut target-enemy prepped-hit?)
        (if skip?
            (values 0.0 0.0 'marine #f #f)
            (let ([x (hash-ref u 'x base-x)]
                  [y (hash-ref u 'y base-y)]
                  [t (unit-type-sym u)])
              (define-values (te ph?)
                (select-target-enemy-from-prepped x y prepped-eng-enemies t ally-has-stealth?))
              (values x y t te ph?))))

      ;; Respect weapon-swing lock, splash evasion, Wave 3 handled/snipe-locked units, Queen casts, and channel/morph orders
      (unless (or skip? (not target-enemy))
        (define eid (hash-ref target-enemy 'id 9001))
        (define etype (unit-type-sym target-enemy))
        (define ex (hash-ref target-enemy 'x nat-x))
        (define ey (hash-ref target-enemy 'y nat-y))
        (define edist2 (l34-safe-coord-dist2 ux uy ex ey))
        (define can-hit-target?
          (or (not live-obs?)
              prepped-hit?))
        (define enemy-near-our-territory?
          (l34-fast-enemy-near-territory? ctx target-enemy ex ey))
        (define unit-should-engage-target?
          (and can-hit-target?
               (cond
                 [bo-prepos-active?
                  (or (fl<= edist2 256.0) enemy-near-our-territory?)]
                 [bo-contain-active?
                  (or (fl<= edist2 256.0)
                      enemy-near-our-territory?
                      (l34-within-r2? ex ey fbo-px fbo-py 256.0 16.0))]
                 [else
                  (or (not live-obs?)
                      (fl<= edist2 484.0)
                      enemy-near-our-territory?
                      eff-wave-commit?)])))
        (define tank-supporting-vs-static?
          (and has-siege-supporters?
               (fl<= edist2 64.0)
               (hash-has-key? RUNTIME-SHORT-BIO-SET ut)
               (hash-has-key? RUNTIME-STATIC-DEFENSE-SET etype)
               (l34-any-ally-siege-near? ctx ex ey ux uy)))
        (define zergling-hold-off-pf-siege?
          (and (eq? ut 'zergling)
               live-tactics-obs?
               (or (pair? enemy-pf-list) (pair? enemy-sieged-tanks-near))
               (not enemy-near-our-territory?)
               (or (not can-break-siege-line?)
                   (and (not have-heavy-or-siege-breaker?)
                        (< local-val-ratio 1.55)))
               (or (and (pair? enemy-pf-list) (l34-find-pf-holding-off ctx etype ex ey ux uy))
                   (and (pair? enemy-sieged-tanks-near) (l34-find-sieged-tank-holding-off ctx ex ey ux uy)))))
        (define nearest-enemy-tank
          (and siege-line-hold?
               (pair? enemy-sieged-tanks-near)
               (not (fast-unit-is-flying-sym? ut))
               (l34-find-nearest-sieged-tank ctx ux uy)))
        (case ut
          [(ravager)
           (if (and (not live-obs?)
                    (or (not live-upgrades-tracked?)
                        (and (fl<= edist2 90.25)
                             (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                                        (list 'ravager-bile uid)
                                                        frame
                                                        156))))
               (begin
                 (l34-emit! ctx (list 'cast-spell uid 'corrosive-bile ex ey))
                 (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
          [(lurker lurker-burrowed)
           (define is-burrowed? (or (eq? ut 'lurker-burrowed) (hash-ref u 'burrowed #f)))
           (define min-ground-dist2 (l34-lurker-min-ground-dist2 (l34-get-ground-eng-enemy-recs ctx) ux uy ex ey))
           (define mode-ready?
             (or (not live-obs?)
                 (>= (- frame (hash-ref splash-mode-dwell-ht uid -1000)) 48)))
           (cond
             [(and is-burrowed? (> min-ground-dist2 110.25) mode-ready?)
              (hash-set! splash-mode-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'burrow-up uid))]
             [(and (not is-burrowed?)
                   mode-ready?
                   (or (not live-upgrades-tracked?) (<= min-ground-dist2 81.0)))
              (hash-set! splash-mode-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'burrow eid))
              (unless live-obs?
                (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
             [else
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])]
          [(widow-mine widow-mine-burrowed)
           (define is-burrowed? (or (eq? ut 'widow-mine-burrowed) (hash-ref u 'burrowed #f)))
           (define min-enemy-dist (l34-min-eng-fast-dist2d ctx ux uy ex ey))
           (define holding-choke? (<= (fast-dist2d ux uy nat-x nat-y) 4.0))
           (define wm-dwell-ready?
             (or (not live-obs?)
                 (>= (- frame (hash-ref splash-wm-dwell-ht uid -1000)) 56)))
           (cond
             [(and is-burrowed?
                   (> min-enemy-dist (if live-obs? 13.5 6.5))
                   (not (and live-obs? holding-choke?))
                   wm-dwell-ready?)
              (hash-set! splash-wm-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'widow-mine-unburrow uid))]
             [is-burrowed?
              (when (<= min-enemy-dist 5.5)
                (define best-cluster-enemy (l34-wm-best-cluster-enemy ctx ux uy ex ey target-enemy))
                (l34-emit! ctx (list 'attack-unit uid (hash-ref best-cluster-enemy 'id eid))))]
             [(and wm-dwell-ready?
                   (or (not live-upgrades-tracked?)
                       (<= min-enemy-dist 9.5)
                       (and live-obs? holding-choke?)
                       under-tactics-base-attack?))
              (hash-set! splash-wm-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'burrow eid))
              (unless live-obs?
                (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
             [else
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])]
          [(liberator liberator-ag)
           (define is-ag? (eq? ut 'liberator-ag))
           (define lib-r (if is-ag? 11.5 9.0))
           (define lib-r2 (if is-ag? 132.25 81.0))
           (define first-ground-enemy-near
             (for/first ([r (in-list (l34-get-ground-eng-enemy-recs ctx))]
                         #:when (l34-within-r2? ux uy
                                            (or (vector-ref r 1) 9999.0)
                                            (or (vector-ref r 2) 9999.0)
                                            lib-r2 lib-r))
               (vector-ref r 0)))
           (define lib-dwell-ready?
             (>= (- frame (hash-ref splash-lib-dwell-ht uid -1000)) 48))
           (cond
             [(and (not is-ag?) first-ground-enemy-near lib-dwell-ready?)
              (define ge first-ground-enemy-near)
              (define gx (hash-ref ge 'x ex))
              (define gy (hash-ref ge 'y ey))
              (define gd (max 1.0 (fast-dist2d ux uy gx gy)))
              (define zx (safe-coord (+ ux (* (min 4.0 gd) (/ (- gx ux) gd))) gx))
              (define zy (safe-coord (+ uy (* (min 4.0 gd) (/ (- gy uy) gd))) gy))
              (hash-set! splash-lib-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'morph-liberator-ag zx zy))]
             [(and is-ag? (not first-ground-enemy-near) lib-dwell-ready?)
              (hash-set! splash-lib-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'morph-liberator-aa uid))]
             [(not is-ag?)
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])]
          [(viking viking-fighter viking-assault)
           (define is-assault? (eq? ut 'viking-assault))
           (define ground-close?
             (for/or ([r (in-list (l34-get-ground-eng-enemy-recs ctx))])
               (l34-within-r2? ux uy
                           (or (vector-ref r 1) 9999.0)
                           (or (vector-ref r 2) 9999.0)
                           36.0 6.0)))
           (define vik-dwell-ready?
             (>= (- frame (hash-ref splash-vik-dwell-ht uid -1000)) 48))
           (define viking-tether-target?
             (and (not is-assault?)
                  target-enemy
                  (memq etype VIKING-TETHER-TARGET-SYMS)))
           (define dist-to-ground-anchor
             (if viking-tether-target?
                 (dist2d ux uy ground-army-cx ground-army-cy)
                 0.0))
           (define viking-tether-kite?
             (and viking-tether-target?
                  (> dist-to-ground-anchor 4.5)
                  (let ([da (dist2d ground-army-cx ground-army-cy ex ey)])
                    (fl< edist2 (* da da)))
                  (>= (l34-viking-screen-aa-count ctx ux uy ex ey) 3)))
           (cond
             [(and (not live-obs?) is-assault? (not (null? enemy-air-or-colossus)))
              (hash-set! splash-vik-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'morph-viking-fighter uid))]
             [(and (not live-obs?)
                   (not is-assault?)
                   (null? enemy-air-or-colossus)
                   ground-close?
                   vik-dwell-ready?)
              (hash-set! splash-vik-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'morph-viking-assault uid))]
             [viking-tether-kite?
              (define step (min 4.0 dist-to-ground-anchor))
              (define tx
                (safe-coord (+ ux (* step (/ (- ground-army-cx ux) (max 1e-3 dist-to-ground-anchor))))
                            ground-army-cx))
              (define ty
                (safe-coord (+ uy (* step (/ (- ground-army-cy uy) (max 1e-3 dist-to-ground-anchor))))
                            ground-army-cy))
              (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx tx ground-army-cx) (l34-quantize-cell-2.5 ctx ty ground-army-cy)))]
             [else
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])]
          [(thor thor-ap)
           (define is-high-impact? (eq? ut 'thor-ap))
           (define thor-dwell-ready?
             (>= (- frame (hash-ref splash-thor-dwell-ht uid -1000))
                 (if live-obs? THOR-MODE-DWELL-FRAMES 48)))
           (define thor-safe-ok?
             (or (not live-obs?)
                 (thor-morph-safe? u enemy-units)))
           (cond
             [(and (not is-high-impact?)
                   (not (null? enemy-massive-air-or-colossus))
                   (or (not live-obs?) (null? enemy-mutalisks) (null? (cdr enemy-mutalisks)) (null? (cddr enemy-mutalisks)))
                   thor-dwell-ready?
                   thor-safe-ok?
                   (not (set-member? wave3-thor-morphed-tags uid)))
              (hash-set! splash-thor-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'morph-thor-high-impact uid))]
             [(and (not live-obs?)
                   is-high-impact?
                   (null? enemy-massive-air-or-colossus)
                   (not (null? enemy-mutalisks))
                   thor-dwell-ready?)
              (hash-set! splash-thor-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'morph-thor-explosive uid))]
             [else
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])]
          [(viper)
           (if live-obs?
               (l34-emit-caster-rear-leash! ctx uid ux uy)
               (let* ([u-energy (hash-ref u 'energy 0)]
                      [consume-bldg (and (< u-energy 75) (l34-viper-find-consume-bldg ctx ux uy))]
                      [air-clump-tgt (and (>= u-energy 125) (l34-viper-find-air-clump ctx ux uy))]
                      [cloud-tgt (and (>= u-energy 100) (l34-viper-find-cloud-tgt ctx ux uy))]
                      [abduct-tgt (and (>= u-energy 75) (l34-viper-find-abduct-tgt ctx ux uy))])
                 (cond
                   [(and consume-bldg
                         (exact-integer? (hash-ref consume-bldg 'id 0))
                         (> (hash-ref consume-bldg 'id 0) 0))
                    (l34-emit! ctx (list 'cast-spell uid 'viper-consume (hash-ref consume-bldg 'id)))]
                   [(and air-clump-tgt
                         (exact-integer? (hash-ref air-clump-tgt 'id 0))
                         (> (hash-ref air-clump-tgt 'id 0) 0))
                    (l34-emit! ctx (list 'cast-spell uid 'parasitic-bomb (hash-ref air-clump-tgt 'id)))]
                   [cloud-tgt
                    (l34-emit! ctx (list 'cast-spell uid 'blinding-cloud
                                 (safe-coord (hash-ref cloud-tgt 'x ex) ex)
                                 (safe-coord (hash-ref cloud-tgt 'y ey) ey)))]
                   [(and abduct-tgt
                         (exact-integer? (hash-ref abduct-tgt 'id 0))
                         (> (hash-ref abduct-tgt 'id 0) 0))
                    (l34-emit! ctx (list 'cast-spell uid 'abduct (hash-ref abduct-tgt 'id)))]
                   [else
                    (l34-emit-caster-rear-leash! ctx uid ux uy)])))]
          [(infestor infestor-burrowed)
           (if live-obs?
               (unless (or (eq? ut 'infestor-burrowed) (hash-ref u 'burrowed #f))
                 (l34-emit-caster-rear-leash! ctx uid ux uy))
               (let* ([u-energy (hash-ref u 'energy 0)]
                      [fungal-tgt (and (>= u-energy 75) (l34-infestor-find-fungal-tgt ctx ux uy))])
                 (if fungal-tgt
                     (l34-emit! ctx (list 'cast-spell uid 'fungal-growth
                                  (safe-coord (hash-ref fungal-tgt 'x ex) ex)
                                  (safe-coord (hash-ref fungal-tgt 'y ey) ey)))
                     (l34-emit-caster-rear-leash! ctx uid ux uy))))]
          [(high-templar)
           (define u-energy (hash-ref u 'energy 0))
           (if live-obs?
               (if (< u-energy 50)
                   (l34-emit-caster-rear-leash! ctx uid ux uy)
                   (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))
               (let ([storm-tgt
                      (and (>= u-energy 75)
                           (or (not live-upgrades-tracked?) (l34-has-upgrade? ctx 'psi-storm))
                           (l34-ht-find-storm-tgt ctx ux uy))]
                     [feedback-tgt
                      (and (>= u-energy 50) (l34-ht-find-feedback-tgt ctx ux uy))])
                 (cond
                   [storm-tgt
                    (l34-emit! ctx (list 'cast-spell uid 'psi-storm
                                 (safe-coord (hash-ref storm-tgt 'x ex) ex)
                                 (safe-coord (hash-ref storm-tgt 'y ey) ey)))]
                   [(and feedback-tgt
                         (exact-integer? (hash-ref feedback-tgt 'id 0))
                         (> (hash-ref feedback-tgt 'id 0) 0))
                    (l34-emit! ctx (list 'cast-spell uid 'feedback (hash-ref feedback-tgt 'id)))]
                   [(< u-energy 50)
                    (l34-emit-caster-rear-leash! ctx uid ux uy)]
                   [else
                    (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])))]
          [(battlecruiser)
           (if live-obs?
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)
               (let* ([u-hp (hash-ref u 'hp 100)]
                      [jump-ready-f (hash-ref splash-bc-jump-ht uid 0)]
                      [yamato-ready-f (hash-ref splash-bc-yamato-ht uid 0)]
                      [yamato-tgt
                       (and (>= frame yamato-ready-f)
                            (or (not live-upgrades-tracked?) (l34-has-upgrade? ctx 'weapon-refit))
                            (l34-bc-find-yamato-tgt ctx ux uy))])
                 (cond
                   [(and (< u-hp 180) (>= frame jump-ready-f))
                    (hash-set! splash-bc-jump-ht uid (+ frame 2012))
                    (l34-emit! ctx (list 'cast-spell uid 'tactical-jump base-x base-y))]
                   [(and yamato-tgt
                         (let ([ytid (hash-ref yamato-tgt 'id eid)])
                           (and (exact-integer? ytid) (> ytid 0))))
                    (hash-set! splash-bc-yamato-ht uid (+ frame 1590))
                    (l34-emit! ctx (list 'cast-spell uid 'yamato-cannon (hash-ref yamato-tgt 'id eid)))]
                   [else
                    (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])))]
          [(baneling)
           (if (and (fl> edist2 3.24) (fl<= edist2 100.0))
               (begin
                 (l34-emit! ctx (list 'kite uid (safe-coord ex ux) (safe-coord ey uy)))
                 (unless live-obs?
                   (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)))
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
          [(carrier)
           (when (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                            (list 'carrier-int uid)
                                            frame
                                            68)
             (l34-emit! ctx (list 'cast-spell uid 'build-interceptors uid)))
           (if (and (fl< edist2 56.25) (fl> edist2 0.01))
               (let-values ([(kx ky) (compute-kite-vector ux uy ex ey 2.5)])
                 (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy))))
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
          [(disruptor)
           (when (fl< edist2 110.25)
             (let-values ([(kx ky) (compute-kite-vector ux uy ex ey 3.0)])
               (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy)))))]
          [(disruptor-phased)
           (void)]
          [(sentry)
           (cond
             [(and (not live-obs?)
                   (>= (hash-ref u 'energy SC2-SENTRY-FORCE-FIELD-ENERGY) SC2-SENTRY-GUARDIAN-SHIELD-ENERGY)
                   (or (not live-upgrades-tracked?) (fl<= edist2 81.0))
                   (not (memq 'guardian-shield (hash-ref u 'buffs '()))))
              ;; Guardian Shield is off-GCD instant self-aura
              (l34-emit! ctx (list 'cast-spell uid 'guardian-shield eid))
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)]
             [(and (not live-obs?)
                   (>= (hash-ref u 'energy SC2-SENTRY-FORCE-FIELD-ENERGY) SC2-SENTRY-FORCE-FIELD-ENERGY)
                   (or (not live-upgrades-tracked?) (fl<= edist2 81.0)))
              (l34-emit! ctx (list 'cast-spell uid 'force-field
                           (safe-coord (* 0.5 (+ nat-x ex)) nat-x)
                           (safe-coord (* 0.5 (+ nat-y ey)) nat-y)))
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)]
             [else
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])]
          [(stalker)
           (if (and (l34-has-upgrade? ctx 'blink)
                    (< (hash-ref u 'hp 100) SC2-STALKER-BLINK-HP-THRESH)
                    (or (not live-obs?)
                        (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                                   (list 'stalker-blink uid)
                                                   frame
                                                   160)))
               (let-values ([(kx ky) (compute-kite-vector ux uy ex ey SC2-KITE-STEP-DISTANCE)])
                 (l34-emit! ctx (list 'cast-spell uid 'blink (safe-coord kx ux) (safe-coord ky uy)))
                 (unless live-obs?
                   (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)))
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
          [(adept)
           (define adept-fork-shade?
             (and bo-fork-active?
                  (not under-tactics-base-attack?)
                  (> (+ (* (- bo-sx ux) (- bo-sx ux))
                        (* (- bo-sy uy) (- bo-sy uy)))
                     64.0)))
           (if (and (or adept-fork-shade?
                        (not live-upgrades-tracked?)
                        (fl<= edist2 144.0))
                    (or (not live-obs?)
                        (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                                   (list 'adept-shade uid)
                                                   frame
                                                   248)))
               (begin
                 (l34-emit! ctx (list 'cast uid 'psionic-transfer
                              (if adept-fork-shade? bo-sx ex)
                              (if adept-fork-shade? bo-sy ey)))
                 (unless live-obs?
                   (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)))
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
          [(siege-tank siege-tank-sieged)
           (define is-sieged? (or (eq? ut 'siege-tank-sieged) (hash-ref u 'sieged #f)))
           (define min-enemy-dist (l34-min-eng-dist2d ctx ux uy ex ey))
           (define tank-dwell-ready?
             (or (not live-obs?)
                 (>= (- frame (hash-ref splash-tank-dwell-ht uid -1000)) 48)))
           (cond
             [(and is-sieged? (> min-enemy-dist SC2-SIEGE-TANK-UNSIEGE-RANGE) tank-dwell-ready?)
              (hash-set! splash-tank-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'unsiege-mode uid))
              (unless live-upgrades-tracked?
                (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
             [(and (not is-sieged?) (<= min-enemy-dist SC2-SIEGE-TANK-SIEGE-RANGE) tank-dwell-ready?)
              (hash-set! splash-tank-dwell-ht uid frame)
              (l34-emit! ctx (list 'cast-spell uid 'siege-mode eid))
              (unless live-upgrades-tracked?
                (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
             [else
              (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)])]
          [(ghost)
           (if live-obs?
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)
               (begin
                 (when (>= (hash-ref u 'energy 75) 75)
                   (l34-emit! ctx (list 'cast-spell uid 'emp-round
                                (safe-coord ex base-x)
                                (safe-coord ey base-y)))
                   (when (and (exact-integer? eid) (> eid 0))
                     (l34-emit! ctx (list 'cast-spell uid 'snipe eid))))
                 (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?)))]
          [(marine marauder)
           (when (and (l34-has-upgrade? ctx 'stimpack)
                      (>= (hash-ref u 'hp 100) SC2-MARINE-STIM-MIN-HP)
                      (or (not live-upgrades-tracked?) (fl<= edist2 90.25)))
             (let ([u-buffs (hash-ref u 'buffs '())])
               (when (and (not (memq 'stimpack u-buffs))
                          (not (memq 'stimpack-marauder u-buffs)))
                 (l34-emit! ctx (list 'cast-spell uid 'stimpack eid)))))
           (unless (and live-obs? (set-member? wave3-marauder-target-tags uid))
             (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
          [(mutalisk)
           (if (< (hash-ref u 'hp 100) SC2-MUTALISK-KITE-HP-THRESH)
               (let-values ([(kx ky) (compute-kite-vector ux uy ex ey SC2-KITE-STEP-DISTANCE)])
                 (l34-emit! ctx (list 'kite uid (l34-quantize-cell-2.5 ctx kx ux) (l34-quantize-cell-2.5 ctx ky uy))))
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
          [(banshee)
           (define mirrored-acts (if has-tbrain-acts? (hash-ref tbrain-unit-actions uid '()) '()))
           (if (not (null? mirrored-acts))
               (for ([ma (in-list mirrored-acts)]) (l34-emit! ctx ma))
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]
          [else
           (define mirrored-acts
             (if (and has-tbrain-acts?
                      (not nearest-enemy-tank)
                      (not tank-supporting-vs-static?)
                      (not zergling-hold-off-pf-siege?)
                      unit-should-engage-target?)
                 (hash-ref tbrain-unit-actions uid '())
                 '()))
           (if (not (null? mirrored-acts))
               (for ([ma (in-list mirrored-acts)]) (l34-emit! ctx ma))
               (l34-emit-engage-or-rally! ctx uid ux uy ex ey eid nearest-enemy-tank zergling-hold-off-pf-siege? tank-supporting-vs-static? unit-should-engage-target?))]))))

  )

(define (l34-phase6-raid-concave-reach! ctx)
  (define ally-infestors (l34-ctx-ally-infestors ctx))
  (define ally-overseers (l34-ctx-ally-overseers ctx))
  (define ally-sentries (l34-ctx-ally-sentries ctx))
  (define ally-units (l34-ctx-ally-units ctx))
  (define base-x (l34-ctx-base-x ctx))
  (define base-y (l34-ctx-base-y ctx))
  (define bo-fork-active? (l34-ctx-bo-fork-active? ctx))
  (define bo-micro-dirs (l34-ctx-bo-micro-dirs ctx))
  (define bo-rally-override? (l34-ctx-bo-rally-override? ctx))
  (define bo-rally-tx (l34-ctx-bo-rally-tx ctx))
  (define bo-rally-ty (l34-ctx-bo-rally-ty ctx))
  (define bo-sx (l34-ctx-bo-sx ctx))
  (define bo-sy (l34-ctx-bo-sy ctx))
  (define combat-units (l34-ctx-combat-units ctx))
  (define disruptor-handled-tags (l34-ctx-disruptor-handled-tags ctx))
  (define eff-wave-commit? (l34-ctx-eff-wave-commit? ctx))
  (define enemy-bldgs (l34-ctx-enemy-bldgs ctx))
  (define enemy-changelings (l34-ctx-enemy-changelings ctx))
  (define enemy-exp-x (l34-ctx-enemy-exp-x ctx))
  (define enemy-exp-y (l34-ctx-enemy-exp-y ctx))
  (define enemy-unit-shimmer? (l34-ctx-enemy-unit-shimmer? ctx))
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define enemy-x (l34-ctx-enemy-x ctx))
  (define enemy-y (l34-ctx-enemy-y ctx))
  (define enemy-z-early (l34-ctx-enemy-z-early ctx))
  (define fbo-rally-tx (l34-ctx-fbo-rally-tx ctx))
  (define fbo-rally-ty (l34-ctx-fbo-rally-ty ctx))
  (define frame (l34-ctx-frame ctx))
  (define has-ally-roach? (l34-ctx-has-ally-roach? ctx))
  (define has-non-overlord-spotter? (l34-ctx-has-non-overlord-spotter? ctx))
  (define live-attack-wave-min (l34-ctx-live-attack-wave-min ctx))
  (define live-combat-supply (l34-ctx-live-combat-supply ctx))
  (define live-obs? (l34-ctx-live-obs? ctx))
  (define nat-x (l34-ctx-nat-x ctx))
  (define nat-y (l34-ctx-nat-y ctx))
  (define obs (l34-ctx-obs ctx))
  (define our-z-early (l34-ctx-our-z-early ctx))
  (define prelim-army-cx (l34-ctx-prelim-army-cx ctx))
  (define prelim-army-cy (l34-ctx-prelim-army-cy ctx))
  (define rt (l34-ctx-rt ctx))
  (define splash-evading-tags (l34-ctx-splash-evading-tags ctx))
  (define splash-st (l34-ctx-splash-st ctx))
  (define sum-eb-x (l34-ctx-sum-eb-x ctx))
  (define sum-eb-y (l34-ctx-sum-eb-y ctx))
  (define sum-eu-x (l34-ctx-sum-eu-x ctx))
  (define sum-eu-y (l34-ctx-sum-eu-y ctx))
  (define tbrain-committed-tags (l34-ctx-tbrain-committed-tags ctx))
  (define third-x (l34-ctx-third-x ctx))
  (define third-y (l34-ctx-third-y ctx))
  (define wave3-handled-tags (l34-ctx-wave3-handled-tags ctx))
  (define wave3-preserved-set (l34-ctx-wave3-preserved-set ctx))
  ;; ---------------------------------------------------------------------------
  ;; Pro Mechanic #8: Burrowed Zergling Base-Blocker, Cheap Patrol Expansion
  ;;                  Blocker, Peripheral Economic Harassment Raider Squad, &
  ;;                  Probing-Attack Recon Vanguard (PV9)
  ;; ---------------------------------------------------------------------------
  (define cur-tel-ht
    (let ([t (live-bot-runtime-last-telemetry rt)])
      (if (hash? t) t (hash))))
  (define cur-intel-staleness
    (hash-ref cur-tel-ht 'intel-staleness-frames
              (if (and (null? enemy-units) (null? enemy-bldgs)) frame 0)))
  (define mm-verdict
    (mirror-mind-state-mirror-macro-verdict (live-bot-runtime-mirror-mind rt)))
  (define maybe-harass-raid?
    (if live-obs?
        (or (hash-ref obs 'enable-economic-disruption #f)
            (and bo-fork-active?
                 (refractory-ready? (live-bot-runtime-cooldown-tracker rt)
                                    '(live-harass-raid)
                                    frame
                                    336))
            (and (>= live-combat-supply 28)
                 (refractory-ready? (live-bot-runtime-cooldown-tracker rt)
                                    '(live-harass-raid)
                                    frame
                                    672)))
        (or (hash-ref obs 'enable-economic-disruption #f)
            bo-fork-active?
            (and (>= cur-intel-staleness 224)
                 (>= (length combat-units) 4))
            (and (eq? mm-verdict 'punish-And-Deny-Greedy-Expand)
                 (>= (length combat-units) (min 6 live-attack-wave-min)))
            (and (null? enemy-units)
                 (>= (length combat-units) (min 6 live-attack-wave-min))))))
  (define cheap-blockers
    (if maybe-harass-raid?
        (filter (lambda (u)
                  (and (memq (unit-type-sym u) '(zergling marine zealot reaper adept hellion oracle phoenix mutalisk banshee))
                       (not (set-member? tbrain-committed-tags (hash-ref u 'id -1)))
                       (not (set-member? wave3-handled-tags (hash-ref u 'id -1)))))
                combat-units)
        '()))
  (define allow-harass-raid?
    (and maybe-harass-raid?
         (if live-obs?
             (or (hash-ref obs 'enable-economic-disruption #f)
                 (and bo-fork-active?
                      (>= (length cheap-blockers) 2)
                      (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                                 '(live-harass-raid)
                                                 frame
                                                 336))
                 (and (>= (length cheap-blockers) 4)
                      (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                                 '(live-harass-raid)
                                                 frame
                                                 672)))
             (or (hash-ref obs 'enable-economic-disruption #f)
                 (and bo-fork-active? (>= (length cheap-blockers) 2))
                 (>= cur-intel-staleness 224)
                 (eq? mm-verdict 'punish-And-Deny-Greedy-Expand)
                 (>= (length cheap-blockers) 3)))))
  (when (and (not (null? cheap-blockers)) allow-harass-raid?)
    (define blocker (car cheap-blockers))
    (define bid (hash-ref blocker 'id 110))
    (if (eq? (unit-type-sym blocker) 'zergling)
        (l34-emit! ctx (list 'burrow-block bid enemy-exp-x enemy-exp-y))
        (l34-emit! ctx (list 'patrol-block-expansion bid enemy-exp-x enemy-exp-y)))
    (when (>= (length cheap-blockers) 2)
      (define raider-ids
        (map (lambda (u) (hash-ref u 'id 111))
             (take (cdr cheap-blockers) (min 3 (length (cdr cheap-blockers))))))
      (l34-emit! ctx (list 'harass-workers raider-ids
                   (if bo-fork-active? bo-sx enemy-x)
                   (if bo-fork-active? bo-sy enemy-y)))))

  (when (and bo-rally-override?
             (null? enemy-units)
             (or (not live-obs?) (null? enemy-bldgs))
             (pair? combat-units)
             (or (not live-obs?)
                 (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                            '(bo-timing-rally)
                                            frame
                                            28)))
    (define bo-march-units
      (for/list ([u (in-list combat-units)]
                 #:when (let* ([uid (hash-ref u 'id -1)]
                               [ut (unit-type-sym u)]
                               [ux (exact->inexact (hash-ref u 'x base-x))]
                               [uy (exact->inexact (hash-ref u 'y base-y))]
                               [dx (- ux fbo-rally-tx)]
                               [dy (- uy fbo-rally-ty)])
                          (and (not (set-member? wave3-handled-tags uid))
                               (not (set-member? splash-evading-tags uid))
                               (not (set-member? disruptor-handled-tags uid))
                               (not (set-member? tbrain-committed-tags uid))
                               (not (memq ut '(overlord overseer observer warp-prism warp-prism-phasing medivac queen)))
                               (> (+ (* dx dx) (* dy dy)) 36.0))))
        u))
    (when (pair? bo-march-units)
      (if (<= (length bo-march-units) 8)
          (for ([u (in-list bo-march-units)])
            (l34-emit! ctx (list 'attack-pos (hash-ref u 'id 110) bo-rally-tx bo-rally-ty)))
          (l34-emit! ctx (list 'attack-pos
                       (map (lambda (u) (hash-ref u 'id 110)) bo-march-units)
                       bo-rally-tx
                       bo-rally-ty)))))

  (when (and (null? enemy-units)
             (not bo-rally-override?)
             (or (not live-obs?)
                 (and (null? enemy-bldgs)
                      (< (length combat-units) live-attack-wave-min)
                      (refractory-ready? (live-bot-runtime-cooldown-tracker rt)
                                         '(idle-nat-rally)
                                         frame
                                         44))))
    (define idle-rally-candidates
      (filter (lambda (u) (not (set-member? wave3-handled-tags (hash-ref u 'id -1))))
              combat-units))
    (when (and (>= (length idle-rally-candidates) 2)
               (or (not live-obs?)
                   (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                              '(idle-nat-rally)
                                              frame
                                              44)))
      (for ([u (in-list (take idle-rally-candidates 2))])
        (l34-emit! ctx (list 'attack-pos (hash-ref u 'id 110) nat-x nat-y)))))

  ;; ---------------------------------------------------------------------------
  ;; Pro Mechanic #9: Enemy Changeling Sniping & Active Deception/Scout Spells
  ;; ---------------------------------------------------------------------------
  (for ([ec (in-list enemy-changelings)])
    (l34-emit! ctx (list 'snipe-enemy-changeling (hash-ref ec 'id 9099))))

  (when has-ally-roach?
    (for ([ba (in-list (execute-roach-tunneling-burrow-micro obs))])
      (l34-emit! ctx ba)))
  (when (not (null? ally-infestors))
    (for ([ia (in-list (execute-infestor-burrow-cast-micro obs))])
      (unless (and live-obs?
                   (pair? ia)
                   (>= (length ia) 2)
                   (set-member? wave3-handled-tags (second ia)))
        (l34-emit! ctx ia))))
  (define has-ripple-or-shimmer?
    (or enemy-unit-shimmer?
        (let ([rs (hash-ref obs 'shimmer-and-burrow-ripples #f)])
          (and (list? rs) (pair? rs)))))
  (when has-ripple-or-shimmer?
    (for ([sa (in-list (execute-shimmer-and-burrow-ripple-response obs))])
      (l34-emit! ctx sa)))

  (when (and (or (hash-ref obs 'enable-deception-and-buffs #f)
                 (not (null? ally-sentries))
                 (not (null? ally-overseers)))
             (or (not live-obs?)
                 (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                            '(deception-scout-spells)
                                            frame
                                            336)))
    (l34-emit! ctx '(cast-deception-and-scout-spells
             sentry-hallucination-phoenix-scout
             sentry-hallucination-archon-tank
             overseer-spawn-changeling)))

  ;; ---------------------------------------------------------------------------
  ;; Pro Mechanic #10: Protective Buff Aura, Throttled Pre-Split 3-Wing Squads,
  ;;                   Throttled Concave Arc, & High-Ground Mastery
  ;; ---------------------------------------------------------------------------
  (define army-cx prelim-army-cx)
  (define army-cy prelim-army-cy)
  (define use-eb-for-target? (and live-obs? (null? enemy-units)))
  (define visible-enemies-for-target
    (if use-eb-for-target? enemy-bldgs enemy-units))
  (define target-ex
    (if (null? visible-enemies-for-target)
        (if bo-rally-override? bo-rally-tx enemy-x)
        (safe-coord (/ (if use-eb-for-target? sum-eb-x sum-eu-x)
                       (max 1 (length visible-enemies-for-target)))
                    enemy-x)))
  (define target-ey
    (if (null? visible-enemies-for-target)
        (if bo-rally-override? bo-rally-ty enemy-y)
        (safe-coord (/ (if use-eb-for-target? sum-eb-y sum-eu-y)
                       (max 1 (length visible-enemies-for-target)))
                    enemy-y)))

  (when (and (or (hash-ref obs 'enable-deception-and-buffs #f)
                 (not (null? ally-sentries))
                 (not (null? ally-infestors))
                 (and (not (null? enemy-units)) (not (null? combat-units))))
             (or (not live-obs?)
                 (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                            '(buff-aura-position)
                                            frame
                                            44)))
    (define use-shroud?
      (or (not (null? ally-infestors))
          (eq? (live-bot-runtime-actual-race rt) 'Zerg)))
    (define aura-type (if use-shroud? 'microbial-shroud 'guardian-shield))
    (define aura-radius (if use-shroud? 3.5 4.5))
    (l34-emit! ctx (list 'cast-protective-buff-aura aura-type army-cx army-cy aura-radius))
    (l34-emit! ctx (list 'position-in-buff-aura-with-splash-spread
                 aura-type army-cx army-cy aura-radius 1.6 #t)))

  ;; Pre-Split 3-Wing Formation & Concave Arc Formation (throttled in live games to stay well below 400 APM)
  (when (and (or (not (null? enemy-units))
                 (and bo-rally-override?
                      (pair? combat-units)
                      (memq 'pre-split-vs-emp bo-micro-dirs))
                 (hash-ref obs 'pre-split-engage #f)
                 (hash-ref obs 'form-concave #f))
             (or (not live-obs?)
                 (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                            '(formation-arc-split)
                                            frame
                                            28)))
    (define dx (- target-ex army-cx))
    (define dy (- target-ey army-cy))
    (define d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
    (define nx (/ (- dy) d))
    (define ny (/ dx d))
    (define wing-spread 6.0)
    (define mid-x (safe-coord (+ army-cx (* 0.5 dx)) army-cx))
    (define mid-y (safe-coord (+ army-cy (* 0.5 dy)) army-cy))
    (define left-x (safe-coord (+ mid-x (* wing-spread nx)) mid-x))
    (define left-y (safe-coord (+ mid-y (* wing-spread ny)) mid-y))
    (define right-x (safe-coord (- mid-x (* wing-spread nx)) mid-x))
    (define right-y (safe-coord (- mid-y (* wing-spread ny)) mid-y))
    (l34-emit! ctx (list 'pre-split-wings left-x left-y mid-x mid-y right-x right-y))
    (l34-emit! ctx (list 'form-concave-arc target-ex target-ey 10 120)))

  ;; High-Ground Terrain & Vision Mastery
  (define our-z our-z-early)
  (define enemy-z enemy-z-early)
  (when (and (or (not (= our-z enemy-z))
                 (not (null? enemy-units))
                 (hash-ref obs 'high-ground-check #f))
             (or (not live-obs?)
                 (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                            '(high-ground-posture)
                                            frame
                                            28)))
    (define has-spotter? (or (not live-obs?) has-non-overlord-spotter?))
    (cond
      [(> our-z enemy-z)
       (l34-emit! ctx (list 'high-ground-tactics 'hold-high-ground-ramp-arc nat-x nat-y #f))]
      [(> enemy-z our-z)
       (l34-emit! ctx (list 'high-ground-tactics 'uphill-vision-spotter-and-concave target-ex target-ey has-spotter?))]
      [else
       (l34-emit! ctx (list 'high-ground-tactics 'contest-high-ground-control nat-x nat-y #f))]))

  ;; Spatio-Temporal Enemy Army Reachability & Counter-Positioning / Backstab / Surround Maneuver
  (define mm-rt (live-bot-runtime-mirror-mind rt))
  (define reach-m
    (evaluate-enemy-army-spatio-temporal-reachability
     (hash-ref obs 'frame 0)
     ally-units
     enemy-units
     (mirror-mind-state-last-tech-observation mm-rt)
     (mirror-mind-state-last-shadow-ledger mm-rt)
     #:our-base-x base-x #:our-base-y base-y
     #:our-nat-x nat-x #:our-nat-y nat-y
     #:enemy-exp-x enemy-exp-x
     #:enemy-exp-y enemy-exp-y))
  (set-mirror-mind-state-last-reachability-model! mm-rt reach-m)
  (define raw-sp-maneuver
    (enemy-army-reachability-model-recommended-spatial-maneuver reach-m))
  (define enemy-main-cleared-or-empty?
    (and (null? enemy-units)
         (or (null? enemy-bldgs)
             (not (ormap (lambda (eb)
                           (<= (dist2d (safe-finite-real (hash-ref eb 'x enemy-x) enemy-x)
                                       (safe-finite-real (hash-ref eb 'y enemy-y) enemy-y)
                                       enemy-x enemy-y)
                               16.0))
                         enemy-bldgs)))))
  (define sp-maneuver
    (if (and (eq? raw-sp-maneuver 'pre-rotate-intercept-incoming-threat)
             enemy-main-cleared-or-empty?
             (<= (hash-ref obs 'enemy-threat-supply 0) 0))
        'multiprong-rotate-and-pin
        raw-sp-maneuver))
  (define-values (sp-tx sp-ty)
    (if (and live-obs?
             (or eff-wave-commit?
                 bo-rally-override?
                 (>= (length combat-units) live-attack-wave-min)
                 (and (>= frame 6000) enemy-main-cleared-or-empty? (>= (length combat-units) 4))))
        (case sp-maneuver
          [(pre-rotate-intercept-incoming-threat)
           (values nat-x nat-y)]
          [(backstab-undefended-enemy-expansion)
           (cond
             [bo-fork-active? (values bo-sx bo-sy)]
             [bo-rally-override? (values bo-rally-tx bo-rally-ty)]
             [(null? visible-enemies-for-target) (values enemy-exp-x enemy-exp-y)]
             [else (values target-ex target-ey)])]
          [else
           (if bo-rally-override?
               (values bo-rally-tx bo-rally-ty)
               (values target-ex target-ey))])
        (case sp-maneuver
          [(backstab-undefended-enemy-expansion)
           (cond
             [bo-fork-active? (values bo-sx bo-sy)]
             [bo-rally-override? (values bo-rally-tx bo-rally-ty)]
             [else (values enemy-exp-x enemy-exp-y)])]
          [(surround-and-crush-isolated-enemy-cluster)
           (if bo-rally-override?
               (values bo-rally-tx bo-rally-ty)
               (values target-ex target-ey))]
          [(pre-rotate-intercept-incoming-threat)
           (values nat-x nat-y)]
          [(safe-to-expand-enemy-pinned-far)
           (values third-x third-y)]
          [else
           (if bo-rally-override?
               (values bo-rally-tx bo-rally-ty)
               (values target-ex target-ey))])))
  (when (or (not live-obs?)
            (refractory-allow-action?! (live-bot-runtime-cooldown-tracker rt)
                                       '(spatial-maneuver)
                                       frame
                                       28))
    (l34-emit! ctx (list 'execute-spatial-maneuver sp-maneuver sp-tx sp-ty)))

  (hash-set! splash-st 'wave3-preserved-frame frame)
  (hash-set! splash-st 'wave3-preserved-set wave3-preserved-set)

)

(define (l34-phase7-direct-tactics! ctx)
  (define actions (l34-ctx-actions ctx))
  (define ally-bldgs (l34-ctx-ally-bldgs ctx))
  (define ally-overseers (l34-ctx-ally-overseers ctx))
  (define ally-units (l34-ctx-ally-units ctx))
  (define ally-zerg-burrow-candidate? (l34-ctx-ally-zerg-burrow-candidate? ctx))
  (define base-x (l34-ctx-base-x ctx))
  (define base-y (l34-ctx-base-y ctx))
  (define creep-ally-slice-rev (l34-ctx-creep-ally-slice-rev ctx))
  (define creep-enemy-slice-rev (l34-ctx-creep-enemy-slice-rev ctx))
  (define disruptor-handled-tags (l34-ctx-disruptor-handled-tags ctx))
  (define enemy-bldgs (l34-ctx-enemy-bldgs ctx))
  (define enemy-near-home? (l34-ctx-enemy-near-home? ctx))
  (define enemy-units (l34-ctx-enemy-units ctx))
  (define enemy-x (l34-ctx-enemy-x ctx))
  (define enemy-y (l34-ctx-enemy-y ctx))
  (define frame (l34-ctx-frame ctx))
  (define has-ally-changeling-or-overseer? (l34-ctx-has-ally-changeling-or-overseer? ctx))
  (define has-ally-dropperlord? (l34-ctx-has-ally-dropperlord? ctx))
  (define has-ally-harass-sym? (l34-ctx-has-ally-harass-sym? ctx))
  (define has-ally-map-elem-or-recall? (l34-ctx-has-ally-map-elem-or-recall? ctx))
  (define has-ally-queen-or-tumor? (l34-ctx-has-ally-queen-or-tumor? ctx))
  (define has-ally-queen? (l34-ctx-has-ally-queen? ctx))
  (define has-ally-static-def-or-nydus? (l34-ctx-has-ally-static-def-or-nydus? ctx))
  (define has-ally-swarm-host-or-locust? (l34-ctx-has-ally-swarm-host-or-locust? ctx))
  (define has-ally-unwalled-punish-unit? (l34-ctx-has-ally-unwalled-punish-unit? ctx))
  (define has-ally-wall-block-bldg? (l34-ctx-has-ally-wall-block-bldg? ctx))
  (define has-ally-zergling? (l34-ctx-has-ally-zergling? ctx))
  (define has-enemy-burrow-or-sh-counter? (l34-ctx-has-enemy-burrow-or-sh-counter? ctx))
  (define has-enemy-changeling? (l34-ctx-has-enemy-changeling? ctx))
  (define has-enemy-creep-tumor? (l34-ctx-has-enemy-creep-tumor? ctx))
  (define has-enemy-dropperlord? (l34-ctx-has-enemy-dropperlord? ctx))
  (define has-enemy-harass-sym? (l34-ctx-has-enemy-harass-sym? ctx))
  (define has-enemy-map-elem-or-recall? (l34-ctx-has-enemy-map-elem-or-recall? ctx))
  (define has-enemy-overseer? (l34-ctx-has-enemy-overseer? ctx))
  (define has-enemy-static-def-or-nydus? (l34-ctx-has-enemy-static-def-or-nydus? ctx))
  (define has-enemy-static-det? (l34-ctx-has-enemy-static-det? ctx))
  (define has-enemy-swarm-host-or-locust? (l34-ctx-has-enemy-swarm-host-or-locust? ctx))
  (define l34-sc (l34-ctx-l34-sc ctx))
  (define leases (l34-ctx-leases ctx))
  (define nat-x (l34-ctx-nat-x ctx))
  (define nat-y (l34-ctx-nat-y ctx))
  (define obs (l34-ctx-obs ctx))
  (define reserve-count (l34-ctx-reserve-count ctx))
  (define rt (l34-ctx-rt ctx))
  (define splash-evading-tags (l34-ctx-splash-evading-tags ctx))
  (define stasis-frozen-tags (l34-ctx-stasis-frozen-tags ctx))
  (define vanguard-count (l34-ctx-vanguard-count ctx))
  (define wave3-handled-tags (l34-ctx-wave3-handled-tags ctx))
  (define direct-claimed-ht (pooled-hasheqv! l34-sc 'direct-claimed-ht))
  (for ([tid (in-set wave3-handled-tags)])
    (when (and (exact-integer? tid) (> tid 0))
      (hash-set! direct-claimed-ht tid #t)))
  (for ([tid (in-set disruptor-handled-tags)])
    (when (and (exact-integer? tid) (> tid 0))
      (hash-set! direct-claimed-ht tid #t)))
  (for ([tid (in-set splash-evading-tags)])
    (when (and (exact-integer? tid) (> tid 0))
      (hash-set! direct-claimed-ht tid #t)))
  (for ([tid (in-list stasis-frozen-tags)])
    (hash-set! direct-claimed-ht tid #t))
  (when (hash? leases)
    (for ([uid (in-hash-keys leases)])
      (when (unit-leased-above? leases uid 'army frame)
        (hash-set! direct-claimed-ht uid #t))))

  (define direct-prev-tel (live-bot-runtime-last-telemetry rt))
  (define direct-our-race
    (let ([r (live-bot-runtime-actual-race rt)])
      (if (and (symbol? r) (not (eq? r 'Unknown)))
          r
          (hash-ref obs 'race 'Zerg))))
  (define direct-enemy-race
    (if (hash? direct-prev-tel)
        (hash-ref direct-prev-tel 'effective-enemy-race (hash-ref obs 'enemy-race 'Unknown))
        (hash-ref obs 'enemy-race 'Unknown)))
  (define zerg-or-random? (memq direct-our-race '(Zerg Random)))
  (define has-any-enemy? (or (pair? enemy-units) (pair? enemy-bldgs)))
  (define has-ally-overseer? (pair? ally-overseers))
  (define direct-seen-sexps #f)

  (define (emit-direct-batch! raw-acts)
    (when (pair? raw-acts)
      (unless direct-seen-sexps
        (set! direct-seen-sexps (make-hash)))
      (define newly-claimed '())
      (for ([act (in-list raw-acts)]
            #:when (and (pair? act) (symbol? (car act))))
        (define-values (filtered-act actor-ids)
          (cond
            [(null? (cdr act)) (values act '())]
            [else
             (define head (car act))
             (define arg1 (cadr act))
             (cond
               [(and (eq? head 'bunker-load)
                     (pair? (cddr act))
                     (exact-integer? (caddr act))
                     (> (caddr act) 0))
                (define bio-id (caddr act))
                (if (hash-ref direct-claimed-ht bio-id #f)
                    (values #f '())
                    (values act (list bio-id)))]
               [(and (eq? head 'transport-juggle)
                     (exact-integer? arg1)
                     (> arg1 0)
                     (pair? (cddr act))
                     (list? (caddr act)))
                (if (hash-ref direct-claimed-ht arg1 #f)
                    (values #f '())
                    (let ([unclaimed-pax
                           (for/list ([p (in-list (caddr act))]
                                      #:when (and (exact-integer? p)
                                                  (> p 0)
                                                  (not (hash-ref direct-claimed-ht p #f))))
                             p)])
                      (if (null? unclaimed-pax)
                          (values #f '())
                          (values (list* head arg1 unclaimed-pax (cdddr act))
                                  (cons arg1 unclaimed-pax)))))]
               [(and (pair? arg1) (exact-integer? (car arg1)))
                (define free-ids
                  (for/list ([uid (in-list arg1)]
                             #:when (and (exact-integer? uid)
                                         (> uid 0)
                                         (not (hash-ref direct-claimed-ht uid #f))))
                    uid))
                (if (null? free-ids)
                    (values #f '())
                    (values (cons head (cons free-ids (cddr act))) free-ids))]
               [(and (exact-integer? arg1) (> arg1 0))
                (if (hash-ref direct-claimed-ht arg1 #f)
                    (values #f '())
                    (values act (list arg1)))]
               [else (values act '())])]))
        (when (and filtered-act (not (hash-ref direct-seen-sexps filtered-act #f)))
          (define skip-worker-proxy-pull?
            (and (list? filtered-act)
                 (eq? (car filtered-act) 'pull-workers-attack)
                 (let ([tid (and (>= (length filtered-act) 5) (third filtered-act))])
                   (not (and (exact-integer? tid)
                             (for/or ([eb (in-list enemy-bldgs)])
                               (and (= (hash-ref eb 'id -1) tid)
                                    (memq (fast-canonical-structure-sym (unit-type-sym eb))
                                          '(nydus-canal nydus-worm)))))))))
          (define skip-dummy?
            (and (list? filtered-act)
                 (eq? (car filtered-act) 'cast-spell)
                 (or (and (>= (length filtered-act) 5)
                          (real? (fourth filtered-act))
                          (real? (fifth filtered-act))
                          (let ([tx (fourth filtered-act)] [ty (fifth filtered-act)])
                            (and (or (and (= tx 46.0) (= ty 46.0))
                                     (and (= tx 88.0) (= ty 88.0))
                                     (and (= tx 152.0) (= ty 152.0)))
                                 (not (for/or ([eu (in-list enemy-units)])
                                        (let ([ex (hash-ref eu 'x -999.0)]
                                              [ey (hash-ref eu 'y -999.0)])
                                          (and (real? ex) (real? ey) (= (- ex ex) 0) (= (- ey ey) 0)
                                               (let ([dx (- (exact->inexact tx) (exact->inexact ex))]
                                                     [dy (- (exact->inexact ty) (exact->inexact ey))])
                                                 (<= (+ (* dx dx) (* dy dy)) 64.0)))))))))
                     (and (= (length filtered-act) 4)
                          (equal? (fourth filtered-act) 1)
                          (not (for/or ([eu (in-list enemy-units)]) (= (hash-ref eu 'id -1) 1)))))))
          (unless (or skip-worker-proxy-pull? skip-dummy?)
            (hash-set! direct-seen-sexps filtered-act #t)
            (l34-emit! ctx filtered-act)
            (for ([uid (in-list actor-ids)])
              (set! newly-claimed (cons uid newly-claimed))))))
      (for ([uid (in-list newly-claimed)])
        (hash-set! direct-claimed-ht uid #t))))

  (define (unclaimed-ally-units-now)
    (if (zero? (hash-count direct-claimed-ht))
        ally-units
        (for/list ([u (in-list ally-units)]
                   #:when (let ([uid (hash-ref u 'id (hash-ref u 'tag -1))])
                            (not (and (exact-integer? uid) (> uid 0)
                                      (hash-ref direct-claimed-ht uid #f)))))
          u)))

  ;; Direct Tactic #1: `zerg-burrow-micro.rkt` + Swarm Host (`static-defense-and-nydus-tactics.rkt`)
  ;; (Roach tunneling + Infestor burrow cast already executed directly at lines ~13101-13110)
  (when (and has-any-enemy? zerg-or-random? ally-zerg-burrow-candidate?)
    (emit-direct-batch!
     (execute-zerg-reactive-burrow-dodge-micro obs #:tracker (rt-burrow-tracker rt))))
  (when (and zerg-or-random? has-enemy-static-det?)
    (emit-direct-batch! (execute-stationary-detection-ring-ambush-micro obs)))
  (when has-ally-swarm-host-or-locust?
    (emit-direct-batch! (plan-spread-burrowed-swarm-host-harass obs)))
  (when has-enemy-swarm-host-or-locust?
    (emit-direct-batch! (plan-counter-spread-swarm-host-harass obs)))
  (when (or has-enemy-burrow-or-sh-counter?
            (let ([rb (hash-ref obs 'remembered-burrows '())])
              (and (list? rb) (pair? rb))))
    (emit-direct-batch!
     (CounterBurrowPlan-commands (plan-counter-burrow-response obs #:tracker (rt-burrow-tracker rt)))))
  (when (and has-ally-zergling?
             (or (let ([v (hash-ref obs 'expansion-pads '())]) (and (list? v) (pair? v)))
                 (let ([v (hash-ref obs 'pending-expansion-targets '())]) (and (list? v) (pair? v)))
                 (hash-ref obs 'pending-expansion-target #f)))
    (emit-direct-batch!
     (plan-burrowed-zergling-expansion-blocks obs #:tracker (rt-burrow-tracker rt))))

  ;; Direct Tactic #2: `multitask-harass-and-proxy.rkt`
  (when (and has-any-enemy?
             (or has-ally-harass-sym?
                 has-enemy-harass-sym?
                 (and (<= frame 4500) enemy-near-home?)))
    (define free-allies (unclaimed-ally-units-now))
    (when (and (pair? free-allies)
               (or enemy-near-home?
                   (for/or ([u (in-list free-allies)])
                     (not (hash-ref RUNTIME-NON-COMBAT-HARASS-SKIP-SET (unit-type-sym u) #f)))))
      (emit-direct-batch!
       (step-multitask-harass-and-proxy
        direct-our-race
        direct-enemy-race
        free-allies
        enemy-units
        #:current-frame frame
        #:home-x base-x
        #:home-y base-y
        #:enemy-main-x enemy-x
        #:enemy-main-y enemy-y))))

  ;; Direct Tactic #3: `creep-and-changeling-tactics.rkt`
  (define creep-tr (rt-creep-tracker rt))
  (when has-ally-queen-or-tumor?
    (define creep-obs
      (hash-set (hash-set obs 'ally-units (reverse creep-ally-slice-rev))
                'enemy-units
                (reverse creep-enemy-slice-rev)))
    (emit-direct-batch! (plan-multi-highway-creep-spread creep-obs #:tracker creep-tr)))
  (when (or has-enemy-creep-tumor?
            (let ([et (hash-ref obs 'enemy-tumors '())]) (and (list? et) (pair? et))))
    (emit-direct-batch! (plan-counter-creep-clearing obs)))
  (when has-ally-changeling-or-overseer?
    (emit-direct-batch! (plan-changeling-free-unit-tactics obs)))
  (when has-enemy-changeling?
    (emit-direct-batch! (plan-counter-changeling-defense obs)))
  (when (or (and has-ally-dropperlord? has-ally-queen?) has-enemy-dropperlord?)
    (emit-direct-batch! (plan-dropperlord-queen-creep-expedition obs #:tracker creep-tr)))
  (when (or (and has-ally-overseer? (pair? enemy-bldgs)) has-enemy-overseer?)
    (emit-direct-batch! (plan-overseer-contaminate-disruption obs)))

  ;; Direct Tactic #4: `wall-and-block-tactics.rkt`
  (when enemy-near-home?
    (emit-direct-batch! (plan-own-wall-integrity-defense obs)))
  (when (and has-ally-unwalled-punish-unit?
             (or (pair? enemy-bldgs)
                 (hash-ref obs 'scouted-enemy-choke? #f)
                 (hash-ref obs 'scouted-enemy-main? #f)))
    (emit-direct-batch! (UnwalledPunishPlan-commands (plan-unwalled-opponent-punish obs))))
  (when (or (<= frame 2800) has-ally-wall-block-bldg?)
    (emit-direct-batch! (plan-expansion-and-gas-blocks obs)))
  (when (or (pair? enemy-bldgs)
            (and (<= frame 3600)
                 (>= (exact->inexact (fast-finite-real (hash-ref obs 'minerals 0.0) 0.0)) 180.0)))
    (emit-direct-batch! (plan-counter-expansion-and-gas-blocks obs)))

  ;; Direct Tactic #5: `static-defense-and-nydus-tactics.rkt`
  (when (or has-ally-static-def-or-nydus? has-enemy-static-def-or-nydus?)
    (emit-direct-batch! (plan-static-defense-and-nydus-actions obs)))

  ;; Direct Tactic #6: `map-elements-and-experiments.rkt`
  (let ([neutrals (let ([v (hash-ref obs 'neutral-units '())]) (if (list? v) v '()))])
    (when (or (pair? neutrals)
              has-ally-map-elem-or-recall?
              has-enemy-map-elem-or-recall?)
      (define free-allies (unclaimed-ally-units-now))
      (define res
        (step-map-elements-tactical-micro!
         free-allies
         ally-bldgs
         enemy-units
         neutrals
         #:frame frame
         #:minerals (max 0 (let ([m (hash-ref obs 'minerals 400)]) (if (exact-integer? m) m 400)))
         #:gas (max 0 (let ([g (hash-ref obs 'gas 200)]) (if (exact-integer? g) g 200)))
         #:supply-left (max 0 (let ([s (hash-ref obs 'supply-left 12)]) (if (exact-integer? s) s 12)))
         #:home-x base-x
         #:home-y base-y
         #:nat-x nat-x
         #:nat-y nat-y
         #:enemy-x enemy-x
         #:enemy-y enemy-y
         #:expansion-pads (let ([ep (hash-ref obs 'expansion-pads '())]) (if (list? ep) ep '()))
         #:tracker (rt-map-elem-tracker rt)
         #:validated-only? #t))
      (define me-acts (hash-ref res 'actions '()))
      (when (list? me-acts)
        (emit-direct-batch! me-acts))))

  ;; Direct Tactic #7: `situational-counter-planner.rkt`
  (when (and (or (pair? ally-units) (pair? ally-bldgs))
             (or has-any-enemy?
                 (hash-ref obs 'proxy-detected? #f)
                 (hash-ref obs 'our-army-trapped? #f)))
    (define cached-sit-vec (unbox (rt-sit-plan-cache rt)))
    (define sit-plan
      (if (and (vector? cached-sit-vec) (>= (vector-length cached-sit-vec) 4))
          (vector-ref cached-sit-vec 3)
          (evaluate-situational-counter-plan obs direct-our-race direct-enemy-race frame)))
    (define raw-sit-acts (situational-counter-plan-ability-actions sit-plan))
    (when (pair? raw-sit-acts)
      (define remapped-acts
        (let ([has-id-1? 'unknown]
              [first-eid 'unknown])
          (for/list ([act (in-list raw-sit-acts)]
                     #:when (let ([ok? (cond
                                         [(and (pair? act)
                                               (eq? (car act) 'cast-spell)
                                               (= (length act) 4)
                                               (equal? (cadddr act) 1))
                                          (when (eq? has-id-1? 'unknown)
                                            (set! has-id-1?
                                                  (for/or ([e (in-list enemy-units)])
                                                    (= (hash-ref e 'id (hash-ref e 'tag -1)) 1)))
                                            (unless has-id-1?
                                              (set! first-eid
                                                    (for/or ([e (in-list enemy-units)])
                                                      (define id (hash-ref e 'id (hash-ref e 'tag -1)))
                                                      (and (exact-integer? id) (> id 0) id)))))
                                          (or has-id-1? first-eid)]
                                         [else #t])])
                              ok?))
            (if (and (pair? act)
                     (eq? (car act) 'cast-spell)
                     (= (length act) 4)
                     (equal? (cadddr act) 1)
                     (not has-id-1?))
                (list (car act) (cadr act) (caddr act) first-eid)
                act))))
      (emit-direct-batch! remapped-acts)))

  (define sanitized-tactic-actions
    (sanitize-stale-target-actions (reverse (l34-ctx-actions ctx)) obs #:pos-cache (rt-enemy-pos-cache rt)))
  (values sanitized-tactic-actions vanguard-count reserve-count))

(define (step-layer3-and-4-tactics! rt raw-obs fap-score #:sanitized? [sanitized? #f])
  (define ctx (rt-l34-ctx rt))
  (l34-phase1-setup! ctx rt raw-obs fap-score sanitized?)
  (l34-phase2-tbrain-drops! ctx)
  (l34-phase3-classify! ctx)
  (l34-phase4a-hazards-wm! ctx)
  (l34-phase4b-baneling-oracle! ctx)
  (l34-phase5a-wave-casters! ctx)
  (l34-phase5b-engage! ctx)
  (l34-phase6-raid-concave-reach! ctx)
  (define-values (sanitized-tactic-actions vanguard-count reserve-count)
    (l34-phase7-direct-tactics! ctx))
  (l34-clear-ctx-refs! ctx)
  (values sanitized-tactic-actions vanguard-count reserve-count))


;; =============================================================================
;; Layer 5: Human Cortex Camera Saccades, Ability Throttling & Token Filtering
;; =============================================================================

(define (step-layer5-human-cortex! rt raw-actions raw-obs #:sanitized? [sanitized? #f])
  (define obs (if sanitized? raw-obs (sanitize-obs-hash raw-obs)))
  (define frame (hash-ref obs 'frame 0))
  (define limiter (live-bot-runtime-cast-limiter rt))
  (define cortex (live-bot-runtime-cortex rt))
  (define nat-x (hash-ref obs 'natural-x 45.0))
  (define nat-y (hash-ref obs 'natural-y 45.0))

  ;; 1. Refractory ability cast limiter (cross Typed/Untyped boundary only for cast candidates)
  (define cast-acts
    (for/fold ([acc '()]) ([act (in-list raw-actions)])
      (if (and (pair? act)
               (let ([head (car act)])
                 (or (eq? head 'cast)
                     (eq? head 'cast-spell)
                     (eq? head 'use-ability)
                     (eq? head 'inject-larva))))
          (cons act acc)
          acc)))
  (define-values (unthrottled-actions spell-throttled)
    (if (null? cast-acts)
        (begin
          (throttle-ability-casts! limiter '() frame)
          (values raw-actions 0))
        (let-values ([(kept-casts throttled)
                      (throttle-ability-casts! limiter (reverse cast-acts) frame)])
          (if (= throttled 0)
              (values raw-actions 0)
              (let loop ([rem raw-actions] [krem kept-casts] [acc '()])
                (cond
                  [(null? rem) (values (reverse acc) throttled)]
                  [else
                   (define act (car rem))
                   (define cast?
                     (and (pair? act)
                          (let ([head (car act)])
                            (or (eq? head 'cast)
                                (eq? head 'cast-spell)
                                (eq? head 'use-ability)
                                (eq? head 'inject-larva)))))
                   (if (not cast?)
                       (loop (cdr rem) krem (cons act acc))
                       (if (and (pair? krem) (equal? act (car krem)))
                           (loop (cdr rem) (cdr krem) (cons act acc))
                           (loop (cdr rem) krem acc)))]))))))

  ;; 2. Selection & Control-Group Compiler + Per-Action Camera Framing for Un-Grouped Units
  (define base-x (hash-ref obs 'base-x 32.5))
  (define base-y (hash-ref obs 'base-y 32.5))
  (define ally-units (hash-ref obs 'ally-units '()))
  (define ally-bldgs (hash-ref obs 'ally-buildings '()))
  (define l5-sc (rt-l5-scratch rt))
  (define all-cgroup-member-ids (pooled-hasheqv! l5-sc 'all-cgroup-member-ids))
  (for ([g (in-range 1 7)])
    (for ([uid (in-list (cortex-get-control-group cortex g))])
      (when (exact-integer? uid)
        (hash-set! all-cgroup-member-ids uid #t))))
  (define unit-pos-cache #f)
  (define (get-unit-pos-by-id)
    (or unit-pos-cache
        (let ([ht (make-hasheqv)])
          (for ([r (in-list ally-units)])
            (when (hash? r)
              (define id (hash-ref r 'id #f))
              (define x (hash-ref r 'x #f))
              (define y (hash-ref r 'y #f))
              (when (and (exact-integer? id) (real? x) (real? y))
                (hash-set! ht id (cons (exact->inexact x) (exact->inexact y))))))
          (for ([r (in-list ally-bldgs)])
            (when (hash? r)
              (define id (hash-ref r 'id #f))
              (define x (hash-ref r 'x #f))
              (define y (hash-ref r 'y #f))
              (when (and (exact-integer? id) (real? x) (real? y))
                (hash-set! ht id (cons (exact->inexact x) (exact->inexact y))))))
          (set! unit-pos-cache ht)
          ht)))

  (define selection-compiled-actions
    (if (or (not (eq? (hash-ref raw-obs 'mineral-harvesters RUNTIME-MISSING) RUNTIME-MISSING))
            (hash-ref raw-obs 'compile-human-selections? #f))
        (cortex-collapse-and-compile-selections!
         cortex
         unthrottled-actions
         ally-units
         ally-bldgs)
        unthrottled-actions))

  (define cam-moved? #f)
  (define framed-actions
    (let loop ([rem selection-compiled-actions]
               [cx (human-cortex-cam-x cortex)]
               [cy (human-cortex-cam-y cortex)]
               [acc '()])
      (cond
        [(null? rem) (reverse acc)]
        [else
         (define act (car rem))
         (define-values (next-cx next-cy new-acc)
           (match act
             [(list 'move-camera (? real? mx) (? real? my))
              (set! cam-moved? #t)
              (cortex-move-camera! cortex (exact->inexact mx) (exact->inexact my))
              (values (exact->inexact mx) (exact->inexact my) (cons act acc))]
             [(list 'camera-focus _ (? real? mx) (? real? my))
              (set! cam-moved? #t)
              (cortex-move-camera! cortex (exact->inexact mx) (exact->inexact my))
              (values (exact->inexact mx) (exact->inexact my) (cons act acc))]
             [(list 'camera-focus (? real? mx) (? real? my))
              (set! cam-moved? #t)
              (cortex-move-camera! cortex (exact->inexact mx) (exact->inexact my))
              (values (exact->inexact mx) (exact->inexact my) (cons act acc))]
             [_
              (define focus
                (action-requires-camera-focus act all-cgroup-member-ids get-unit-pos-by-id base-x base-y))
              (if (and (pair? focus)
                       (not (in-camera-viewport? cx cy (car focus) (cdr focus))))
                  (let ([fx (safe-coord (car focus) cx)]
                        [fy (safe-coord (cdr focus) cy)])
                    (set! cam-moved? #t)
                    (cortex-move-camera! cortex fx fy)
                    (values fx fy (cons act (cons (list 'move-camera fx fy) acc))))
                  (values cx cy (cons act acc)))]))
         (loop (cdr rem) next-cx next-cy new-acc)])))

  ;; Fallback enemy focal check only when no per-action camera framing occurred
  (define enemy-units (hash-ref obs 'enemy-units '()))
  (define cam-actions
    (cond
      [cam-moved? '()]
      [(and (not (null? enemy-units))
            (not (in-camera-viewport? (human-cortex-cam-x cortex)
                                      (human-cortex-cam-y cortex)
                                      (hash-ref (car enemy-units) 'x nat-x)
                                      (hash-ref (car enemy-units) 'y nat-y))))
       (define tx (safe-coord (hash-ref (car enemy-units) 'x nat-x) nat-x))
       (define ty (safe-coord (hash-ref (car enemy-units) 'y nat-y) nat-y))
       (cortex-move-camera! cortex tx ty)
       (list (list 'move-camera tx ty))]
      [else
       (cortex-move-camera! cortex
                            (human-cortex-cam-x cortex)
                            (human-cortex-cam-y cortex))
       '()]))

  (define combined (append cam-actions framed-actions))
  (define-values (accepted dropped)
    (cortex-filter-actions! cortex combined))
  (values accepted dropped spell-throttled))

;; =============================================================================
;; Layer 5b: Pro-Human Camera Saccade (60-90 SPM) & APM/EPM Discipline Governor
;; =============================================================================

(define PRO-CAMERA-SACCADE-ZONES
  '(home-macro-base
    natural-expansion
    active-army-front
    harass-or-blocker-zone))

(define (step-pro-human-camera-and-apm-governor! rt [raw-obs (hash)] #:sanitized? [sanitized? #f])
  (define obs (if sanitized? raw-obs (sanitize-obs-hash raw-obs)))
  (define frame (hash-ref obs 'frame 0))
  (define cortex (live-bot-runtime-cortex rt))
  (define bmarks (human-cortex-camera-bookmarks cortex))
  (define base-x (hash-ref obs 'base-x 32.5))
  (define base-y (hash-ref obs 'base-y 32.5))
  (define nat-x (hash-ref obs 'natural-x 45.0))
  (define nat-y (hash-ref obs 'natural-y 45.0))
  (define enemy-x (hash-ref obs 'enemy-x 160.5))
  (define enemy-y (hash-ref obs 'enemy-y 160.5))
  (define enemy-exp-x (hash-ref obs 'enemy-expand-x 148.0))
  (define enemy-exp-y (hash-ref obs 'enemy-expand-y 148.0))
  (define enemy-units (hash-ref obs 'enemy-units '()))
  (define ally-bldgs (hash-ref obs 'ally-buildings '()))
  (define live-cam-obs?
    (not (eq? (hash-ref raw-obs 'mineral-harvesters RUNTIME-MISSING) RUNTIME-MISSING)))

  (define dwell-min
    (if live-cam-obs?
        (max 28 SC2-CAMERA-SACCADE-MIN-DWELL-FRAMES)
        SC2-CAMERA-SACCADE-MIN-DWELL-FRAMES))
  (define last-frame (hash-ref bmarks 'last-saccade-frame #f))
  (define cur-idx (safe-nonneg-int (hash-ref bmarks 'saccade-zone-idx 0) 0))
  ;; Pro humans dwell >= 28 frames (~1.25s) per camera zone in live games unless jumping > 18 tiles for a crisis.
  (define saccade-due?
    (or (not (exact-integer? last-frame))
        (= frame last-frame)
        (>= (abs (- frame last-frame)) dwell-min)))
  (define next-idx
    (cond
      [(not (exact-integer? last-frame)) 0]
      [saccade-due?
       (modulo (add1 cur-idx) (length PRO-CAMERA-SACCADE-ZONES))]
      [else (modulo cur-idx (length PRO-CAMERA-SACCADE-ZONES))]))
  (when saccade-due?
    (hash-set! bmarks 'last-saccade-frame frame)
    (hash-set! bmarks 'saccade-zone-idx next-idx))

  (define active-crisis-now?
    (let ([fbx (if (flonum? base-x) base-x (exact->inexact base-x))]
          [fby (if (flonum? base-y) base-y (exact->inexact base-y))]
          [fnx (if (flonum? nat-x) nat-x (exact->inexact nat-x))]
          [fny (if (flonum? nat-y) nat-y (exact->inexact nat-y))])
      (or (eq? (hash-ref obs 'under-attack #f) #t)
          (eq? (hash-ref obs 'under-cheese-rush #f) #t)
          (for/or ([b (in-list ally-bldgs)])
            (and (hash? b) (eq? (hash-ref b 'under-attack #f) #t)))
          (for/or ([e (in-list enemy-units)])
            (and (hash? e)
                 (let* ([rx (hash-ref e 'x 9999.0)]
                        [ry (hash-ref e 'y 9999.0)]
                        [ex (if (flonum? rx) rx (exact->inexact rx))]
                        [ey (if (flonum? ry) ry (exact->inexact ry))]
                        [dx1 (fl- ex fbx)]
                        [dy1 (fl- ey fby)]
                        [dx2 (fl- ex fnx)]
                        [dy2 (fl- ey fny)])
                   (or (fl<= (fl+ (fl* dx1 dx1) (fl* dy1 dy1)) 784.0)
                       (fl<= (fl+ (fl* dx2 dx2) (fl* dy2 dy2)) 784.0))))))))
  (define zone
    (if (and live-cam-obs? active-crisis-now? (not (null? enemy-units)))
        'active-army-front
        (list-ref PRO-CAMERA-SACCADE-ZONES next-idx)))
  (define-values (zx zy)
    (case zone
      [(home-macro-base)
       (values base-x base-y)]
      [(natural-expansion)
       (values nat-x nat-y)]
      [(active-army-front)
       (if (not (null? enemy-units))
           (values (safe-coord (hash-ref (car enemy-units) 'x nat-x) nat-x)
                   (safe-coord (hash-ref (car enemy-units) 'y nat-y) nat-y))
           (values (safe-coord (* 0.5 (+ nat-x enemy-x)) nat-x)
                   (safe-coord (* 0.5 (+ nat-y enemy-y)) nat-y)))]
      [(harass-or-blocker-zone)
       (values enemy-exp-x enemy-exp-y)]
      [else
       (values base-x base-y)]))

  (define prev-focus-f (hash-ref bmarks 'last-camera-focus-frame #f))
  (define prev-focus-x (safe-finite-real (hash-ref bmarks 'last-camera-focus-x zx) zx))
  (define prev-focus-y (safe-finite-real (hash-ref bmarks 'last-camera-focus-y zy) zy))
  (define crisis-cam-jump?
    (and active-crisis-now?
         (> (dist2d zx zy prev-focus-x prev-focus-y) 18.0)))
  (define emit-camera-focus?
    (or (not live-cam-obs?)
        (not (exact-integer? prev-focus-f))
        (< frame prev-focus-f)
        (>= (- frame prev-focus-f) 28)
        crisis-cam-jump?))
  (when emit-camera-focus?
    (hash-set! bmarks 'last-camera-focus-frame frame)
    (hash-set! bmarks 'last-camera-focus-x zx)
    (hash-set! bmarks 'last-camera-focus-y zy))

  (define prof (get-pro-cortex-profile (human-cortex-profile-name cortex)))
  (define target-apm (min 360 (safe-nonneg-int (hash-ref prof 'mean-epm 350) 350)))
  (if emit-camera-focus?
      (list (list 'camera-focus zone zx zy)
            (list 'human-apm-discipline target-apm 3 #t #t))
      (list (list 'human-apm-discipline target-apm 3 #t #t))))

;; =============================================================================
;; Top-Level 5-Layer Step (`step-live-bot-runtime!`)
;; =============================================================================

(define EXTENDED-STASIS-AND-DRILL-HEADS
  '(worker-drill-stack-attack
    evacuate-workers-from-stasis-ward
    trigger-stasis-ward-single-unit
    counter-enemy-worker-drill
    stasis-worker-stoppage-compensation
    return-workers-to-gather))

(define (step-live-bot-runtime! rt [obs-or-sexp (hash)])
  (define t0-step-ms (current-inexact-monotonic-milliseconds))
  (define raw-obs
    (cond
      [(hash? obs-or-sexp) obs-or-sexp]
      [(pair? obs-or-sexp) (parse-frame-state-sexp obs-or-sexp)]
      [(string? obs-or-sexp)
       (with-handlers ([exn:fail? (lambda (_e) (hash))])
         (parse-frame-state-sexp (read (open-input-string obs-or-sexp))))]
      [else (hash)]))
  (define obs (sanitize-obs-hash raw-obs))

  (set-live-bot-runtime-step-count! rt (add1 (live-bot-runtime-step-count rt)))
  (set-box! (rt-wall-aabbs-box rt) '())

  ;; Layer 1
  (step-layer1-perception! rt obs #:sanitized? #t)
  ;; Layer 1b
  (define-values (posture-acts fap-score) (step-layer1b-mastermind! rt obs #:sanitized? #t))
  ;; Layer 1c (Generic k-Level Mirror-Mind Opponent Prediction Layer)
  ;; Cache unchanged midgame predictions up to 16 frames (~0.7s) in live games while running immediately on any change.
  (define step-frame-early (safe-nonneg-int (hash-ref obs 'frame 0) 0))
  (define door-st-cache (rt-door-state rt))
  (define mirror-cache (hash-ref door-st-cache 'mirror-cache #f))
  (define mirror-sig
    (list (length (hash-ref obs 'enemy-units '()))
          (length (hash-ref obs 'enemy-buildings '()))
          (length (hash-ref obs 'ally-buildings '()))
          (not (not (hash-ref obs 'under-attack #f)))))
  (define has-mh?
    (not (eq? (hash-ref raw-obs 'mineral-harvesters RUNTIME-MISSING) RUNTIME-MISSING)))
  (define run-mirror-now?
    (or (not has-mh?)
        (not (vector? mirror-cache))
        (<= step-frame-early 16)
        (< step-frame-early (vector-ref mirror-cache 0))
        (and (>= (- step-frame-early (vector-ref mirror-cache 0)) 16)
             (= (modulo step-frame-early 16) 8))
        (not (equal? mirror-sig (vector-ref mirror-cache 1)))))
  (define mirror-acts
    (cond
      [run-mirror-now?
       (define ma (step-layer1c-mirror-mind! rt obs))
       (hash-set! door-st-cache 'mirror-cache (vector step-frame-early mirror-sig ma))
       ma]
      [else '()]))
  ;; Layer 2
  (define econ-acts (step-layer2-economy! rt obs #:raw-obs raw-obs #:sanitized? #t))
  ;; Layer 3 & 4
  (define-values (tactic-acts vanguard-cnt reserve-cnt)
    (step-layer3-and-4-tactics! rt obs fap-score #:sanitized? #t))

  (define has-drill-head-passthrough?
    (and (hash? raw-obs)
         (or has-mh?
             (not (eq? (hash-ref raw-obs 'raw-mineral-harvesters RUNTIME-MISSING) RUNTIME-MISSING))
             (hash-ref raw-obs 'include-extended-drill-actions? #f))))
  (define raw-actions
    (if has-drill-head-passthrough?
        (append posture-acts econ-acts tactic-acts)
        (let ([acc-rev '()])
          (define (keep-non-drill! xs)
            (for ([a (in-list xs)])
              (unless (and (pair? a) (memq (car a) EXTENDED-STASIS-AND-DRILL-HEADS))
                (set! acc-rev (cons a acc-rev)))))
          (keep-non-drill! posture-acts)
          (keep-non-drill! econ-acts)
          (keep-non-drill! tactic-acts)
          (reverse acc-rev))))

  ;; Layer 5
  (define-values (accepted dropped spell-throttled)
    (step-layer5-human-cortex! rt raw-actions obs #:sanitized? #t))
  ;; Layer 5b: Pro-Human Camera Saccade (60-90 SPM) & APM/EPM Discipline Governor
  (define pro-apm-acts
    (step-pro-human-camera-and-apm-governor! rt obs #:sanitized? #t))
  (define cur-msp
    (let ([lt (live-bot-runtime-last-telemetry rt)])
      (and (hash? lt) (hash-ref lt 'max-supply-plan #f))))
  (define msp-set
    (if (and (max-supply-plan? cur-msp) (max-supply-plan-active? cur-msp))
        (max-supply-plan-combined-actions cur-msp)
        '()))
  (define accepted-ht-box #f)
  (define (get-accepted-ht)
    (unless accepted-ht-box
      (define ht (make-hash))
      (for ([a (in-list accepted)]) (hash-set! ht a #t))
      (set! accepted-ht-box ht))
    accepted-ht-box)
  (define msp-action-ht
    (and (pair? msp-set)
         (let ([ht (make-hash)])
           (for ([x (in-list msp-set)]) (hash-set! ht x #t))
           ht)))
  (define preserved-tactical-directives
    (let ([acc-rev '()]
          [splash-st-rt (rt-splash-state rt)])
      (define disruptor-dir-set
        (and (hash? splash-st-rt)
             (equal? (hash-ref splash-st-rt 'disruptor-directive-frame #f) step-frame-early)
             (hash-ref splash-st-rt 'disruptor-directive-set #f)))
      (define wave3-dir-set
        (and (hash? splash-st-rt)
             (equal? (hash-ref splash-st-rt 'wave3-preserved-frame #f) step-frame-early)
             (hash-ref splash-st-rt 'wave3-preserved-set #f)))
      (for ([a (in-list econ-acts)])
        (when (and (pair? a)
                   (let ([h (car a)])
                     (or (hash-ref PRESERVED-ECON-HEAD-SET h #f)
                         (and (or (eq? h 'cast) (eq? h 'cast-spell))
                              (pair? (cdr a))
                              (pair? (cddr a))
                              (hash-ref PRESERVED-ECON-CAST-SET (caddr a) #f))
                         (and msp-action-ht (hash-ref msp-action-ht a #f))))
                   (not (hash-ref (get-accepted-ht) a #f)))
          (set! acc-rev (cons a acc-rev))))
      (for ([a (in-list tactic-acts)])
        (when (and (pair? a)
                   (let ([h (car a)])
                     (or (hash-ref PRESERVED-TACTIC-HEAD-SET h #f)
                         (and (or (eq? h 'cast) (eq? h 'cast-spell))
                              (pair? (cdr a))
                              (pair? (cddr a))
                              (hash-ref PRESERVED-TACTIC-CAST-SET (caddr a) #f))
                         (and disruptor-dir-set (set-member? disruptor-dir-set a))
                         (and wave3-dir-set (set-member? wave3-dir-set a))))
                   (not (hash-ref (get-accepted-ht) a #f)))
          (set! acc-rev (cons a acc-rev))))
      (reverse acc-rev)))

  (define cortex (live-bot-runtime-cortex rt))
  (define mstate (live-bot-runtime-mastermind rt))
  (define mmstate (live-bot-runtime-mirror-mind rt))
  (define tbrain (live-bot-runtime-tactical-brain rt))
  (define oledger (live-bot-runtime-order-ledger rt))
  (define mmledger (mirror-mind-state-last-shadow-ledger mmstate))
  (define mmalloc (mirror-mind-state-toolbox-allocation mmstate))
  (define mmtech (mirror-mind-state-last-tech-observation mmstate))
  (define mmzs (mirror-mind-state-last-zero-sum-reading mmstate))
  (define scouted-sec-cnt
    (max 1 (length (hash-ref obs 'visible-sectors '(0 1 2 3)))))
  (define hist (live-bot-runtime-posture-history rt))
  (define recent-switches
    (max 1 (min 7 (sub1 (max 1 (length hist))))))
  (define pda
    (make-pda-trace #:scouted-sectors scouted-sec-cnt
                    #:posture-switches recent-switches
                    #:actions-emitted (+ (length accepted) dropped spell-throttled)
                    #:actions-dropped (+ dropped spell-throttled)))
  (define rplan
    (evaluate-random-stealth-harass-plan
     (live-bot-runtime-configured-race rt)
     (live-bot-runtime-actual-race rt)
     (hash-ref obs 'frame 0)))

  (define last-tel-ht
    (let ([t (live-bot-runtime-last-telemetry rt)])
      (if (hash? t) t (hash))))
  (define step-wall-aabbs (unbox (rt-wall-aabbs-box rt)))
  (define b-obs-frame (safe-nonneg-int (hash-ref obs 'frame 0) 0))
  (define b-enemy-race (hash-ref last-tel-ht 'effective-enemy-race (hash-ref obs 'enemy-race 'Unknown)))
  (define b-base-x (hash-ref obs 'base-x SC2-DEFAULT-HOME-BASE-X))
  (define b-base-y (hash-ref obs 'base-y SC2-DEFAULT-HOME-BASE-Y))
  (define b-enemy-x (hash-ref obs 'enemy-x SC2-DEFAULT-ENEMY-BASE-X))
  (define b-enemy-y (hash-ref obs 'enemy-y SC2-DEFAULT-ENEMY-BASE-Y))
  (define b-enemy-nat-x (hash-ref obs 'enemy-natural-x (hash-ref obs 'enemy-expand-x SC2-DEFAULT-ENEMY-EXPAND-X)))
  (define b-enemy-nat-y (hash-ref obs 'enemy-natural-y (hash-ref obs 'enemy-expand-y SC2-DEFAULT-ENEMY-EXPAND-Y)))
  (define b-base-fx (if (flonum? b-base-x) b-base-x (exact->inexact b-base-x)))
  (define b-base-fy (if (flonum? b-base-y) b-base-y (exact->inexact b-base-y)))
  (define b-enemy-fx (if (flonum? b-enemy-x) b-enemy-x (exact->inexact b-enemy-x)))
  (define b-enemy-fy (if (flonum? b-enemy-y) b-enemy-y (exact->inexact b-enemy-y)))
  (define b-enemy-nat-fx (if (flonum? b-enemy-nat-x) b-enemy-nat-x (exact->inexact b-enemy-nat-x)))
  (define b-enemy-nat-fy (if (flonum? b-enemy-nat-y) b-enemy-nat-y (exact->inexact b-enemy-nat-y)))
  (define b-wall-cnt 0)
  (define b-lowered-cnt 0)
  (define b-static-def-cnt 0)
  (define b-home-prod-cnt 0)
  (define b-gas-cnt 0)
  (define b-nat-taken? #f)
  (define b-proxy? #f)
  (for ([eb (in-list (hash-ref obs 'enemy-buildings '()))]
        #:when (hash? eb))
    (define bt (unit-type-sym eb))
    (define bf (fast-bayes-eb-flags bt))
    (unless (zero? bf)
      (when (not (zero? (bitwise-and bf 15)))
        (define need-wall? (bitwise-bit-set? bf 0))
        (define need-prod? (bitwise-bit-set? bf 1))
        (define need-th? (and (not b-nat-taken?) (bitwise-bit-set? bf 2)))
        (define need-proxy? (and (not b-proxy?) (> b-obs-frame 0) (bitwise-bit-set? bf 3)))
        (when (or need-wall? need-prod? need-th? need-proxy?)
          (define ex-raw (hash-ref eb 'x b-enemy-fx))
          (define ey-raw (hash-ref eb 'y b-enemy-fy))
          (define ex (if (flonum? ex-raw) ex-raw (exact->inexact ex-raw)))
          (define ey (if (flonum? ey-raw) ey-raw (exact->inexact ey-raw)))
          (when need-wall?
            (define dx (fl- ex b-enemy-nat-fx))
            (define dy (fl- ey b-enemy-nat-fy))
            (when (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 256.0)
              (set! b-wall-cnt (add1 b-wall-cnt))))
          (when need-prod?
            (define dx (fl- ex b-enemy-fx))
            (define dy (fl- ey b-enemy-fy))
            (when (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 900.0)
              (set! b-home-prod-cnt (add1 b-home-prod-cnt))))
          (when need-th?
            (define dx (fl- ex b-enemy-nat-fx))
            (define dy (fl- ey b-enemy-nat-fy))
            (when (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 100.0)
              (set! b-nat-taken? #t)))
          (when need-proxy?
            (define dx (fl- ex b-base-fx))
            (define dy (fl- ey b-base-fy))
            (when (fl<= (fl+ (fl* dx dx) (fl* dy dy)) 2025.0)
              (set! b-proxy? #t)))))
      (when (bitwise-bit-set? bf 4)
        (set! b-lowered-cnt (add1 b-lowered-cnt)))
      (when (bitwise-bit-set? bf 5)
        (set! b-static-def-cnt (add1 b-static-def-cnt)))
      (when (bitwise-bit-set? bf 6)
        (set! b-gas-cnt (add1 b-gas-cnt)))))
  (define b-combat-cnt 0)
  (define b-air-harass? #f)
  (define b-near-home-cnt 0)
  (define b-min-home-d2 998001.0)
  (for ([eu (in-list (hash-ref obs 'enemy-units '()))]
        #:when (hash? eu))
    (define ut (unit-type-sym eu))
    (define ef (hash-ref BAYES-EU-FLAGS-HT ut 0))
    (when (and (not b-air-harass?) (bitwise-bit-set? ef 0))
      (set! b-air-harass? #t))
    (when (zero? (bitwise-and ef 2))
      (define ex-raw (hash-ref eu 'x b-enemy-fx))
      (define ey-raw (hash-ref eu 'y b-enemy-fy))
      (define ex (if (flonum? ex-raw) ex-raw (exact->inexact ex-raw)))
      (define ey (if (flonum? ey-raw) ey-raw (exact->inexact ey-raw)))
      (define dx (fl- ex b-base-fx))
      (define dy (fl- ey b-base-fy))
      (define d2 (fl+ (fl* dx dx) (fl* dy dy)))
      (set! b-combat-cnt (add1 b-combat-cnt))
      (when (fl<= d2 576.0)
        (set! b-near-home-cnt (add1 b-near-home-cnt)))
      (when (fl< d2 b-min-home-d2)
        (set! b-min-home-d2 d2))))
  (define b-min-home-dist (flsqrt b-min-home-d2))
  (define bc (rt-bayes-cache rt))
  (define u-scouted?
    (and (or (> b-wall-cnt 0)
             (> (hash-ref last-tel-ht 'last-seen-natural-frame 0) 0))
         #t))
  (define u-frame-ge? (>= b-obs-frame 1568))
  (define b-unwalled-post
    (if (and (vector-ref bc 6)
             (= (vector-ref bc 0) b-wall-cnt)
             (= (vector-ref bc 1) b-lowered-cnt)
             (eq? (vector-ref bc 2) u-scouted?)
             (eq? (vector-ref bc 3) b-enemy-race)
             (eq? (vector-ref bc 4) u-frame-ge?)
             (= (vector-ref bc 5) b-static-def-cnt))
        (vector-ref bc 6)
        (let ([res (compute-bayesian-unwalled-opponent-posterior
                    #:prior 0.35
                    #:wall-structure-count b-wall-cnt
                    #:lowered-depot-count b-lowered-cnt
                    #:door-gap-units (if (= b-wall-cnt 0) 2.5 0.0)
                    #:scouted-choke? u-scouted?
                    #:enemy-race b-enemy-race
                    #:frame (if u-frame-ge? 1568 0)
                    #:static-defense-count b-static-def-cnt)])
          (vector-set! bc 0 b-wall-cnt)
          (vector-set! bc 1 b-lowered-cnt)
          (vector-set! bc 2 u-scouted?)
          (vector-set! bc 3 b-enemy-race)
          (vector-set! bc 4 u-frame-ge?)
          (vector-set! bc 5 b-static-def-cnt)
          (vector-set! bc 6 res)
          res)))
  (define p-exp (cond [(< b-obs-frame 1500) 0] [(< b-obs-frame 3000) 1] [else 2]))
  (define p-nat? (and b-nat-taken? #t))
  (define p-main? (and (> (hash-ref last-tel-ht 'last-seen-main-frame 0) 0) #t))
  (define p-fbucket (cond [(< b-obs-frame 1800) 0] [(< b-obs-frame 2000) 1800] [(<= b-obs-frame 3600) 2000] [else 3601]))
  (define p-proxy? (and b-proxy? #t))
  (define p-early-combat (if (< b-obs-frame 3600) b-combat-cnt 0))
  (define b-proxy-post
    (if (and (vector-ref bc 18)
             (= (vector-ref bc 10) b-home-prod-cnt)
             (= (vector-ref bc 11) p-exp)
             (eq? (vector-ref bc 12) p-nat?)
             (eq? (vector-ref bc 13) p-main?)
             (= (vector-ref bc 14) b-gas-cnt)
             (= (vector-ref bc 15) p-fbucket)
             (eq? (vector-ref bc 16) p-proxy?)
             (= (vector-ref bc 17) p-early-combat))
        (vector-ref bc 18)
        (let ([res (compute-bayesian-proxy-all-in-posterior
                    #:prior 0.12
                    #:home-production-count b-home-prod-cnt
                    #:expected-home-production p-exp
                    #:enemy-natural-taken? p-nat?
                    #:scouted-enemy-main? p-main?
                    #:enemy-gas-count b-gas-cnt
                    #:frame p-fbucket
                    #:proxy-bldg-spotted? p-proxy?
                    #:early-enemy-combat-count p-early-combat
                    #:enemy-worker-deficit? #f)])
          (vector-set! bc 10 b-home-prod-cnt)
          (vector-set! bc 11 p-exp)
          (vector-set! bc 12 p-nat?)
          (vector-set! bc 13 p-main?)
          (vector-set! bc 14 b-gas-cnt)
          (vector-set! bc 15 p-fbucket)
          (vector-set! bc 16 p-proxy?)
          (vector-set! bc 17 p-early-combat)
          (vector-set! bc 18 res)
          res)))
  (define m-dist-bucket (cond [(fl>= b-min-home-dist 22.0) 22.0] [(fl< b-min-home-dist 14.0) 0.0] [else 15.0]))
  (define m-unwalled? (fl>= b-unwalled-post 0.55))
  (define m-air? (and b-air-harass? #t))
  (define m-unprot (if (>= b-obs-frame 4000) 1 0))
  (define m-harass-ready? (and (or (pair? tactic-acts) (>= (hash-ref obs 'army-supply 0) 12)) #t))
  (define m-under-atk? (>= b-near-home-cnt 4))
  (define m-attn (if (or b-air-harass? (> b-near-home-cnt 0)) 0.65 0.25))
  (define b-multi-prong-post
    (if (and (vector-ref bc 28)
             (eqv? (vector-ref bc 20) m-dist-bucket)
             (eq? (vector-ref bc 21) m-unwalled?)
             (eq? (vector-ref bc 22) m-air?)
             (= (vector-ref bc 23) m-unprot)
             (eq? (vector-ref bc 24) m-harass-ready?)
             (eq? (vector-ref bc 25) m-under-atk?)
             (= (vector-ref bc 26) b-static-def-cnt)
             (eqv? (vector-ref bc 27) m-attn))
        (vector-ref bc 28)
        (let ([res (compute-bayesian-multi-prong-window-posterior
                    #:prior 0.25
                    #:enemy-army-dist-from-home m-dist-bucket
                    #:enemy-unwalled? m-unwalled?
                    #:active-air-harass? m-air?
                    #:unprotected-mineral-lines m-unprot
                    #:unused-harass-supply-ready? m-harass-ready?
                    #:under-heavy-home-attack? m-under-atk?
                    #:enemy-static-defense-count b-static-def-cnt
                    #:opponent-attention-load m-attn)])
          (vector-set! bc 20 m-dist-bucket)
          (vector-set! bc 21 m-unwalled?)
          (vector-set! bc 22 m-air?)
          (vector-set! bc 23 m-unprot)
          (vector-set! bc 24 m-harass-ready?)
          (vector-set! bc 25 m-under-atk?)
          (vector-set! bc 26 b-static-def-cnt)
          (vector-set! bc 27 m-attn)
          (vector-set! bc 28 res)
          res)))
  (define-syntax-rule (tel-keep th k def)
    (if (eq? (hash-ref th k RUNTIME-MISSING) RUNTIME-MISSING)
        (hash-set th k def)
        th))
  (define telemetry0
    (let ([th last-tel-ht])
      (set! th (tel-set th 'posture (live-bot-runtime-posture rt)))
      (set! th (tel-set th 'actual-race (live-bot-runtime-actual-race rt)))
      (set! th (tel-set th 'bo-tactical-plan (hash-ref door-st-cache 'bo-tactical-plan #f)))
      (set! th (tel-set th 'bo-tactical-disposition (hash-ref door-st-cache 'bo-tactical-disposition #f)))
      (set! th (tel-set th 'bo-tactical-phase (hash-ref door-st-cache 'bo-tactical-phase #f)))
      (set! th (tel-set th 'bo-micro-directives (hash-ref door-st-cache 'bo-micro-directives '())))
      (set! th (tel-set th 'bo-active-tactics (hash-ref door-st-cache 'bo-active-tactics '())))
      (set! th (tel-set th 'random-stealth-active? (random-stealth-harass-plan-active? rplan)))
      (set! th (tel-set th 'random-stealth-doctrine (random-stealth-harass-plan-doctrine-name rplan)))
      (set! th (tel-set th 'random-stealth-phase (random-stealth-harass-plan-stealth-phase rplan)))
      (set! th (tel-set th 'random-deny-scout-choke? (random-stealth-harass-plan-deny-scout-choke? rplan)))
      (set! th (tel-set th 'random-perimeter-flight? (random-stealth-harass-plan-perimeter-flight-path? rplan)))
      (set! th (tel-set th 'random-fake-normal-front? (random-stealth-harass-plan-fake-normal-front? rplan)))
      (set! th (tel-set th 'epm (* 71 (human-cortex-accepted-count cortex))))
      (set! th (tel-set th 'accepted (length accepted)))
      (set! th (tel-set th 'dropped dropped))
      (set! th (tel-set th 'spell-throttled spell-throttled))
      (set! th (tel-set th 'cam-x (human-cortex-cam-x cortex)))
      (set! th (tel-set th 'cam-y (human-cortex-cam-y cortex)))
      (set! th (tel-set th 'fixation (human-cortex-fixation-frames cortex)))
      (set! th (tel-set th 'fap-score fap-score))
      (set! th (tel-set th 'fap-posture (fap-posture-with-hysteresis fap-score 'hold)))
      (set! th (tel-set th 'enemy-archetype (mastermind-state-enemy-archetype mstate)))
      (set! th (tel-set th 'mastermind-unit (mastermind-state-selected-unit mstate)))
      (set! th (tel-set th 'mastermind-directive (mastermind-state-directive mstate)))
      (set! th (tel-set th 'double-reactions (mastermind-state-double-reactions mstate)))
      (set! th (tel-set th 'flank-angle-idx (mastermind-state-flank-angle-idx mstate)))
      (set! th (tel-set th 'compounding-dominant (mastermind-state-compounding-dominant mstate)))
      (set! th (tel-set th 'mirror-active-depth (mirror-mind-state-active-depth mmstate)))
      (set! th (tel-set th 'mirror-inferred-opponent-depth (mirror-mind-state-inferred-opponent-depth mmstate)))
      (set! th (tel-set th 'mirror-last-probe-response (mirror-mind-state-last-probe-response mmstate)))
      (set! th (tel-set th 'mirror-toolbox-weight (mirror-toolbox-allocation-toolbox-weight mmalloc)))
      (set! th (tel-set th 'mirror-primary-macro-weight (mirror-toolbox-allocation-primary-macro-weight mmalloc)))
      (set! th (tel-set th 'mirror-toolbox-role (mirror-toolbox-allocation-toolbox-role mmalloc)))
      (set! th (tel-set th 'mirror-allow-unit-hedge? (mirror-toolbox-allocation-allow-unit-hedge? mmalloc)))
      (set! th (tel-set th 'mirror-allow-posture-override? (mirror-toolbox-allocation-allow-posture-override? mmalloc)))
      (set! th (tel-set th 'mirror-opp-belief-about-us (mirror-mind-state-opp-belief-about-us mmstate)))
      (set! th (tel-set th 'mirror-strategic-hypothesis (mirror-mind-state-strategic-hypothesis mmstate)))
      (set! th (tel-set th 'mirror-tactical-target (mirror-mind-state-tactical-target mmstate)))
      (set! th (tel-set th 'mirror-predicted-enemy-unit (mirror-mind-state-predicted-enemy-unit mmstate)))
      (set! th (tel-set th 'mirror-preemptive-unit (mirror-mind-state-preemptive-counter-unit mmstate)))
      (set! th (tel-set th 'mirror-strategic-accuracy (mirror-mind-state-strategic-accuracy mmstate)))
      (set! th (tel-set th 'mirror-tactical-accuracy (mirror-mind-state-tactical-accuracy mmstate)))
      (set! th (tel-set th 'mirror-overall-accuracy (mirror-mind-state-overall-accuracy mmstate)))
      (set! th (tel-set th 'mirror-trust-mode (mirror-mind-state-trust-mode mmstate)))
      (set! th (tel-set th 'mirror-unaccounted-minerals (shadow-ledger-unaccounted-minerals mmledger)))
      (set! th (tel-set th 'mirror-unaccounted-gas (shadow-ledger-unaccounted-gas mmledger)))
      (set! th (tel-set th 'mirror-predicted-enemy-bases (mirror-mind-state-predicted-enemy-bases mmstate)))
      (set! th (tel-set th 'mirror-predicted-enemy-workers (mirror-mind-state-predicted-enemy-workers mmstate)))
      (set! th (tel-set th 'mirror-macro-verdict (mirror-mind-state-mirror-macro-verdict mmstate)))
      (set! th (tel-set th 'mirror-recommended-min-bases (mirror-mind-state-recommended-min-bases mmstate)))
      (set! th (tel-set th 'mirror-disruption-priority (mirror-mind-state-disruption-priority mmstate)))
      (set! th (tel-set th 'mirror-observed-upgrades (enemy-tech-observation-observed-upgrades mmtech)))
      (set! th (tel-set th 'mirror-implied-tech-buildings (enemy-tech-observation-implied-tech-buildings mmtech)))
      (set! th (tel-set th 'mirror-enemy-upgrade-advantage (enemy-tech-observation-enemy-upgrade-advantage mmtech)))
      (set! th (tel-set th 'mirror-requires-detection? (enemy-tech-observation-requires-detection? mmtech)))
      (set! th (tel-set th 'mirror-requires-anti-air? (enemy-tech-observation-requires-anti-air? mmtech)))
      (set! th (tel-set th 'mirror-observed-spells (enemy-tech-observation-observed-spells mmtech)))
      (set! th (tel-set th 'mirror-crippled-tech-buildings (enemy-tech-observation-crippled-tech-buildings mmtech)))
      (set! th (tel-set th 'mirror-committed-branch (zero-sum-exclusion-reading-committed-primary-branch mmzs)))
      (set! th (tel-set th 'mirror-excluded-branches (zero-sum-exclusion-reading-excluded-tech-branches mmzs)))
      (set! th (tel-set th 'mirror-bluff-suspected? (zero-sum-exclusion-reading-bluff-or-feint-suspected? mmzs)))
      (set! th (tel-set th 'tactical-arenas (length (tactical-mirror-brain-active-arenas tbrain))))
      (set! th (tel-set th 'tactical-decisions (tactical-mirror-brain-last-decisions tbrain)))
      (set! th (tel-set th 'active-orders-tracked (hash-count (in-progress-order-ledger-unit-orders oledger))))
      (set! th (tel-keep th 'priority-summary (hash)))
      (set! th (tel-keep th 'priority-log-line ""))
      (set! th (tel-keep th 'bank-target #f))
      (set! th (tel-keep th 'goal-stream-allocation #f))
      (set! th (tel-keep th 'decoupled-stream-spendable (hash)))
      (set! th (tel-keep th 'goal-streams DEC-GOAL-STREAMS))
      (set! th (tel-keep th 'max-supply-plan #f))
      (set! th (tel-keep th 'dynamic-plan #f))
      (set! th (tel-keep th 'dynamic-plan-next-actions '()))
      (set! th (tel-keep th 'dynamic-plan-in-progress '()))
      (set! th (tel-keep th 'peak-supply-reached 0))
      (set! th (tel-set th 'repaired-prereqs (hash-ref last-tel-ht 'priority-repaired-prereqs '())))
      (set! th (tel-keep th 'priority-repaired-prereqs '()))
      (set! th (tel-keep th 'scout-worker-id #f))
      (set! th (tel-keep th 'last-enemy-seen-frame 0))
      (set! th (tel-keep th 'last-seen-main-frame 0))
      (set! th (tel-keep th 'last-seen-natural-frame 0))
      (set! th (tel-keep th 'last-seen-third-frame 0))
      (set! th (tel-keep th 'last-seen-army-frame 0))
      (set! th (tel-keep th 'intel-staleness-frames 0))
      (set! th (tel-keep th 'intel-freshness 1.0))
      (set! th (tel-keep th 'intel-coverage 1.0))
      (set! th (tel-keep th 'intel-confidence 1.0))
      (set! th (tel-keep th 'intel-deficit 0.0))
      (set! th (tel-keep th 'intel-priority-sector 'enemy-natural))
      (set! th (tel-keep th 'intel-target-goal 'maintain-vision))
      (set! th (tel-keep th 'intel-pressure 0.0))
      (set! th (tel-keep th 'intel-gathering-method 'scouting))
      (set! th (tel-keep th 'remembered-enemy-threat-supply 0))
      (set! th (tel-keep th 'remembered-enemy-threat-frame -9999))
      (set! th (tel-keep th 'escrow-goal-sym #f))
      (set! th (tel-keep th 'escrow-age-frames 0))
      (set! th (tel-keep th 'escrow-peak-min 0))
      (set! th (tel-keep th 'escrow-prev-min 0))
      (set! th (tel-keep th 'escrow-start-frame 0))
      (set! th (tel-keep th 'escrow-last-frame 0))
      (set! th (tel-keep th 'escrow-suppressed-goal #f))
      (set! th (tel-set th 'unwalled-opponent-posterior b-unwalled-post))
      (set! th (tel-set th 'proxy-all-in-posterior b-proxy-post))
      (set! th (tel-set th 'multi-prong-window-posterior b-multi-prong-post))
      (set! th (tel-keep th 'experiment-id #f))
      (set! th (tel-keep th 'experiment-spot-idx 0))
      (set! th (tel-keep th 'spot-label #f))
      (set! th (tel-keep th 'experiment-spot-label #f))
      (set! th (tel-keep th 'experiment-tag #f))
      (set! th (tel-keep th 'experiment-spot-x #f))
      (set! th (tel-keep th 'experiment-spot-y #f))
      (set! th (tel-keep th 'experiment #f))
      (set! th (tel-keep th 'situational-plan #f))
      (set! th (tel-keep th 'primary-situation #f))
      (set! th (tel-keep th 'escrow-suppressed-until-frame 0))
      (set! th (tel-set th 'vanguard-count vanguard-cnt))
      (set! th (tel-set th 'reserve-count reserve-cnt))
      (set! th (tel-set th 'role-leases (rt-role-leases rt)))
      (set! th (tel-set th 'wall-reserved-aabbs step-wall-aabbs))
      (set! th (tel-set th 'personality (let ([p (mastermind-state-personality mstate)])
                                          (cond
                                            [(bot-personality? p) (bot-personality-name p)]
                                            [(symbol? p) p]
                                            [else 'UNKNOWN]))))
      (set! th (tel-set th 'pda-bucket (diagnose-bot-anomaly pda)))
      th))

  (define rt-pos-cache (rt-enemy-pos-cache rt))
  (define-values (rt-valid-tags _pos-tbl-ignored)
    (populate-valid-enemy-tags-and-pos! obs rt-pos-cache))
  (define final-actions
    (sanitize-stale-target-actions
     (append accepted preserved-tactical-directives pro-apm-acts)
     obs
     #:pos-cache rt-pos-cache
     #:precomputed-valid-tags rt-valid-tags))
  (define final-mirror-actions
    (sanitize-stale-target-actions
     mirror-acts
     obs
     #:pos-cache rt-pos-cache
     #:precomputed-valid-tags rt-valid-tags))

  ;; Structured step state log (`lib/sc2-logging.rkt`) — defer heavy Bayesian posteriors & snapshot allocation
  ;; until `should-emit-step-log?` fires (every 22 frames or on posture / build-goal transitions).
  (define step-frame (safe-nonneg-int (hash-ref obs 'frame 0) 0))
  (define prev-state-log (hash-ref last-tel-ht 'state-log #f))
  (define prev-mind-posture
    (and (hash? prev-state-log)
         (let ([m (hash-ref prev-state-log 'mind #f)])
           (and (hash? m) (hash-ref m 'posture #f)))))
  (define prev-goal-sym
    (and (hash? prev-state-log)
         (let ([g (hash-ref prev-state-log 'goals #f)])
           (and (hash? g) (hash-ref g 'active-bo-goal-sym #f)))))
  (define cur-mind-posture (live-bot-runtime-posture rt))
  (define cur-goal-sym
    (let* ([raw-ag (hash-ref telemetry0 'bo-active-goal #f)]
           [def-sym (if (pro-bo-goal? raw-ag) (pro-bo-goal-target-sym raw-ag) 'none)]
           [ps (hash-ref telemetry0 'priority-summary #f)]
           [sf (if (hash? ps) (hash-ref ps 'saving-for 'none) 'none)])
      (cond
        [(symbol? sf) sf]
        [(and (string? sf) (> (string-length sf) 0)) (string->symbol sf)]
        [else def-sym])))
  (define state-changed?
    (or (not (hash? prev-state-log))
        (not (eq? prev-mind-posture cur-mind-posture))
        (not (eq? prev-goal-sym cur-goal-sym))))
  (define emit-state-log?
    (should-emit-step-log? step-frame 22 state-changed?))
  (define-values (state-log-hash state-log-line)
    (cond
      [(or emit-state-log? (not (hash? prev-state-log)))
       (define step-our-race (live-bot-runtime-actual-race rt))
       (define step-enemy-race
         (let ([tel-er (hash-ref telemetry0 'effective-enemy-race #f)]
               [box-er (unbox (rt-enemy-race-box rt))])
           (cond
             [(memq tel-er '(Zerg Terran Protoss)) tel-er]
             [(memq box-er '(Zerg Terran Protoss)) box-er]
             [else (hash-ref obs 'enemy-race (hash-ref obs 'opponent-requested-race 'Random))])))
       (define step-matchup (resolve-matchup-symbol step-our-race step-enemy-race))
       (define mmact (mirror-mind-state-last-action-reading mmstate))
       (define enemy-units-obs (hash-ref obs 'enemy-units '()))
       (define enemy-bldgs-obs (hash-ref obs 'enemy-buildings '()))
       (define ally-units-obs (hash-ref obs 'ally-units '()))
       (define combat-enemy-cnt
         (for/sum ([e (in-list enemy-units-obs)])
           (if (and (hash? e) (combat-unit-record? e)) 1 0)))
       (define bluff-post
         (compute-bayesian-bluff-posterior
          enemy-units-obs
          enemy-bldgs-obs
          mmtech
          mmledger
          #:prior 0.08
          #:opponent-scouted-us? (or (mirror-mind-state-ever-scouted-by-enemy? mmstate)
                                     (and mmact (action-lens-reading-opponent-scouted-us? mmact) #t))))
       (define bayes-priors
         (evaluate-strategic-posteriors-from-signals
          #:bluff-prior 0.08
          #:bluff-posterior bluff-post
          #:frame step-frame
          #:combat-count combat-enemy-cnt
          #:unaccounted-minerals (if (shadow-ledger? mmledger) (safe-finite-real (shadow-ledger-unaccounted-minerals mmledger) 0.0) 0.0)
          #:unaccounted-gas (if (shadow-ledger? mmledger) (safe-finite-real (shadow-ledger-unaccounted-gas mmledger) 0.0) 0.0)
          #:dark-matter-hypothesis (if (shadow-ledger? mmledger) (shadow-ledger-dark-matter-hypothesis mmledger) 'accounted-visible-macro)
          #:predicted-enemy-bases (if (shadow-ledger? mmledger) (safe-nonneg-int (shadow-ledger-predicted-enemy-bases mmledger) 1) 1)
          #:feint-or-poke-detected? (and mmact (action-lens-reading-feint-or-poke-detected? mmact) #t)
          #:proxy-or-rush-detected? (and mmact (action-lens-reading-proxy-or-rush-detected? mmact) #t)
          #:branch-posteriors (hash)))
       (define self-army-val
         (max 0.0 (safe-finite-real (hash-ref obs 'army-supply
                                              (lambda ()
                                                (for/sum ([u (in-list ally-units-obs)])
                                                  (if (and (hash? u) (combat-unit-record? u)) 1 0))))
                                    0.0)))
       (define enemy-army-val
         (max 0.0 (safe-finite-real (hash-ref obs 'enemy-threat-supply combat-enemy-cnt) 0.0)))
       (define win-prob-est
         (max 0.0 (min 1.0 (/ 1.0 (+ 1.0 (exp (* -0.025 (safe-finite-real fap-score 0.0))))))))
       (define snowball-adv
         (/ (lanchester-snowball-advantage self-army-val enemy-army-val) 20.0))
       (define prio-sum (hash-ref telemetry0 'priority-summary (hash)))
       (define escrow-blocked-ids
         (for/list ([d (in-list (hash-ref prio-sum 'decisions '()))]
                    #:when (and (hash? d)
                                (memq (hash-ref d 'outcome 'none) '(blocked-by-escrow escrowed-saving))
                                (hash-ref d 'id #f)))
           (hash-ref d 'id #f)))
       (define burrowed-cnt
         (for/sum ([u (in-list ally-units-obs)])
           (if (and (hash? u)
                    (or (eq? (hash-ref u 'burrowed #f) #t)
                        (eq? (hash-ref u 'is-burrowed #f) #t)
                        (hash-ref ZERG-SHALLOW-BURROW-SET (unit-type-sym u) #f)))
               1
               0)))
       (define shimmer-cnt
         (for/sum ([a (in-list tactic-acts)])
           (if (and (pair? a)
                    (memq (car a) '(blind-skillshot-shimmer emergency-detector-response)))
               1
               0)))
       (define addon-cnt
         (for/sum ([a (in-list econ-acts)])
           (if (and (pair? a) (eq? (car a) 'terran-addon-swap)) 1 0)))
       (define state-rec
         (extract-bot-step-log-record
          (hash 'frame step-frame
                'race step-our-race
                'enemy-race step-enemy-race
                'matchup step-matchup
                'posture cur-mind-posture
                'personality (hash-ref telemetry0 'personality 'default)
                'experiment-id (hash-ref telemetry0 'experiment-id #f)
                'experiment-tag (hash-ref telemetry0 'experiment-tag #f)
                'enemy-archetype (mastermind-state-enemy-archetype mstate)
                'win-prob win-prob-est
                'confidence (mirror-mind-state-overall-accuracy mmstate)
                'bluff-posterior (bayesian-strategic-priors-bluff-posterior bayes-priors)
                'rush-posterior (bayesian-strategic-priors-rush-posterior bayes-priors)
                'hidden-expand-posterior (bayesian-strategic-priors-hidden-expand-posterior bayes-priors)
                'tech-switch-posterior (bayesian-strategic-priors-tech-switch-posterior bayes-priors)
                'pad-camped-posterior (hash-ref telemetry0 'pad-camped-posterior 0.0))
          (hash 'active-bo-goal (hash-ref telemetry0 'bo-active-goal #f)
                'saving-for (hash-ref prio-sum 'saving-for 'none)
                'reserved-min-floor (hash-ref prio-sum 'reserved-min-floor 0)
                'reserved-gas-floor (hash-ref prio-sum 'reserved-gas-floor 0)
                'target-workers (hash-ref telemetry0 'target-workers 0)
                'target-army-supply (hash-ref telemetry0 'target-army-supply 0)
                'scheduled-ids (hash-ref prio-sum 'scheduled-ids '())
                'escrow-blocked-ids escrow-blocked-ids)
          (hash 'combat-posture (hash-ref telemetry0 'fap-posture 'hold)
                'snowball-adv snowball-adv
                'retreat-sector (best-retreat-sector (live-bot-runtime-perception rt))
                'burrowed-count burrowed-cnt
                'shimmer-alerts shimmer-cnt
                'swapped-addons addon-cnt
                'issued-orders (length final-actions))))
       (values (bot-step-log-record->hash state-rec)
               (if emit-state-log? (format-bot-step-log-line state-rec) ""))]
      [else (values prev-state-log "")]))
  (define step-elapsed-us
    (max 0.0 (* 1000.0 (- (current-inexact-monotonic-milliseconds) t0-step-ms))))
  (define telemetry
    (hash-set (hash-set (hash-set telemetry0 'step-elapsed-us step-elapsed-us)
                        'state-log state-log-hash)
              'state-log-line state-log-line))
  (set-live-bot-runtime-last-telemetry! rt telemetry)
  (hash 'actions final-actions
        'mirror-actions final-mirror-actions
        'telemetry telemetry
        'posture (live-bot-runtime-posture rt)
        'actual-race (live-bot-runtime-actual-race rt)
        'role-leases (rt-role-leases rt)
        'wall-reserved-aabbs step-wall-aabbs))

;; =============================================================================
;; S-Expression Wire Parser for `sim/racket_sc2_ipc_bot.rkt`
;; =============================================================================

(define (parse-unit-tuple tup)
  (match tup
    [(list id type x y hp energy)
     (sanitize-unit-record
      (hash 'id id 'type type 'x x 'y y 'hp hp 'energy energy)
      32.5 32.5)]
    [(list id type x y hp)
     (sanitize-unit-record
      (hash 'id id 'type type 'x x 'y y 'hp hp)
      32.5 32.5)]
    [(? hash? h) (sanitize-unit-record h 32.5 32.5)]
    [_ (hash 'id 101 'type 'zergling 'x 32.5 'y 32.5 'hp 35)]))

(define (parse-bldg-tuple tup)
  (match tup
    [(list id type x y hp-pct build-prog halted-flag)
     (define spct (max 0.0 (min 1.0 (safe-finite-real hp-pct 1.0))))
     (sanitize-bldg-record
      (hash 'id id
            'type type
            'x x
            'y y
            'hp (max 1 (safe-exact-int (* 500.0 spct) 500))
            'hp-pct spct
            'build-progress (max 0.0 (min 1.0 (safe-finite-real build-prog 1.0)))
            'halted (eq? halted-flag #t))
      32.5 32.5)]
    [(list id type x y hp)
     (sanitize-bldg-record
      (hash 'id id 'type type 'x x 'y y 'hp hp)
      32.5 32.5)]
    [(? hash? h) (sanitize-bldg-record h 32.5 32.5)]
    [_ (hash 'id 201 'type 'hatchery 'x 32.5 'y 32.5 'hp 1500)]))

(define (parse-effect-tuple tup)
  (match tup
    [(list type x y)
     (sanitize-effect-record (hash 'type type 'x x 'y y))]
    [(? hash? h) (sanitize-effect-record h)]
    [_ (hash 'type 'none 'x 0.0 'y 0.0)]))

(define (parse-order-tuple tup)
  (match tup
    [(list uid ab-id tx ty)
     (hash 'unit-id uid 'ability-id ab-id 'target-x tx 'target-y ty)]
    [(list uid ab-id)
     (hash 'unit-id uid 'ability-id ab-id)]
    [(? hash? h) h]
    [_ (hash)]))

(define (parse-frame-state-sexp sexp)
  (match sexp
    [(cons 'frame-state kvs)
     (define h (make-hash))
     (let loop ([rem (if (list? kvs) kvs '())])
       (match rem
         [(list* k v rest)
          (define key-str (if (keyword? k) (keyword->string k) (format "~a" k)))
          (case (string->symbol key-str)
            [(frame)          (hash-set! h 'frame (safe-nonneg-int v 0))]
            [(race)           (hash-set! h 'race v)]
            [(minerals)       (hash-set! h 'minerals (safe-nonneg-int v 0))]
            [(gas)            (hash-set! h 'gas (safe-nonneg-int v 0))]
            [(supply-used)    (hash-set! h 'supply-used (safe-nonneg-int v 12))]
            [(supply-cap)     (hash-set! h 'supply-cap (min 200 (safe-nonneg-int v 15)))]
            [(supply-left)    (hash-set! h 'supply-left (safe-nonneg-int v 0))]
            [(pending-supply) (hash-set! h 'pending-supply (safe-nonneg-int v 0))]
            [(start-pos)
             (when (and (list? v) (>= (length v) 2))
               (hash-set! h 'base-x (safe-coord (first v) 32.5))
               (hash-set! h 'base-y (safe-coord (second v) 32.5)))]
            [(natural-pos)
             (when (and (list? v) (>= (length v) 2))
               (hash-set! h 'natural-x (safe-coord (first v) 45.0))
               (hash-set! h 'natural-y (safe-coord (second v) 45.0)))]
            [(third-pos)
             (when (and (list? v) (>= (length v) 2))
               (hash-set! h 'third-x (safe-coord (first v) 60.5))
               (hash-set! h 'third-y (safe-coord (second v) 40.5)))]
            [(enemy-base)
             (when (and (list? v) (>= (length v) 2))
               (hash-set! h 'enemy-x (safe-coord (first v) 160.5))
               (hash-set! h 'enemy-y (safe-coord (second v) 160.5)))]
            [(enemy-expand-pos)
             (when (and (list? v) (>= (length v) 2))
               (hash-set! h 'enemy-expand-x (safe-coord (first v) 148.0))
               (hash-set! h 'enemy-expand-y (safe-coord (second v) 148.0)))]
            [(researched-upgrades)
             (hash-set! h 'researched-upgrades (if (list? v) (filter symbol? v) '()))]
            [(pending-upgrades)
             (hash-set! h 'pending-upgrades (if (list? v) (filter symbol? v) '()))]
            [(depleting-bases)
             (hash-set! h 'depleting-bases (safe-nonneg-int v 0))]
            [(mineral-harvesters)
             (hash-set! h 'mineral-harvesters (safe-nonneg-int v 0))]
            [(ideal-mineral-harvesters)
             (hash-set! h 'ideal-mineral-harvesters (safe-nonneg-int v 0))]
            [(gas-harvesters)
             (hash-set! h 'gas-harvesters (safe-nonneg-int v 0))]
            [(ideal-gas-harvesters)
             (hash-set! h 'ideal-gas-harvesters (safe-nonneg-int v 0))]
            [(busy-facilities)
             (hash-set! h 'busy-facilities (safe-nonneg-int v 0))]
            [(busy-townhalls)
             (hash-set! h 'busy-townhalls (safe-nonneg-int v 0))]
            [(army-supply)
             (hash-set! h 'army-supply (safe-nonneg-int v 0))]
            [(in-progress-orders)
             (hash-set! h 'in-progress-orders (if (list? v) (map parse-order-tuple v) '()))]
            [(enemy-race)             (hash-set! h 'enemy-race v)]
            [(opponent-requested-race)(hash-set! h 'opponent-requested-race v)]
            [(map-grids)              (when (hash? v) (hash-set! h 'map-grids v))]
            [(expansion-candidates)   (when (list? v) (hash-set! h 'expansion-candidates v))]
            [(my-units)       (hash-set! h 'ally-units (if (list? v) (map parse-unit-tuple v) '()))]
            [(my-buildings)   (hash-set! h 'ally-buildings (if (list? v) (map parse-bldg-tuple v) '()))]
            [(enemy-units)    (hash-set! h 'enemy-units (if (list? v) (map parse-unit-tuple v) '()))]
            [(enemy-buildings)(hash-set! h 'enemy-buildings (if (list? v) (map parse-bldg-tuple v) '()))]
            [(effects)        (hash-set! h 'effects (if (list? v) (map parse-effect-tuple v) '()))])
          (loop rest)]
         [_ (void)]))
     (sanitize-obs-hash h)]
    [_ (sanitize-obs-hash (hash))]))

(define (runtime-step-sexp! rt sexp)
  (define res (step-live-bot-runtime! rt sexp))
  (append (hash-ref res 'mirror-actions '())
          (hash-ref res 'actions '())))
