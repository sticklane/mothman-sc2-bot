#lang racket/base

(require racket/match
         racket/list
         racket/math
         racket/string
         racket/runtime-path
         "../compiler/syntax.rkt"
         (except-in "sc2-common.rkt"
                    pro-unit-timing
                    struct:pro-unit-timing
                    pro-unit-timing?
                    pro-unit-timing-unit-sym
                    pro-unit-timing-target-count
                    pro-unit-timing-min-supply
                    pro-unit-timing-target-sec
                    pro-unit-timing-prereq-ready-sym
                    pro-upgrade-timing
                    struct:pro-upgrade-timing
                    pro-upgrade-timing?
                    pro-upgrade-timing-upgrade-sym
                    pro-upgrade-timing-start-sec
                    pro-upgrade-timing-complete-sec
                    pro-upgrade-timing-min-supply
                    pro-upgrade-timing-prereq-ready-sym)
         (only-in "sc2-types.rkt"
                  pro-bo-eval-result
                  struct:pro-bo-eval-result
                  pro-bo-eval-result?
                  pro-bo-eval-result-matchup
                  pro-bo-eval-result-active-goal
                  pro-bo-eval-result-ready-actions
                  pro-bo-eval-result-reserved-minerals
                  pro-bo-eval-result-reserved-gas
                  pro-bo-eval-result-target-workers
                  pro-bo-eval-result-target-army-supply
                  normalize-known-race
                  resolve-matchup-symbol)
         "sc2-game-constants.rkt"
         "build-orders.rkt")

(provide
 ;; Build-Order Combinators & Locutus Worker Chaining
 (struct-out bo-node)
 bo-step
 seq>>
 par||
 auto-supply
 saturate-bases
 chain-worker>>
 compile-build-order
 build-order-grade

 ;; McRave UCB1 Multi-Armed Bandit Strategy Selector
 (struct-out ucb1-arm)
 (struct-out ucb1-bandit)
 make-ucb1-bandit
 ucb1-score
 ucb1-select-arm
 ucb1-update-arm!

 ;; BOSS Branch-and-Bound Goal Synthesis
 (struct-out boss-plan)
 boss-synthesize-build-plan

 ;; Stardust HTN Plays
 (struct-out htn-play)
 make-htn-play
 htn-decompose-play
 htn-preempt-play

 ;; Symbiotic Resource Ledger with Borrowing + Crisis Preemption
 (struct-out ledger-lease)
 (struct-out symbiotic-ledger)
 make-symbiotic-ledger
 ledger-available-minerals
 ledger-available-gas
 ledger-available-supply
 ledger-reserve!
 ledger-borrow!
 ledger-preempt-for-crisis!
 ledger-repay!
 ledger-commit!
 ledger-verify-invariant?

 ;; Coupled Depletion-Driven Macro & Map-Wide Expansion Governor
 (struct-out coupled-macro-plan)
 evaluate-coupled-macro-governor

 ;; Planned & Adaptive Build-Order & Tech/Upgrade Goal Planner
 (struct-out build-goal-stage)
 (struct-out adaptive-tech-plan)
 evaluate-adaptive-build-and-tech-plan

 ;; Guns-vs-Butter PPF & Dynamic Gas-to-Mineral Worker Allocation Controller
 (struct-out gas-worker-allocation)
 compute-optimal-gas-workers
 (struct-out guns-vs-butter-ppf)
 evaluate-guns-vs-butter-ppf

 ;; Marginal-Utility Prioritization & Resource Scheduler (PV1-PV9)
 (struct-out priority-candidate)
 (struct-out priority-decision-entry)
 (struct-out priority-schedule-result)
 (struct-out opponent-intel-quality)
 PV-INTEL-GATHERING-UNIT-SYMS
 evaluate-opponent-intel-quality
 select-intel-gathering-method
 ZERG-SIEGE-SPLASH-ENEMY-SYMS
 TERRAN-GHOST-COUNTER-ENEMY-SYMS
 TERRAN-LIBERATOR-COUNTER-ENEMY-SYMS
 PROTOSS-CAPITAL-AIR-ENEMY-SYMS
 normalize-enemy-race-sym
 enemy-counts-have-any?
 gas-building-cap
 gas-building-cap-ok?
 zerg-stepped-drone-army-floor
 zerg-worker-army-floor-ok?
 zergling-target-cap
 terran-desired-barracks-techlabs
 terran-desired-factories
 terran-enemy-needs-ghost?
 terran-enemy-needs-liberator?
 terran-desired-ghost-cap
 terran-desired-liberator-cap
 protoss-enemy-capital-air?
 protoss-4th-nexus-due?
 CRISIS-DEFENDER-SYMS
 CRISIS-DEFERRED-UPGRADE-SYMS
 CRISIS-DEFERRED-TECH-SYMS
 TERRAN-GROUND-AA-SCREEN-ENEMY-SYMS
 crisis-defense-tech-defer-active?
 crisis-deferred-sym?
 terran-enemy-ground-aa-count
 terran-enemy-capital-air-with-ground-aa?
 terran-desired-thor-cap
 terran-air-fleet-count
 terran-ship-weapons-due?
 enrich-priority-metrics
 compute-state-pressure-metrics
 compute-candidate-marginal-utility
 generate-race-priority-candidates
 schedule-priority-candidates-with-ledger!
 priority-schedule-decision-trace
 priority-schedule-can-spend?
 priority-schedule-summary-hash
 format-priority-schedule-log-line
 (struct-out refractory-cooldown-tracker)
 make-refractory-cooldown-tracker
 refractory-allow-action?!

 ;; Empirical Pro Replay Build-Order Database & Goal-Queue Executor
 ;; (Canonical definitions in `lib/sc2-types.rkt` and `lib/build-orders.rkt`)
 PRO-BUILD-ORDER-DB
 (struct-out pro-bo-goal)
 make-pro-bo-goal
 (struct-out pro-unit-timing)
 (struct-out pro-upgrade-timing)
 (struct-out pro-bo-eval-result)
 find-matchup-entry
 select-pro-build-order
 pro-build-order-steps-for-matchup
 pro-unit-timings-for-matchup
 pro-upgrade-timings-for-matchup
 due-pro-unit-timings
 due-pro-upgrade-timings
 pro-supply-curve-target
 evaluate-build-order-next-step
 compute-natural-expansion-mineral-reserve

 ;; Decoupled 8-Stream Resource & Bank Manager + 200/200 Late-Game Max-Supply Manager
 DEC-GOAL-STREAMS
 (struct-out race-bank-target)
 (struct-out stream-budget-slice)
 (struct-out decoupled-bank-allocation)
 (struct-out max-supply-plan)
 compute-bank-targets
 allocate-decoupled-goal-streams
 decoupled-stream-can-spend?
 evaluate-max-supply-manager)

;; =============================================================================
;; 1. Build-Order Combinators & Locutus Worker Chaining
;; =============================================================================

(struct bo-node (kind op children grade) #:transparent)

(define (bo-step op [minerals 50] [gas 0] [supply 1] [cap 'One])
  (bo-node 'primitive op '()
           (sc-grade cap minerals gas supply 1 'fixated 'visible-only)))

(define (seq>> . nodes)
  (define valid (filter values nodes))
  (cond
    [(null? valid) (bo-node 'empty '(noop) '() grade-zero)]
    [(null? (cdr valid)) (car valid)]
    [else
     (define total-grade
       (foldl (lambda (n acc) (grade-seq acc (bo-node-grade n)))
              grade-zero
              valid))
     (bo-node 'seq '(seq) valid total-grade)]))

(define (par|| . nodes)
  (define valid (filter values nodes))
  (cond
    [(null? valid) (bo-node 'empty '(noop) '() grade-zero)]
    [(null? (cdr valid)) (car valid)]
    [else
     (define total-grade
       (foldl (lambda (n acc) (grade-par acc (bo-node-grade n)))
              grade-zero
              valid))
     (bo-node 'par '(par) valid total-grade)]))

(define (auto-supply race node)
  (define supply-bldg
    (case race
      [(Zerg zerg)       (bo-step '(train overlord) 100 0 0 'One)]
      [(Protoss protoss) (bo-step '(build pylon) 100 0 0 'One)]
      [(Terran terran)   (bo-step '(build supply-depot) 100 0 0 'One)]
      [else              (bo-step '(train overlord) 100 0 0 'One)]))
  (define g (bo-node-grade node))
  (if (> (sc-grade-supply g) 0)
      (seq>> supply-bldg node)
      node))

(define (saturate-bases race num-bases)
  (define worker-sym
    (case race
      [(Zerg zerg) 'drone]
      [(Protoss protoss) 'probe]
      [(Terran terran) 'scv]
      [else 'drone]))
  (define steps
    (for/list ([i (in-range (max 1 (* 3 num-bases)))])
      (bo-step (list 'train worker-sym) 50 0 1 'One)))
  (apply seq>> steps))

;; Locutus long-distance worker chaining: pre-move worker along waypoint chain
;; so it arrives at (x, y) on the exact frame minerals reach building cost.
(define (chain-worker>> worker-id waypoints build-op [minerals 300] [gas 0])
  (define move-steps
    (for/list ([wp (in-list waypoints)])
      (bo-step (list 'move-waypoint worker-id (car wp) (cdr wp)) 0 0 0 'Borrowed)))
  (define final-step
    (bo-step build-op minerals gas 0 'One))
  (apply seq>> (append move-steps (list final-step))))

(define (compile-build-order node)
  (match node
    [(bo-node 'empty _ _ _) '()]
    [(bo-node 'primitive op _ _) (list op)]
    [(bo-node (or 'seq 'par) _ children _)
     (append-map compile-build-order children)]
    [(? list? xs) xs]
    [_ (list node)]))

(define (build-order-grade node)
  (if (bo-node? node)
      (bo-node-grade node)
      (derive-grades-from-bot-ast node)))

;; =============================================================================
;; 2. McRave UCB1 Multi-Armed Bandit Strategy Selector
;; =============================================================================

(struct ucb1-arm (name wins plays) #:mutable #:transparent)
(struct ucb1-bandit (arms total-plays c) #:mutable #:transparent)

(define (make-ucb1-bandit arm-names [c 1.41421356])
  (ucb1-bandit
   (for/list ([name (in-list arm-names)])
     (ucb1-arm name 0.0 0))
   0
   c))

(define (ucb1-score arm total-plays [c 1.41421356])
  (define n (ucb1-arm-plays arm))
  (if (zero? n)
      +inf.0
      (+ (/ (ucb1-arm-wins arm) n)
         (* c (sqrt (/ (log (max 1 total-plays)) n))))))

(define (ucb1-select-arm bandit)
  (define tot (max 1 (ucb1-bandit-total-plays bandit)))
  (define c (ucb1-bandit-c bandit))
  (define best
    (argmax (lambda (arm) (ucb1-score arm tot c))
            (ucb1-bandit-arms bandit)))
  (ucb1-arm-name best))

(define (ucb1-update-arm! bandit arm-name reward)
  (for ([arm (in-list (ucb1-bandit-arms bandit))]
        #:when (eq? (ucb1-arm-name arm) arm-name))
    (set-ucb1-arm-wins! arm (+ (ucb1-arm-wins arm) reward))
    (set-ucb1-arm-plays! arm (add1 (ucb1-arm-plays arm))))
  (set-ucb1-bandit-total-plays! bandit (add1 (ucb1-bandit-total-plays bandit)))
  bandit)

;; =============================================================================
;; 3. BOSS Branch-and-Bound Goal Synthesis
;; (Shared `finite-real?`, `safe-real`, `safe-exact-int`, `safe-nonneg-int`,
;;  `safe-list` imported from `sc2-common.rkt`.)
;; =============================================================================

(struct boss-plan (race goal-units steps makespan-frames total-minerals total-gas)
  #:transparent)

(define (unit-prereq-building u)
  (case u
    [(zergling queen) 'spawning-pool]
    [(roach ravager) 'roach-warren]
    [(hydralisk lurker) 'hydralisk-den]
    [(mutalisk corruptor) 'spire]
    [(zealot adept) 'gateway]
    [(stalker sentry) 'cybernetics-core]
    [(immortal colossus disruptor observer warp-prism) 'robotics-facility]
    [(marine marauder reaper) 'barracks]
    [(siege-tank hellion widow-mine cyclone thor) 'factory]
    [(medivac viking liberator banshee raven) 'starport]
    [(ghost) 'ghost-academy]
    [else #f]))

(define (boss-synthesize-build-plan race goal-alist #:existing-buildings [existing '()])
  ;; goal-alist: list of `(cons unit-type count)`
  (define safe-goals (filter pair? (safe-list goal-alist)))
  (define safe-existing (safe-list existing))
  (define needed-prereqs
    (remove-duplicates
     (filter (lambda (b) (and b (not (memq b safe-existing))))
             (map (lambda (pair) (unit-prereq-building (car pair))) safe-goals))))
  (define prereq-steps
    (for/list ([b (in-list needed-prereqs)])
      (list 'build b)))
  (define unit-steps
    (append-map
     (lambda (pair)
       (make-list (safe-nonneg-int (cdr pair) 0) (list 'train (car pair))))
     safe-goals))
  (define all-steps (append prereq-steps unit-steps))
  (define g (derive-grades-from-bot-ast all-steps))
  ;; Makespan lower-bounded by prerequisite build frames + parallel production cycles
  (define makespan
    (+ (* 360 (length prereq-steps))
       (* 120 (length unit-steps))))
  (boss-plan race
             safe-goals
             all-steps
             makespan
             (sc-grade-minerals g)
             (sc-grade-gas g)))

;; =============================================================================
;; 4. Stardust HTN Plays (Hierarchical Task Network with Crisis Preemption)
;; =============================================================================

(struct htn-play (name priority status subtasks reserved-minerals reserved-gas)
  #:mutable
  #:transparent)

(define (make-htn-play name priority subtasks [minerals 0] [gas 0])
  (htn-play name priority 'active subtasks minerals gas))

(define (htn-decompose-play play world-state)
  (cond
    [(not (eq? (htn-play-status play) 'active)) '()]
    [else (htn-play-subtasks play)]))

(define (htn-preempt-play low-play crisis-play)
  (when (> (htn-play-priority crisis-play) (htn-play-priority low-play))
    (set-htn-play-status! low-play 'suspended)
    (set-htn-play-status! crisis-play 'active))
  (list crisis-play low-play))

;; =============================================================================
;; 5. Symbiotic Resource Ledger (Borrowing, Crisis Preemption & Exact Invariant)
;;    Invariant: Total == Available + Reserved + Borrowed - Repaid (or
;;               Total == Available + Reserved + ActiveBorrowed)
;; =============================================================================

(struct ledger-lease (id owner minerals gas supply priority status)
  #:mutable
  #:transparent)

(struct symbiotic-ledger
  (total-minerals
   total-gas
   total-supply
   reserved-minerals
   reserved-gas
   reserved-supply
   borrowed-minerals
   borrowed-gas
   borrowed-supply
   leases)
  #:mutable
  #:transparent)

(define safe-ledger-int safe-nonneg-int)

(define (make-symbiotic-ledger [minerals 500] [gas 200] [supply 10])
  (symbiotic-ledger (safe-ledger-int minerals 500)
                    (safe-ledger-int gas 200)
                    (safe-ledger-int supply 10)
                    0 0 0 0 0 0 '()))

(define (ledger-available-minerals l)
  (- (symbiotic-ledger-total-minerals l)
     (symbiotic-ledger-reserved-minerals l)
     (symbiotic-ledger-borrowed-minerals l)))

(define (ledger-available-gas l)
  (- (symbiotic-ledger-total-gas l)
     (symbiotic-ledger-reserved-gas l)
     (symbiotic-ledger-borrowed-gas l)))

(define (ledger-available-supply l)
  (- (symbiotic-ledger-total-supply l)
     (symbiotic-ledger-reserved-supply l)
     (symbiotic-ledger-borrowed-supply l)))

(define (ledger-verify-invariant? l)
  (and (= (symbiotic-ledger-total-minerals l)
          (+ (ledger-available-minerals l)
             (symbiotic-ledger-reserved-minerals l)
             (symbiotic-ledger-borrowed-minerals l)))
       (= (symbiotic-ledger-total-gas l)
          (+ (ledger-available-gas l)
             (symbiotic-ledger-reserved-gas l)
             (symbiotic-ledger-borrowed-gas l)))
       (= (symbiotic-ledger-total-supply l)
          (+ (ledger-available-supply l)
             (symbiotic-ledger-reserved-supply l)
             (symbiotic-ledger-borrowed-supply l)))
       (>= (ledger-available-minerals l) 0)
       (>= (ledger-available-gas l) 0)
       (>= (ledger-available-supply l) 0)))

(define (ledger-reserve! l lease-id owner raw-m raw-g raw-s [raw-priority 1])
  (define m (safe-ledger-int raw-m 0))
  (define g (safe-ledger-int raw-g 0))
  (define s (safe-ledger-int raw-s 0))
  (define priority (safe-ledger-int raw-priority 1))
  (when (or (< (ledger-available-minerals l) m)
            (< (ledger-available-gas l) g)
            (< (ledger-available-supply l) s))
    (error 'ledger-reserve! "Insufficient unreserved resources in symbiotic ledger"))
  (define lease (ledger-lease lease-id owner m g s priority 'reserved))
  (set-symbiotic-ledger-reserved-minerals! l (+ (symbiotic-ledger-reserved-minerals l) m))
  (set-symbiotic-ledger-reserved-gas! l (+ (symbiotic-ledger-reserved-gas l) g))
  (set-symbiotic-ledger-reserved-supply! l (+ (symbiotic-ledger-reserved-supply l) s))
  (set-symbiotic-ledger-leases! l (cons lease (symbiotic-ledger-leases l)))
  lease)

;; Symbiotic borrowing: borrow from an idle low-priority reservation without violating total accounting
(define (ledger-borrow! l borrower-id raw-m raw-g raw-s [raw-priority 5])
  (define m (safe-ledger-int raw-m 0))
  (define g (safe-ledger-int raw-g 0))
  (define s (safe-ledger-int raw-s 0))
  (define priority (safe-ledger-int raw-priority 5))
  (cond
    [(and (>= (ledger-available-minerals l) m)
          (>= (ledger-available-gas l) g)
          (>= (ledger-available-supply l) s))
     (set-symbiotic-ledger-borrowed-minerals! l (+ (symbiotic-ledger-borrowed-minerals l) m))
     (set-symbiotic-ledger-borrowed-gas! l (+ (symbiotic-ledger-borrowed-gas l) g))
     (set-symbiotic-ledger-borrowed-supply! l (+ (symbiotic-ledger-borrowed-supply l) s))
     (define lease (ledger-lease borrower-id borrower-id m g s priority 'borrowed))
     (set-symbiotic-ledger-leases! l (cons lease (symbiotic-ledger-leases l)))
     lease]
    [else
     ;; Preempt/borrow from lower-priority reserved leases
     (ledger-preempt-for-crisis! l borrower-id m g s priority)]))

(define (ledger-preempt-for-crisis! l crisis-id raw-m raw-g raw-s [raw-priority 10])
  (define m (safe-ledger-int raw-m 0))
  (define g (safe-ledger-int raw-g 0))
  (define s (safe-ledger-int raw-s 0))
  (define priority (safe-ledger-int raw-priority 10))
  ;; Release lower-priority reserved leases until (m, g, s) can be allocated to crisis-id
  (for ([lease (in-list (symbiotic-ledger-leases l))]
        #:when (and (eq? (ledger-lease-status lease) 'reserved)
                    (< (ledger-lease-priority lease) priority)
                    (or (< (ledger-available-minerals l) m)
                        (< (ledger-available-gas l) g)
                        (< (ledger-available-supply l) s))))
    (set-ledger-lease-status! lease 'preempted)
    (set-symbiotic-ledger-reserved-minerals!
     l (- (symbiotic-ledger-reserved-minerals l) (ledger-lease-minerals lease)))
    (set-symbiotic-ledger-reserved-gas!
     l (- (symbiotic-ledger-reserved-gas l) (ledger-lease-gas lease)))
    (set-symbiotic-ledger-reserved-supply!
     l (- (symbiotic-ledger-reserved-supply l) (ledger-lease-supply lease))))
  (when (or (< (ledger-available-minerals l) m)
            (< (ledger-available-gas l) g)
            (< (ledger-available-supply l) s))
    (error 'ledger-preempt-for-crisis! "Even after preemption, insufficient resources for crisis"))
  (set-symbiotic-ledger-borrowed-minerals! l (+ (symbiotic-ledger-borrowed-minerals l) m))
  (set-symbiotic-ledger-borrowed-gas! l (+ (symbiotic-ledger-borrowed-gas l) g))
  (set-symbiotic-ledger-borrowed-supply! l (+ (symbiotic-ledger-borrowed-supply l) s))
  (define crisis-lease (ledger-lease crisis-id crisis-id m g s priority 'borrowed))
  (set-symbiotic-ledger-leases! l (cons crisis-lease (symbiotic-ledger-leases l)))
  crisis-lease)

(define (ledger-repay! l lease-id)
  (for ([lease (in-list (symbiotic-ledger-leases l))]
        #:when (and (eq? (ledger-lease-id lease) lease-id)
                    (eq? (ledger-lease-status lease) 'borrowed)))
    (set-ledger-lease-status! lease 'repaid)
    (set-symbiotic-ledger-borrowed-minerals!
     l (- (symbiotic-ledger-borrowed-minerals l) (ledger-lease-minerals lease)))
    (set-symbiotic-ledger-borrowed-gas!
     l (- (symbiotic-ledger-borrowed-gas l) (ledger-lease-gas lease)))
    (set-symbiotic-ledger-borrowed-supply!
     l (- (symbiotic-ledger-borrowed-supply l) (ledger-lease-supply lease))))
  l)

(define (ledger-commit! l lease-id)
  (for ([lease (in-list (symbiotic-ledger-leases l))]
        #:when (and (eq? (ledger-lease-id lease) lease-id)
                    (memq (ledger-lease-status lease) '(reserved borrowed))))
    (define m (ledger-lease-minerals lease))
    (define g (ledger-lease-gas lease))
    (define s (ledger-lease-supply lease))
    (if (eq? (ledger-lease-status lease) 'reserved)
        (begin
          (set-symbiotic-ledger-reserved-minerals! l (- (symbiotic-ledger-reserved-minerals l) m))
          (set-symbiotic-ledger-reserved-gas! l (- (symbiotic-ledger-reserved-gas l) g))
          (set-symbiotic-ledger-reserved-supply! l (- (symbiotic-ledger-reserved-supply l) s)))
        (begin
          (set-symbiotic-ledger-borrowed-minerals! l (- (symbiotic-ledger-borrowed-minerals l) m))
          (set-symbiotic-ledger-borrowed-gas! l (- (symbiotic-ledger-borrowed-gas l) g))
          (set-symbiotic-ledger-borrowed-supply! l (- (symbiotic-ledger-borrowed-supply l) s))))
    (set-symbiotic-ledger-total-minerals! l (- (symbiotic-ledger-total-minerals l) m))
    (set-symbiotic-ledger-total-gas! l (- (symbiotic-ledger-total-gas l) g))
    (set-symbiotic-ledger-total-supply! l (- (symbiotic-ledger-total-supply l) s))
    (set-ledger-lease-status! lease 'committed))
  l)

;; =============================================================================
;; 6. Coupled Depletion-Driven Macro & Map-Wide Expansion Governor
;;    (`coupled-macro-plan`, `evaluate-coupled-macro-governor`)
;; =============================================================================

(struct coupled-macro-plan
  (active-bases
   depleting-bases
   healthy-bases
   desired-bases
   target-workers
   should-expand?
   expansion-reason
   escrow-minerals
   unreserved-minerals
   unreserved-gas
   idle-worker-production-slots
   idle-unit-production-slots
   zero-unused-production?)
  #:transparent)

(define (evaluate-coupled-macro-governor
         #:race [race 'Zerg]
         #:frame [raw-frame 0]
         #:minerals [raw-minerals 200]
         #:gas [raw-gas 100]
         #:supply-left [raw-supply-left 4]
         #:active-bases [raw-active-bases 1]
         #:depleting-bases [raw-depleting-bases 0]
         #:workers [raw-workers 12]
         #:pending-workers [raw-pending-workers 0]
         #:mineral-harvesters [raw-mineral-harvesters #f]
         #:ideal-mineral-harvesters [raw-ideal-mineral-harvesters #f]
         #:gas-harvesters [raw-gas-harvesters #f]
         #:ideal-gas-harvesters [raw-ideal-gas-harvesters #f]
         #:production-facilities [raw-production-facilities 1]
         #:busy-facilities [raw-busy-facilities 0]
         #:busy-townhalls [raw-busy-townhalls 0]
         #:under-crisis? [under-crisis? #f]
         #:recommended-min-bases [raw-recommended-min-bases 1]
         #:max-map-bases [raw-max-map-bases 16])
  (define frame (safe-nonneg-int raw-frame 0))
  (define minerals (safe-nonneg-int raw-minerals 0))
  (define gas (safe-nonneg-int raw-gas 0))
  (define supply-left (safe-exact-int raw-supply-left 0))
  (define active-bases (safe-nonneg-int raw-active-bases 1))
  (define depleting-bases (safe-nonneg-int raw-depleting-bases 0))
  (define workers (safe-nonneg-int raw-workers 12))
  (define pending-workers (safe-nonneg-int raw-pending-workers 0))
  (define production-facilities (max 1 (safe-nonneg-int raw-production-facilities 1)))
  (define busy-facilities (safe-nonneg-int raw-busy-facilities 0))
  (define busy-townhalls (safe-nonneg-int raw-busy-townhalls 0))
  (define recommended-min-bases (max 1 (safe-nonneg-int raw-recommended-min-bases 1)))
  (define max-map-bases (max 1 (safe-nonneg-int raw-max-map-bases 16)))

  (define eff-bases (max 1 active-bases))
  (define healthy-bases (max 0 (- eff-bases depleting-bases)))
  (define total-workers (+ workers pending-workers))
  (define base-cost (if (memq race '(Zerg zerg)) 300 400))

  ;; Live mineral & gas harvester saturation check (replaces hard 36/50 worker cutoffs
  ;; whenever live harvester assignment/capacity telemetry is supplied).
  (define explicit-harvester-telemetry?
    (or (not (eq? raw-mineral-harvesters #f))
        (not (eq? raw-ideal-mineral-harvesters #f))
        (not (eq? raw-gas-harvesters #f))
        (not (eq? raw-ideal-gas-harvesters #f))))
  (define ideal-min-h
    (if (not (eq? raw-ideal-mineral-harvesters #f))
        (safe-nonneg-int raw-ideal-mineral-harvesters (* 16 (max 1 healthy-bases)))
        (* 16 (max 1 healthy-bases))))
  (define cur-min-h
    (if (not (eq? raw-mineral-harvesters #f))
        (safe-nonneg-int raw-mineral-harvesters (max 0 (- total-workers (* 3 (max 1 healthy-bases)))))
        (max 0 (- total-workers (* 3 (max 1 healthy-bases))))))
  (define ideal-gas-h
    (if (not (eq? raw-ideal-gas-harvesters #f))
        (safe-nonneg-int raw-ideal-gas-harvesters (* 3 (max 1 healthy-bases)))
        (* 3 (max 1 healthy-bases))))
  (define cur-gas-h
    (if (not (eq? raw-gas-harvesters #f))
        (safe-nonneg-int raw-gas-harvesters (* 3 (max 1 healthy-bases)))
        (* 3 (max 1 healthy-bases))))
  (define mineral-saturated?
    (and (> ideal-min-h 0)
         (>= cur-min-h (max 1 (- ideal-min-h 2)))))
  (define gas-saturated?
    (or (<= ideal-gas-h 0)
        (>= cur-gas-h (max 1 (- ideal-gas-h 1)))))
  (define harvesters-saturated?
    (if explicit-harvester-telemetry?
        (and mineral-saturated? gas-saturated?)
        (>= total-workers (* 18 (max 1 healthy-bases)))))

  ;; Unconstrained map-wide expansion target: scales up to max-map-bases (default 16)
  ;; whenever mineral+gas harvesters saturate healthy bases, bases deplete, minerals float,
  ;; or Mirror-Mind recommends out-expanding the opponent.
  (define raw-time-bases (add1 (quotient (max 0 frame) 1600)))
  (define time-bases
    (if (< total-workers (* 14 (max 1 healthy-bases)))
        (min raw-time-bases (+ eff-bases 1))
        raw-time-bases))
  (define saturation-bases
    (if harvesters-saturated?
        (+ eff-bases (max 1 depleting-bases))
        eff-bases))
  (define float-bases
    (if (>= minerals (* 2 base-cost))
        (+ eff-bases (quotient minerals (* 2 base-cost)))
        eff-bases))
  (define depletion-replacement-bases
    (+ eff-bases depleting-bases))

  (define desired-bases
    (min max-map-bases
         (max eff-bases
              recommended-min-bases
              depletion-replacement-bases
              saturation-bases
              float-bases
              time-bases)))

  (define should-expand?
    (and (not under-crisis?)
         (or (> depleting-bases 0)
             (> desired-bases eff-bases))))

  ;; Target workers coupled to healthy + desired bases (22 per active/desired base, up to 84),
  ;; capped to healthy bases (+1 if expanding) when depleted bases exist so mined-out bases don't inflate targets.
  (define raw-target-workers
    (min 84 (max 22 (* 22 (min 5 (max healthy-bases desired-bases))))))
  (define target-workers
    (if (< healthy-bases eff-bases)
        (min raw-target-workers
             (min 84 (* 22 (min 5 (max 1 (+ healthy-bases (if should-expand? 1 0)))))))
        raw-target-workers))

  (define expansion-reason
    (cond
      [under-crisis?                           'crisis-hold-expansion]
      [(> depleting-bases 0)                   'depletion-replacement-expand]
      [harvesters-saturated?                   'macro-saturation-expand]
      [(> recommended-min-bases eff-bases)     'mirror-macro-directive-expand]
      [(> float-bases eff-bases)               'mineral-float-macro-expand]
      [(> desired-bases eff-bases)             'map-wide-time-expand]
      [else                                    'bases-satisfied]))

  ;; Expansion escrow: reserve TownHall cost when expansion is scheduled
  (define escrow-minerals
    (if should-expand? base-cost 0))
  (define unreserved-minerals
    (max 0 (- minerals escrow-minerals)))
  (define unreserved-gas
    (max 0 gas))

  ;; Zero-Unused-Production Invariant: compute idle worker & unit production slots
  (define idle-worker-slots
    (if (and (< total-workers target-workers) (> supply-left 0))
        (max 0 (- eff-bases busy-townhalls))
        0))
  (define idle-unit-slots
    (if (> supply-left 0)
        (max 0 (- production-facilities busy-facilities))
        0))
  (define zero-unused?
    (and (zero? idle-worker-slots)
         (zero? idle-unit-slots)))

  (coupled-macro-plan eff-bases
                      depleting-bases
                      healthy-bases
                      desired-bases
                      target-workers
                      should-expand?
                      expansion-reason
                      escrow-minerals
                      unreserved-minerals
                      unreserved-gas
                      idle-worker-slots
                      idle-unit-slots
                      zero-unused?))

;; =============================================================================
;; 7. Planned & Adaptive Build-Order & Tech/Upgrade Goal Planner
;;    (`build-goal-stage`, `adaptive-tech-plan`, `evaluate-adaptive-build-and-tech-plan`)
;; =============================================================================

(struct build-goal-stage
  (stage-name              ; symbol: 'opening-eco-foundation | 'core-synergy-online | 'midgame-counter-tech | 'lategame-tier3-siege
   required-buildings      ; list of symbols
   required-upgrades       ; list of symbols
   core-synergy-invariants ; list of symbols ("what makes the build work")
   stage-satisfied?)       ; boolean
  #:transparent)

(struct adaptive-tech-plan
  (race                     ; 'Zerg | 'Terran | 'Protoss
   build-name               ; symbol
   current-stage            ; symbol
   stages                   ; list of build-goal-stage
   synergy-invariants       ; list of symbols ("what makes the build work")
   missing-synergy-reqs     ; list of symbols
   counter-tech-buildings   ; list of symbols adapted to opponent archetype / Mirror-Mind
   priority-upgrades        ; list of symbols
   priority-morphs          ; list of symbols
   desired-unit-mix         ; alist of (cons unit-sym weight)
   target-gas-mineral-ratio ; flonum: rho^*_{G/M}(t)
   next-actions)            ; list of S-expression commands
  #:transparent)

(define (classify-threat-family enemy-archetype mirror-predicted-unit)
  (cond
    [(or (memq enemy-archetype '(sky-toss muta-flock))
         (memq mirror-predicted-unit
               '(void-ray carrier tempest oracle phoenix mutalisk corruptor
                 brood-lord banshee battlecruiser liberator)))
     'air-fleet]
    [(or (memq enemy-archetype '(mech-siege stalker-colossus roach-ravager lurker-contain))
         (memq mirror-predicted-unit
               '(siege-tank siege-tank-sieged thor cyclone immortal colossus
                 disruptor roach ravager lurker ultralisk)))
     'armored-mech-siege]
    [else
     'bio-swarm-light]))

(define (evaluate-adaptive-build-and-tech-plan
         race
         #:ally-buildings [raw-ally-buildings '()]
         #:ally-units [raw-ally-units '()]
         #:researched-upgrades [raw-researched-upgrades '()]
         #:enemy-archetype [enemy-archetype 'standard-macro]
         #:mirror-predicted-unit [mirror-predicted-unit 'marine]
         #:mirror-macro-verdict [mirror-macro-verdict 'pace-Macro-And-Disrupt]
         #:requires-detection? [requires-detection? #f]
         #:requires-anti-air? [requires-anti-air? #f]
         #:enemy-upgrade-advantage [raw-enemy-upgrade-advantage 0]
         #:minerals [raw-minerals 300]
         #:gas [raw-gas 150])
  (define ally-buildings (safe-list raw-ally-buildings))
  (define ally-units (safe-list raw-ally-units))
  (define researched-upgrades (safe-list raw-researched-upgrades))
  (define enemy-upgrade-advantage (safe-exact-int raw-enemy-upgrade-advantage 0))
  (define minerals (safe-nonneg-int raw-minerals 300))
  (define gas (safe-nonneg-int raw-gas 150))
  (define norm-race
    (case race
      [(Zerg zerg) 'Zerg]
      [(Terran terran) 'Terran]
      [(Protoss protoss) 'Protoss]
      [else 'Zerg]))
  (define threat-family
    (if requires-anti-air?
        'air-fleet
        (classify-threat-family enemy-archetype mirror-predicted-unit)))
  (define (upgrade-aliases u)
    (case u
      [(zergling-movementspeed metabolic-boost)
       '(zergling-movementspeed metabolic-boost)]
      [(missile-attacks-1 zerg-missile-weapons-1)
       '(missile-attacks-1 zerg-missile-weapons-1)]
      [(ground-carapace-1 zerg-ground-armor-1 zerg-ground-carapace-1)
       '(ground-carapace-1 zerg-ground-armor-1 zerg-ground-carapace-1)]
      [(melee-attacks-1 zerg-melee-weapons-1)
       '(melee-attacks-1 zerg-melee-weapons-1)]
      [(centrifical-hooks centrifugal-hooks)
       '(centrifical-hooks centrifugal-hooks)]
      [(infantry-weapons-1 terran-infantry-weapons-1)
       '(infantry-weapons-1 terran-infantry-weapons-1)]
      [(infantry-armor-1 terran-infantry-armor-1)
       '(infantry-armor-1 terran-infantry-armor-1)]
      [(vehicle-weapons-1 terran-vehicle-weapons-1)
       '(vehicle-weapons-1 terran-vehicle-weapons-1)]
      [(infernal-pre-igniter infernal-preigniter)
       '(infernal-pre-igniter infernal-preigniter)]
      [(ground-weapons-1 protoss-ground-weapons-1)
       '(ground-weapons-1 protoss-ground-weapons-1)]
      [(ground-armor-1 protoss-ground-armor-1)
       '(ground-armor-1 protoss-ground-armor-1)]
      [(warp-gate-research warpgate)
       '(warp-gate-research warpgate)]
      [else (list u)]))
  (define (have-up? u pool)
    (ormap (lambda (a) (not (not (memq a pool)))) (upgrade-aliases u)))
  (define (have-bldg? b pool)
    (or (not (not (memq b pool)))
        (ormap (lambda (s) (sc2-structure-matches-target? s b #f)) pool)))
  (define (have-item? x pool)
    (or (have-up? x pool)
        (have-bldg? x pool)
        (ormap (lambda (u) (not (not (memq u pool)))) (sc2-unit-equivalent-syms x))))
  (define (have-all? reqs pool)
    (andmap (lambda (r) (have-item? r pool)) reqs))

  (case norm-race
    [(Zerg)
     ;; Core Zerg Synergy ("What makes Roach/Hydra/Ling/Bane/Lurker work"):
     ;; Metabolic Boost (zergling-movementspeed) + Burrow + Lair + Glial Reconstitution
     ;; + Grooved Spines + +1/+1 Missile/Carapace
     (define synergy-invariants
       '(zergling-movementspeed burrow lair glial-reconstitution
         grooved-spines missile-attacks-1 ground-carapace-1))
     (define base-counter-tech
      (case threat-family
         [(air-fleet)          '(lair spire hydralisk-den spore-crawler)]
         [(armored-mech-siege) '(lair roach-warren hydralisk-den lurker-den spire)]
         [else                 '(lair baneling-nest roach-warren infestation-pit ultralisk-cavern)]))
     (define counter-tech
       (remove-duplicates
        (append (if requires-detection? '(spore-crawler lair) '())
                base-counter-tech)))
     (define prio-upgrades
       (case threat-family
         [(air-fleet)
          '(zergling-movementspeed burrow grooved-spines muscular-augments missile-attacks-1 ground-carapace-1)]
         [(armored-mech-siege)
          '(zergling-movementspeed burrow glial-reconstitution grooved-spines adaptive-talons missile-attacks-1 ground-carapace-1)]
         [else
          '(zergling-movementspeed burrow centrifical-hooks glial-reconstitution chitinous-plating missile-attacks-1 ground-carapace-1)]))
     (define prio-morphs
       (remove-duplicates
        (append (if requires-detection? '(overseer) '())
                (case threat-family
                  [(air-fleet)          '(lair overseer hive)]
                  [(armored-mech-siege) '(lair ravager lurker brood-lord hive)]
                  [else                 '(lair baneling ravager overseer hive)]))))
     (define unit-mix
       (case threat-family
         [(air-fleet)          '((corruptor . 0.45) (hydralisk . 0.40) (queen . 0.15))]
         [(armored-mech-siege) '((ravager . 0.35) (lurker . 0.35) (brood-lord . 0.15) (roach . 0.15))]
         [else                 '((baneling . 0.35) (zergling . 0.30) (roach . 0.20) (ultralisk . 0.15))]))
     (define target-gm-ratio
       (case threat-family
         [(air-fleet)          0.62]
         [(armored-mech-siege) 0.58]
         [else                 0.42]))

     (define st1-b '(hatchery spawning-pool extractor))
     (define st1-u '(zergling-movementspeed))
     (define st2-b '(roach-warren lair evolution-chamber))
     (define st2-u '(burrow glial-reconstitution missile-attacks-1 ground-carapace-1))
     (define st3-b counter-tech)
     (define st3-u '(grooved-spines))
     (define st4-b '(hive ultralisk-cavern greater-spire))
     (define st4-u '(chitinous-plating zergling-attackspeed))

     (define s1-ok? (and (have-all? st1-b ally-buildings) (have-all? st1-u researched-upgrades)))
     (define s2-ok? (and s1-ok? (have-all? st2-b ally-buildings) (have-all? st2-u researched-upgrades)))
     (define s3-ok? (and s2-ok? (have-all? st3-b ally-buildings) (have-all? st3-u researched-upgrades)))
     (define s4-ok? (and s3-ok? (have-all? st4-b ally-buildings)))

     (define stages
       (list (build-goal-stage 'opening-eco-foundation st1-b st1-u '(zergling-movementspeed queen-inject) s1-ok?)
             (build-goal-stage 'core-synergy-online st2-b st2-u synergy-invariants s2-ok?)
             (build-goal-stage 'midgame-counter-tech st3-b st3-u counter-tech s3-ok?)
             (build-goal-stage 'lategame-tier3-siege st4-b st4-u '(hive brood-lord ultralisk) s4-ok?)))
     (define cur-stage
       (cond [(not s1-ok?) 'opening-eco-foundation]
             [(not s2-ok?) 'core-synergy-online]
             [(not s3-ok?) 'midgame-counter-tech]
             [else         'lategame-tier3-siege]))
     (define known-all (append ally-buildings ally-units researched-upgrades))
     (define missing-synergy
       (filter (lambda (x) (not (have-item? x known-all))) synergy-invariants))
     (define missing-bldgs
       (filter (lambda (b) (not (have-bldg? b ally-buildings)))
               (remove-duplicates (append st1-b st2-b counter-tech))))
     (define missing-upgs
       (filter (lambda (u) (not (have-up? u researched-upgrades))) prio-upgrades))
     (define next-acts
       (append
        (for/list ([b (in-list (take missing-bldgs (min 2 (length missing-bldgs))))])
          (if (memq b '(lair hive greater-spire))
              (list 'morph b)
              (list 'build b)))
        (for/list ([u (in-list (take missing-upgs (min 2 (length missing-upgs))))])
          (list 'research u))
        (list (list 'train (caar unit-mix)))))
     (adaptive-tech-plan 'Zerg
                         'Zerg-RoachHydraLurker-AdaptiveSwarm
                         cur-stage
                         stages
                         synergy-invariants
                         missing-synergy
                         counter-tech
                         prio-upgrades
                         prio-morphs
                         unit-mix
                         target-gm-ratio
                         next-acts)]

    [(Terran)
     ;; Core Terran Synergy ("What makes Bio/Tank/Medivac work"):
     ;; Stimpack + Combat Shield + Concussive Shells + Medivacs + +1/+1 Infantry (Siege Tanks start with LotV Siege Mode!)
     (define synergy-invariants
       '(stimpack combat-shield concussive-shells medivac
         infantry-weapons-1 infantry-armor-1))
     (define base-counter-tech
       (case threat-family
         [(air-fleet)          '(starport armory engineering-bay missile-turret)]
         [(armored-mech-siege) '(barracks-techlab factory factory-techlab starport)]
         [else                 '(factory barracks-reactor starport armory)]))
     (define counter-tech
       (remove-duplicates
        (append (if requires-detection? '(engineering-bay missile-turret starport-techlab) '())
                base-counter-tech)))
     (define prio-upgrades
       (case threat-family
         [(air-fleet)
          '(stimpack combat-shield infantry-weapons-1 infantry-armor-1 vehicle-weapons-1)]
         [(armored-mech-siege)
          '(stimpack combat-shield concussive-shells drilling-claws infantry-weapons-1 infantry-armor-1)]
         [else
          '(stimpack combat-shield infernal-pre-igniter infantry-weapons-1 infantry-armor-1)]))
     (define prio-morphs
       '(orbital-command hellbat planetary-fortress))
     (define unit-mix
       (case threat-family
         [(air-fleet)          '((viking . 0.45) (thor . 0.30) (marine . 0.25))]
         [(armored-mech-siege) '((marauder . 0.40) (siege-tank . 0.35) (medivac . 0.15) (liberator . 0.10))]
         [else                 '((widow-mine . 0.25) (hellbat . 0.25) (siege-tank . 0.20) (marine . 0.20) (medivac . 0.10))]))
     (define target-gm-ratio
       (case threat-family
         [(air-fleet)          0.55]
         [(armored-mech-siege) 0.52]
         [else                 0.38]))

     (define st1-b '(command-center supply-depot barracks refinery))
     (define st1-u '(stimpack))
     (define st2-b '(barracks-techlab factory starport engineering-bay))
     (define st2-u '(combat-shield concussive-shells infantry-weapons-1 infantry-armor-1))
     (define st3-b counter-tech)
     (define st3-u '(drilling-claws))
     (define st4-b '(armory ghost-academy fusion-core))
     (define st4-u '(vehicle-weapons-1))

     (define s1-ok? (and (have-all? st1-b ally-buildings) (have-all? st1-u researched-upgrades)))
     (define s2-ok? (and s1-ok? (have-all? st2-b ally-buildings) (have-all? st2-u researched-upgrades)))
     (define s3-ok? (and s2-ok? (have-all? st3-b ally-buildings)))
     (define s4-ok? (and s3-ok? (have-all? st4-b ally-buildings)))

     (define stages
       (list (build-goal-stage 'opening-eco-foundation st1-b st1-u '(orbital-command stimpack) s1-ok?)
             (build-goal-stage 'core-synergy-online st2-b st2-u synergy-invariants s2-ok?)
             (build-goal-stage 'midgame-counter-tech st3-b st3-u counter-tech s3-ok?)
             (build-goal-stage 'lategame-tier3-siege st4-b st4-u '(thor ghost battlecruiser) s4-ok?)))
     (define cur-stage
       (cond [(not s1-ok?) 'opening-eco-foundation]
             [(not s2-ok?) 'core-synergy-online]
             [(not s3-ok?) 'midgame-counter-tech]
             [else         'lategame-tier3-siege]))
     (define known-all (append ally-buildings ally-units researched-upgrades))
     (define missing-synergy
       (filter (lambda (x) (not (have-item? x known-all))) synergy-invariants))
     (define missing-bldgs
       (filter (lambda (b) (not (have-bldg? b ally-buildings)))
               (remove-duplicates (append st1-b st2-b counter-tech))))
     (define missing-upgs
       (filter (lambda (u) (not (have-up? u researched-upgrades))) prio-upgrades))
     (define next-acts
       (append
        (for/list ([b (in-list (take missing-bldgs (min 2 (length missing-bldgs))))])
          (list 'build b))
        (for/list ([u (in-list (take missing-upgs (min 2 (length missing-upgs))))])
          (list 'research u))
        (list (list 'train (caar unit-mix)))))
     (adaptive-tech-plan 'Terran
                         'Terran-BioTankMedivac-AdaptiveTempo
                         cur-stage
                         stages
                         synergy-invariants
                         missing-synergy
                         counter-tech
                         prio-upgrades
                         prio-morphs
                         unit-mix
                         target-gm-ratio
                         next-acts)]

    [(Protoss)
     ;; Core Protoss Synergy ("What makes Gateway/Robo/Twilight work"):
     ;; WarpGate + Cybernetics Core + Immortal + Charge + Blink + +1/+1 Ground
     (define synergy-invariants
       '(warp-gate-research cybernetics-core immortal charge blink
         ground-weapons-1 ground-armor-1))
     (define base-counter-tech
       (case threat-family
         [(air-fleet)          '(cybernetics-core stargate twilight-council templar-archives photon-cannon)]
         [(armored-mech-siege) '(robotics-facility robotics-bay twilight-council)]
         [else                 '(robotics-facility robotics-bay twilight-council templar-archives)]))
     (define counter-tech
       (remove-duplicates
        (append (if requires-detection? '(forge photon-cannon robotics-facility) '())
                base-counter-tech)))
     (define prio-upgrades
       (case threat-family
         [(air-fleet)
          '(warp-gate-research blink psi-storm ground-weapons-1 ground-armor-1)]
         [(armored-mech-siege)
          '(warp-gate-research charge extended-thermal-lance ground-weapons-1 ground-armor-1)]
         [else
          '(warp-gate-research charge extended-thermal-lance psi-storm ground-weapons-1 ground-armor-1)]))
     (define prio-morphs
       '(warp-gate archon))
     (define unit-mix
       (case threat-family
         [(air-fleet)          '((stalker . 0.45) (archon . 0.30) (phoenix . 0.25))]
         [(armored-mech-siege) '((immortal . 0.45) (colossus . 0.25) (zealot . 0.20) (archon . 0.10))]
         [else                 '((colossus . 0.35) (archon . 0.25) (high-templar . 0.15) (zealot . 0.25))]))
     (define target-gm-ratio
       (case threat-family
         [(air-fleet)          0.58]
         [(armored-mech-siege) 0.50]
         [else                 0.56]))

     (define st1-b '(nexus pylon gateway cybernetics-core assimilator))
     (define st1-u '(warp-gate-research))
     (define st2-b '(robotics-facility twilight-council forge))
     (define st2-u '(charge blink ground-weapons-1 ground-armor-1))
     (define st3-b counter-tech)
     (define st3-u '(extended-thermal-lance))
     (define st4-b '(templar-archives fleet-beacon))
     (define st4-u '(psi-storm))

     (define s1-ok? (and (have-all? st1-b ally-buildings) (have-all? st1-u researched-upgrades)))
     (define s2-ok? (and s1-ok? (have-all? st2-b ally-buildings) (have-all? st2-u researched-upgrades)))
     (define s3-ok? (and s2-ok? (have-all? st3-b ally-buildings)))
     (define s4-ok? (and s3-ok? (have-all? st4-b ally-buildings)))

     (define stages
       (list (build-goal-stage 'opening-eco-foundation st1-b st1-u '(warp-gate-research cybernetics-core) s1-ok?)
             (build-goal-stage 'core-synergy-online st2-b st2-u synergy-invariants s2-ok?)
             (build-goal-stage 'midgame-counter-tech st3-b st3-u counter-tech s3-ok?)
             (build-goal-stage 'lategame-tier3-siege st4-b st4-u '(archon colossus carrier) s4-ok?)))
     (define cur-stage
       (cond [(not s1-ok?) 'opening-eco-foundation]
             [(not s2-ok?) 'core-synergy-online]
             [(not s3-ok?) 'midgame-counter-tech]
             [else         'lategame-tier3-siege]))
     (define known-all (append ally-buildings ally-units researched-upgrades))
     (define missing-synergy
       (filter (lambda (x) (not (have-item? x known-all))) synergy-invariants))
     (define missing-bldgs
       (filter (lambda (b) (not (have-bldg? b ally-buildings)))
               (remove-duplicates (append st1-b st2-b counter-tech))))
     (define missing-upgs
       (filter (lambda (u) (not (have-up? u researched-upgrades))) prio-upgrades))
     (define next-acts
       (append
        (for/list ([b (in-list (take missing-bldgs (min 2 (length missing-bldgs))))])
          (list 'build b))
        (for/list ([u (in-list (take missing-upgs (min 2 (length missing-upgs))))])
          (list 'research u))
        (list (list 'train (caar unit-mix)))))
     (adaptive-tech-plan 'Protoss
                         'Protoss-GateRoboTwilight-AdaptiveArmada
                         cur-stage
                         stages
                         synergy-invariants
                         missing-synergy
                         counter-tech
                         prio-upgrades
                         prio-morphs
                         unit-mix
                         target-gm-ratio
                         next-acts)]))

;; =============================================================================
;; 8. Guns-vs-Butter Production Possibility Frontier (PPF) & Dynamic
;;    Gas-to-Mineral Worker Allocation Controller
;;    (`gas-worker-allocation`, `compute-optimal-gas-workers`,
;;     `guns-vs-butter-ppf`, `evaluate-guns-vs-butter-ppf`)
;; =============================================================================

(struct gas-worker-allocation
  (active-geysers
   current-gas-workers
   desired-gas-workers
   workers-per-geyser
   target-gas-mineral-ratio
   current-gas-mineral-ratio
   action
   delta-gas-workers
   rationale)
  #:transparent)

(define (compute-optimal-gas-workers
         #:race [race 'Zerg]
         #:frame [raw-frame 0]
         #:minerals [raw-minerals 200]
         #:gas [raw-gas 0]
         #:workers [raw-workers 16]
         #:active-bases [raw-active-bases 1]
         #:active-geysers [raw-active-geysers 1]
         #:current-gas-workers [raw-current-gas-workers 3]
         #:should-expand? [should-expand? #f]
         #:escrow-minerals [raw-escrow-minerals 0]
         #:tech-gas-demand [raw-tech-gas-demand 100]
         #:unit-gas-ratio [raw-unit-gas-ratio 0.35]
         #:under-crisis? [under-crisis? #f])
  (define frame (safe-nonneg-int raw-frame 0))
  (define minerals (safe-nonneg-int raw-minerals 0))
  (define gas (safe-nonneg-int raw-gas 0))
  (define workers (safe-nonneg-int raw-workers 16))
  (define active-bases (safe-nonneg-int raw-active-bases 1))
  (define active-geysers (safe-nonneg-int raw-active-geysers 1))
  (define current-gas-workers (safe-nonneg-int raw-current-gas-workers 0))
  (define escrow-minerals (safe-nonneg-int raw-escrow-minerals 0))
  (define tech-gas-demand (safe-nonneg-int raw-tech-gas-demand 0))
  (define unit-gas-ratio (max 0.0 (min 1.0 (safe-real raw-unit-gas-ratio 0.35))))
  (define eff-bases (max 1 active-bases))
  (define max-geysers (* 2 eff-bases))
  (define cur-gm-ratio
    (exact->inexact (/ (max 0 gas) (max 50 minerals))))
  (define target-gm-ratio
    (cond
      [(and (< frame 1400) (< workers 16)) 0.15]
      [(and should-expand? (< eff-bases 2) (< minerals 300) (>= gas 100)) 0.12]
      [(and (>= minerals 600) (< gas 150)) 0.85]
      [(>= tech-gas-demand 200) (max 0.55 unit-gas-ratio)]
      [else (max 0.25 unit-gas-ratio)]))

  (cond
    ;; Case 1: Floating high gas (> 400G) while mineral-starved (< 300M), OR
    ;;         saving for early natural expansion with >= 100G banked -> pull off gas!
    [(or (and (> gas 400) (< minerals 300))
         (and should-expand? (< eff-bases 2) (< minerals 300) (>= gas 100))
         (and (< workers 14) (< minerals 200) (>= gas 100)))
     (define wpg (if (or (> gas 600) (< workers 14)) 0 1))
     (define desired (* (min active-geysers eff-bases) wpg))
     (gas-worker-allocation active-geysers
                            current-gas-workers
                            desired
                            wpg
                            target-gm-ratio
                            cur-gm-ratio
                            'pull-off-gas-to-minerals
                            (- desired current-gas-workers)
                            'gas-float-or-expansion-escrow-prioritize-minerals)]

    ;; Case 2: Early game (< 16 workers on 1 base) -> never put > 3 workers in gas
    ;;         (taking 2 gases too early costs -340 min/min and starves natural expand + workers!)
    [(and (< workers 16) (< eff-bases 2))
     (define wpg (if (< workers 13) 0 (min 3 (- workers 12))))
     (define desired (* (min 1 active-geysers) wpg))
     (define act
       (if (< desired current-gas-workers)
           'pull-off-gas-to-minerals
           'hold-gas-workers))
     (gas-worker-allocation active-geysers
                            current-gas-workers
                            desired
                            wpg
                            target-gm-ratio
                            cur-gm-ratio
                            act
                            (- desired current-gas-workers)
                            'protect-early-mineral-income-single-gas-cap)]

    ;; Case 3: Banking minerals (> 600M) or high tech demand while gas-starved (< 150G)
    ;;         -> fill 3/3 per geyser and take additional geysers!
    [(or (and (>= minerals 600) (< gas 150))
         (and (>= tech-gas-demand 200) (< gas 150) (>= workers 20)))
     (define wpg 3)
     (define target-geysers (min max-geysers (max 1 (add1 active-geysers))))
     (define max-gas-workers (max 0 (- workers (* 12 eff-bases))))
     (define desired (min max-gas-workers (* wpg (max 1 target-geysers))))
     (define act
       (if (< active-geysers max-geysers)
           'build-new-geyser-and-saturate
           'saturate-existing-geysers))
     (gas-worker-allocation active-geysers
                            current-gas-workers
                            desired
                            wpg
                            target-gm-ratio
                            cur-gm-ratio
                            act
                            (- desired current-gas-workers)
                            'mineral-bank-gas-starved-expand-and-saturate-geysers)]

    ;; Case 4: Standard balanced macro
    [else
     (define wpg (if (> gas 350) 2 3))
     (define max-gas-workers (max 0 (- workers (* 13 eff-bases))))
     (define desired (min max-gas-workers (* wpg (max 1 active-geysers))))
     (define act
       (cond
         [(< desired current-gas-workers) 'pull-off-gas-to-minerals]
         [(> desired current-gas-workers) 'saturate-existing-geysers]
         [else                            'hold-gas-workers]))
     (gas-worker-allocation active-geysers
                            current-gas-workers
                            desired
                            wpg
                            target-gm-ratio
                            cur-gm-ratio
                            act
                            (- desired current-gas-workers)
                            'balanced-macro-gas-mineral-equilibrium)]))

(struct guns-vs-butter-ppf
  (butter-utility                ; flonum: U'_butter (bases + workers)
   infrastructure-utility        ; flonum: U'_infra (production facilities + supply)
   tech-upgrade-utility          ; flonum: U'_tech (upgrades + tech buildings, Lanchester N^1.7 scaled)
   guns-army-utility             ; flonum: U'_guns (standing combat army)
   disruption-utility            ; flonum: U'_disrupt (burrowed blockers + worker raiders)
   bucket-ranking                ; list of bucket symbols sorted highest-to-lowest marginal utility
   top-priority-bucket           ; symbol: highest marginal utility bucket
   butter-share                  ; flonum in [0.0, 1.0]
   guns-share                    ; flonum in [0.0, 1.0]
   tech-share                    ; flonum in [0.0, 1.0]
   lanchester-upgrade-multiplier ; flonum: N^1.7 force multiplier
   recommended-gas-allocation)   ; gas-worker-allocation
  #:transparent)

(define (evaluate-guns-vs-butter-ppf
         #:race [race 'Zerg]
         #:frame [raw-frame 0]
         #:minerals [raw-minerals 200]
         #:gas [raw-gas 100]
         #:supply-left [raw-supply-left 6]
         #:supply-cap [raw-supply-cap 22]
         #:workers [raw-workers 16]
         #:target-workers [raw-target-workers 44]
         #:active-bases [raw-active-bases 1]
         #:depleting-bases [raw-depleting-bases 0]
         #:active-geysers [raw-active-geysers 1]
         #:current-gas-workers [raw-current-gas-workers 3]
         #:production-facilities [raw-production-facilities 1]
         #:busy-facilities [raw-busy-facilities 0]
         #:army-count [raw-army-count 4]
         #:missing-synergy-count [raw-missing-synergy-count 2]
         #:fap-score [raw-fap-score 0]
         #:under-crisis? [under-crisis? #f]
         #:mirror-macro-verdict [mirror-macro-verdict 'pace-Macro-And-Disrupt]
         #:enemy-upgrade-advantage [raw-enemy-upgrade-advantage 0]
         #:enemy-active-research-count [raw-enemy-active-research-count 0]
         #:requires-detection? [requires-detection? #f]
         #:requires-anti-air? [requires-anti-air? #f])
  (define frame (safe-nonneg-int raw-frame 0))
  (define minerals (safe-nonneg-int raw-minerals 0))
  (define gas (safe-nonneg-int raw-gas 0))
  (define supply-left (safe-exact-int raw-supply-left 0))
  (define supply-cap (safe-nonneg-int raw-supply-cap 15))
  (define workers (safe-nonneg-int raw-workers 12))
  (define target-workers (max 1 (safe-nonneg-int raw-target-workers 44)))
  (define active-bases (max 1 (safe-nonneg-int raw-active-bases 1)))
  (define depleting-bases (safe-nonneg-int raw-depleting-bases 0))
  (define active-geysers (safe-nonneg-int raw-active-geysers 1))
  (define current-gas-workers (safe-nonneg-int raw-current-gas-workers 0))
  (define production-facilities (max 1 (safe-nonneg-int raw-production-facilities 1)))
  (define busy-facilities (safe-nonneg-int raw-busy-facilities 0))
  (define army-count (safe-nonneg-int raw-army-count 0))
  (define missing-synergy-count (safe-nonneg-int raw-missing-synergy-count 0))
  (define fap-score (safe-real raw-fap-score 0.0))
  (define enemy-upgrade-advantage (safe-exact-int raw-enemy-upgrade-advantage 0))
  (define enemy-active-research-count (safe-nonneg-int raw-enemy-active-research-count 0))

  ;; 1. Butter — Economy (bases + workers):
  ;;    Compounding rate r_econ ~ 0.95 min^-1, boosted by worker deficit, depleting bases,
  ;;    or passive turtle opponent; heavily discounted under immediate crisis/all-in.
  (define worker-deficit-ratio
    (/ (exact->inexact (max 0 (- target-workers workers)))
       (max 1.0 (exact->inexact target-workers))))
  (define depletion-boost (* 35.0 depleting-bases))
  (define verdict-butter-boost
    (case mirror-macro-verdict
      [(out-Expand-Passive-Turtle)         30.0]
      [(punish-And-Deny-Greedy-Expand)     15.0]
      [(defend-All-In-Then-Counter-Expand) -35.0]
      [else                                8.0]))
  (define crisis-discount (if under-crisis? 0.25 1.0))
  (define butter-u
    (max 5.0
         (* crisis-discount
            (+ 25.0
               (* 65.0 worker-deficit-ratio)
               depletion-boost
               verdict-butter-boost))))

  ;; 2. Infrastructure — Production & Supply:
  ;;    Shadow price spikes when supply-left <= 3 (supply block imminent) or when
  ;;    all production facilities are 100% busy while banking resources.
  (define fac-utilization
    (/ (exact->inexact (min production-facilities busy-facilities))
       (max 1.0 (exact->inexact production-facilities))))
  (define supply-pressure
    (cond
      [(>= supply-cap 200) 0.0]
      [(<= supply-left 2)  85.0]
      [(<= supply-left 4)  45.0]
      [else                8.0]))
  (define bottleneck-pressure
    (if (and (>= fac-utilization 0.95) (>= minerals 450))
        55.0
        (* 25.0 fac-utilization)))
  (define infra-u
    (+ 10.0 supply-pressure bottleneck-pressure))

  ;; 3. Tech & Upgrades (Lanchester N^1.7 Force Multiplier + Opponent Tech Parity):
  ;;    A_eff = alpha(U) * N^1.7 -> dA_eff/dU = (d alpha / dU) * N^1.7.
  ;;    Low marginal value when standing army N < 6; massive value when N >= 12,
  ;;    when core build synergy upgrades are missing, or when opponent has an upgrade lead!
  (define lanchester-mult
    (/ (expt (max 1.0 (exact->inexact army-count)) 1.7)
       (expt 8.0 1.7)))
  (define enemy-tech-parity-boost
    (+ (* 24.0 (max 0 enemy-upgrade-advantage))
       (* 14.0 (max 0 enemy-active-research-count))
       (if (or requires-detection? requires-anti-air?) 16.0 0.0)))
  (define tech-u
    (min 140.0
         (+ 12.0
            (* 22.0 lanchester-mult (max 1 missing-synergy-count))
            enemy-tech-parity-boost
            (if (eq? mirror-macro-verdict 'out-Expand-Passive-Turtle) 20.0 0.0))))

  ;; 4. Guns — Standing Army:
  ;;    Dominates during crisis, enemy 1-base all-in, negative FAP score, or
  ;;    when we have idle production slots and unreserved resources.
  (define crisis-guns-boost
    (cond
      [under-crisis?                                                90.0]
      [(eq? mirror-macro-verdict 'defend-All-In-Then-Counter-Expand) 75.0]
      [(< fap-score -10)                                            45.0]
      [else                                                         0.0]))
  (define idle-fac-boost
    (* 12.0 (max 0 (- production-facilities busy-facilities))))
  (define guns-u
    (+ 28.0 crisis-guns-boost idle-fac-boost))

  ;; 5. Disruption — Asymmetric ROI (25M Zergling blocking 300M Hatchery + 1000M/min):
  (define disrupt-u
    (case mirror-macro-verdict
      [(punish-And-Deny-Greedy-Expand)     95.0]
      [(pace-Macro-And-Disrupt)            42.0]
      [(out-Expand-Passive-Turtle)         38.0]
      [(defend-All-In-Then-Counter-Expand) 12.0]
      [else                                30.0]))

  (define scored-buckets
    (list (cons 'butter-economy butter-u)
          (cons 'infrastructure-production-supply infra-u)
          (cons 'tech-and-upgrades tech-u)
          (cons 'guns-standing-army guns-u)
          (cons 'disruption-asymmetric-roi disrupt-u)))
  (define sorted-buckets
    (sort scored-buckets > #:key cdr))
  (define ranking (map car sorted-buckets))
  (define top-bucket (car ranking))

  (define total-core (+ butter-u guns-u tech-u))
  (define butter-sh (/ butter-u (max 1.0 total-core)))
  (define guns-sh (/ guns-u (max 1.0 total-core)))
  (define tech-sh (/ tech-u (max 1.0 total-core)))

  (define gas-alloc
    (compute-optimal-gas-workers
     #:race race
     #:frame frame
     #:minerals minerals
     #:gas gas
     #:workers workers
     #:active-bases active-bases
     #:active-geysers active-geysers
     #:current-gas-workers current-gas-workers
     #:should-expand? (or (> depleting-bases 0) (< workers target-workers))
     #:tech-gas-demand (* 75 missing-synergy-count)
     #:unit-gas-ratio (if (> tech-sh 0.35) 0.55 0.35)
     #:under-crisis? under-crisis?))

  (guns-vs-butter-ppf butter-u
                      infra-u
                      tech-u
                      guns-u
                      disrupt-u
                      ranking
                      top-bucket
                      butter-sh
                      guns-sh
                      tech-sh
                      lanchester-mult
                      gas-alloc))

;; =============================================================================
;; 9. Marginal-Utility Prioritization & Braun-Heap Resource Scheduler (PV1-PV6)
;; =============================================================================

;; Canonical race normalization lives in `lib/sc2-types.rkt`.
(define normalize-ledger-race normalize-known-race)

;; Category is one of:
;;   'supply | 'combat-unit | 'counter-tech | 'production-scaling
;;   | 'tech-upgrade | 'worker | 'expansion
(struct priority-candidate
  (id
   category
   action
   min-cost
   gas-cost
   supply-cost
   utility-score
   urgency-tier
   blocking-allowed?)
  #:transparent)

(struct priority-decision-entry
  (rank
   id
   category
   action
   min-cost
   gas-cost
   supply-cost
   utility-score
   blocking-allowed?
   outcome
   applicable-min-floor
   applicable-gas-floor
   blocked-by-id)
  #:transparent)

(struct priority-schedule-result
  (scheduled-actions
   scheduled-candidates
   reserved-candidate
   remaining-minerals
   remaining-gas
   remaining-supply
   category-utilities)
  #:transparent)

;; Invariant PV6: Refractory Cooldown Tracker
(struct refractory-cooldown-tracker (table) #:mutable #:transparent)

(define (make-refractory-cooldown-tracker)
  (refractory-cooldown-tracker (make-hash)))

(define (refractory-allow-action?! tracker key frame cooldown-frames)
  (cond
    [(not (refractory-cooldown-tracker? tracker)) #t]
    [else
     (define tbl
       (let ([t (refractory-cooldown-tracker-table tracker)])
         (if (hash? t)
             t
             (let ([nt (make-hash)])
               (set-refractory-cooldown-tracker-table! tracker nt)
               nt))))
     (define f (safe-exact-int frame 0))
     (define cd (max 1 (safe-exact-int cooldown-frames 1)))
     (define last-f (hash-ref tbl key #f))
     (cond
       [(or (not (exact-integer? last-f))
            (>= (- f last-f) cd))
        (hash-set! tbl key f)
        #t]
       [else #f])]))

;; Continuous, breakpoint-free pressure metrics (returns an immutable hash)
;; =============================================================================
;; Opponent Intelligence Freshness & Coverage Model (`opponent-intel-quality`)
;;
;; Models opponent knowledge as two continuous dimensions in [0.0, 1.0] across
;; 4 spatial/functional opponent sectors rather than an all-or-nothing timer:
;;   1. `enemy-main`    (half-life = 1344 frames / 60s: tech tree & main production)
;;   2. `enemy-natural` (half-life = 1120 frames / 50s: natural expansion & defense)
;;   3. `enemy-third`   (half-life = 1344 frames / 60s: 3rd+ bases, active at frame >= 3360)
;;   4. `corridor-army` (half-life = 784 frames  / 35s: mobile army & attack corridor)
;;
;; Produces:
;;   - `freshness`  in [0.0, 1.0]: weighted exponential decay across opponent sectors
;;   - `coverage`   in [0.0, 1.0]: fraction of active opponent sectors with non-expired intel
;;   - `confidence` in [0.0, 1.0]: `0.55 * freshness + 0.45 * coverage`
;;   - `deficit`    in [0.0, 1.0]: `1.0 - confidence`
;;   - `priority-sector`: `'enemy-natural` | `'enemy-main` | `'enemy-third` | `'corridor-army`
;;                        (the sector with largest weighted uncertainty `w_s * (1 - F_s)`)
;;   - `target-goal`:     `'maintain-vision` | `'expand-coverage` | `'refresh-tech-intel`
;;                        | `'harass-and-probe` | `'recon-in-force`
;; =============================================================================

(struct opponent-intel-quality
  (freshness
   coverage
   confidence
   deficit
   priority-sector
   target-goal
   sector-freshness-hash)
  #:transparent)

(define (sector-decay-freshness frame last-seen-frame half-life-frames [fallback-staleness #f])
  (define age
    (cond
      [(and (real? last-seen-frame) (> last-seen-frame 0))
       (max 0.0 (- (exact->inexact frame) (exact->inexact last-seen-frame)))]
      [(and (real? fallback-staleness) (>= fallback-staleness 0))
       (max 0.0 (exact->inexact fallback-staleness))]
      [else
       (max 0.0 (exact->inexact frame))]))
  ;; Opening grace curve: before frame 1120 (50s), while the opening scout is still walking
  ;; across the map, smoothly decay from 1.0 rather than treating frame 300 as "blind".
  (define raw-f
    (if (and (or (not (real? last-seen-frame)) (<= last-seen-frame 0))
             (not fallback-staleness)
             (< frame 1120))
        (max 0.45 (- 1.0 (/ (exact->inexact frame) 1680.0)))
        (exp (* -0.6931471805599453 (/ age (max 1.0 (exact->inexact half-life-frames)))))))
  (max 0.0 (min 1.0 raw-f)))

(define (evaluate-opponent-intel-quality
         #:frame [raw-frame 0]
         #:last-seen-main-frame [last-main -1]
         #:last-seen-natural-frame [last-nat -1]
         #:last-seen-third-frame [last-third -1]
         #:last-seen-army-frame [last-army -1]
         #:intel-staleness-frames [fallback-staleness #f]
         #:army-supply [raw-army-supply 0.0]
         #:ally-units [ally-units '()])
  (define frame (safe-nonneg-int raw-frame 0))
  (define army-sup (safe-real raw-army-supply 0.0))
  (define f-main (sector-decay-freshness frame last-main 1120.0 fallback-staleness))
  (define f-nat  (sector-decay-freshness frame last-nat  784.0  fallback-staleness))
  (define f-third
    (if (< frame 3360)
        1.0
        (sector-decay-freshness frame last-third 1120.0 fallback-staleness)))
  (define f-army (sector-decay-freshness frame last-army 448.0  fallback-staleness))

  ;; Phase-dependent sector weights (3rd base becomes relevant at frame >= 3360 = 2m30s)
  (define w-main  (if (>= frame 3360) 0.32 0.38))
  (define w-nat   (if (>= frame 3360) 0.28 0.36))
  (define w-third (if (>= frame 3360) 0.15 0.00))
  (define w-army  (if (>= frame 3360) 0.25 0.26))

  (define freshness
    (max 0.0 (min 1.0 (+ (* w-main f-main)
                         (* w-nat f-nat)
                         (* w-third f-third)
                         (* w-army f-army)))))

  ;; Sector coverage: an observed sector with freshness >= 0.65 counts as fully covered (1.0),
  ;; tapering smoothly to 0.0 at freshness <= 0.35; unobserved sectors after opening grace have 0.0 coverage.
  (define (sec-cov f last-sec)
    (cond
      [(and (or (not (real? last-sec)) (<= last-sec 0))
            (not fallback-staleness)
            (>= frame 1120))
       0.0]
      [else
       (max 0.0 (min 1.0 (/ (- f 0.35) 0.30)))]))
  (define coverage
    (max 0.0 (min 1.0 (+ (* w-main (sec-cov f-main last-main))
                         (* w-nat (sec-cov f-nat last-nat))
                         (* w-third (if (< frame 3360) 1.0 (sec-cov f-third last-third)))
                         (* w-army (sec-cov f-army last-army))))))

  (define confidence (max 0.0 (min 1.0 (+ (* 0.55 freshness) (* 0.45 coverage)))))
  (define deficit (max 0.0 (- 1.0 confidence)))

  ;; Pick the priority sector with largest weighted uncertainty `w_s * (1 - F_s)`
  (define sector-gaps
    (list (cons 'enemy-natural (* w-nat (- 1.0 f-nat)))
          (cons 'enemy-main    (* w-main (- 1.0 f-main)))
          (cons 'corridor-army (* w-army (- 1.0 f-army)))
          (cons 'enemy-third   (* w-third (- 1.0 f-third)))))
  (define priority-sector
    (car (argmax cdr sector-gaps)))

  (define has-raiders?
    (and (list? ally-units)
         (ormap (lambda (u)
                  (define sym (if (hash? u) (hash-ref u 'type 'none) u))
                  (memq sym '(reaper hellion oracle phoenix adept mutalisk banshee zergling warp-prism medivac)))
                ally-units)))

  ;; Graduated info-gathering goal based on Freshness x Coverage:
  (define target-goal
    (cond
      [(>= confidence 0.65) 'maintain-vision]
      [(and (< confidence 0.35) (>= army-sup 10.0)) 'recon-in-force]
      [(and (< confidence 0.35) (or has-raiders? (>= army-sup 4.0))) 'harass-and-probe]
      [(< coverage 0.55) 'expand-coverage]
      [(< f-main 0.45) 'refresh-tech-intel]
      [(or has-raiders? (>= army-sup 4.0)) 'harass-and-probe]
      [else 'expand-coverage]))

  (opponent-intel-quality
   freshness
   coverage
   confidence
   deficit
   priority-sector
   target-goal
   (hash 'enemy-main f-main
         'enemy-natural f-nat
         'enemy-third f-third
         'corridor-army f-army)))

(define (compute-state-pressure-metrics
         #:race [raw-race 'Zerg]
         #:frame [raw-frame 0]
         #:minerals [raw-minerals 200]
         #:gas [raw-gas 0]
         #:supply-left [raw-supply-left 4]
         #:supply-cap [raw-supply-cap 15]
         #:pending-supply [raw-pending-supply 0]
         #:workers [raw-workers 16]
         #:target-workers [raw-target-workers 44]
         #:active-bases [raw-active-bases 1]
         #:desired-bases [raw-desired-bases 2]
         #:production-facilities [raw-prod-facilities 1]
         #:max-facilities [raw-max-facilities 4]
         #:army-supply [raw-army-supply 0]
         #:enemy-threat-supply [raw-enemy-threat-supply 0]
         #:under-attack? [raw-under-attack? #f]
         #:requires-anti-air? [raw-requires-anti-air? #f]
         #:requires-detection? [raw-requires-detection? #f]
         #:escrow-age-frames [raw-escrow-age-frames 0]
         #:max-escrow-frames [raw-max-escrow-frames 224]
         #:intel-staleness-frames [raw-intel-staleness-frames 0]
         #:max-intel-staleness-frames [raw-max-intel-staleness-frames 896]
         #:intel-freshness [override-intel-freshness #f]
         #:intel-coverage [override-intel-coverage #f]
         #:intel-confidence [override-intel-confidence #f]
         #:supply-at-risk? [raw-supply-at-risk? #f]
         #:supply-buffer [override-supply-buffer #f])
  (define race (normalize-ledger-race raw-race))
  (define frame (safe-nonneg-int raw-frame 0))
  (define minerals (safe-nonneg-int raw-minerals 0))
  (define gas (safe-nonneg-int raw-gas 0))
  (define supply-left (max 0 (safe-exact-int raw-supply-left 4)))
  (define supply-cap (min 200 (max 1 (safe-nonneg-int raw-supply-cap 15))))
  (define pending-supply (safe-nonneg-int raw-pending-supply 0))
  (define workers (safe-nonneg-int raw-workers 12))
  (define target-workers (min 70 (max 12 (safe-nonneg-int raw-target-workers 44))))
  (define active-bases (max 1 (safe-nonneg-int raw-active-bases 1)))
  (define desired-bases (max 1 (safe-nonneg-int raw-desired-bases 2)))
  (define prod-facilities (max 1 (safe-nonneg-int raw-prod-facilities 1)))
  (define max-facilities (max 1 (safe-nonneg-int raw-max-facilities 4)))
  (define army-supply (max 0.0 (safe-real raw-army-supply 0.0)))
  (define enemy-threat-supply (max 0.0 (safe-real raw-enemy-threat-supply 0.0)))
  (define under-attack? (eq? raw-under-attack? #t))
  (define requires-anti-air? (eq? raw-requires-anti-air? #t))
  (define requires-detection? (eq? raw-requires-detection? #t))
  (define escrow-age-frames (safe-nonneg-int raw-escrow-age-frames 0))
  (define max-escrow-frames (max 1 (safe-nonneg-int raw-max-escrow-frames 224)))
  (define intel-staleness-frames (safe-nonneg-int raw-intel-staleness-frames 0))
  (define max-intel-staleness-frames (max 1 (safe-nonneg-int raw-max-intel-staleness-frames 896)))
  (define supply-at-risk? (eq? raw-supply-at-risk? #t))

  ;; 1. Supply buffer & continuous supply hazard in [0.0, 2.0]
  ;; Add +2.0 lead headroom between 30 and 90 supply used while keeping < 30 openings unchanged.
  (define supply-used (max 0 (- supply-cap supply-left)))
  (define supply-buffer
    (if (and override-supply-buffer (real? override-supply-buffer) (not (nan? override-supply-buffer)))
        (max 1.0 (exact->inexact override-supply-buffer))
        (+ 2.0
           (* 0.06 (exact->inexact supply-cap))
           (if (and (>= supply-used 30) (<= supply-used 90)) 2.0 0.0))))
  (define pending-credit-per-unit
    (if (eq? race 'Zerg) 4.0 8.0))
  (define eff-supply
    (+ (exact->inexact supply-left) (* pending-credit-per-unit (exact->inexact pending-supply))))
  (define raw-supply-hazard
    (/ (max 0.0 (- supply-buffer eff-supply))
       (max 1.0 supply-buffer)))
  (define supply-hazard
    (cond
      [(>= supply-cap 200) 0.0]
      [(and (> pending-supply 0)
            (not supply-at-risk?)
            (not (and (eq? race 'Zerg) (>= active-bases 3) (<= pending-supply 1))))
       0.0]
      [(and supply-at-risk?
            (< pending-supply 2)
            (<= eff-supply (+ supply-buffer 6.0)))
       (min 2.0 (max 0.5 raw-supply-hazard))]
      [(<= eff-supply supply-buffer)
       ;; Strictly positive in [0.05, 2.0] whenever supply-left <= supply-buffer (PV4)
       (min 2.0 (max 0.05 raw-supply-hazard))]
      [else 0.0]))

  ;; 2. Threat pressure
  (define threat-pressure
    (/ (+ (* 1.5 enemy-threat-supply)
          (if under-attack? 12.0 0.0)
          (if (or under-attack? (> enemy-threat-supply 0.0))
              (max 0.0 (- (* 0.65 (exact->inexact (max 0 (- workers 14))))
                          army-supply))
              0.0))
       (max 4.0 army-supply)))

  ;; 3. Gas imbalance
  (define gas-imbalance
    (/ (exact->inexact gas)
       (max 50.0 (exact->inexact minerals))))

  ;; 4. Worker saturation gap (smoothly decays toward 0 under high threat-pressure)
  (define worker-saturation-gap
    (* (max 0.0 (/ (exact->inexact (- target-workers workers))
                   (max 1.0 (exact->inexact target-workers))))
       (/ 1.0 (+ 1.0 (* 1.8 threat-pressure)))))

  ;; 5. Facility scaling pressure
  (define facility-scaling-pressure
    (* (max 0.0 (/ (exact->inexact (- max-facilities prod-facilities))
                   (max 1.0 (exact->inexact max-facilities))))
       (+ 1.0 (/ (exact->inexact minerals) 250.0))))

  ;; 6. Continuous Opponent Information Freshness, Coverage & Pressure (`intel-pressure` in [0.0, 2.5]):
  ;;    Combines sector-level `intel-freshness` and `intel-coverage` (`intel-confidence = 0.55*F + 0.45*C`)
  ;;    with `intel-staleness-frames / max-intel-staleness-frames` (default 896 frames = 40s):
  ;;      - High confidence (>= 0.65) and low staleness -> 0.0 pressure (zero macro interference)
  ;;      - Moderate deficit (0.35 <= confidence < 0.65) -> smooth [0.1, 0.95] pressure (recon goal, no escrow cancel)
  ;;      - Severe blindness (confidence < 0.35 or staleness >= max-intel-staleness-frames) -> >= 1.0 pressure
  (define default-iq
    (evaluate-opponent-intel-quality
     #:frame frame
     #:intel-staleness-frames intel-staleness-frames
     #:army-supply army-supply))
  (define iq-freshness
    (if (and override-intel-freshness (real? override-intel-freshness))
        (max 0.0 (min 1.0 (exact->inexact override-intel-freshness)))
        (opponent-intel-quality-freshness default-iq)))
  (define iq-coverage
    (if (and override-intel-coverage (real? override-intel-coverage))
        (max 0.0 (min 1.0 (exact->inexact override-intel-coverage)))
        (opponent-intel-quality-coverage default-iq)))
  (define iq-confidence
    (if (and override-intel-confidence (real? override-intel-confidence))
        (max 0.0 (min 1.0 (exact->inexact override-intel-confidence)))
        (max 0.0 (min 1.0 (+ (* 0.55 iq-freshness) (* 0.45 iq-coverage))))))
  (define staleness-ratio
    (if (<= intel-staleness-frames 0)
        0.0
        (/ (exact->inexact intel-staleness-frames)
           (max 1.0 (exact->inexact max-intel-staleness-frames)))))
  (define confidence-pressure
    (cond
      [(>= iq-confidence 0.65) 0.0]
      [(>= iq-confidence 0.35) (* 0.95 (/ (- 0.65 iq-confidence) 0.30))]
      [else (+ 1.0 (min 1.5 (/ (- 0.35 iq-confidence) 0.25)))]))
  (define intel-pressure
    (min 2.5 (max staleness-ratio confidence-pressure)))

  ;; 7. Expansion desire & escrow eligibility (PV1 / PV7 / PV9)
  (define expansion-desire
    (if (and (< active-bases desired-bases) (not under-attack?))
        (* (/ (exact->inexact (- desired-bases active-bases))
              (max 1.0 (exact->inexact desired-bases)))
           (/ 1.0 (+ 1.0 (* 0.8 threat-pressure) (* 0.25 intel-pressure)))
           (+ 0.65 (min 1.35 (/ (exact->inexact minerals) 350.0))))
        0.0))
  (define escrow-eligible?
    (and (< escrow-age-frames max-escrow-frames)
         (< threat-pressure 0.85)
         (<= enemy-threat-supply 0.0)
         (or (< intel-pressure 1.0) (< frame 2688) (>= army-supply 12))
         (or (= active-bases 1) (>= army-supply 18))
         (not under-attack?)
         (< active-bases desired-bases)))

  (hash 'race race
        'frame frame
        'minerals minerals
        'gas gas
        'supply-left supply-left
        'supply-cap supply-cap
        'pending-supply pending-supply
        'supply-buffer supply-buffer
        'supply-hazard supply-hazard
        'supply-at-risk? supply-at-risk?
        'workers workers
        'target-workers target-workers
        'active-bases active-bases
        'desired-bases desired-bases
        'production-facilities prod-facilities
        'max-facilities max-facilities
        'army-supply army-supply
        'enemy-threat-supply enemy-threat-supply
        'under-attack? under-attack?
        'requires-anti-air? requires-anti-air?
        'requires-detection? requires-detection?
        'escrow-age-frames escrow-age-frames
        'max-escrow-frames max-escrow-frames
        'intel-staleness-frames intel-staleness-frames
        'max-intel-staleness-frames max-intel-staleness-frames
        'intel-freshness iq-freshness
        'intel-coverage iq-coverage
        'intel-confidence iq-confidence
        'intel-pressure intel-pressure
        'threat-pressure threat-pressure
        'gas-imbalance gas-imbalance
        'worker-saturation-gap worker-saturation-gap
        'facility-scaling-pressure facility-scaling-pressure
        'expansion-desire expansion-desire
        'escrow-eligible? escrow-eligible?))

(define PV5-ANTI-AIR-SYMS
  '(queen hydralisk corruptor mutalisk spore-crawler
    hydralisk-den spire
    viking-fighter viking thor cyclone liberator missile-turret engineering-bay starport
    stalker phoenix void-ray carrier tempest archon photon-cannon cybernetics-core stargate shield-battery))

(define PV5-DETECTOR-SYMS
  '(spore-crawler overseer lair
    missile-turret engineering-bay raven starport starport-techlab
    observer photon-cannon robotics-facility forge))

(define PV5-PURE-DETECTOR-SYMS
  '(observer overseer raven lair robotics-facility starport-techlab forge))

(define PV5-PURE-ANTI-AIR-SYMS
  '(queen hydralisk corruptor mutalisk hydralisk-den spire
    viking-fighter viking thor cyclone liberator
    stalker phoenix void-ray carrier tempest archon cybernetics-core stargate shield-battery))

(define PV5-COUNTER-TECH-AND-UNIT-SYMS
  (remove-duplicates (append PV5-ANTI-AIR-SYMS PV5-DETECTOR-SYMS) eq?))

(define PV3-GAS-COMBAT-UNIT-SYMS
  '(roach ravager hydralisk lurker mutalisk corruptor
    marauder siege-tank widow-mine medivac viking viking-fighter ghost
    stalker sentry adept immortal colossus disruptor oracle void-ray phoenix))

(define PV3-MINERAL-ONLY-COMBAT-UNIT-SYMS
  '(zergling marine zealot))

(define PV-INTEL-GATHERING-UNIT-SYMS
  '(;; Dedicated Scouts & Mobile Detectors (Scouting)
    observer overseer overlord sentry
    ;; Fast Harassment & Recon Raiders (Harassment)
    reaper hellion oracle phoenix adept mutalisk banshee medivac warp-prism
    ;; Mobile Probing / Attacking Units (Attacking for Intel)
    zergling stalker marine zealot roach))

;; Selects the optimal modality for gathering information on the opponent based on
;; continuous Freshness x Coverage (`intel-confidence`, `intel-coverage`) and army state:
;;   - 'attacking  when army-supply >= 10 (recon-in-force / multi-base probing sweep)
;;   - 'harassment when mobile harassment raiders exist or army-supply >= 4 (mineral-line / expansion poke)
;;   - 'scouting   otherwise (worker scout, Overlord, Observer/Overseer/Hallucination/Scan, or single spotter)
(define (select-intel-gathering-method
         #:race [raw-race 'Zerg]
         #:frame [raw-frame 0]
         #:army-supply [raw-army-supply 0]
         #:ally-units [ally-units '()]
         #:intel-staleness-frames [raw-staleness 0]
         #:intel-freshness [raw-freshness #f]
         #:intel-coverage [raw-coverage #f])
  (define army-sup (safe-real raw-army-supply 0.0))
  (define units (if (list? ally-units) ally-units '()))
  (define has-raiders?
    (ormap (lambda (u)
             (define sym (if (hash? u) (hash-ref u 'type 'none) u))
             (memq sym '(reaper hellion oracle phoenix adept mutalisk banshee zergling warp-prism medivac)))
           units))
  (cond
    [(>= army-sup 10.0) 'attacking]
    [(or has-raiders? (>= army-sup 4.0)) 'harassment]
    [else 'scouting]))

;; Shared Matchup, Counter-Composition, Scaling & Resource-Cap Policies
(define ZERG-SIEGE-SPLASH-ENEMY-SYMS
  '(siege-tank siege-tank-sieged colossus archon))

(define TERRAN-GHOST-COUNTER-ENEMY-SYMS
  '(infestor infestor-burrowed viper ultralisk ultralisk-burrowed
    high-templar archon lurker lurker-mp lurker-burrowed lurker-mp-burrowed))

(define TERRAN-LIBERATOR-COUNTER-ENEMY-SYMS
  '(lurker lurker-mp lurker-burrowed lurker-mp-burrowed
    ultralisk ultralisk-burrowed siege-tank siege-tank-sieged))

(define PROTOSS-CAPITAL-AIR-ENEMY-SYMS
  '(tempest carrier battlecruiser brood-lord broodlord mothership))

(define (normalize-enemy-race-sym raw-enemy-race)
  (cond
    [(memq raw-enemy-race '(Zerg Terran Protoss Random Unknown)) raw-enemy-race]
    [(string? raw-enemy-race)
     (case (string-downcase raw-enemy-race)
       [("zerg") 'Zerg]
       [("terran") 'Terran]
       [("protoss") 'Protoss]
       [("random") 'Random]
       [else 'Unknown])]
    [else 'Unknown]))

(define (enemy-counts-have-any? enemy-u-counts syms)
  (and (hash? enemy-u-counts)
       (> (hash-count enemy-u-counts) 0)
       (for/or ([s (in-list syms)])
         (> (safe-nonneg-int (hash-ref enemy-u-counts s 0) 0) 0))))

(define (gas-building-cap active-bases)
  (* 2 (max 1 (safe-nonneg-int active-bases 1))))

(define (gas-building-cap-ok? cur-gas-bldgs active-bases)
  (< (safe-nonneg-int cur-gas-bldgs 0) (gas-building-cap active-bases)))

;; Mirrors runtime stepped Zerg Drone pause vs Terran/Protoss:
;; >38 Drones requires >=12 army supply, >46 requires >=22, >54 requires >=34.
(define (zerg-stepped-drone-army-floor race enemy-race workers)
  (define w (safe-nonneg-int workers 0))
  (if (and (eq? race 'Zerg) (memq enemy-race '(Terran Protoss)))
      (cond
        [(> w 54) 34.0]
        [(> w 46) 22.0]
        [(> w 38) 12.0]
        [else 0.0])
      0.0))

(define (zerg-worker-army-floor-ok? race enemy-race workers army-supply)
  (>= (max 0.0 (safe-real army-supply 0.0))
      (zerg-stepped-drone-army-floor race enemy-race workers)))

(define (zergling-target-cap minerals enemy-u-counts)
  (cond
    [(>= (safe-nonneg-int minerals 0) 1500) 9999]
    [(enemy-counts-have-any? enemy-u-counts ZERG-SIEGE-SPLASH-ENEMY-SYMS) 20]
    [else 32]))

(define (terran-desired-barracks-techlabs race enemy-race barracks-cnt)
  (define r-cnt (safe-nonneg-int barracks-cnt 0))
  (cond
    [(<= r-cnt 0) 0]
    [(and (eq? race 'Terran) (memq enemy-race '(Terran Protoss)))
     (cond
       [(>= r-cnt 5) 3]
       [(>= r-cnt 3) 2]
       [else 1])]
    [else 1]))

(define (terran-desired-factories race enemy-race active-bases supply-used)
  (if (and (eq? race 'Terran)
           (eq? enemy-race 'Terran)
           (>= (safe-nonneg-int active-bases 1) 2)
           (>= (safe-nonneg-int supply-used 0) 68))
      2
      1))

(define (terran-enemy-needs-ghost? enemy-u-counts)
  (enemy-counts-have-any? enemy-u-counts TERRAN-GHOST-COUNTER-ENEMY-SYMS))

(define (terran-enemy-needs-liberator? enemy-u-counts)
  (enemy-counts-have-any? enemy-u-counts TERRAN-LIBERATOR-COUNTER-ENEMY-SYMS))

(define (terran-desired-ghost-cap active-bases supply-used enemy-race enemy-u-counts)
  (cond
    [(or (terran-enemy-needs-ghost? enemy-u-counts)
         (memq enemy-race '(Zerg Protoss Unknown)))
     10]
    [(>= (safe-nonneg-int active-bases 1) 4) 6]
    [(>= (safe-nonneg-int supply-used 0) 130) 4]
    [else 2]))

(define (terran-desired-liberator-cap active-bases enemy-u-counts)
  (define bases (max 1 (safe-nonneg-int active-bases 1)))
  (cond
    [(and (>= bases 4) (terran-enemy-needs-liberator? enemy-u-counts)) 8]
    [(and (>= bases 3) (terran-enemy-needs-liberator? enemy-u-counts)) 6]
    [(>= bases 4) 5]
    [else 3]))

(define CRISIS-DEFENDER-SYMS
  '(roach ravager queen spine-crawler
    immortal stalker zealot shield-battery
    marauder siege-tank bunker))

(define CRISIS-DEFERRED-UPGRADE-SYMS
  '(glial-reconstitution
    centrifical-hooks centrifugal-hooks
    grooved-spines muscular-augments
    burrow tunneling-claws
    pathogen-glands neural-parasite chitinous-plating anabolic-synthesis zergling-attackspeed
    zerg-melee-weapons-1 zerg-melee-weapons-2 zerg-melee-weapons-3 melee-attacks-1
    zerg-missile-weapons-1 zerg-missile-weapons-2 zerg-missile-weapons-3 missile-attacks-1
    zerg-ground-armor-1 zerg-ground-armor-2 zerg-ground-armor-3 ground-carapace-1 zerg-ground-carapace-1
    zerg-ground-armors-1 zerg-ground-armors-2 zerg-ground-armors-3
    zerg-flyer-weapons-1 zerg-flyer-armor-1 zerg-flyer-armors-1
    psi-storm psionic-storm
    extended-thermal-lance
    resonating-glaives gravitic-booster gravitic-boosters gravitic-drive
    protoss-ground-weapons-1 protoss-ground-weapons-2 protoss-ground-weapons-3 ground-weapons-1
    protoss-ground-armor-1 protoss-ground-armor-2 protoss-ground-armor-3 ground-armor-1
    protoss-ground-armors-1 protoss-ground-armors-2 protoss-ground-armors-3
    protoss-shields-1 protoss-air-weapons-1 protoss-air-armor-1 protoss-air-armors-1
    banshee-cloak cloaking-field banshee-cloaking-field
    personal-cloaking
    drilling-claws smart-servos advanced-ballistics weapon-refit hyperflight-rotors
    terran-infantry-weapons-1 terran-infantry-weapons-2 terran-infantry-weapons-3 infantry-weapons-1
    terran-infantry-armor-1 terran-infantry-armor-2 terran-infantry-armor-3 infantry-armor-1
    terran-infantry-armors-1 terran-infantry-armors-2 terran-infantry-armors-3
    terran-vehicle-weapons-1 terran-vehicle-weapons-2 terran-vehicle-weapons-3 vehicle-weapons-1
    terran-vehicle-and-ship-plating-1 terran-vehicle-and-ship-armors-1
    terran-ship-weapons-1 terran-ship-weapons-2 terran-ship-weapons-3))

(define CRISIS-DEFERRED-TECH-SYMS
  '(lair hive infestation-pit spire greater-spire ultralisk-cavern
    templar-archive templar-archives fleet-beacon dark-shrine robotics-bay
    fusion-core))

(define TERRAN-GROUND-AA-SCREEN-ENEMY-SYMS
  '(stalker hydralisk))

(define (crisis-defense-tech-defer-active? under-attack? army-supply enemy-threat-supply [workers 44])
  (and (eq? under-attack? #t)
       (let ([army (safe-real army-supply 0.0)]
             [threat (safe-real enemy-threat-supply 0.0)]
             [w (safe-nonneg-int workers 44)])
         (or (< army threat) (< w 32)))))

(define (crisis-deferred-sym? sym crisis-defer?
                              #:defer-stargate? [defer-stargate? #f]
                              #:keep-ship-weapons? [keep-ship-weapons? #f])
  (and (eq? crisis-defer? #t)
       (or (and (not (and keep-ship-weapons? (eq? sym 'terran-ship-weapons-1)))
                (not (not (memq sym CRISIS-DEFERRED-UPGRADE-SYMS))))
           (not (not (memq sym CRISIS-DEFERRED-TECH-SYMS)))
           (and defer-stargate? (eq? sym 'stargate)))))

(define (terran-enemy-ground-aa-count enemy-u-counts)
  (if (hash? enemy-u-counts)
      (+ (safe-nonneg-int (hash-ref enemy-u-counts 'stalker 0) 0)
         (safe-nonneg-int (hash-ref enemy-u-counts 'hydralisk 0) 0))
      0))

(define (terran-enemy-capital-air-with-ground-aa? enemy-u-counts)
  (and (protoss-enemy-capital-air? enemy-u-counts)
       (>= (terran-enemy-ground-aa-count enemy-u-counts) 6)))

(define (terran-desired-thor-cap enemy-u-counts)
  (cond
    [(terran-enemy-capital-air-with-ground-aa? enemy-u-counts) 6]
    [(protoss-enemy-capital-air? enemy-u-counts) 5]
    [else 0]))

(define (terran-air-fleet-count units-or-hash)
  (define air-syms '(viking-fighter viking viking-assault liberator liberator-ag battlecruiser))
  (cond
    [(hash? units-or-hash)
     (for/sum ([s (in-list air-syms)])
       (safe-nonneg-int (hash-ref units-or-hash s 0) 0))]
    [(list? units-or-hash)
     (count (lambda (u) (not (not (memq u air-syms)))) units-or-hash)]
    [else 0]))

(define (terran-ship-weapons-due? race air-fleet-cnt has-ready-armory? upgs)
  (and (eq? race 'Terran)
       (eq? has-ready-armory? #t)
       (>= (safe-nonneg-int air-fleet-cnt 0) 4)
       (list? upgs)
       (not (memq 'terran-ship-weapons-1 upgs))))

(define (protoss-enemy-capital-air? enemy-u-counts)
  (enemy-counts-have-any? enemy-u-counts PROTOSS-CAPITAL-AIR-ENEMY-SYMS))

(define (protoss-4th-nexus-due? race active-bases workers army-supply minerals enemy-capital-air?)
  (and (eq? race 'Protoss)
       (= (safe-nonneg-int active-bases 1) 3)
       (>= (safe-nonneg-int workers 0) 54)
       (or (>= (max 0.0 (safe-real army-supply 0.0)) 12.0)
           (>= (safe-nonneg-int minerals 0) 500)
           (eq? enemy-capital-air? #t))))

(define (enrich-priority-metrics
         base-metrics
         #:race race
         #:enemy-race [raw-enemy-race 'Unknown]
         #:minerals [raw-minerals 0]
         #:active-bases [raw-active-bases 1]
         #:under-attack? [raw-under-attack? #f]
         #:requires-anti-air? [raw-requires-anti-air? #f]
         #:army-supply [raw-army-supply 0.0]
         #:enemy-threat-supply [raw-enemy-threat-supply 0.0]
         #:workers [raw-workers 44]
         #:has-barracks-techlab? [has-rax-tl? #f]
         #:has-twilight-or-charge? [has-twilight-or-charge? #f]
         #:has-hydralisk-den? [has-hydralisk-den? #f]
         #:has-robo? [has-robo? #f]
         #:has-armory? [has-armory? #f]
         #:crisis-defense-defer? [raw-crisis-defer? 'auto]
         #:enemy-capital-air-ground-aa? [raw-cap-air-ground-aa? 'auto]
         #:terran-ship-weapons-due? [ship-weap-due? #f]
         #:stalker-count [stalker-count 0]
         #:roach-count [roach-count 0]
         #:enemy-unit-counts [enemy-u-counts #f]
         #:bo-goal-sym [bo-goal-sym #f])
  (define enemy-race (normalize-enemy-race-sym raw-enemy-race))
  (let* ([m (hash-set base-metrics 'race race)]
         [m (hash-set m 'enemy-race enemy-race)]
         [m (hash-set m 'minerals (safe-nonneg-int raw-minerals 0))]
         [m (hash-set m 'requires-anti-air? (eq? raw-requires-anti-air? #t))]
         [m (hash-set m 'active-bases (max 1 (safe-nonneg-int raw-active-bases 1)))]
         [m (hash-set m 'under-attack? (eq? raw-under-attack? #t))]
         [m (hash-set m 'army-supply (max 0.0 (safe-real raw-army-supply 0.0)))]
         [m (hash-set m 'enemy-threat-supply (max 0.0 (safe-real raw-enemy-threat-supply 0.0)))]
         [m (hash-set m 'has-barracks-techlab? (not (not has-rax-tl?)))]
         [m (hash-set m 'has-twilight-or-charge? (not (not has-twilight-or-charge?)))]
         [m (hash-set m 'has-hydralisk-den? (not (not has-hydralisk-den?)))]
         [m (hash-set m 'stalker-count (safe-nonneg-int stalker-count 0))]
         [m (hash-set m 'roach-count (safe-nonneg-int roach-count 0))]
         [crisis-defer?
          (if (eq? raw-crisis-defer? 'auto)
              (crisis-defense-tech-defer-active?
               raw-under-attack? raw-army-supply raw-enemy-threat-supply raw-workers)
              (eq? raw-crisis-defer? #t))]
         [cap-air-ground-aa?
          (if (eq? raw-cap-air-ground-aa? 'auto)
              (terran-enemy-capital-air-with-ground-aa? enemy-u-counts)
              (eq? raw-cap-air-ground-aa? #t))]
         [m (hash-set m 'enemy-capital-air? (protoss-enemy-capital-air? enemy-u-counts))]
         [m (hash-set m 'enemy-needs-ghost? (terran-enemy-needs-ghost? enemy-u-counts))]
         [m (hash-set m 'enemy-needs-liberator? (terran-enemy-needs-liberator? enemy-u-counts))]
         [m (hash-set m 'has-robo? (eq? has-robo? #t))]
         [m (hash-set m 'has-armory? (eq? has-armory? #t))]
         [m (hash-set m 'crisis-defense-defer? crisis-defer?)]
         [m (hash-set m 'enemy-capital-air-ground-aa? cap-air-ground-aa?)]
         [m (hash-set m 'terran-ship-weapons-due? (eq? ship-weap-due? #t))])
    (if bo-goal-sym
        (hash-set m 'bo-goal-sym bo-goal-sym)
        m)))

(define (compute-candidate-marginal-utility cand metrics)
  (define m (if (hash? metrics) metrics (compute-state-pressure-metrics)))
  (define id (priority-candidate-id cand))
  (define cat (priority-candidate-category cand))
  (define m-cost (safe-nonneg-int (priority-candidate-min-cost cand) 0))
  (define g-cost (safe-nonneg-int (priority-candidate-gas-cost cand) 0))

  (define supply-cap (safe-nonneg-int (hash-ref m 'supply-cap 15) 15))
  (define pending-supply (safe-nonneg-int (hash-ref m 'pending-supply 0) 0))
  (define supply-left (safe-exact-int (hash-ref m 'supply-left 4) 4))
  (define supply-buffer (safe-real (hash-ref m 'supply-buffer (+ 2.0 (* 0.06 supply-cap))) 4.0))
  (define supply-hazard (safe-real (hash-ref m 'supply-hazard 0.0) 0.0))
  (define supply-at-risk? (eq? (hash-ref m 'supply-at-risk? #f) #t))
  (define threat-pressure (safe-real (hash-ref m 'threat-pressure 0.0) 0.0))
  (define intel-pressure (safe-real (hash-ref m 'intel-pressure 0.0) 0.0))
  (define army-supply (safe-real (hash-ref m 'army-supply 0.0) 0.0))
  (define enemy-threat-supply (safe-real (hash-ref m 'enemy-threat-supply 0.0) 0.0))
  (define under-attack? (eq? (hash-ref m 'under-attack? #f) #t))
  (define minerals (safe-nonneg-int (hash-ref m 'minerals 0) 0))
  (define gas (safe-nonneg-int (hash-ref m 'gas 0) 0))
  (define m-race (hash-ref m 'race 'Unknown))
  (define m-enemy-race (hash-ref m 'enemy-race 'Unknown))
  (define has-rax-tl? (hash-ref m 'has-barracks-techlab? #f))
  (define has-twilight-or-charge? (hash-ref m 'has-twilight-or-charge? #f))
  (define has-hydralisk-den? (hash-ref m 'has-hydralisk-den? #f))
  (define pvz-stalker-count (safe-nonneg-int (hash-ref m 'stalker-count 0) 0))
  (define roach-cnt (safe-nonneg-int (hash-ref m 'roach-count 0) 0))
  (define enemy-capital-air? (eq? (hash-ref m 'enemy-capital-air? #f) #t))
  (define enemy-cap-air-ground-aa? (eq? (hash-ref m 'enemy-capital-air-ground-aa? #f) #t))
  (define enemy-needs-ghost? (eq? (hash-ref m 'enemy-needs-ghost? #f) #t))
  (define enemy-needs-liberator? (eq? (hash-ref m 'enemy-needs-liberator? #f) #t))
  (define has-robo? (eq? (hash-ref m 'has-robo? #f) #t))
  (define has-armory? (eq? (hash-ref m 'has-armory? #f) #t))
  (define crisis-defer? (eq? (hash-ref m 'crisis-defense-defer? #f) #t))
  (define ship-weapons-due? (eq? (hash-ref m 'terran-ship-weapons-due? #f) #t))
  (define gas-imbalance (safe-real (hash-ref m 'gas-imbalance 0.0) 0.0))
  (define worker-saturation-gap (safe-real (hash-ref m 'worker-saturation-gap 0.5) 0.5))
  (define facility-scaling-pressure (safe-real (hash-ref m 'facility-scaling-pressure 0.2) 0.2))
  (define expansion-desire (safe-real (hash-ref m 'expansion-desire 0.0) 0.0))
  (define workers (safe-nonneg-int (hash-ref m 'workers 12) 12))
  (define active-bases (max 1 (safe-nonneg-int (hash-ref m 'active-bases 1) 1)))
  (define escrow-eligible? (eq? (hash-ref m 'escrow-eligible? #f) #t))
  (define requires-anti-air? (eq? (hash-ref m 'requires-anti-air? #f) #t))
  (define requires-detection? (eq? (hash-ref m 'requires-detection? #f) #t))
  (define bo-goal-sym (hash-ref m 'bo-goal-sym #f))
  (define defer-stargate-here?
    (or has-robo? (and (not requires-anti-air?) (not enemy-capital-air?))))
  (define crisis-deferred-here?
    (crisis-deferred-sym? id crisis-defer?
                          #:defer-stargate? defer-stargate-here?
                          #:keep-ship-weapons? ship-weapons-due?))
  (define crisis-defender-here?
    (and crisis-defer? (>= workers 8) (not (not (memq id CRISIS-DEFENDER-SYMS)))))
  (define severe-crisis-static-def?
    (and crisis-defer?
         (or (>= army-supply 4.0) (>= minerals 200))
         (or (< workers 32)
             (< army-supply (* 0.8 enemy-threat-supply))
             (< army-supply 16.0))))

  (define under-threat?
    (or under-attack?
        (>= threat-pressure 1.0)
        (> enemy-threat-supply 0.0)))

  (define gas-sink-active?
    (and (>= gas 100) (>= gas-imbalance 1.5)))

  (define eff-supply (+ (exact->inexact supply-left) (* 8.0 (exact->inexact pending-supply))))
  (define supply-urgent?
    (and (< supply-cap 200)
         (or (> supply-hazard 0.0)
             (and supply-at-risk? (< pending-supply 2) (<= eff-supply (+ supply-buffer 6.0)))
             (and (= pending-supply 0) (<= supply-left supply-buffer)))))

  ;; PV5 boost (+ 180.0) split cleanly between anti-air vs detection roles:
  ;; pure detectors (`observer`, `overseer`, `raven`) match `requires-detection?`,
  ;; pure AA units/tech (`viking-fighter`, `corruptor`, `stalker`, `hydralisk-den`) match `requires-anti-air?`,
  ;; and multi-role static defense (`missile-turret`, `photon-cannon`, `spore-crawler`) matches both.
  (define matches-aa-counter?
    (and requires-anti-air?
         (or (not (not (memq id PV5-ANTI-AIR-SYMS)))
             (and (eq? cat 'counter-tech)
                  (not (memq id PV5-PURE-DETECTOR-SYMS))))))
  (define matches-det-counter?
    (and requires-detection?
         (or (not (not (memq id PV5-DETECTOR-SYMS)))
             (and (eq? cat 'counter-tech)
                  (not (memq id PV5-PURE-ANTI-AIR-SYMS))))))
  (define active-counter-match?
    (or matches-aa-counter? matches-det-counter?))
  (define pv5-boost
    (if active-counter-match?
        (+ 180.0 (if (and matches-aa-counter? matches-det-counter?) 20.0 0.0))
        0.0))

  ;; Information-Gathering Boost (PV9): when opponent intel is stale (`intel-pressure > 0.0`),
  ;; boost units/tech that gather opponent information via scouting, harassment, or probing attack.
  (define intel-gathering-boost
    (cond
      [(<= intel-pressure 0.0) 0.0]
      [(memq id '(observer overseer sentry oracle reaper hellion adept phoenix mutalisk banshee warp-prism medivac))
       (* 65.0 intel-pressure)]
      [(memq id PV-INTEL-GATHERING-UNIT-SYMS)
       (* 42.0 intel-pressure)]
      [else 0.0]))

  ;; General Build-Order Alignment Boost: when the candidate matches the active
  ;; head of the Pro Build Order queue (`bo-goal-sym`), boost its marginal utility
  ;; in proportion to `1 / (1 + 0.5 * threat-pressure)` (and 0 under emergency attack).
  (define bo-head-boost
    (if (and bo-goal-sym (eq? id bo-goal-sym) (not under-attack?))
        (/ 42.0 (+ 1.0 (* 0.5 threat-pressure)))
        0.0))

  (case cat
    [(supply)
     (if supply-urgent?
         (+ 1200.0 (* 300.0 (max 0.1 supply-hazard)))
         12.0)]

    [(intel-gathering)
     (if (>= intel-pressure 1.0)
         (+ 215.0 (* 65.0 intel-pressure) bo-head-boost)
         (+ 55.0 (* 95.0 intel-pressure) bo-head-boost))]

    [(counter-tech)
     (define active-counter-need? active-counter-match?)
     (define counter-matchup-adj
       (cond
         [(and (eq? m-race 'Terran) (eq? m-enemy-race 'Terran) (eq? id 'viking-fighter)) 26.0]
         [(and (eq? m-race 'Terran) (eq? m-enemy-race 'Terran) (eq? id 'factory-techlab)) 28.0]
         [(and (eq? m-race 'Terran) enemy-capital-air? (eq? id 'viking-fighter)) 24.0]
         [else 0.0]))
     (define threat-boost
       (cond
         [(and active-counter-need? under-threat?)
          (+ 135.0 (* 45.0 (min 4.0 threat-pressure)))]
         [active-counter-need?
          (* 30.0 (min 4.0 threat-pressure))]
         [under-threat?
          (+ 28.0 (* 12.0 (min 4.0 threat-pressure)))]
         [else
          (* 8.0 (min 3.0 threat-pressure))]))
     (define counter-crisis-adj
       (if (and crisis-defender-here?
                (or severe-crisis-static-def?
                    (not (memq id '(spine-crawler shield-battery bunker)))))
           (if (memq id '(spine-crawler shield-battery bunker)) 85.0 45.0)
           0.0))
     (define raw-counter-u
       (+ (if active-counter-need? 138.0 118.0) pv5-boost intel-gathering-boost threat-boost counter-matchup-adj counter-crisis-adj bo-head-boost))
     (cond
       [crisis-deferred-here? 5.0]
       [(and (memq id '(spine-crawler shield-battery bunker))
             (< army-supply 4.0)
             (< minerals 200))
        (min 120.0 raw-counter-u)]
       [else raw-counter-u])]

    [(combat-unit)
     (define gas-unit?
       (or (> g-cost 0)
           (memq id PV3-GAS-COMBAT-UNIT-SYMS)))
     (define mineral-only-unit?
       (and (not gas-unit?)
            (or (= g-cost 0)
                (memq id PV3-MINERAL-ONLY-COMBAT-UNIT-SYMS))))
     ;; Continuous tech-tier & resource-value gradient for gas-bearing units:
     ;; higher-tier units with open facility slots (e.g. Colossus > Immortal > Stalker > Zealot;
     ;; Siege Tank > Medivac > Marauder > Marine; Hydralisk > Roach > Zergling) naturally outrank
     ;; lower-tier mineral dumps without any unit-specific special cases.
     (define tech-tier-gradient
       (if gas-unit?
           (min 16.0 (+ (* 0.025 (exact->inexact m-cost))
                        (* 0.075 (exact->inexact g-cost))))
           0.0))
     (define base-combat
       (if gas-unit? (+ 122.0 tech-tier-gradient) 108.0))
     (define threat-boost
       (cond
         [under-attack?
          (+ 165.0 (* 45.0 (min 4.0 threat-pressure)))]
         [under-threat?
          (+ 115.0 (* 35.0 (min 4.0 threat-pressure)))]
         [else
          (* 25.0 threat-pressure)]))
     (define gas-sink-adj
       (cond
         [(and gas-sink-active? gas-unit?)
          (+ 165.0 (* 25.0 (min 4.0 gas-imbalance)))]
         [(and gas-sink-active? mineral-only-unit?)
          -20.0]
         [else 0.0]))
     (define matchup-unit-adj
       (+
        (cond
          [(and (eq? m-race 'Protoss) (eq? m-enemy-race 'Zerg))
           (case id
             [(colossus) 35.0]
             [(immortal) 32.0]
             [(archon) 30.0]
             [(high-templar) 22.0]
             [(zealot) (if (or has-twilight-or-charge? (>= army-supply 4.0) (>= pvz-stalker-count 2))
                           26.0
                           14.0)]
             [(stalker) (if (and (not requires-anti-air?) (not enemy-capital-air?) (>= pvz-stalker-count 3)) -25.0 0.0)]
             [else 0.0])]
          [(and (eq? m-race 'Terran) (eq? m-enemy-race 'Protoss) (eq? id 'marauder) has-rax-tl?)
           34.0]
          [(and (eq? m-race 'Terran) (eq? m-enemy-race 'Terran))
           (case id
             [(siege-tank) 38.0]
             [(marauder) (if has-rax-tl? 32.0 18.0)]
             [(medivac) 24.0]
             [(liberator) 18.0]
             [(marine) 8.0]
             [else 0.0])]
          [else 0.0])
        (if (and (eq? m-race 'Terran) (eq? id 'ghost) (or enemy-needs-ghost? (memq m-enemy-race '(Zerg Protoss))))
            34.0
            0.0)
        (if (and (eq? m-race 'Terran) (eq? id 'liberator) enemy-needs-liberator?)
            38.0
            0.0)
        (if (and (eq? m-race 'Protoss) enemy-capital-air?)
            (case id
              [(tempest) 48.0]
              [(void-ray) 44.0]
              [(stalker) 38.0]
              [(carrier) 24.0]
              [else 0.0])
            0.0)
        (if (and (eq? m-race 'Zerg) (eq? id 'roach) (>= minerals 300) (< roach-cnt 16))
            (if has-hydralisk-den? 1.5 20.0)
            0.0)
        (if (and (eq? m-race 'Zerg) (memq id '(ultralisk brood-lord)) (memq m-enemy-race '(Terran Protoss)))
            12.0
            0.0)
        (if (and (eq? m-race 'Terran) (memq id '(thor thor-ap)) enemy-capital-air?)
            (if enemy-cap-air-ground-aa? 135.0 105.0)
            0.0)
        (if crisis-defender-here?
            (if (and (eq? id 'zealot) (eq? m-race 'Protoss) (>= gas 100)) 30.0 65.0)
            0.0)))
     (if crisis-deferred-here?
         5.0
         (+ base-combat threat-boost gas-sink-adj matchup-unit-adj pv5-boost intel-gathering-boost bo-head-boost))]

    [(tech-upgrade)
     (define outnumbered-by-threat?
       (and (> enemy-threat-supply 0.0)
            (< army-supply (* 1.2 enemy-threat-supply))))
     (define gas-ready-boost
       (if (and (>= gas 100) (not outnumbered-by-threat?)) 45.0 0.0))
     (define threat-research-boost
       (if (and under-threat? (not under-attack?) (not outnumbered-by-threat?) (>= gas 100))
           (+ 110.0 (* 32.0 (min 4.0 threat-pressure)))
           0.0))
     (define gas-sink-boost
       (if gas-sink-active?
           (if outnumbered-by-threat?
               45.0
               (+ 165.0 (* 25.0 (min 4.0 gas-imbalance))))
           (if outnumbered-by-threat?
               0.0
               (* 15.0 (min 2.0 gas-imbalance)))))
     (define tech-matchup-adj
       (+ (if (and (eq? m-race 'Terran) (eq? id 'ghost-academy) (or enemy-needs-ghost? (eq? m-enemy-race 'Zerg))) 38.0 0.0)
          (if (and (eq? m-race 'Terran) (eq? id 'armory) enemy-capital-air?
                   (or enemy-cap-air-ground-aa? has-armory? (>= gas 80)))
              (if enemy-cap-air-ground-aa? 95.0 60.0)
              0.0)
          (if (and (eq? m-race 'Terran) (eq? id 'terran-ship-weapons-1) ship-weapons-due?) 90.0 0.0)
          (if (and (eq? m-race 'Protoss) enemy-capital-air? (eq? id 'fleet-beacon)) 45.0 0.0)))
     (define eff-bo-boost (if outnumbered-by-threat? 0.0 bo-head-boost))
     (if crisis-deferred-here?
         5.0
         (+ 145.0 gas-ready-boost threat-research-boost gas-sink-boost tech-matchup-adj pv5-boost eff-bo-boost))]

    [(production-scaling)
     (define gas-tech-bonus
       (if (> g-cost 0)
           (min 18.0 (* 0.14 (exact->inexact g-cost)))
           0.0))
     (define prod-matchup-adj
       (+ (if (and (eq? m-race 'Terran) (memq m-enemy-race '(Terran Protoss)) (eq? id 'barracks-techlab)) 36.0 0.0)
          (if (and (eq? m-race 'Terran) (eq? m-enemy-race 'Terran) (memq id '(factory factory-techlab))) 38.0 0.0)
          (if (and (eq? m-race 'Protoss) enemy-capital-air? (eq? id 'stargate)) 46.0 0.0)))
     (+ 116.0 gas-tech-bonus (* 45.0 (min 3.0 facility-scaling-pressure)) prod-matchup-adj pv5-boost bo-head-boost)]

    [(worker)
     (define m-army (hash-ref metrics 'army-supply 0.0))
     (define light-non-overrun-threat?
       (and (not under-attack?)
            (<= enemy-threat-supply (* 1.65 (max 6.0 m-army)))))
     (define base-worker-u
       (if (and under-threat? (not light-non-overrun-threat?))
           (* 42.0 worker-saturation-gap)
           (+ 35.0 (* 52.0 worker-saturation-gap))))
     (if (and (not under-attack?)
              (< workers (min 66 (* 22 active-bases))))
         (max (if (and light-non-overrun-threat?
                       (< workers (min 44 (* 22 active-bases))))
                  95.0
                  60.0)
              base-worker-u)
         base-worker-u)]

    [(expansion)
     (cond
       [(<= expansion-desire 0.0) 5.0]
       [(and (= active-bases 1) escrow-eligible?)
        ;; Natural expansion on 1 base when escrow-eligible: outranks passive worker
        ;; and non-crisis units, but stays below supply (>1000), PV5 counter-tech (>=318),
        ;; PV2 crisis combat (>=238), and PV3 gas-sink combat/tech (>=287).
        (+ 175.0 (* 20.0 (min 1.5 expansion-desire)))]
       [else
        ;; PV1: When active-bases >= 2 or (not escrow-eligible?), expansion NEVER
        ;; outranks or blocks tech-upgrade (>=142), counter-tech (>=138),
        ;; production-scaling (>=116), or combat-unit (>=88).
        (+ 48.0 (* 18.0 (min 1.5 expansion-desire)) bo-head-boost)])]

    [else 25.0]))

(define (make-scored-candidate id category action min-cost gas-cost supply-cost blocking-allowed? metrics)
  (define blk-bool (not (not blocking-allowed?)))
  (define raw-cand
    (priority-candidate id category action min-cost gas-cost supply-cost 0.0 'medium blk-bool))
  (define score (compute-candidate-marginal-utility raw-cand metrics))
  (define tier
    (cond
      [(>= score 1000.0) 'critical-supply]
      [(>= score 230.0)  'high-priority]
      [(>= score 110.0)  'standard-macro]
      [else              'background-economy]))
  (priority-candidate id category action min-cost gas-cost supply-cost score tier blk-bool))

(define (generate-race-priority-candidates
         #:race [raw-race 'Zerg]
         #:frame [raw-frame 0]
         #:minerals [raw-minerals 200]
         #:gas [raw-gas 0]
         #:supply-left [raw-supply-left 4]
         #:supply-cap [raw-supply-cap 15]
         #:pending-supply [raw-pending-supply 0]
         #:workers [raw-workers 12]
         #:target-workers [raw-target-workers 44]
         #:active-bases [raw-active-bases 1]
         #:desired-bases [raw-desired-bases 2]
         #:production-facilities [raw-prod-facilities 1]
         #:max-facilities [raw-max-facilities 4]
         #:army-supply [raw-army-supply 0]
         #:enemy-threat-supply [raw-enemy-threat-supply 0]
         #:under-attack? [raw-under-attack? #f]
         #:requires-anti-air? [raw-requires-anti-air? #f]
         #:requires-detection? [raw-requires-detection? #f]
         #:escrow-age-frames [raw-escrow-age-frames 0]
         #:max-escrow-frames [raw-max-escrow-frames 224]
         #:intel-staleness-frames [raw-intel-staleness-frames 0]
         #:max-intel-staleness-frames [raw-max-intel-staleness-frames 268]
         #:supply-at-risk? [raw-supply-at-risk? #f]
         #:supply-buffer [override-supply-buffer #f]
         #:ally-buildings [ally-buildings '()]
         #:ready-buildings [ready-buildings #f]
         #:open-prod-slots [open-prod-slots #f]
         #:bo-active-goal [bo-active-goal #f]
         #:ally-units [ally-units '()]
         #:researched-upgrades [researched-upgrades '()]
         #:random-stealth-plan [_random-stealth-plan #f]
         #:enemy-race [raw-enemy-race 'Unknown]
         #:enemy-unit-counts [raw-enemy-unit-counts #f]
         #:base-x [raw-base-x 32.5]
         #:base-y [raw-base-y 32.5]
         #:nat-x [raw-nat-x 50.5]
         #:nat-y [raw-nat-y 50.5]
         #:third-x [raw-third-x 60.5]
         #:third-y [raw-third-y 40.5])
  (define race (normalize-ledger-race raw-race))
  (define enemy-race (normalize-enemy-race-sym raw-enemy-race))
  (define enemy-u-counts (and (hash? raw-enemy-unit-counts) raw-enemy-unit-counts))
  (define enemy-cap-air? (protoss-enemy-capital-air? enemy-u-counts))
  (define active-bases (max 1 (safe-nonneg-int raw-active-bases 1)))
  (define base-x (safe-tile-coord raw-base-x 32.5))
  (define base-y (safe-tile-coord raw-base-y 32.5))
  (define nat-x (safe-tile-coord raw-nat-x 50.5))
  (define nat-y (safe-tile-coord raw-nat-y 50.5))
  (define third-x (safe-tile-coord raw-third-x 60.5))
  (define third-y (safe-tile-coord raw-third-y 40.5))
  (define exp-x (if (>= active-bases 2) third-x nat-x))
  (define exp-y (if (>= active-bases 2) third-y nat-y))
  (define upgs (if (list? researched-upgrades) researched-upgrades '()))
  (define bldgs (if (list? ally-buildings) ally-buildings '()))
  (define r-bldgs (if (list? ready-buildings) ready-buildings bldgs))
  (define (bldg-eq-count sym)
    (define eqs (sc2-structure-equivalent-syms sym #f))
    (count (lambda (b) (not (not (memq b eqs)))) bldgs))
  (define (ready-bldg-eq-count sym)
    (define eqs (sc2-structure-equivalent-syms sym #f))
    (count (lambda (b) (not (not (memq b eqs)))) r-bldgs))
  (define enemy-ground-army?
    (if (and (hash? enemy-u-counts) (> (hash-count enemy-u-counts) 0))
        (let ([ground-cnt
               (for/sum ([(utype cnt) (in-hash enemy-u-counts)]
                         #:when (and (> (safe-nonneg-int cnt 0) 0)
                                     (not (memq utype
                                                '(drone scv probe larva egg cocoon
                                                  overlord overlord-transport overseer overseer-siege-mode
                                                  observer observer-siege-mode medivac warp-prism warp-prism-phasing
                                                  mutalisk corruptor brood-lord broodlord viper
                                                  viking viking-fighter liberator banshee raven battlecruiser
                                                  phoenix oracle void-ray voidray carrier tempest mothership interceptor)))))
                 (safe-nonneg-int cnt 0))]
              [air-combat-cnt
               (for/sum ([(utype cnt) (in-hash enemy-u-counts)]
                         #:when (memq utype '(mutalisk corruptor brood-lord broodlord viper
                                               viking viking-fighter liberator banshee raven battlecruiser
                                               phoenix oracle void-ray voidray carrier tempest mothership)))
                 (safe-nonneg-int cnt 0))])
          (or (> ground-cnt 0)
              (and (not raw-requires-anti-air?) (= air-combat-cnt 0))))
        (not raw-requires-anti-air?)))
  (define live-workers (safe-nonneg-int raw-workers 12))
  (define has-robo? (> (bldg-eq-count 'robotics-facility) 0))
  (define has-armory? (> (bldg-eq-count 'armory) 0))
  (define has-ready-armory? (> (ready-bldg-eq-count 'armory) 0))
  (define units (if (list? ally-units) ally-units '()))
  (define bo-goal-sym (and (pro-bo-goal? bo-active-goal) (pro-bo-goal-target-sym bo-active-goal)))
  (define crisis-defer?
    (crisis-defense-tech-defer-active?
     raw-under-attack? raw-army-supply raw-enemy-threat-supply live-workers))
  (define defer-stargate?
    (or has-robo? (and (not raw-requires-anti-air?) (not enemy-cap-air?))))
  (define enemy-cap-air-ground-aa?
    (terran-enemy-capital-air-with-ground-aa? enemy-u-counts))
  (define desired-thor-cap (terran-desired-thor-cap enemy-u-counts))
  (define air-fleet-cnt (terran-air-fleet-count units))
  (define ship-weap-due?
    (terran-ship-weapons-due? race air-fleet-cnt has-ready-armory? upgs))
  (define severe-crisis-static-def?
    (and crisis-defer?
         (or (>= (safe-real raw-army-supply 0.0) 4.0) (>= (safe-nonneg-int raw-minerals 0) 200))
         (or (< live-workers 32)
             (< (safe-real raw-army-supply 0.0) (* 0.8 (safe-real raw-enemy-threat-supply 0.0)))
             (< (safe-real raw-army-supply 0.0) 16.0))))

  (define base-metrics
    (compute-state-pressure-metrics
     #:race race
     #:frame raw-frame
     #:minerals raw-minerals
     #:gas raw-gas
     #:supply-left raw-supply-left
     #:supply-cap raw-supply-cap
     #:pending-supply raw-pending-supply
     #:workers raw-workers
     #:target-workers raw-target-workers
     #:active-bases active-bases
     #:desired-bases raw-desired-bases
     #:production-facilities raw-prod-facilities
     #:max-facilities raw-max-facilities
     #:army-supply raw-army-supply
     #:enemy-threat-supply raw-enemy-threat-supply
     #:under-attack? raw-under-attack?
     #:requires-anti-air? raw-requires-anti-air?
     #:requires-detection? raw-requires-detection?
     #:escrow-age-frames raw-escrow-age-frames
     #:max-escrow-frames raw-max-escrow-frames
     #:intel-staleness-frames raw-intel-staleness-frames
     #:max-intel-staleness-frames raw-max-intel-staleness-frames
     #:supply-at-risk? raw-supply-at-risk?
     #:supply-buffer override-supply-buffer))

  (define metrics
    (enrich-priority-metrics
     base-metrics
     #:race race
     #:enemy-race enemy-race
     #:minerals raw-minerals
     #:active-bases active-bases
     #:under-attack? raw-under-attack?
     #:requires-anti-air? raw-requires-anti-air?
     #:army-supply raw-army-supply
     #:enemy-threat-supply raw-enemy-threat-supply
     #:workers live-workers
     #:has-barracks-techlab? (or (memq 'barracks-techlab r-bldgs)
                                 (memq 'barracks-tech-lab r-bldgs))
     #:has-twilight-or-charge? (or (memq 'twilight-council r-bldgs)
                                   (memq 'charge upgs))
     #:has-hydralisk-den? (memq 'hydralisk-den r-bldgs)
     #:has-robo? has-robo?
     #:has-armory? has-armory?
     #:crisis-defense-defer? crisis-defer?
     #:enemy-capital-air-ground-aa? enemy-cap-air-ground-aa?
     #:terran-ship-weapons-due? ship-weap-due?
     #:stalker-count (count (lambda (u) (eq? u 'stalker)) units)
     #:roach-count (count (lambda (u) (eq? u 'roach)) units)
     #:enemy-unit-counts enemy-u-counts
     #:bo-goal-sym bo-goal-sym))

  (define frame-val (safe-nonneg-int raw-frame 0))
  (define min-val (safe-nonneg-int raw-minerals 0))
  (define sup-used
    (max 0 (- (safe-nonneg-int raw-supply-cap 15)
              (max 0 (safe-exact-int raw-supply-left 4)))))
  (define army-val (max 0.0 (safe-real raw-army-supply 0.0)))
  (define threat-val (max 0.0 (safe-real raw-enemy-threat-supply 0.0)))
  (define root-combat-ready?
    (case race
      [(Zerg) (not (not (memq 'spawning-pool r-bldgs)))]
      [(Terran) (not (not (memq 'barracks r-bldgs)))]
      [else (or (not (not (memq 'gateway r-bldgs)))
                (not (not (memq 'warp-gate r-bldgs))))]))
  (define under-early-rush-crisis?
    (and (hash? open-prod-slots)
         (< frame-val 3000)
         (or (eq? raw-under-attack? #t) (>= threat-val 4.0))))
  (define t3-endgame?
    (and (hash? open-prod-slots)
         (>= active-bases 3)
         (or (>= live-workers 50) (>= sup-used 90))))
  (define zerg-army-step-ok?
    (zerg-worker-army-floor-ok? race enemy-race live-workers army-val))
  (define zerg-3base-interleave-ok?
    (and (eq? race 'Zerg)
         (>= active-bases 3)
         (< live-workers 55)
         (not raw-under-attack?)
         zerg-army-step-ok?
         (>= army-val 4.0)))
  (define worker-curve-ok?
    (or (not (hash? open-prod-slots))
        (and zerg-army-step-ok?
             (or (< live-workers 24)
                 zerg-3base-interleave-ok?
                 (and (not raw-under-attack?)
                      (< live-workers (min 44 (* 22 active-bases)))
                      (or (<= threat-val 0.0)
                          (and (< threat-val 18.0)
                               (<= threat-val (* 1.65 (max 6.0 army-val))))))
                 (>= army-val (required-army-supply-for-worker-growth live-workers threat-val))))))
  (define emergency-army-before-workers?
    (and (or raw-under-attack? (> threat-val 0.0))
         (< army-val 4.0)
         root-combat-ready?
         (>= live-workers 1)))
  (define worker-survival-crisis?
    (and (hash? open-prod-slots)
         (< live-workers 6)
         (not emergency-army-before-workers?)))
  (define escrow-ok?
    (and (not worker-survival-crisis?)
         (or (eq? (hash-ref metrics 'escrow-eligible? #f) #t)
             ;; Camped-natural redirect unblock: allow 1-base expansion once >= 350M & basic defense ready
             (and (hash? open-prod-slots)
                  (= active-bases 1)
                  (not raw-under-attack?)
                  (<= threat-val 0.0)
                  (>= min-val 350)
                  (>= frame-val 2688)
                  (or root-combat-ready? (>= army-val 6.0))))))
  (define exp-blocking?
    (and (or (= active-bases 1)
             (protoss-4th-nexus-due? race active-bases live-workers army-val min-val enemy-cap-air?)
             (and (hash? open-prod-slots)
                  (not (not (memq bo-goal-sym '(hatchery nexus command-center))))))
         escrow-ok?
         (if (hash? open-prod-slots)
             (or (protoss-4th-nexus-due? race active-bases live-workers army-val min-val enemy-cap-air?)
                 (not (not (memq bo-goal-sym '(hatchery nexus command-center))))
                 (>= min-val 350)
                 (>= live-workers (if (eq? race 'Zerg) 16 19)))
             #t)))
  (define supply-urgent? (> (hash-ref metrics 'supply-hazard 0.0) 0.0))

  ;; When `open-prod-slots` is provided, a facility's production/addon candidate is
  ;; `blocking-allowed? = #t` iff its prerequisite structure is ready AND its facility has
  ;; an open production slot (> 0) AND we are not in a `< 6` worker starvation crisis.
  ;; When `open-prod-slots` is #f (synthetic tests / PV lattice),
  ;; default to #t so all formal PV1-PV6 lattice checks evaluate all candidates.
  (define (facility-slot-open? slot-key [prereq-sym #f])
    (if (hash? open-prod-slots)
        (and (not worker-survival-crisis?)
             (> (hash-ref open-prod-slots slot-key 0) 0)
             (or (not prereq-sym) (not (not (memq prereq-sym r-bldgs)))))
        #t))

  (define (cand id category action blocking-allowed?)
    (define base-c
      (make-scored-candidate id
                             category
                             action
                             (sc2-min-cost id)
                             (sc2-gas-cost id)
                             (sc2-supply-cost id 0)
                             (if (and worker-survival-crisis? (not (memq category '(supply worker))))
                                 #f
                                 blocking-allowed?)
                             metrics))
    (cond
      [(and (eq? category 'worker) (hash? open-prod-slots) (>= live-workers 70))
       (struct-copy priority-candidate base-c
                    [utility-score 20.0]
                    [blocking-allowed? #f])]
      [(and (eq? category 'worker)
            (hash? open-prod-slots)
            (< live-workers 8)
            (not emergency-army-before-workers?))
       (struct-copy priority-candidate base-c
                    [utility-score (+ (priority-candidate-utility-score base-c)
                                      (* 120.0 (- 8.0 live-workers)))]
                    [blocking-allowed? (> live-workers 0)])]
      [(and (eq? category 'worker)
            (hash? open-prod-slots)
            (not worker-curve-ok?))
       (struct-copy priority-candidate base-c
                    [utility-score (min 105.0 (* 0.55 (priority-candidate-utility-score base-c)))]
                    [blocking-allowed? #f])]
      [else base-c]))

  (define (boost-cand id category action blocking-allowed? bonus-u)
    (define c0 (cand id category action blocking-allowed?))
    (if (and (hash? open-prod-slots) (> bonus-u 0.0))
        (let ([new-u (+ (priority-candidate-utility-score c0) bonus-u)])
          (struct-copy priority-candidate c0
                       [utility-score new-u]
                       [urgency-tier (if (>= new-u 230.0)
                                         'high-priority
                                         (priority-candidate-urgency-tier c0))]))
        c0))

  (case race
    [(Zerg)
     (define has-lair-or-hive?
       (or (not (not (memq 'lair r-bldgs)))
           (not (not (memq 'hive r-bldgs)))))
     (define has-hive? (not (not (memq 'hive r-bldgs))))
     (define has-ultra-cavern? (not (not (memq 'ultralisk-cavern r-bldgs))))
     (define upg-sym
       (cond
         [(not (memq 'metabolic-boost upgs)) 'metabolic-boost]
         [(not (memq 'glial-reconstitution upgs)) 'glial-reconstitution]
         [(not (memq 'zerg-missile-weapons-1 upgs)) 'zerg-missile-weapons-1]
         [(not (memq 'burrow upgs)) 'burrow]
         [(not (memq 'tunneling-claws upgs)) 'tunneling-claws]
         [(not (memq 'zerg-ground-armor-1 upgs)) 'zerg-ground-armor-1]
         [(not (memq 'grooved-spines upgs)) 'grooved-spines]
         [(not (memq 'muscular-augments upgs)) 'muscular-augments]
         [(and has-ultra-cavern? (not (memq 'chitinous-plating upgs))) 'chitinous-plating]
         [(and has-ultra-cavern? (not (memq 'anabolic-synthesis upgs))) 'anabolic-synthesis]
         [(not (memq 'zerg-missile-weapons-2 upgs)) 'zerg-missile-weapons-2]
         [(not (memq 'zerg-ground-armor-2 upgs)) 'zerg-ground-armor-2]
         [(not (memq 'centrifical-hooks upgs)) 'centrifical-hooks]
         [else 'zerg-missile-weapons-3]))
     (define zerg-upg-ready?
       (if (hash? open-prod-slots)
           (case upg-sym
             [(metabolic-boost) (not (not (memq 'spawning-pool r-bldgs)))]
             [(burrow) (or (not (not (memq 'hatchery r-bldgs))) has-lair-or-hive?)]
             [(glial-reconstitution tunneling-claws)
              (and (not (not (memq 'roach-warren r-bldgs))) has-lair-or-hive?)]
             [(grooved-spines) (not (not (memq 'hydralisk-den r-bldgs)))]
             [(muscular-augments) (and (not (not (memq 'hydralisk-den r-bldgs))) has-lair-or-hive?)]
             [(centrifical-hooks) (and (not (not (memq 'baneling-nest r-bldgs))) has-lair-or-hive?)]
             [(chitinous-plating anabolic-synthesis) has-ultra-cavern?]
             [(zerg-missile-weapons-2 zerg-ground-armor-2)
              (and (not (not (memq 'evolution-chamber r-bldgs))) has-lair-or-hive?)]
             [(zerg-missile-weapons-3)
              (and (not (not (memq 'evolution-chamber r-bldgs))) has-hive?)]
             [else (not (not (memq 'evolution-chamber r-bldgs)))])
           #t))
     (define cur-queens (count (lambda (u) (memq u '(queen queen-burrowed))) units))
     (define max-queens (min SC2-MAX-QUEENS-CAP (+ active-bases (if (>= active-bases 2) 2 1))))
     (define cur-overseers (count (lambda (u) (memq u '(overseer overseer-siege-mode overlord-cocoon))) units))
     (define want-overseers (if (or (>= army-val 40.0) raw-requires-detection?) 2 1))
     (define zerg-rush-cands
       (if (or under-early-rush-crisis? severe-crisis-static-def?)
           (append
            (if (and under-early-rush-crisis? (not (memq 'spawning-pool bldgs)))
                (list (boost-cand 'spawning-pool 'production-scaling
                                  (list 'build 'spawning-pool (safe-tile-coord (+ base-x 3.5)) (safe-tile-coord (- base-y 3.5)))
                                  #t 500.0))
                '())
            (if (and root-combat-ready? (< (bldg-eq-count 'spine-crawler) (if severe-crisis-static-def? 2 1)))
                (list (boost-cand 'spine-crawler 'counter-tech
                                  (list 'build 'spine-crawler (safe-tile-coord (+ base-x 3.0)) (safe-tile-coord (- base-y 3.0)))
                                  #t (if under-early-rush-crisis? 260.0 165.0)))
                '()))
           '()))
     (define zerg-pit-spire-army-ok?
       (and (>= active-bases 3) (>= army-val 28.0)))
     (define corruptor-cap
       (sc2-zerg-corruptor-target-cap enemy-u-counts raw-requires-anti-air? enemy-race))
     (define cur-corruptors
       (count (lambda (u) (memq u '(corruptor brood-lord broodlord brood-lord-cocoon))) units))
     (define zerg-t3-cands
       (append
        ;; Emergency AA Spire remains permitted when `raw-requires-anti-air?` is #t even before T3 army threshold
        ;; unless base-defense crisis tech deferral is active; normal `infestation-pit` and `spire` wait for 3 bases + 28 army.
        (if (and (not crisis-defer?)
                 has-lair-or-hive?
                 (= (bldg-eq-count 'infestation-pit) 0)
                 (or zerg-pit-spire-army-ok?
                     raw-requires-anti-air?
                     raw-requires-detection?))
            (list (boost-cand 'infestation-pit 'tech-upgrade
                              (list 'build 'infestation-pit (safe-tile-coord (+ base-x 5.5)) (safe-tile-coord (- base-y 4.5)))
                              #t 145.0))
            '())
        (if (and (not crisis-defer?)
                 has-lair-or-hive?
                 (= (bldg-eq-count 'spire) 0)
                 (or zerg-pit-spire-army-ok? raw-requires-anti-air?))
            (list (boost-cand 'spire 'tech-upgrade
                              (list 'build 'spire (safe-tile-coord (- base-x 4.5)) (safe-tile-coord (+ base-y 4.5)))
                              #t 140.0))
            '())
        (if (and (or (> corruptor-cap 0)
                     (and (memq 'greater-spire r-bldgs) (= cur-corruptors 0)))
                 (or (memq 'spire r-bldgs) (memq 'greater-spire r-bldgs))
                 (facility-slot-open? 'larva)
                 (or (memq 'greater-spire bldgs) raw-requires-anti-air?)
                 (< cur-corruptors (max corruptor-cap (if (memq 'greater-spire r-bldgs) 2 0))))
            (list (boost-cand 'corruptor 'combat-unit '(train corruptor) #t 135.0))
            '())
        ;; Ready-tech Zerg siege-breakers: never disappear below 3 bases / 50 workers once tech is ready
        (if (and (facility-slot-open? 'larva 'ultralisk-cavern)
                 (< (count (lambda (u) (memq u '(ultralisk ultralisk-burrowed))) units) 6))
            (list (boost-cand 'ultralisk 'combat-unit '(train ultralisk) #t 155.0))
            '())
        (if (and (memq 'greater-spire r-bldgs)
                 (memq 'corruptor units)
                 (< (count (lambda (u) (memq u '(brood-lord broodlord brood-lord-cocoon))) units) 6))
            (list (boost-cand 'brood-lord 'combat-unit '(morph brood-lord) #t 160.0))
            '())
        (if (and t3-endgame? (not crisis-defer?))
            (append
             (if (and (memq 'lair r-bldgs) (memq 'infestation-pit r-bldgs) (= (bldg-eq-count 'hive) 0))
                 (list (boost-cand 'hive 'tech-upgrade '(morph hive) #t 165.0))
                 '())
             (if (and has-hive? (= (bldg-eq-count 'ultralisk-cavern) 0))
                 (list (boost-cand 'ultralisk-cavern 'tech-upgrade
                                   (list 'build 'ultralisk-cavern (safe-tile-coord (+ base-x 6.5)) (safe-tile-coord (+ base-y 4.5)))
                                   #t 155.0))
                 '())
             (if (and has-hive? (memq 'spire r-bldgs) (= (bldg-eq-count 'greater-spire) 0))
                 (list (boost-cand 'greater-spire 'tech-upgrade '(morph greater-spire) #t 155.0))
                 '())
             (if (and (facility-slot-open? 'larva 'hive)
                      (< (count (lambda (u) (eq? u 'viper)) units) 3))
                 (list (boost-cand 'viper 'combat-unit '(train viper) #t 150.0))
                 '())
             (if (and (facility-slot-open? 'larva 'infestation-pit)
                      (< (count (lambda (u) (memq u '(infestor infestor-burrowed))) units) 2))
                 (list (boost-cand 'infestor 'combat-unit '(train infestor) #t 135.0))
                 '()))
            '())))
     (define cur-zerglings (count (lambda (u) (memq u '(zergling zergling-burrowed))) units))
     (define cur-roaches (count (lambda (u) (memq u '(roach roach-burrowed))) units))
     (define ling-cap (zergling-target-cap min-val enemy-u-counts))
     (define cur-banelings (count (lambda (u) (memq u '(baneling baneling-burrowed baneling-cocoon))) units))
     (define baneling-cap (min 12 (max 4 (quotient cur-zerglings 2))))
     (define cur-hydras (count (lambda (u) (memq u '(hydralisk hydralisk-burrowed))) units))
     (define cur-lurkers
       (count (lambda (u) (memq u '(lurker lurker-burrowed lurker-mp lurker-mp-burrowed lurker-egg lurker-mp-egg))) units))
     (define cur-ravagers
       (count (lambda (u) (memq u '(ravager ravager-cocoon))) units))
     (define zerg-morph-cands
       (append
        (if (and crisis-defer?
                 (> (ready-bldg-eq-count 'roach-warren) 0)
                 (> cur-roaches 0)
                 (< cur-ravagers (min 6 cur-roaches)))
            (list (boost-cand 'ravager 'combat-unit '(morph ravager) #t 145.0))
            '())
        (if (and (> (ready-bldg-eq-count 'baneling-nest) 0)
                 (>= cur-zerglings 8)
                 enemy-ground-army?
                 (< cur-banelings baneling-cap))
            (list (boost-cand 'baneling 'combat-unit '(morph baneling) #t
                              (if (< cur-banelings 4) 155.0 135.0)))
            '())
        (if (and (> (ready-bldg-eq-count 'lurker-den) 0)
                 (>= cur-hydras 2)
                 (< cur-lurkers 10))
            (list (boost-cand 'lurker 'combat-unit '(morph lurker) #t
                              (if (< cur-lurkers 4) 170.0 145.0)))
            '())))
     (append
      zerg-rush-cands
      zerg-morph-cands
      (list
       (cand 'overlord 'supply '(train overlord) supply-urgent?)
       (cand 'spore-crawler 'counter-tech (list 'build 'spore-crawler (safe-tile-coord (+ base-x 3.0)) (safe-tile-coord (+ base-y 3.0)))
             (if (hash? open-prod-slots) (or raw-requires-anti-air? raw-requires-detection?) #t))
       (cand 'queen 'counter-tech '(train queen)
             (and (facility-slot-open? 'townhall 'spawning-pool)
                  (if (hash? open-prod-slots) (< cur-queens max-queens) #t)))
       (cand 'hydralisk-den 'counter-tech (list 'build 'hydralisk-den (safe-tile-coord (+ base-x 4.0)) (safe-tile-coord (+ base-y 5.0)))
             (if (hash? open-prod-slots) (and has-lair-or-hive? (= (bldg-eq-count 'hydralisk-den) 0)) #t))
       (boost-cand 'overseer 'counter-tech '(morph overseer)
                   (if (hash? open-prod-slots)
                       (and has-lair-or-hive? (< cur-overseers want-overseers))
                       #t)
                   (if (and has-lair-or-hive? (= cur-overseers 0)) 140.0 0.0))
       (boost-cand 'roach 'combat-unit '(train roach)
                   (facility-slot-open? 'larva 'roach-warren)
                   (if (and (>= min-val 300) (< cur-roaches 16) (not (memq 'hydralisk-den r-bldgs))) 20.0 0.0))
       (cand 'hydralisk 'combat-unit '(train hydralisk) (facility-slot-open? 'larva 'hydralisk-den)))
      (if (or (not (hash? open-prod-slots)) (< cur-zerglings ling-cap))
          (list (cand 'zergling 'combat-unit '(train zergling) (facility-slot-open? 'larva 'spawning-pool)))
          '())
      (if (crisis-deferred-sym? upg-sym crisis-defer?)
          '()
          (list (cand upg-sym 'tech-upgrade (list 'research upg-sym) zerg-upg-ready?)))
      (list
       (cand 'roach-warren 'production-scaling (list 'build 'roach-warren (safe-tile-coord (+ base-x 4.0)) (safe-tile-coord (- base-y 4.0)))
             (if (hash? open-prod-slots) (and (memq 'spawning-pool r-bldgs) (= (bldg-eq-count 'roach-warren) 0)) #t))
       (cand 'drone 'worker '(train drone) #f)
       (cand 'hatchery 'expansion (list 'expand exp-x exp-y) exp-blocking?))
      zerg-t3-cands)]

    [(Protoss)
     (define has-templar-arch?
       (or (not (not (memq 'templar-archive r-bldgs)))
           (not (not (memq 'templar-archives r-bldgs)))))
     (define has-robo-bay?
       (or (not (not (memq 'robotics-bay r-bldgs)))
           (not (not (memq 'robotics-support-bay r-bldgs)))))
     (define has-colossus?
       (>= (count (lambda (u) (eq? u 'colossus)) units) 1))
     (define upg-sym
       (cond
         [(not (memq 'warp-gate-research upgs)) 'warp-gate-research]
         [(not (memq 'charge upgs)) 'charge]
         [(not (memq 'protoss-ground-weapons-1 upgs)) 'protoss-ground-weapons-1]
         [(not (memq 'blink upgs)) 'blink]
         [(not (memq 'protoss-ground-armor-1 upgs)) 'protoss-ground-armor-1]
         [(and has-robo-bay? has-colossus? (not (memq 'extended-thermal-lance upgs))) 'extended-thermal-lance]
         [(and has-templar-arch? (not (memq 'psi-storm upgs))) 'psi-storm]
         [(not (memq 'protoss-ground-weapons-2 upgs)) 'protoss-ground-weapons-2]
         [(not (memq 'protoss-ground-armor-2 upgs)) 'protoss-ground-armor-2]
         [else 'protoss-shields-1]))
     (define robo-open?
       (and (facility-slot-open? 'robotics-facility 'robotics-facility)
            (if (hash? open-prod-slots)
                (< (count (lambda (u) (memq u '(immortal colossus))) units)
                   (if t3-endgame? 6 3))
                #t)))
     (define protoss-rush-cands
       (if (or under-early-rush-crisis? severe-crisis-static-def?)
           (append
            (if (and under-early-rush-crisis? (memq 'pylon r-bldgs) (= (bldg-eq-count 'gateway) 0))
                (list (boost-cand 'gateway 'production-scaling
                                  (list 'build 'gateway (safe-tile-coord (+ base-x 4.0)) (safe-tile-coord (+ base-y 4.0)))
                                  #t 500.0))
                '())
            (if (and (memq 'cybernetics-core r-bldgs)
                     (< (bldg-eq-count 'shield-battery) (if severe-crisis-static-def? 2 1)))
                (list (boost-cand 'shield-battery 'counter-tech
                                  (list 'build 'shield-battery (safe-tile-coord (+ base-x 3.0)) (safe-tile-coord (+ base-y 3.0)))
                                  #t (if under-early-rush-crisis? 260.0 165.0)))
                '())
            (if (and under-early-rush-crisis?
                     (memq 'cybernetics-core r-bldgs)
                     (facility-slot-open? 'gateway 'cybernetics-core))
                (list (boost-cand 'stalker 'combat-unit '(train stalker) #t 280.0)
                      (boost-cand 'adept 'combat-unit '(train adept) #t 240.0))
                '()))
           '()))
     (define protoss-ready-tech-units
       (append
        (if (and has-robo-bay?
                 (facility-slot-open? 'robotics-facility 'robotics-facility)
                 (< (count (lambda (u) (eq? u 'colossus)) units) 4))
            (list (boost-cand 'colossus 'combat-unit '(train colossus) #t 150.0))
            '())
        (if (and has-robo-bay?
                 (facility-slot-open? 'robotics-facility 'robotics-facility)
                 (< (count (lambda (u) (memq u '(disruptor disruptor-phased))) units) 2))
            (list (boost-cand 'disruptor 'combat-unit '(train disruptor) #t 140.0))
            '())
        (if (and has-templar-arch?
                 (or (facility-slot-open? 'gateway) (facility-slot-open? 'warp-gate))
                 (< (count (lambda (u) (eq? u 'high-templar)) units) 4))
            (list (boost-cand 'high-templar 'combat-unit '(train high-templar) #t 145.0))
            '())
        (if (and (>= (count (lambda (u) (eq? u 'high-templar)) units) 2)
                 (< (count (lambda (u) (eq? u 'archon)) units) 4))
            (list (boost-cand 'archon 'combat-unit '(morph archon) #t 150.0))
            '())))
     (define protoss-t3-cands
       (append
        protoss-ready-tech-units
        ;; Anti-Capital-Air (`tempest`, `carrier`, `battlecruiser`, `brood-lord`): unlock Stargate/Void-Ray/Fleet-Beacon/Tempest
        ;; immediately regardless of base count or `t3-endgame?` (#5122493 fix).
        (if (and (or enemy-cap-air? raw-requires-anti-air?)
                 (facility-slot-open? 'stargate 'stargate)
                 (< (count (lambda (u) (memq u '(void-ray voidray))) units)
                    (if enemy-cap-air? 8 4)))
            (list (boost-cand 'void-ray 'combat-unit '(train void-ray) #t
                              (if enemy-cap-air? 165.0 135.0)))
            '())
        (if (and (memq 'fleet-beacon r-bldgs)
                 (facility-slot-open? 'stargate 'fleet-beacon)
                 (or t3-endgame? enemy-cap-air?)
                 (< (count (lambda (u) (eq? u 'tempest)) units)
                    (if enemy-cap-air? 6 3)))
            (list (boost-cand 'tempest 'combat-unit '(train tempest) #t
                              (if enemy-cap-air? 170.0 145.0)))
            '())
        (if (and (not (crisis-deferred-sym? 'stargate crisis-defer? #:defer-stargate? defer-stargate?))
                 (or enemy-cap-air?
                     (and t3-endgame?
                          (>= active-bases 4)
                          (not (and (<= active-bases 2)
                                    (not raw-requires-anti-air?)
                                    (not raw-requires-detection?)
                                    (> (bldg-eq-count 'robotics-facility) 0)
                                    (> (bldg-eq-count 'twilight-council) 0)))))
                 (memq 'cybernetics-core r-bldgs)
                 (= (bldg-eq-count 'stargate) 0))
            (list (boost-cand 'stargate 'production-scaling
                              (list 'build 'stargate (safe-tile-coord (+ base-x 5.5)) (safe-tile-coord (+ base-y 5.5)))
                              #t (if enemy-cap-air? 160.0 140.0)))
            '())
        (if (and (not crisis-defer?)
                 (or enemy-cap-air? (and t3-endgame? (>= active-bases 4)))
                 (memq 'stargate r-bldgs)
                 (= (bldg-eq-count 'fleet-beacon) 0))
            (list (boost-cand 'fleet-beacon 'tech-upgrade
                              (list 'build 'fleet-beacon (safe-tile-coord (- base-x 6.5)) (safe-tile-coord (+ base-y 5.5)))
                              #t (if enemy-cap-air? 160.0 150.0)))
            '())
        (if (and t3-endgame? (not crisis-defer?))
            (append
             (if (and (memq 'robotics-facility r-bldgs) (= (bldg-eq-count 'robotics-bay) 0))
                 (list (boost-cand 'robotics-bay 'tech-upgrade
                                   (list 'build 'robotics-bay (safe-tile-coord (+ base-x 6.5)) (safe-tile-coord (- base-y 4.5)))
                                   #t 150.0))
                 '())
             (if (and (memq 'cybernetics-core r-bldgs) (= (bldg-eq-count 'twilight-council) 0))
                 (list (boost-cand 'twilight-council 'tech-upgrade
                                   (list 'build 'twilight-council (safe-tile-coord (- base-x 4.5)) (safe-tile-coord (+ base-y 4.5)))
                                   #t 145.0))
                 '())
             (if (and (memq 'twilight-council r-bldgs) (= (bldg-eq-count 'templar-archive) 0))
                 (list (boost-cand 'templar-archive 'tech-upgrade
                                   (list 'build 'templar-archive (safe-tile-coord (- base-x 5.5)) (safe-tile-coord (- base-y 4.5)))
                                   #t 150.0))
                 '())
             (if (and (>= active-bases 4)
                      (memq 'fleet-beacon r-bldgs)
                      (facility-slot-open? 'stargate 'fleet-beacon)
                      (< (count (lambda (u) (eq? u 'carrier)) units) 4))
                 (list (boost-cand 'carrier 'combat-unit '(train carrier) #t 150.0))
                 '()))
            '())))
     (append
      protoss-rush-cands
      (list
       (cand 'pylon 'supply (list 'build 'pylon (safe-tile-coord (+ base-x 4.0)) (safe-tile-coord (+ base-y 4.0))) supply-urgent?)
       (cand 'photon-cannon 'counter-tech (list 'build 'photon-cannon nat-x nat-y)
             (if (hash? open-prod-slots) (and (or raw-requires-anti-air? raw-requires-detection?) (memq 'forge r-bldgs)) #t))
       (cand 'robotics-facility 'counter-tech (list 'build 'robotics-facility (safe-tile-coord (+ base-x 6.0)) (safe-tile-coord (+ base-y 6.0)))
             (if (hash? open-prod-slots) (and (memq 'cybernetics-core r-bldgs) (not (memq 'robotics-facility bldgs))) #t))
       (cand 'observer 'counter-tech '(train observer)
             (and (facility-slot-open? 'robotics-facility 'robotics-facility)
                  (if (hash? open-prod-slots) (not (memq 'observer units)) #t)))
       (boost-cand 'stalker 'combat-unit '(train stalker)
                   (facility-slot-open? 'gateway 'cybernetics-core)
                   (if enemy-cap-air? 155.0 0.0))
       (cand 'immortal 'combat-unit '(train immortal) robo-open?)
       (cand 'zealot 'combat-unit '(train zealot)
             (facility-slot-open? 'gateway)))
      (if (crisis-deferred-sym? upg-sym crisis-defer?)
          '()
          (list
           (cand upg-sym 'tech-upgrade (list 'research upg-sym)
                 (if (hash? open-prod-slots)
                     (case upg-sym
                       [(warp-gate-research) (not (not (memq 'cybernetics-core r-bldgs)))]
                       [(charge blink) (not (not (memq 'twilight-council r-bldgs)))]
                       [(extended-thermal-lance) (and has-robo-bay? has-colossus?)]
                       [(psi-storm) has-templar-arch?]
                       [(protoss-ground-weapons-2 protoss-ground-armor-2)
                        (and (not (not (memq 'forge r-bldgs)))
                             (not (not (memq 'twilight-council r-bldgs))))]
                       [else (not (not (memq 'forge r-bldgs)))])
                     #t))))
      (list
       (cand 'gateway 'production-scaling (list 'build 'gateway (safe-tile-coord (+ base-x 4.0)) (safe-tile-coord (+ base-y 4.0)))
             (if (hash? open-prod-slots)
                 (let ([cur-gates (bldg-eq-count 'gateway)]
                       [gate-cap (max raw-max-facilities
                                      (cond
                                        [(>= active-bases 3) 8]
                                        [(>= active-bases 2) (if (or (>= live-workers 34) (>= min-val 400)) 6 4)]
                                        [(memq enemy-race '(Protoss Random)) 2]
                                        [else 1]))])
                   (and (< cur-gates gate-cap)
                        (or (> active-bases 1)
                            (and (memq enemy-race '(Protoss Random)) (< cur-gates 2))
                            (< raw-prod-facilities 1)
                            (not escrow-ok?)
                            (< raw-frame 1500)
                            (>= (- raw-minerals 400) (sc2-min-cost 'gateway)))))
                 #t))
       (cand 'probe 'worker '(train probe) #f)
       (cand 'nexus 'expansion (list 'expand exp-x exp-y) exp-blocking?))
      protoss-t3-cands)]

    [else ;; Terran
     (define has-rax-tl?
       (or (not (not (memq 'barracks-techlab r-bldgs)))
           (not (not (memq 'barracks-tech-lab r-bldgs)))))
     (define has-fac-tl?
       (or (not (not (memq 'factory-techlab r-bldgs)))
           (not (not (memq 'factory-tech-lab r-bldgs)))))
     (define has-port-tl?
       (or (not (not (memq 'starport-techlab r-bldgs)))
           (not (not (memq 'starport-tech-lab r-bldgs)))))
     (define has-fusion-core? (not (not (memq 'fusion-core r-bldgs))))
     (define upg-sym
       (cond
         [(not (memq 'stimpack upgs)) 'stimpack]
         [(not (memq 'combat-shield upgs)) 'combat-shield]
         [(not (memq 'terran-infantry-weapons-1 upgs)) 'terran-infantry-weapons-1]
         [(not (memq 'concussive-shells upgs)) 'concussive-shells]
         [(not (memq 'terran-infantry-armor-1 upgs)) 'terran-infantry-armor-1]
         [(and has-fusion-core? has-port-tl? (not (memq 'advanced-ballistics upgs))) 'advanced-ballistics]
         [(and has-fusion-core? (>= active-bases 4) (not (memq 'weapon-refit upgs))) 'weapon-refit]
         [(not (memq 'terran-infantry-weapons-2 upgs)) 'terran-infantry-weapons-2]
         [(not (memq 'terran-infantry-armor-2 upgs)) 'terran-infantry-armor-2]
         [(and (>= (count (lambda (u) (eq? u 'banshee)) units) 1)
               (not (memq 'banshee-cloak upgs)))
          'banshee-cloak]
         [else 'terran-infantry-weapons-3]))
     (define has-fac-tl-any?
       (or has-fac-tl?
           (memq 'factory-techlab bldgs)
           (memq 'factory-tech-lab bldgs)))
     (define terran-rush-cands
       (if (or under-early-rush-crisis? severe-crisis-static-def?)
           (append
            (if (and under-early-rush-crisis? (memq 'supply-depot r-bldgs) (not (memq 'barracks bldgs)))
                (list (boost-cand 'barracks 'production-scaling
                                  (list 'build 'barracks (safe-tile-coord (+ base-x 4.0)) (safe-tile-coord (+ base-y 4.0)))
                                  #t 500.0))
                '())
            (if (and root-combat-ready? (< (bldg-eq-count 'bunker) (if severe-crisis-static-def? 2 1)))
                (list (boost-cand 'bunker 'counter-tech
                                  (list 'build 'bunker (safe-tile-coord (+ base-x 3.5)) (safe-tile-coord (- base-y 3.0)))
                                  #t (if under-early-rush-crisis? 260.0 165.0)))
                '()))
           '()))
     (define desired-rax-tl
       (terran-desired-barracks-techlabs race enemy-race (bldg-eq-count 'barracks)))
     (define cur-rax-addons
       (+ (bldg-eq-count 'barracks-techlab) (bldg-eq-count 'barracks-reactor)))
     (define desired-factories
       (terran-desired-factories race enemy-race active-bases sup-used))
     (define cur-fac-addons
       (+ (bldg-eq-count 'factory-techlab) (bldg-eq-count 'factory-reactor)))
     (define desired-ghost-cap
       (terran-desired-ghost-cap active-bases sup-used enemy-race enemy-u-counts))
     (define desired-lib-cap
       (terran-desired-liberator-cap active-bases enemy-u-counts))
     (define terran-t3-cands
       (append
        ;; TvT Barracks TechLab + 2nd Factory scaling (#5123417, #5123667)
        (if (and (memq enemy-race '(Terran Protoss))
                 (< (bldg-eq-count 'barracks-techlab) desired-rax-tl)
                 (> (ready-bldg-eq-count 'barracks) cur-rax-addons)
                 (facility-slot-open? 'barracks 'barracks))
            (list (boost-cand 'barracks-techlab 'production-scaling
                              (list 'build 'barracks-techlab (safe-tile-coord (+ base-x 7.5)) (safe-tile-coord (+ base-y 3.0)))
                              #t 145.0))
            '())
        (if (and (>= desired-factories 2)
                 (< (bldg-eq-count 'factory) desired-factories)
                 (memq 'barracks r-bldgs))
            (list (boost-cand 'factory 'production-scaling
                              (list 'build 'factory (safe-tile-coord (+ base-x 6.0)) (safe-tile-coord (+ base-y 2.5)))
                              #t 150.0))
            '())
        ;; Ready-tech / enemy-triggered Ghost Academy, Ghosts (< 10) & Liberators (< 6-8) (#5123937)
        (if (and (memq 'barracks r-bldgs)
                 (= (bldg-eq-count 'ghost-academy) 0)
                 (or t3-endgame?
                     (and (>= active-bases 3) (terran-enemy-needs-ghost? enemy-u-counts))))
            (list (boost-cand 'ghost-academy 'tech-upgrade
                              (list 'build 'ghost-academy (safe-tile-coord (- base-x 4.5)) (safe-tile-coord (- base-y 4.5)))
                              #t (if (terran-enemy-needs-ghost? enemy-u-counts) 160.0 140.0)))
            '())
        (if (and (facility-slot-open? 'starport 'starport)
                 (or t3-endgame?
                     (and (>= active-bases 3) (terran-enemy-needs-liberator? enemy-u-counts))
                     (and (>= active-bases 3) (>= (count (lambda (u) (eq? u 'medivac)) units) 2)))
                 (< (count (lambda (u) (memq u '(liberator liberator-ag))) units) desired-lib-cap))
            (list (boost-cand 'liberator 'combat-unit '(train liberator) #t
                              (if (terran-enemy-needs-liberator? enemy-u-counts) 165.0 145.0)))
            '())
        (if (and (facility-slot-open? 'barracks 'ghost-academy)
                 has-rax-tl?
                 (< (count (lambda (u) (eq? u 'ghost)) units) desired-ghost-cap))
            (list (boost-cand 'ghost 'combat-unit '(train ghost) #t 155.0))
            '())
        ;; [NOTE-R4-B] Anti-Capital-Air (`tempest`, `carrier`, `battlecruiser`, `brood-lord`):
        ;; unlock Armory + Thors (< 5-6) outside `t3-endgame?`, plus `+1` Ship Weapons when air fleet >= 4.
        (if (and (memq 'factory r-bldgs)
                 (= (bldg-eq-count 'armory) 0)
                 enemy-cap-air?
                 (or enemy-cap-air-ground-aa? has-fac-tl-any?))
            (list (boost-cand 'armory 'tech-upgrade
                              (list 'build 'armory (safe-tile-coord (+ base-x 6.5)) (safe-tile-coord (- base-y 4.5)))
                              #t (if enemy-cap-air-ground-aa? 185.0 165.0)))
            '())
        (if (and (facility-slot-open? 'factory 'armory)
                 has-fac-tl?
                 enemy-cap-air?
                 (< (count (lambda (u) (memq u '(thor thor-ap))) units) desired-thor-cap))
            (list (boost-cand 'thor 'combat-unit '(train thor) #t
                              (if enemy-cap-air-ground-aa? 180.0 160.0)))
            '())
        (if (and ship-weap-due?
                 (not (crisis-deferred-sym? 'terran-ship-weapons-1 crisis-defer? #:keep-ship-weapons? #t))
                 (or (not (hash? open-prod-slots))
                     (> (hash-ref open-prod-slots 'armory 1) 0)))
            (list (boost-cand 'terran-ship-weapons-1 'tech-upgrade '(research terran-ship-weapons-1)
                              #t 175.0))
            '())
        (if t3-endgame?
            (append
             (if (and (memq 'factory r-bldgs) (not (memq 'armory bldgs)))
                 (list (boost-cand 'armory 'tech-upgrade
                                   (list 'build 'armory (safe-tile-coord (+ base-x 6.5)) (safe-tile-coord (- base-y 4.5)))
                                   #t 150.0))
                 '())
             (if (and (not crisis-defer?) (memq 'starport r-bldgs) (= (bldg-eq-count 'fusion-core) 0))
                 (list (boost-cand 'fusion-core 'tech-upgrade
                                   (list 'build 'fusion-core (safe-tile-coord (- base-x 5.5)) (safe-tile-coord (+ base-y 4.5)))
                                   #t 145.0))
                 '())
             (if (and (facility-slot-open? 'starport 'starport)
                      (< (count (lambda (u) (eq? u 'medivac)) units) 4))
                 (list (boost-cand 'medivac 'combat-unit '(train medivac) #t 140.0))
                 '())
             (if (and (facility-slot-open? 'factory 'armory)
                      has-fac-tl?
                      (< (count (lambda (u) (memq u '(thor thor-ap))) units) (max 4 desired-thor-cap)))
                 (list (boost-cand 'thor 'combat-unit '(train thor) #t 150.0))
                 '())
             (if (and (>= active-bases 4)
                      (facility-slot-open? 'starport 'fusion-core)
                      has-port-tl?
                      (< (count (lambda (u) (eq? u 'battlecruiser)) units) 4))
                 (list (boost-cand 'battlecruiser 'combat-unit '(train battlecruiser) #t 155.0))
                 '()))
            '())))
     (append
      terran-rush-cands
      (if (and (hash? open-prod-slots)
               (facility-slot-open? 'factory 'factory)
               (> (ready-bldg-eq-count 'factory) cur-fac-addons)
               (< (bldg-eq-count 'factory-techlab) desired-factories))
          (list (cand 'factory-techlab 'counter-tech
                      (list 'build 'factory-techlab (safe-tile-coord (+ base-x 8.5)) (safe-tile-coord (+ base-y 3.0)))
                      #t))
          '())
      (list
       (cand 'supply-depot 'supply (list 'build 'supply-depot (safe-tile-coord (+ base-x 4.0)) (safe-tile-coord (- base-y 3.0))) supply-urgent?)
       (cand 'missile-turret 'counter-tech (list 'build 'missile-turret (safe-tile-coord (+ base-x 3.0)) (safe-tile-coord (+ base-y 3.0)))
             (if (hash? open-prod-slots) (and (or raw-requires-anti-air? raw-requires-detection?) (memq 'engineering-bay r-bldgs)) #t))
       (cand 'engineering-bay 'counter-tech (list 'build 'engineering-bay (safe-tile-coord (+ base-x 5.0)) (safe-tile-coord (- base-y 3.0)))
             (if (hash? open-prod-slots) (and (or raw-requires-anti-air? raw-requires-detection?) (< (bldg-eq-count 'engineering-bay) 2)) #t))
       (cand 'viking-fighter 'counter-tech '(train viking-fighter)
             (facility-slot-open? 'starport 'starport))
       (cand 'marauder 'combat-unit '(train marauder)
             (if (hash? open-prod-slots) (and (facility-slot-open? 'barracks 'barracks) has-rax-tl?) #t))
       (cand 'siege-tank 'combat-unit '(train siege-tank)
             (if (hash? open-prod-slots) (and (facility-slot-open? 'factory 'factory) has-fac-tl?) #t))
       (cand 'marine 'combat-unit '(train marine)
             (facility-slot-open? 'barracks 'barracks)))
      (if (crisis-deferred-sym? upg-sym crisis-defer?)
          '()
          (list
           (cand upg-sym 'tech-upgrade (list 'research upg-sym)
                 (if (hash? open-prod-slots)
                     (case upg-sym
                       [(stimpack combat-shield concussive-shells) has-rax-tl?]
                       [(terran-infantry-weapons-2 terran-infantry-armor-2 terran-infantry-weapons-3)
                        (and (not (not (memq 'engineering-bay r-bldgs)))
                             (not (not (memq 'armory r-bldgs))))]
                       [(advanced-ballistics) (and has-fusion-core? has-port-tl?)]
                       [(weapon-refit) has-fusion-core?]
                       [(banshee-cloak) has-port-tl?]
                       [else (not (not (memq 'engineering-bay r-bldgs)))])
                     #t))))
      (list
       (cand 'barracks 'production-scaling (list 'build 'barracks (safe-tile-coord (+ base-x 4.0)) (safe-tile-coord (+ base-y 4.0)))
             (if (hash? open-prod-slots)
                 (let ([cur-rax (bldg-eq-count 'barracks)]
                       [rax-cap (max raw-max-facilities
                                     (cond
                                       [(>= active-bases 3) 8]
                                       [(>= active-bases 2) (if (or (>= live-workers 34) (>= min-val 400)) 5 3)]
                                       [else 2]))])
                   (and (< cur-rax rax-cap)
                        (or (and (>= active-bases 2)
                                 (or (< cur-rax 3) (>= live-workers 20) (>= min-val 350)))
                            (< raw-prod-facilities 1)
                            (not escrow-ok?)
                            (< raw-frame 1500)
                            (>= (- raw-minerals 400) (sc2-min-cost 'barracks)))))
                 #t))
       (cand 'scv 'worker '(train scv) #f)
       (cand 'command-center 'expansion (list 'expand exp-x exp-y) exp-blocking?))
      terran-t3-cands)]))

;; Computes reserved minerals for the natural expansion (`400M` Terran/Protoss, `300M` Zerg)
;; when on 1 base (`active-bases + pending-bases < 2`) at `frame >= 1500` (or `workers >= 18/15`)
;; without active base attack or enemy threat, preventing a `150M` 2nd Barracks or Gateway
;; from starving the natural TownHall (Match 5115348 root-cause fix).
;; When `natural-blocked?` is `#t`, returns `0` below `350M` (preserving PV1) and allows
;; reservation at `>= 350M` (`army-supply >= 6` or `frame >= 2688`) for 3rd-base redirect.
(define (compute-natural-expansion-mineral-reserve
         #:race [raw-race 'Terran]
         #:frame [raw-frame 0]
         #:active-bases [raw-active-bases 1]
         #:pending-bases [raw-pending-bases 0]
         #:workers [raw-workers 12]
         #:minerals [raw-minerals 0]
         #:army-supply [raw-army-supply 0]
         #:under-attack? [under-attack? #f]
         #:enemy-threat-supply [enemy-threat 0]
         #:natural-blocked? [natural-blocked? #f]
         #:escrow-expired? [escrow-expired? #f])
  (define race (normalize-ledger-race raw-race))
  (define total-bases (+ (safe-nonneg-int raw-active-bases 1)
                         (safe-nonneg-int raw-pending-bases 0)))
  (define frame (safe-nonneg-int raw-frame 0))
  (define workers (safe-nonneg-int raw-workers 12))
  (define minerals (safe-nonneg-int raw-minerals 0))
  (define army-sup (safe-real raw-army-supply 0.0))
  (if (and (< total-bases 2)
           (not under-attack?)
           (<= (safe-real enemy-threat 0.0) 0.0)
           (or (not natural-blocked?)
               (and (>= minerals 350)
                    (or (>= army-sup 6.0) (>= frame 2688))))
           (not escrow-expired?)
           (or (and (>= frame 1500) (>= workers 12))
               (>= workers (if (eq? race 'Zerg) 15 18))))
      (sc2-race-townhall-min-cost race)
      0))

(define (schedule-priority-candidates-with-ledger!
         candidates
         #:minerals [raw-minerals 200]
         #:gas [raw-gas 0]
         #:supply-left [raw-supply-left 4]
         #:supply-cap [raw-supply-cap 200]
         #:escrow-eligible? [escrow-eligible? #f])
  (define init-min (safe-nonneg-int raw-minerals 0))
  (define init-gas (safe-nonneg-int raw-gas 0))
  (define init-sup (max 0 (safe-exact-int raw-supply-left 0)))
  (define supply-cap (min 200 (max 1 (safe-nonneg-int raw-supply-cap 200))))
  (define ledger (make-symbiotic-ledger init-min init-gas init-sup))
  (define cands (if (list? candidates) (filter priority-candidate? candidates) '()))

  ;; Insert all candidates into an Okasaki Braun heap keyed by (- effective-utility)
  ;; PV1: When (not escrow-eligible?), an 'expansion candidate NEVER outranks
  ;; affordable 'tech-upgrade, 'counter-tech, 'production-scaling, or 'combat-unit.
  (define min-non-exp-utility
    (for/fold ([acc +inf.0])
              ([c (in-list cands)]
               #:when (memq (priority-candidate-category c)
                            '(tech-upgrade counter-tech production-scaling combat-unit)))
      (min acc (safe-real (priority-candidate-utility-score c) 100.0))))

  (define keyed-cands
    (for/list ([c (in-list cands)]
               [idx (in-naturals)])
      (define raw-u (safe-real (priority-candidate-utility-score c) 0.0))
      (define eff-u
        (if (and (eq? (priority-candidate-category c) 'expansion)
                 (or (not escrow-eligible?)
                     (not (priority-candidate-blocking-allowed? c)))
                 (not (infinite? min-non-exp-utility)))
            (min raw-u (- min-non-exp-utility 1.0))
            raw-u))
      (cons (+ (- eff-u) (* 1e-7 idx)) c)))

  ;; Sort candidates in descending utility order (tie-breaking by index)
  (define sorted-cands
    (map cdr (sort keyed-cands < #:key car)))

  ;; Track category -> max utility-score map & candidate id -> utility map
  (define cat-utils0
    (for/fold ([ht (hash)])
              ([c (in-list sorted-cands)])
      (define cat (priority-candidate-category c))
      (define u (safe-real (priority-candidate-utility-score c) 0.0))
      (hash-set ht cat (max u (hash-ref ht cat -inf.0)))))
  (define cand-utils
    (for/fold ([ht (hash)])
              ([c (in-list sorted-cands)])
      (hash-set ht (priority-candidate-id c) (safe-real (priority-candidate-utility-score c) 0.0))))

  (define rem-min init-min)
  (define rem-gas init-gas)
  (define rem-sup init-sup)
  (define scheduled-cands '())
  (define reserved-cand #f)
  (define decision-entries '())
  ;; Each escrowed entry is (list utility min-cost gas-cost id category)
  (define escrowed-entries '())

  ;; Orthogonal mineral & gas reservation floors enforcing PV1-PV4 + general rank-ordered escrow:
  ;;   1. supply-floor: urgent supply (> 1000.0) blocks all non-supply candidates (PV4)
  ;;   2. expansion-floor: 1-base escrow-eligible expansion blocks lower-utility candidates (PV1)
  ;;   3. combat-floor: waiting combat-unit/counter-tech blocks worker / non-blocking candidates (PV2)
  ;;   4. gas-sink-floor: waiting gas-consuming unit/tech blocks mineral-only worker/combat-unit (PV3)
  ;;   5. higher-rank-floor: any ready blocking-allowed? candidate with utility > u(c) + 1.0 and gas-ok?
  ;;      reserves its mineral cost against lower-ranked candidates `c` (including 0-gas escrows!).
  ;;   6. gas-escrow-floor: any ready blocking-allowed? tech-upgrade/counter-tech/production-scaling waiting on gas
  ;;      reserves its gas cost against lower-ranked gas-consuming candidates.
  (define supply-floor 0)
  (define expansion-floor 0)
  (define combat-floor 0)
  (define gas-sink-floor 0)
  (define gas-escrow-floor 0)
  (define seen-tech-counts (make-hasheq))

  (for ([c (in-list sorted-cands)]
        [rank-idx (in-naturals 1)])
    (define id (priority-candidate-id c))
    (define canon-tech-id
      (case id
        [(lurker-den-mp) 'lurker-den]
        [(templar-archives) 'templar-archive]
        [(robotics-support-bay) 'robotics-bay]
        [else id]))
    (define dup-tech-blocked?
      (or (and (memq id SC2-SINGLETON-TECH-BUILDINGS)
               (>= (hash-ref seen-tech-counts canon-tech-id 0) 1))
          (and (memq id SC2-DUAL-CAP-TECH-BUILDINGS)
               (>= (hash-ref seen-tech-counts canon-tech-id 0) 2))))
    (define cat (priority-candidate-category c))
    (define act (priority-candidate-action c))
    (define m-cost (safe-nonneg-int (priority-candidate-min-cost c) 0))
    (define g-cost (safe-nonneg-int (priority-candidate-gas-cost c) 0))
    (define s-cost (safe-nonneg-int (priority-candidate-supply-cost c) 0))
    (define u-score (safe-real (priority-candidate-utility-score c) 0.0))
    (define blk-ok? (eq? (priority-candidate-blocking-allowed? c) #t))

    (define supply-ok?
      (or (<= s-cost 0)
          (>= rem-sup s-cost)))
    (define gas-ok?
      (>= rem-gas g-cost))
    (define min-ok?
      (>= rem-min m-cost))

    ;; Rank-ordered escrow floor from higher-utility ready candidates (mineral-only & gas-bearing)
    (define higher-rank-min-floor
      (for/fold ([mf 0])
                ([e (in-list escrowed-entries)])
        (match-define (list eu em _eg _eid ecat) e)
        (if (and (> eu (+ u-score 1.0))
                 (not (eq? cat 'supply))
                 ;; PV1: expansion escrow only applies when escrow-eligible?
                 (or (not (eq? ecat 'expansion)) escrow-eligible?))
            (max mf em)
            mf)))

    ;; Determine effective mineral reservation floor that applies to candidate `c`
    (define applicable-floor
      (max (if (eq? cat 'supply) 0 supply-floor)
           (if (eq? cat 'expansion) 0 expansion-floor)
           (if (or (eq? cat 'worker) (not blk-ok?)) combat-floor 0)
           (if (and (= g-cost 0) (memq cat '(worker combat-unit))) gas-sink-floor 0)
           higher-rank-min-floor))

    (define applicable-gas-floor
      (if (or (eq? cat 'supply) (= g-cost 0)) 0 gas-escrow-floor))
    (define floor-ok?
      (and (>= (- rem-min m-cost) applicable-floor)
           (or (= g-cost 0) (>= (- rem-gas g-cost) applicable-gas-floor))))

    (define blocked-by-id
      (and min-ok?
           gas-ok?
           (not floor-ok?)
           (or (and reserved-cand (priority-candidate-id reserved-cand))
               (and (pair? escrowed-entries) (fourth (last escrowed-entries))))))

    (cond
      [dup-tech-blocked?
       (set! decision-entries
             (cons (priority-decision-entry rank-idx id cat act m-cost g-cost s-cost
                                            u-score blk-ok? 'duplicate-singleton-tech
                                            applicable-floor applicable-gas-floor #f)
                   decision-entries))]
      [(and supply-ok? gas-ok? min-ok? floor-ok?)
       (if (ledger-reserve! ledger id cat m-cost g-cost s-cost u-score)
           (begin
             (set! rem-min (- rem-min m-cost))
             (set! rem-gas (- rem-gas g-cost))
             (set! rem-sup (- rem-sup s-cost))
             (when (or (memq id SC2-SINGLETON-TECH-BUILDINGS)
                       (memq id SC2-DUAL-CAP-TECH-BUILDINGS))
               (hash-update! seen-tech-counts canon-tech-id add1 0))
             (set! scheduled-cands (cons c scheduled-cands))
             (set! decision-entries
                   (cons (priority-decision-entry rank-idx id cat act m-cost g-cost s-cost
                                                  u-score blk-ok? 'scheduled
                                                  applicable-floor applicable-gas-floor #f)
                         decision-entries)))
           (set! decision-entries
                 (cons (priority-decision-entry rank-idx id cat act m-cost g-cost s-cost
                                                u-score blk-ok? 'insufficient-resources
                                                applicable-floor applicable-gas-floor #f)
                       decision-entries)))]

      [else
       ;; Candidate was not scheduled; check if it is waiting on minerals or gas and should reserve a floor
       (define escrowed-now? #f)
       (when (and (or (< rem-min m-cost) (< rem-gas g-cost)) supply-ok?)
         (cond
           ;; PV4: Urgent supply reserves 100 minerals before all non-supply candidates
           [(and (eq? cat 'supply) (< supply-cap 200) (< rem-min m-cost) (or (> u-score 1000.0) blk-ok?))
            (set! supply-floor (max supply-floor m-cost))
            (set! escrowed-now? #t)
            (set! escrowed-entries (cons (list u-score m-cost g-cost id cat) escrowed-entries))
            (unless reserved-cand (set! reserved-cand c))]

           ;; PV1: Expansion only reserves minerals when escrow-eligible? AND blocking-allowed?
           [(and (eq? cat 'expansion) (< rem-min m-cost) escrow-eligible? blk-ok?)
            (set! expansion-floor (max expansion-floor m-cost))
            (set! escrowed-now? #t)
            (set! escrowed-entries (cons (list u-score m-cost g-cost id cat) escrowed-entries))
            (unless reserved-cand (set! reserved-cand c))]

           ;; PV2, PV3 & General Rank-Ordered Escrow: Ready blocking combat units, counter-tech,
           ;; tech-upgrade, and production-scaling candidates (including 0-gas escrows!).
           ;; High-bank deadlock guard: when minerals >= 600 and supply-left >= 2, un-actuated
           ;; tech/morph/upgrade/production goals never freeze downstream unit spending.
           [(and blk-ok?
                 (memq cat '(combat-unit counter-tech tech-upgrade production-scaling))
                 (not (and (memq cat '(tech-upgrade counter-tech production-scaling))
                           (>= init-min 600)
                           (>= rem-sup 2))))
            (when (and (< rem-min m-cost) gas-ok? (memq cat '(combat-unit counter-tech)))
              (set! combat-floor (max combat-floor m-cost))
              (set! escrowed-now? #t)
              (unless reserved-cand (set! reserved-cand c)))
            (when (and (< rem-min m-cost) (or gas-ok? (>= init-gas g-cost)))
              (when (> g-cost 0)
                (set! gas-sink-floor (max gas-sink-floor m-cost)))
              (set! escrowed-now? #t)
              (set! escrowed-entries (cons (list u-score m-cost g-cost id cat) escrowed-entries))
              (unless reserved-cand (set! reserved-cand c)))
            (when (and (> g-cost 0) (< rem-gas g-cost) (memq cat '(tech-upgrade counter-tech production-scaling)))
              (set! gas-escrow-floor (max gas-escrow-floor g-cost))
              (set! escrowed-now? #t)
              (unless (and (pair? escrowed-entries) (eq? (fourth (car escrowed-entries)) id))
                (set! escrowed-entries (cons (list u-score (if (< rem-min m-cost) m-cost 0) g-cost id cat) escrowed-entries)))
              (unless reserved-cand (set! reserved-cand c)))]))

       (define outcome-sym
         (cond
           [escrowed-now? 'escrowed-saving]
           [(not supply-ok?) 'insufficient-supply]
           [(and min-ok? gas-ok? (not floor-ok?)) 'blocked-by-escrow]
           [else 'insufficient-resources]))
       (set! decision-entries
             (cons (priority-decision-entry rank-idx id cat act m-cost g-cost s-cost
                                            u-score blk-ok? outcome-sym
                                            applicable-floor applicable-gas-floor blocked-by-id)
                   decision-entries))]))

  (define final-cands (reverse scheduled-cands))
  (define final-actions (map priority-candidate-action final-cands))
  (define final-trace (reverse decision-entries))
  (define final-escrowed (reverse escrowed-entries))
  (define cat-utils
    (hash-set* cat-utils0
               'decision-trace final-trace
               'escrowed-entries final-escrowed
               'candidate-utilities cand-utils
               'reserved-min-floor (max supply-floor expansion-floor combat-floor gas-sink-floor)
               'reserved-gas-floor gas-escrow-floor))
  (priority-schedule-result final-actions
                            final-cands
                            reserved-cand
                            rem-min
                            rem-gas
                            rem-sup
                            cat-utils))

(define (priority-schedule-decision-trace sched)
  (if (priority-schedule-result? sched)
      (hash-ref (priority-schedule-result-category-utilities sched) 'decision-trace '())
      '()))

(define (normalize-priority-spend-sym s)
  (case s
    [(viking) 'viking-fighter]
    [(templar-archives) 'templar-archive]
    [(robotics-support-bay) 'robotics-bay]
    [(lurker-den-mp) 'lurker-den]
    [(barracks-tech-lab) 'barracks-techlab]
    [(factory-tech-lab) 'factory-techlab]
    [(starport-tech-lab) 'starport-techlab]
    [else s]))

(define (same-priority-spend-sym? a b)
  (and (symbol? a)
       (symbol? b)
       (or (eq? a b)
           (eq? (normalize-priority-spend-sym a)
                (normalize-priority-spend-sym b)))))

;; General query: given the current priority schedule `sched`, can a candidate `id-sym`
;; (of category `cat-sym` and cost `m-cost` / `g-cost`) spend from `(cur-min, cur-gas)`
;; without violating the escrow reserved by strictly higher-priority ready candidates
;; or the active build-order goal?
(define (priority-schedule-can-spend?
         sched
         id-sym
         cur-min
         cur-gas
         #:category [cat-sym 'combat-unit]
         #:min-cost [override-min #f]
         #:gas-cost [override-gas #f]
         #:bo-goal-sym [bo-goal-sym #f]
         #:bo-reserved-min [bo-reserved-min 0]
         #:bo-reserved-gas [bo-reserved-gas 0])
  (define norm-id (normalize-priority-spend-sym id-sym))
  (define m-cost (or override-min (sc2-min-cost norm-id)))
  (define g-cost (or override-gas (sc2-gas-cost norm-id)))
  (cond
    [(or (< cur-min m-cost) (< cur-gas g-cost)) #f]
    [(not (priority-schedule-result? sched)) #t]
    [else
     (define cu (priority-schedule-result-category-utilities sched))
     (define cand-utils (hash-ref cu 'candidate-utilities (hash)))
     (define escrowed (hash-ref cu 'escrowed-entries '()))
     (define u-self
       (hash-ref cand-utils id-sym
                 (hash-ref cand-utils norm-id
                           (hash-ref cu cat-sym
                                     (if (eq? cat-sym 'worker) 65.0 120.0)))))
     (define is-bo-head?
       (and bo-goal-sym (same-priority-spend-sym? norm-id bo-goal-sym)))
     (define high-bank-tech-unlock? (>= cur-min 600))
     (define bo-goal-supply? (memq bo-goal-sym '(overlord pylon supply-depot)))
     (define bo-min-floor
       (if (and (not is-bo-head?)
                (> bo-reserved-min 0)
                (not (eq? cat-sym 'supply))
                (or (not high-bank-tech-unlock?) bo-goal-supply?))
           bo-reserved-min
           0))
     (define bo-gas-floor
       (if (and (not is-bo-head?)
                (> bo-reserved-gas 0)
                (> g-cost 0)
                (not (eq? cat-sym 'supply))
                (or (not high-bank-tech-unlock?) bo-goal-supply?))
           bo-reserved-gas
           0))
     (define higher-escrow-min
      (for/fold ([mf bo-min-floor])
                 ([e (in-list escrowed)])
         (match-define (list eu em _eg eid ecat) e)
         (if (and (not (same-priority-spend-sym? eid norm-id))
                  (not (eq? cat-sym 'supply))
                  (not (and high-bank-tech-unlock?
                            (memq ecat '(tech-upgrade counter-tech production-scaling))))
                  (> eu (+ u-self 1.0)))
             (max mf em)
             mf)))
     (define higher-escrow-gas
       (if (or (= g-cost 0) (eq? cat-sym 'supply))
           0
           (for/fold ([gf bo-gas-floor])
                     ([e (in-list escrowed)])
             (match-define (list eu _em eg eid ecat) e)
             (if (and (not (same-priority-spend-sym? eid norm-id))
                      (> eg 0)
                      (not (and high-bank-tech-unlock?
                                (memq ecat '(tech-upgrade counter-tech production-scaling))))
                      (> eu (+ u-self 1.0)))
                 (max gf eg)
                 gf))))
     (and (>= (- cur-min m-cost) higher-escrow-min)
          (or (= g-cost 0)
              (>= (- cur-gas g-cost) (max bo-gas-floor higher-escrow-gas))))]))

(define (priority-schedule-summary-hash
         sched
         #:frame [frame 0]
         #:race [race 'Zerg]
         #:minerals [minerals 0]
         #:gas [gas 0]
         #:supply-used [supply-used 12]
         #:supply-cap [supply-cap 15]
         #:bo-goal-sym [bo-goal-sym #f]
         #:bo-reserved-min [bo-reserved-min 0]
         #:bo-reserved-gas [bo-reserved-gas 0])
  (define trace (priority-schedule-decision-trace sched))
  (define res-cand (and (priority-schedule-result? sched)
                        (priority-schedule-result-reserved-candidate sched)))
  (define cu (if (priority-schedule-result? sched)
                 (priority-schedule-result-category-utilities sched)
                 (hash)))
  (define high-bank-unlock?
    (and (>= minerals 600) (>= (- supply-cap supply-used) 2)))
  (define res-min-floor
    (if high-bank-unlock?
        0
        (max bo-reserved-min (hash-ref cu 'reserved-min-floor 0))))
  (define res-gas-floor
    (if high-bank-unlock?
        0
        (max bo-reserved-gas (hash-ref cu 'reserved-gas-floor 0))))
  (hash 'frame frame
        'race race
        'minerals minerals
        'gas gas
        'supply-used supply-used
        'supply-cap supply-cap
        'bo-goal (or bo-goal-sym 'none)
        'saving-for (if res-cand (priority-candidate-id res-cand) (or bo-goal-sym 'none))
        'reserved-min-floor res-min-floor
        'reserved-gas-floor res-gas-floor
        'scheduled-ids (if (priority-schedule-result? sched)
                           (map priority-candidate-id (priority-schedule-result-scheduled-candidates sched))
                           '())
        'decisions (for/list ([d (in-list trace)])
                     (hash 'rank (priority-decision-entry-rank d)
                           'id (priority-decision-entry-id d)
                           'category (priority-decision-entry-category d)
                           'utility (round1 (priority-decision-entry-utility-score d))
                           'min-cost (priority-decision-entry-min-cost d)
                           'gas-cost (priority-decision-entry-gas-cost d)
                           'blocking? (priority-decision-entry-blocking-allowed? d)
                           'outcome (priority-decision-entry-outcome d)
                           'min-floor (priority-decision-entry-applicable-min-floor d)
                           'blocked-by (or (priority-decision-entry-blocked-by-id d) 'none)))))

(define (format-priority-schedule-log-line
         sched
         #:frame [frame 0]
         #:race [race 'Zerg]
         #:minerals [minerals 0]
         #:gas [gas 0]
         #:supply-used [supply-used 12]
         #:supply-cap [supply-cap 15]
         #:bo-goal-sym [bo-goal-sym #f]
         #:bo-reserved-min [bo-reserved-min 0]
         #:bo-reserved-gas [bo-reserved-gas 0])
  (define trace (priority-schedule-decision-trace sched))
  (define res-cand (and (priority-schedule-result? sched)
                        (priority-schedule-result-reserved-candidate sched)))
  (define cu (if (priority-schedule-result? sched)
                 (priority-schedule-result-category-utilities sched)
                 (hash)))
  (define high-bank-unlock?
    (and (>= minerals 600) (>= (- supply-cap supply-used) 2)))
  (define res-min-floor
    (if high-bank-unlock?
        0
        (max bo-reserved-min (hash-ref cu 'reserved-min-floor 0))))
  (define res-gas-floor
    (if high-bank-unlock?
        0
        (max bo-reserved-gas (hash-ref cu 'reserved-gas-floor 0))))
  (define saving-id (if res-cand (priority-candidate-id res-cand) (or bo-goal-sym 'none)))
  (define sched-strs
    (for/list ([d (in-list trace)]
               #:when (eq? (priority-decision-entry-outcome d) 'scheduled))
      (format "~a@~a"
              (priority-decision-entry-id d)
              (round1 (priority-decision-entry-utility-score d)))))
  (define blocked-strs
    (for/list ([d (in-list trace)]
               #:when (memq (priority-decision-entry-outcome d) '(blocked-by-escrow escrowed-saving)))
      (format "~a(~a,u=~a,floor=~aM)"
              (priority-decision-entry-id d)
              (priority-decision-entry-outcome d)
              (round1 (priority-decision-entry-utility-score d))
              (priority-decision-entry-applicable-min-floor d))))
  (format "[SCBOT_PRIORITY] f=~a race=~a bank=~aM/~aG sup=~a/~a bo=~a saving_for=~a(floor=~aM/~aG) sched=(~a) escrow_queue=(~a)"
          frame race minerals gas supply-used supply-cap
          (or bo-goal-sym 'none)
          saving-id res-min-floor res-gas-floor
          (string-join sched-strs ",")
          (string-join blocked-strs ",")))

;; =============================================================================
;; 10. Empirical Pro Replay Build-Order Database & Goal-Queue Executor
;;     (Canonical DB, structs, supply curve, and matchup specs imported and
;;      re-exported from `lib/sc2-types.rkt` and `lib/build-orders.rkt`)
;; =============================================================================

(define (evaluate-build-order-next-step
         #:race [raw-race 'Zerg]
         #:enemy-race [enemy-race 'Unknown]
         #:frame [raw-frame 0]
         #:minerals [raw-minerals 200]
         #:gas [raw-gas 0]
         #:supply-used [raw-supply-used 12]
         #:supply-left [raw-supply-left 4]
         #:active-bases [raw-active-bases 1]
         #:ready-building-counts [ready-bldg-counts (hash)]
         #:total-building-counts [total-bldg-counts (hash)]
         #:unit-counts [unit-counts (hash)]
         #:researched-upgrades [researched-upgrades '()]
         #:pending-upgrades [pending-upgrades '()]
         #:base-x [raw-base-x 32.5]
         #:base-y [raw-base-y 32.5]
         #:nat-x [raw-nat-x 50.5]
         #:nat-y [raw-nat-y 50.5]
         #:third-x [raw-third-x 60.5]
         #:third-y [raw-third-y 40.5])
  (define race (normalize-ledger-race raw-race))
  (define m-sym (resolve-matchup-symbol race enemy-race))
  (define frame (safe-nonneg-int raw-frame 0))
  (define elapsed-sec (/ (exact->inexact frame) 22.4))
  (define supply-used (safe-nonneg-int raw-supply-used 12))
  (define active-bases (max 1 (safe-nonneg-int raw-active-bases 1)))
  (define base-x (safe-tile-coord raw-base-x 32.5))
  (define base-y (safe-tile-coord raw-base-y 32.5))
  (define nat-x (safe-tile-coord raw-nat-x 50.5))
  (define nat-y (safe-tile-coord raw-nat-y 50.5))
  (define third-x (safe-tile-coord raw-third-x 60.5))
  (define third-y (safe-tile-coord raw-third-y 40.5))
  (define-values (target-workers target-army)
    (pro-supply-curve-target race enemy-race frame active-bases))

  (define all-upgs
    (append (if (list? researched-upgrades) researched-upgrades '())
            (if (list? pending-upgrades) pending-upgrades '())))

  (define (count-total-bldg sym)
    (sc2-count-equivalent-structures total-bldg-counts sym #f))

  (define (prereq-ready? prereq-sym)
    (or (not prereq-sym)
        (> (sc2-count-equivalent-structures ready-bldg-counts prereq-sym #f) 0)))

  (define (goal-satisfied? g)
    (match-define (pro-bo-goal kind sym tgt-cnt _ _ _) g)
    (case kind
      [(build expand morph)
       (>= (count-total-bldg sym) tgt-cnt)]
      [(train)
       (define unit-cnt
         (for/sum ([u-sym (in-list (sc2-unit-equivalent-syms sym))])
           (hash-ref unit-counts u-sym 0)))
       (>= unit-cnt tgt-cnt)]
      [(research)
       (define upg-syms
         (case sym
           [(metabolic-boost zergling-movementspeed) '(metabolic-boost zergling-movementspeed)]
           [(centrifical-hooks centrifugal-hooks) '(centrifical-hooks centrifugal-hooks)]
           [(warp-gate-research warpgate) '(warp-gate-research warpgate)]
           [(banshee-cloak cloaking-field) '(banshee-cloak cloaking-field)]
           [else (list sym)]))
       (ormap (lambda (u) (not (not (memq u all-upgs)))) upg-syms)]
      [else #t]))

  (define (goal->action g)
    (match-define (pro-bo-goal kind sym tgt-cnt _ _ _) g)
    (case kind
      [(expand)
       (define ex (if (>= tgt-cnt 3) third-x nat-x))
       (define ey (if (>= tgt-cnt 3) third-y nat-y))
       (list 'expand ex ey)]
      [(morph)
       (list 'morph sym)]
      [(research)
       (list 'research sym)]
      [(train)
       (list 'train sym)]
      [(build)
       (cond
         [(memq sym '(extractor refinery assimilator
                      barracks-techlab barracks-reactor
                      factory-techlab factory-reactor
                      starport-techlab starport-reactor))
          (list 'build sym)]
         [else
          (list 'build sym
                (safe-tile-coord (+ base-x 4.0))
                (safe-tile-coord (+ base-y 4.0)))])]
      [else
       (list 'build sym)]))

  (define (goal-due? g)
    (define min-sup (pro-bo-goal-min-supply g))
    (define tgt-sec (exact->inexact (pro-bo-goal-target-sec g)))
    (or (>= supply-used min-sup)
        (and (> frame 0)
             (> tgt-sec 0.0)
             (>= elapsed-sec tgt-sec))))

  (define (goal-eligible-now? g)
    (and (not (goal-satisfied? g))
         (goal-due? g)
         (not (and (memq (pro-bo-goal-target-sym g) '(extractor refinery assimilator))
                   (not (gas-building-cap-ok? (count-total-bldg (pro-bo-goal-target-sym g)) active-bases))))
         (not (and (eq? (pro-bo-goal-kind g) 'train)
                   (>= supply-used (+ (pro-bo-goal-min-supply g) 12))))
         (not (and (eq? race 'Protoss)
                   (eq? (pro-bo-goal-target-sym g) 'assimilator)
                   (>= (pro-bo-goal-target-count g) 2)
                   (or (and (eq? enemy-race 'Random)
                            (< (count-total-bldg 'gateway) 2))
                       (and (not (eq? m-sym 'PvP))
                            (< (count-total-bldg 'nexus) 2)))))))

  (define steps (pro-build-order-steps-for-matchup race enemy-race))
  (define extra-timing-goals
    (if (> frame 0)
        (append
         (map pro-upgrade-timing->bo-goal
              (due-pro-upgrade-timings race enemy-race frame supply-used))
         (map pro-unit-timing->bo-goal
              (due-pro-unit-timings race enemy-race frame supply-used)))
        '()))
  (define rem-min (safe-nonneg-int raw-minerals 0))
  (define rem-gas (safe-nonneg-int raw-gas 0))
  (define rem-sup (max 0 (safe-exact-int raw-supply-left 0)))
  (define ready-acts '())
  (define queued-keys (make-hash))
  (define first-ready-head #f)
  (define first-blocked-head #f)
  (define res-min 0)
  (define res-gas 0)

  (define (process-bo-goal! g)
    (define sym (pro-bo-goal-target-sym g))
    (define kind (pro-bo-goal-kind g))
    (define gkey (cons kind sym))
    (unless (hash-has-key? queued-keys gkey)
      (define m-cost (sc2-min-cost sym))
      (define g-cost (sc2-gas-cost sym))
      (define s-cost (if (eq? kind 'train) (sc2-supply-cost sym 0) 0))
      (define pre-ok? (prereq-ready? (pro-bo-goal-prereq-ready-sym g)))
      (cond
        [(and (eq? kind 'train) (> s-cost rem-sup))
         ;; Do not reserve or stall BO head on a supply-blocked unit step
         (void)]
        [(and pre-ok?
              (>= (- rem-min res-min) m-cost)
              (>= (- rem-gas res-gas) g-cost)
              (or (<= s-cost 0) (>= rem-sup s-cost))
              ;; Only emit at most 2 build/research/expand actions per frame from BO queue
              (< (length ready-acts) 2))
         (set! rem-min (- rem-min m-cost))
         (set! rem-gas (- rem-gas g-cost))
         (set! rem-sup (- rem-sup s-cost))
         (hash-set! queued-keys gkey #t)
         (set! ready-acts (cons (goal->action g) ready-acts))
         (unless first-ready-head (set! first-ready-head g))]
        [pre-ok?
         ;; Prerequisite is ready, but waiting on resources -> reserve minerals/gas for first waiting ready step
         (unless first-ready-head
           (set! first-ready-head g)
           (when (memq kind '(build expand morph research train))
             (set! res-min m-cost)
             (set! res-gas g-cost)))]
        [else
         ;; Prerequisite building is still under construction -> do NOT emit or block worker production;
         ;; only record fallback head if no prerequisite-ready step exists.
         (unless first-blocked-head
           (set! first-blocked-head g))])))

  (for ([g (in-list steps)]
        #:when (goal-eligible-now? g))
    (process-bo-goal! g))

  (for ([g (in-list extra-timing-goals)]
        #:when (and (not (goal-satisfied? g))
                    (not (and (eq? (pro-bo-goal-kind g) 'train)
                              (>= supply-used (+ (pro-bo-goal-min-supply g) 12))))))
    (process-bo-goal! g))

  (define raw-active-head (or first-ready-head first-blocked-head))
  ;; Resolve 'train goals whose structure prerequisite has 0 total buildings (e.g. immortal -> robotics-facility)
  ;; so saving_for / bo-goal-sym points to the missing prerequisite and escrows its resources.
  (define active-head
    (if (and (pro-bo-goal? raw-active-head)
             (eq? (pro-bo-goal-kind raw-active-head) 'train)
             (pro-bo-goal-prereq-ready-sym raw-active-head)
             (= (count-total-bldg (pro-bo-goal-prereq-ready-sym raw-active-head)) 0))
        (let* ([prereq-sym (pro-bo-goal-prereq-ready-sym raw-active-head)]
               [prereq-step (findf (lambda (s)
                                     (and (memq (pro-bo-goal-kind s) '(build expand morph))
                                          (eq? (pro-bo-goal-target-sym s) prereq-sym)))
                                   steps)])
          (or prereq-step
              (pro-bo-goal 'build prereq-sym 1
                           (pro-bo-goal-min-supply raw-active-head)
                           #f
                           (pro-bo-goal-target-sec raw-active-head))))
        raw-active-head))
  (when (and (not (eq? active-head raw-active-head))
             (pro-bo-goal? active-head)
             (= res-min 0)
             (= res-gas 0)
             (prereq-ready? (pro-bo-goal-prereq-ready-sym active-head)))
    (set! res-min (sc2-min-cost (pro-bo-goal-target-sym active-head)))
    (set! res-gas (sc2-gas-cost (pro-bo-goal-target-sym active-head))))
  (define release-bo-tech-reserve?
    (and (>= (safe-nonneg-int raw-minerals 0) 600)
         (>= (max 0 (safe-exact-int raw-supply-left 0)) 2)
         (pro-bo-goal? active-head)
         (or (memq (pro-bo-goal-kind active-head) '(morph research))
             (and (eq? (pro-bo-goal-kind active-head) 'build)
                  (not (memq (pro-bo-goal-target-sym active-head)
                             '(overlord pylon supply-depot hatchery command-center nexus)))))))
  (pro-bo-eval-result m-sym
                      active-head
                      (reverse ready-acts)
                      (if release-bo-tech-reserve? 0 (safe-nonneg-int res-min 0))
                      (if release-bo-tech-reserve? 0 (safe-nonneg-int res-gas 0))
                      (safe-nonneg-int target-workers 22)
                      target-army))

;; =============================================================================
;; 11. Decoupled 8-Stream Resource & Bank Manager + 200/200 Max-Supply Manager
;; =============================================================================

(define DEC-GOAL-STREAMS
  '(workers
    supply
    expansion
    tech
    upgrades
    production-facilities
    static-defense
    army))

(struct race-bank-target
  (race
   target-minerals
   target-gas
   surge-kind
   trigger-reason
   active?)
  #:transparent)

(struct stream-budget-slice
  (stream
   weight-min
   weight-gas
   allocated-minerals
   allocated-gas
   reserved-minerals
   reserved-gas
   active-goal-sym
   blocked-by-prereq?)
  #:transparent)

(struct decoupled-bank-allocation
  (race
   frame
   total-minerals
   total-gas
   bank-target
   slices-by-stream
   hard-reserved-minerals
   hard-reserved-gas
   spendable-by-stream)
  #:transparent)

(struct max-supply-plan
  (active?
   overcap-target-supply
   fist-of-neeb-actions
   spore-trick-actions
   cheap-unit-sack-actions
   combined-actions
   reason)
  #:transparent)

(define (compute-bank-targets
         #:race [raw-race 'Zerg]
         #:frame [raw-frame 0]
         #:minerals [raw-minerals 0]
         #:gas [raw-gas 0]
         #:supply-used [raw-supply-used 12]
         #:supply-cap [raw-supply-cap 15]
         #:workers [raw-workers 12]
         #:active-bases [raw-bases 1]
         #:larva-count [raw-larva 3]
         #:warpgate-count [raw-warpgates 0]
         #:production-facility-count [raw-prod-facs 1]
         #:ready-buildings [raw-ready-bldgs '()]
         #:in-progress-buildings [raw-pending-bldgs '()]
         #:open-production-slots [raw-open-slots #f]
         #:in-progress-max-progress [raw-tech-progress #f]
         #:under-attack? [under-attack? #f])
  (define race (normalize-ledger-race raw-race))
  (define supply-used (safe-nonneg-int raw-supply-used 12))
  (define workers (safe-nonneg-int raw-workers 12))
  (define bases (max 1 (safe-nonneg-int raw-bases 1)))
  (define larva-cnt (safe-nonneg-int raw-larva 0))
  (define wg-cnt (safe-nonneg-int raw-warpgates 0))
  (define prod-cnt (safe-nonneg-int raw-prod-facs 1))
  (define ready-syms (if (list? raw-ready-bldgs) (filter symbol? raw-ready-bldgs) '()))
  (define pending-syms (if (list? raw-pending-bldgs) (filter symbol? raw-pending-bldgs) '()))
  (define has-open-prod-slots?
    (and (exact-integer? raw-open-slots) (> raw-open-slots 0)))
  (define tech-progress-scale
    (if (and (real? raw-tech-progress)
             (not (nan? raw-tech-progress))
             (not (infinite? raw-tech-progress))
             (< raw-tech-progress 0.55))
        (max 0.25 (exact->inexact raw-tech-progress))
        1.0))
  (define (scale-tech-surge v)
    (if (< tech-progress-scale 1.0)
        (exact-round (* v tech-progress-scale))
        v))

  (cond
    ;; Never hold macro bank when fighting a survival crisis below late-game max-out
    [(and under-attack? (< supply-used 185))
     (race-bank-target race 0 0 'emergency-spend-all 'under-attack-crisis #f)]
    [(< workers 12)
     (race-bank-target race 0 0 'worker-recovery 'critical-worker-deficit #f)]

    ;; Zerg: Larva-surge & Spire / Hive tech-switch morph banking
    [(eq? race 'Zerg)
     (cond
       [(or (memq 'spire pending-syms)
            (memq 'greater-spire pending-syms)
            (and (or (memq 'spire ready-syms) (memq 'greater-spire ready-syms))
                 (>= larva-cnt 5)))
        (define eff-l (max 4 (min 8 (if (> larva-cnt 0) larva-cnt 6))))
        (define spire-ready? (or (memq 'spire ready-syms) (memq 'greater-spire ready-syms)))
        (define raw-m (* eff-l 100))
        (define raw-g (* eff-l 100))
        (race-bank-target race
                          (if spire-ready? raw-m (scale-tech-surge raw-m))
                          (if spire-ready? raw-g (scale-tech-surge raw-g))
                          'zerg-muta-corruptor-larva-surge
                          'spire-morph-wave
                          #t)]
       [(or (memq 'ultralisk-cavern pending-syms)
            (memq 'lurker-den pending-syms)
            (memq 'lurker-den-mp pending-syms)
            (and (or (memq 'ultralisk-cavern ready-syms)
                     (memq 'lurker-den ready-syms)
                     (memq 'lurker-den-mp ready-syms))
                 (>= larva-cnt 4)
                 (>= supply-used 100)))
        (define eff-l (max 3 (min 6 (if (> larva-cnt 0) larva-cnt 4))))
        (define hive-tech-ready?
          (or (memq 'ultralisk-cavern ready-syms)
              (memq 'lurker-den ready-syms)
              (memq 'lurker-den-mp ready-syms)))
        (define raw-m (* eff-l 150))
        (define raw-g (* eff-l 100))
        (race-bank-target race
                          (if hive-tech-ready? raw-m (scale-tech-surge raw-m))
                          (if hive-tech-ready? raw-g (scale-tech-surge raw-g))
                          'zerg-hive-splash-larva-surge
                          'hive-tech-switch-wave
                          #t)]
       [(and (>= larva-cnt 6) (>= bases 2) (>= supply-used 40))
        (define eff-l (min 12 larva-cnt))
        (race-bank-target race (* eff-l 75) (* eff-l 25)
                          'zerg-inject-larva-surge
                          'pooled-inject-larva-batch
                          #t)]
       [else
        (race-bank-target race 0 0 'none 'steady-macro-spend #f)])]

    ;; Terran: Production-wave cycle sync & capital transition banking
    [(eq? race 'Terran)
     (cond
       [(or (memq 'fusion-core pending-syms)
            (and (memq 'fusion-core ready-syms)
                 (>= supply-used 110)
                 (or (not has-open-prod-slots?) (>= supply-used 160))))
        (define fc-ready? (not (not (memq 'fusion-core ready-syms))))
        (race-bank-target race
                          (if fc-ready? 400 (scale-tech-surge 400))
                          (if fc-ready? 300 (scale-tech-surge 300))
                          'terran-capital-wave-sync
                          'battlecruiser-liberator-wave
                          #t)]
       [(and (>= prod-cnt 3)
             (>= supply-used 48)
             (or (not has-open-prod-slots?) (>= supply-used 160)))
        (define eff-p (min 8 prod-cnt))
        (race-bank-target race (* eff-p 100) (* eff-p 50)
                          'terran-production-wave-sync
                          'multi-facility-cycle-sync
                          #t)]
       [else
        (race-bank-target race 0 0 'none 'steady-macro-spend #f)])]

    ;; Protoss: Warp-Gate cooldown batching & Robotics/Fleet capital surge banking
    [else
     (define capital-in-progress?
       (or (memq 'fleet-beacon pending-syms)
           (memq 'robotics-bay pending-syms)
           (memq 'robotics-support-bay pending-syms)
           (memq 'templar-archive pending-syms)
           (memq 'templar-archives pending-syms)))
     (define capital-ready?
       (or (memq 'fleet-beacon ready-syms)
           (memq 'robotics-bay ready-syms)
           (memq 'robotics-support-bay ready-syms)
           (memq 'templar-archive ready-syms)
           (memq 'templar-archives ready-syms)))
     (cond
       [(or capital-in-progress?
            (and capital-ready?
                 (>= supply-used 100)
                 (not has-open-prod-slots?)))
        (define eff-wg (max 3 (min 8 wg-cnt)))
        (define raw-m (+ 200 (* eff-wg 100)))
        (define raw-g 300)
        (race-bank-target race
                          (if capital-ready? raw-m (scale-tech-surge raw-m))
                          (if capital-ready? raw-g (scale-tech-surge raw-g))
                          'protoss-capital-warpgate-batch
                          'capital-splash-and-warpin-batch
                          #t)]
       [(and (>= wg-cnt 3)
             (>= supply-used 38)
             (not has-open-prod-slots?))
        (define eff-wg (min 10 wg-cnt))
        (race-bank-target race (* eff-wg 100) (* eff-wg 50)
                          'protoss-warpgate-cycle-batch
                          'warpgate-cooldown-batch
                          #t)]
       [else
        (race-bank-target race 0 0 'none 'steady-macro-spend #f)])]))

(define (allocate-decoupled-goal-streams
         #:race [raw-race 'Zerg]
         #:frame [raw-frame 0]
         #:minerals [raw-minerals 0]
         #:gas [raw-gas 0]
         #:supply-used [raw-supply-used 12]
         #:supply-cap [raw-supply-cap 15]
         #:pending-supply [raw-pending-sup 0]
         #:workers [raw-workers 12]
         #:active-bases [raw-bases 1]
         #:gas-harvesters [raw-gas-harv 3]
         #:under-attack? [under-attack? #f]
         #:wants-expand? [wants-expand? #f]
         #:tech-goal-sym [tech-goal-sym #f]
         #:tech-prereq-ready? [tech-prereq-ready? #t]
         #:upgrade-goal-sym [upgrade-goal-sym #f]
         #:upgrade-prereq-ready? [upgrade-prereq-ready? #t]
         #:open-production-slots [raw-open-slots #f]
         #:larva-count [raw-larva-cnt 0]
         #:warpgate-count [raw-wg-cnt 0]
         #:production-facility-count [raw-prod-cnt 0]
         #:ready-buildings [raw-ready-bldgs '()]
         #:in-progress-buildings [raw-in-prog-bldgs '()]
         #:in-progress-max-progress [raw-tech-progress #f]
         #:bank-target [explicit-bank-target #f])
  (define race (normalize-ledger-race raw-race))
  (define frame (safe-nonneg-int raw-frame 0))
  (define minerals (safe-nonneg-int raw-minerals 0))
  (define gas (safe-nonneg-int raw-gas 0))
  (define supply-used (safe-nonneg-int raw-supply-used 12))
  (define supply-cap (max 1 (safe-nonneg-int raw-supply-cap 15)))
  (define supply-left (- supply-cap supply-used))
  (define pending-sup (safe-nonneg-int raw-pending-sup 0))
  (define workers (safe-nonneg-int raw-workers 12))
  (define bases (max 1 (safe-nonneg-int raw-bases 1)))
  (define gas-harv (safe-nonneg-int raw-gas-harv 0))

  (define btarget
    (if (race-bank-target? explicit-bank-target)
        explicit-bank-target
        (compute-bank-targets
         #:race race
         #:frame frame
         #:minerals minerals
         #:gas gas
         #:supply-used supply-used
         #:supply-cap supply-cap
         #:workers workers
         #:active-bases bases
         #:larva-count raw-larva-cnt
         #:warpgate-count raw-wg-cnt
         #:production-facility-count raw-prod-cnt
         #:ready-buildings raw-ready-bldgs
         #:in-progress-buildings raw-in-prog-bldgs
         #:open-production-slots raw-open-slots
         #:in-progress-max-progress raw-tech-progress
         #:under-attack? under-attack?)))

  (define ideal-workers (min 80 (* 22 bases)))
  (define need-workers? (< workers ideal-workers))
  (define need-supply? (and (< supply-cap 200) (<= (+ supply-left pending-sup) 4)))
  (define critical-supply? (and (< supply-cap 200) (<= supply-left 2) (= pending-sup 0)))
  (define need-static-def? (or under-attack? (>= supply-used 190)))

  ;; Decoupled Non-Blocking Prerequisite & Gas-Feasibility Gate:
  ;; If a tech or upgrade goal has unready prerequisites OR requires gas we do not have
  ;; while 0 gas harvesters are active, mark it blocked so it reserves 0 minerals!
  (define tech-min-cost (if (symbol? tech-goal-sym) (sc2-min-cost tech-goal-sym) 0))
  (define tech-gas-cost (if (symbol? tech-goal-sym) (sc2-gas-cost tech-goal-sym) 0))
  (define tech-blocked?
    (and (symbol? tech-goal-sym)
        (or (not tech-prereq-ready?)
            (and (> tech-gas-cost gas) (= gas-harv 0)))))

  (define upg-min-cost (if (symbol? upgrade-goal-sym) (sc2-min-cost upgrade-goal-sym) 0))
  (define upg-gas-cost (if (symbol? upgrade-goal-sym) (sc2-gas-cost upgrade-goal-sym) 0))
  (define upg-blocked?
    (and (symbol? upgrade-goal-sym)
        (or (not upgrade-prereq-ready?)
            (and (> upg-gas-cost gas) (= gas-harv 0)))))

  ;; Raw priority weights across all 8 streams (`DEC-GOAL-STREAMS`)
  (define raw-min-weights
    (hasheq 'workers               (cond [(< workers 12) 0.45] [need-workers? 0.22] [else 0.03])
            'supply                (cond [critical-supply? 0.35] [need-supply? 0.16] [else 0.04])
            'expansion             (cond [(and wants-expand? (not under-attack?)) 0.28] [else 0.08])
            'tech                  (cond [tech-blocked? 0.02] [(symbol? tech-goal-sym) 0.14] [else 0.08])
            'upgrades              (cond [upg-blocked? 0.02] [(symbol? upgrade-goal-sym) 0.10] [else 0.07])
            'production-facilities (cond [(>= minerals 450) 0.18] [else 0.10])
            'static-defense        (cond [under-attack? 0.20] [(>= supply-used 190) 0.24] [else 0.04])
            'army                  (cond [under-attack? 0.42] [else 0.28])))

  (define raw-gas-weights
    (hasheq 'workers               0.00
            'supply                0.00
            'expansion             0.00
            'tech                  (cond [tech-blocked? 0.02] [(symbol? tech-goal-sym) 0.32] [else 0.22])
            'upgrades              (cond [upg-blocked? 0.02] [(symbol? upgrade-goal-sym) 0.28] [else 0.20])
            'production-facilities 0.08
            'static-defense        0.02
            'army                  (if under-attack? 0.65 0.48)))

  (define sum-mw (max 0.001 (for/sum ([s (in-list DEC-GOAL-STREAMS)]) (hash-ref raw-min-weights s 0.0))))
  (define sum-gw (max 0.001 (for/sum ([s (in-list DEC-GOAL-STREAMS)]) (hash-ref raw-gas-weights s 0.0))))

  ;; Hard crisis/macro mineral & gas reserves (strictly decoupled!)
  (define res-supply-min (if critical-supply? 100 0))
  (define res-worker-min (if (and need-workers? (not under-attack?)) 50 0))
  (define exp-cost (case race [(Zerg) 300] [else 400]))
  (define res-expand-min (if (and wants-expand? (not under-attack?) (not critical-supply?)) exp-cost 0))
  (define res-def-min (if (and under-attack? (< supply-used 60)) 100 0))
  (define high-bank-tech-bypass? (and (>= minerals 600) (>= supply-left 2)))
  (define res-tech-min
    (if (and (symbol? tech-goal-sym)
             (not tech-blocked?)
             (not under-attack?)
             (not high-bank-tech-bypass?))
        (min 200 tech-min-cost)
        0))
  (define res-tech-gas
    (if (and (symbol? tech-goal-sym)
             (not tech-blocked?)
             (not under-attack?)
             (not high-bank-tech-bypass?))
        tech-gas-cost
        0))
  (define res-upg-gas
    (if (and (symbol? upgrade-goal-sym)
             (not upg-blocked?)
             (not under-attack?)
             (not high-bank-tech-bypass?))
        upg-gas-cost
        0))

  ;; Survival-only mineral floor (`supply`, `workers`, `expansion`, `static-defense`).
  ;; Non-survival streams (`tech`, `upgrades`, `army`, `production-facilities`) NEVER subtract
  ;; `res-tech-min` from `hard-res-min`!
  (define hard-res-min (+ res-supply-min res-worker-min res-expand-min res-def-min))
  (define hard-res-gas (+ res-tech-gas res-upg-gas))

  (define tech-cross-ready?
    (and (symbol? tech-goal-sym)
         (not tech-blocked?)
         (not under-attack?)
         (or (= tech-gas-cost 0)
             (>= gas (- tech-gas-cost (* 12 gas-harv))))))
  (define soft-tech-res-min
    (if tech-cross-ready? (min 200 tech-min-cost) 0))
  (define army-tech-res-min
    (if (and tech-cross-ready?
             (or (= tech-gas-cost 0)
                 (>= gas (- tech-gas-cost 30))))
        soft-tech-res-min
        0))

  (define slices-ht
    (for/hasheq ([s (in-list DEC-GOAL-STREAMS)])
      (define wm (/ (hash-ref raw-min-weights s 0.0) sum-mw))
      (define wg (/ (hash-ref raw-gas-weights s 0.0) sum-gw))
      (define alloc-m (exact-round (* wm minerals)))
      (define alloc-g (exact-round (* wg gas)))
      (define r-m
        (case s
          [(supply) res-supply-min]
          [(workers) res-worker-min]
          [(expansion) res-expand-min]
          [(static-defense) res-def-min]
          [(tech) res-tech-min]
          [else 0]))
      (define r-g
        (case s
          [(tech) res-tech-gas]
          [(upgrades) res-upg-gas]
          [else 0]))
      (define g-sym
        (case s
          [(workers) (case race [(Zerg) 'drone] [(Terran) 'scv] [else 'probe])]
          [(supply) (case race [(Zerg) 'overlord] [(Terran) 'supply-depot] [else 'pylon])]
          [(expansion) (case race [(Zerg) 'hatchery] [(Terran) 'command-center] [else 'nexus])]
          [(tech) tech-goal-sym]
          [(upgrades) upgrade-goal-sym]
          [else #f]))
      (define blk?
        (case s
          [(tech) tech-blocked?]
          [(upgrades) upg-blocked?]
          [else #f]))
      (values s (stream-budget-slice s wm wg alloc-m alloc-g r-m r-g g-sym blk?))))

  (define spendable-ht
    (for/hasheq ([s (in-list DEC-GOAL-STREAMS)])
      ;; Survival streams (`supply`, `workers`, `static-defense`, `expansion`) spend against upstream survival floors;
      ;; downstream streams (`tech`, `army`, `production-facilities`, `upgrades`) always respect `hard-res-min`,
      ;; and lower-priority `production-facilities`/`upgrades` also respect `soft-tech-res-min` when tech is cross-resource ready.
      (define other-hard-min
        (case s
          [(supply) 0]
          [(workers) res-supply-min]
          [(static-defense) res-supply-min]
          [(expansion) (+ res-supply-min res-def-min)]
          [(tech) hard-res-min]
          [(army) (+ hard-res-min army-tech-res-min)]
          [(production-facilities upgrades) (+ hard-res-min soft-tech-res-min)]
          [else hard-res-min]))
      (define other-hard-gas
        (case s
          [(tech) 0]
          [(upgrades) res-tech-gas]
          [(army)
           (cond
             [under-attack? 0]
             [(< gas (+ res-tech-gas res-upg-gas)) (max res-tech-gas res-upg-gas)]
             [else (+ res-tech-gas res-upg-gas)])]
          [else hard-res-gas]))
      (values s (cons (max 0 (- minerals other-hard-min))
                      (max 0 (- gas other-hard-gas))))))

  (decoupled-bank-allocation
   race
   frame
   minerals
   gas
   btarget
   slices-ht
   hard-res-min
   hard-res-gas
   spendable-ht))

(define (decoupled-stream-can-spend? alloc stream-sym min-cost [gas-cost 0])
  (cond
    [(not (decoupled-bank-allocation? alloc)) #f]
    [else
     (define sl (hash-ref (decoupled-bank-allocation-slices-by-stream alloc) stream-sym #f))
     (define sp (hash-ref (decoupled-bank-allocation-spendable-by-stream alloc) stream-sym '(0 . 0)))
     (and sl
          (not (stream-budget-slice-blocked-by-prereq? sl))
          (>= (car sp) (safe-nonneg-int min-cost 0))
          (>= (cdr sp) (safe-nonneg-int gas-cost 0)))]))

(define extract-record-sym unit-type-sym)

(define (evaluate-max-supply-manager
         #:race [raw-race 'Zerg]
         #:minerals [raw-minerals 0]
         #:gas [raw-gas 0]
         #:supply-used [raw-supply-used 0]
         #:supply-cap [raw-supply-cap 200]
         #:workers [raw-workers 0]
         #:active-bases [raw-bases 1]
         #:ally-units [raw-ally-units '()]
         #:ally-buildings [raw-ally-bldgs '()]
         #:base-x [raw-base-x 32.5]
         #:base-y [raw-base-y 32.5]
         #:nat-x [raw-nat-x 50.5]
         #:nat-y [raw-nat-y 50.5]
         #:third-x [raw-third-x 68.5]
         #:third-y [raw-third-y 50.5]
         #:enemy-x [raw-enemy-x 160.5]
         #:enemy-y [raw-enemy-y 160.5])
  (define race (normalize-ledger-race raw-race))
  (define minerals (safe-nonneg-int raw-minerals 0))
  (define gas (safe-nonneg-int raw-gas 0))
  (define supply-used (safe-nonneg-int raw-supply-used 0))
  (define supply-cap (max 1 (safe-nonneg-int raw-supply-cap 200)))
  (define workers (safe-nonneg-int raw-workers 0))
  (define ally-units (if (list? raw-ally-units) raw-ally-units '()))
  (define ally-bldgs (if (list? raw-ally-bldgs) raw-ally-bldgs '()))
  (define base-x (safe-tile-coord raw-base-x 32.5))
  (define base-y (safe-tile-coord raw-base-y 32.5))
  (define third-x (safe-tile-coord raw-third-x 68.5))
  (define third-y (safe-tile-coord raw-third-y 50.5))
  (define enemy-x (safe-tile-coord raw-enemy-x 160.5))
  (define enemy-y (safe-tile-coord raw-enemy-y 160.5))

  (define active-bases (max 1 (safe-nonneg-int raw-bases 1)))
  (define static-def-cap (min 12 (* 2 active-bases)))
  (define existing-static-def-count
    (count (lambda (b)
             (memq (extract-record-sym b)
                   '(photon-cannon shield-battery missile-turret bunker spine-crawler spore-crawler)))
           ally-bldgs))

  (define has-pending-spore-overcap?
    (and (eq? race 'Zerg)
         (>= supply-used 198)
         (>= supply-cap 198)
         (ormap (lambda (b)
                  (and (hash? b)
                       (eq? (extract-record-sym b) 'spore-crawler)
                       (let ([bp (hash-ref b 'build-progress 1.0)]
                             [bid (hash-ref b 'id 0)])
                         (and (real? bp) (< bp 0.95) (exact-integer? bid) (> bid 0)))))
                ally-bldgs)))

  (define maxed-window?
    (or has-pending-spore-overcap?
        (and (>= supply-cap 198)
             (>= supply-used 194)
             (or (>= minerals 350) (>= gas 300)))))

  (cond
    [(not maxed-window?)
     (max-supply-plan #f supply-cap '() '() '() '() 'below-max-supply-threshold)]
    [else
     (define ready-bldg-syms
       (for/list ([b (in-list ally-bldgs)]
                  #:when (or (symbol? b)
                             (and (hash? b)
                                  (let ([bp (hash-ref b 'build-progress 1.0)]
                                        [bsym (extract-record-sym b)])
                                    (and (or (not (real? bp)) (>= bp 0.99))
                                         (or (not (sc2-structure-requires-pylon-power? bsym))
                                             (not (eq? (hash-ref b 'powered? #t) #f))))))))
         (extract-record-sym b)))
     (define has-bldg-info? (not (null? ally-bldgs)))
     (define (bldg-ready-or-assumed? sym)
       (or (not has-bldg-info?)
           (not (not (memq sym ready-bldg-syms)))))

     ;; Check for Phase B Spore overcap cancellations up front so `neeb-acts` never
     ;; rebuilds a Spore Crawler on the same frame that `spore-acts` cancels Spores.
     (define pending-spores
       (filter (lambda (b)
                 (and (hash? b)
                      (eq? (extract-record-sym b) 'spore-crawler)
                      (let ([bp (hash-ref b 'build-progress 1.0)]
                            [bid (hash-ref b 'id 0)])
                        (and (real? bp) (< bp 0.95) (exact-integer? bid) (> bid 0)))))
               ally-bldgs))
     (define cancelling-pending-spores?
       (and (eq? race 'Zerg) (>= supply-used 198) (not (null? pending-spores))))

     ;; 1. Fist of Neeb: Convert surplus late-game mineral bank (>= 600M at >= 194/200)
     ;;    into 0-supply forward static defense batteries / Planetary Fortresses,
     ;;    strictly capped at `<= (min 12 (* 2 active-bases))` total static defense!
     (define def-x third-x)
     (define def-y third-y)
     (define def-x2 (safe-tile-coord (min 248.0 (+ def-x 2.0)) def-x))
     (define under-static-def-cap? (< existing-static-def-count static-def-cap))
     (define neeb-acts
       (cond
         [(< minerals 600) '()]
         [(eq? race 'Protoss)
          (if (not under-static-def-cap?)
              '()
              (let ([p1 (if (bldg-ready-or-assumed? 'forge)
                            (list (list 'build 'photon-cannon def-x def-y))
                            (list (list 'build 'pylon def-x def-y)))]
                    [p2 (if (and (>= minerals 750)
                                 (< (add1 existing-static-def-count) static-def-cap)
                                 (bldg-ready-or-assumed? 'cybernetics-core))
                            (list (list 'build 'shield-battery def-x2 def-y))
                            '())])
                (append p1 p2)))]
         [(eq? race 'Terran)
          (define t1
            (if (and under-static-def-cap? (bldg-ready-or-assumed? 'engineering-bay))
                (list (list 'build 'missile-turret def-x def-y))
                '()))
          (define t2
            (cond
              [(and (>= minerals 900)
                    (bldg-ready-or-assumed? 'engineering-bay)
                    (memq 'command-center ready-bldg-syms))
               (list '(morph planetary-fortress))]
              [(and (>= minerals 750)
                    (< (+ existing-static-def-count (length t1)) static-def-cap)
                    (bldg-ready-or-assumed? 'barracks))
               (list (list 'build 'bunker def-x2 def-y))]
              [else '()]))
          (append t1 t2)]
         [else ;; Zerg
          (if (and under-static-def-cap? (bldg-ready-or-assumed? 'spawning-pool))
              (append (list (list 'build 'spine-crawler def-x def-y))
                      (if (or cancelling-pending-spores?
                              (>= (add1 existing-static-def-count) static-def-cap))
                          '()
                          (list (list 'build 'spore-crawler def-x2 def-y))))
              '())]))

     ;; 2. Zerg Spore Crawler Trick (`204/200` Supply Overcap):
     ;;    - If temporary in-progress `spore-crawler`s exist while `supply-used >= 198`,
     ;;      cancel them (`cancel-building`) to pop units above the 200/200 cap (`202..204/200`)!
     ;;    - Otherwise at `198..200 / 200` with `minerals >= 350` and Pool ready, morph temporary
     ;;      Spores to dip to `196..198/200` and queue high-tier units into the freed supply!
     (define zerg-overcap-unit
       (cond
         [(and (bldg-ready-or-assumed? 'ultralisk-cavern) (>= gas 200)) 'ultralisk]
         [(and (or (bldg-ready-or-assumed? 'spire) (bldg-ready-or-assumed? 'greater-spire)) (>= gas 150)) 'corruptor]
         [(bldg-ready-or-assumed? 'roach-warren) 'roach]
         [else 'drone]))
     (define spore-acts
       (cond
         [(not (eq? race 'Zerg)) '()]
         [cancelling-pending-spores?
          (for/list ([sp (in-list (take pending-spores (min 4 (length pending-spores))))])
            (list 'cancel-building (hash-ref sp 'id)))]
         [(and (>= supply-used 198)
               (>= supply-cap 200)
               (>= minerals 350)
               (< existing-static-def-count (+ static-def-cap 2))
               (bldg-ready-or-assumed? 'spawning-pool))
          (define sx1 (safe-tile-coord (min 248.0 (+ base-x 2.0)) base-x))
          (define sy1 (safe-tile-coord (min 248.0 (+ base-y 2.0)) base-y))
          (define sx2 (safe-tile-coord (min 248.0 (+ base-x 4.0)) base-x))
          (list (list 'build 'spore-crawler sx1 sy1)
                (list 'build 'spore-crawler sx2 sy1)
                (list 'train zerg-overcap-unit))]
         [else '()]))

     (define overcap-target
       (if (and (eq? race 'Zerg) (not (null? spore-acts)))
           204
           supply-cap))

     ;; 3. Cheap-Unit Sack / Supply Trading:
     ;;    At >= 196/200 supply with high bank (>= 700M & >= 350G), send up to 4 low-tier
     ;;    supply-inefficient combat units (or surplus workers > 68) on an immediate runby
     ;;    trade (`attack-pos`) so freed supply refills with high-tier capital/splash units!
     (define cheap-tier-syms
       (case race
         [(Zerg)    '(zergling roach)]
         [(Terran)  '(marine hellion reaper)]
         [else      '(zealot adept)]))
     (define worker-sym
       (case race [(Zerg) 'drone] [(Terran) 'scv] [else 'probe]))
     (define sack-candidates
       (if (and (>= supply-used 196) (>= minerals 700) (>= gas 350))
           (let ([low-combat
                  (filter (lambda (u)
                            (and (hash? u)
                                 (memq (extract-record-sym u) cheap-tier-syms)
                                 (let ([uid (hash-ref u 'id 0)])
                                   (and (exact-integer? uid) (> uid 0)))))
                          ally-units)]
                 [surplus-workers
                  (if (> workers 68)
                      (filter (lambda (u)
                                (and (hash? u)
                                     (eq? (extract-record-sym u) worker-sym)
                                     (not (eq? (hash-ref u 'has-build-order? #f) #t))
                                     (let ([uid (hash-ref u 'id 0)])
                                       (and (exact-integer? uid) (> uid 0)))))
                              ally-units)
                      '())])
             (append low-combat surplus-workers))
           '()))
     (define sack-acts
       (for/list ([u (in-list (take sack-candidates (min 4 (length sack-candidates))))])
         (list 'attack-pos (hash-ref u 'id) enemy-x enemy-y)))

     (define combined
       (append spore-acts neeb-acts sack-acts))
     (define active-now? (not (null? combined)))
     (max-supply-plan
      active-now?
      overcap-target
      neeb-acts
      spore-acts
      sack-acts
      combined
      (if active-now? 'max-supply-conversion-active 'max-supply-idle))]))
