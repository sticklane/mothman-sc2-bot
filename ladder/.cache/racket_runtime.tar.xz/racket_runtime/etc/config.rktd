#hash((build-stamp . "") (catalogs . ("https://download.racket-lang.org/releases/8.15/catalog/" #f)) (doc-search-url . "https://download.racket-lang.org/releases/8.15/doc/local-redirect/index.html"))
