((root (#"pkgs" #"base"))
 (root (#"pkgs" #"racket-lib")))
